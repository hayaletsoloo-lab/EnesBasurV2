/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.command.CommandSource
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import org.jetbrains.annotations.NotNull;
import thunder.hack.features.cmd.Command;

public class CalcCommand
extends Command {
    public CalcCommand() {
        super("calc");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(CalcCommand.arg("count", StringArgumentType.string()).executes(context -> {
            String expression = (String)context.getArgument("count", String.class);
            try {
                CalcCommand.sendMessage(CalcCommand.evaluateExpression(expression));
                return 1;
            }
            catch (Exception e) {
                CalcCommand.sendMessage("Try use operators: + - m(*) d(/)");
                return -1;
            }
        }));
    }

    public static String evaluateExpression(String expression) {
        int operator = 0;
        int operand1 = 0;
        int operand2 = 0;
        for (int i = 0; i < expression.length(); ++i) {
            char ch = expression.charAt(i);
            if (ch != '+' && ch != '-' && ch != 'm' && ch != 'd') continue;
            operator = ch;
            operand1 = Integer.parseInt(expression.substring(0, i));
            operand2 = Integer.parseInt(expression.substring(i + 1));
            break;
        }
        return switch (operator) {
            case 43 -> String.valueOf(operand1 + operand2);
            case 45 -> String.valueOf(operand1 - operand2);
            case 109 -> String.valueOf(operand1 * operand2);
            case 100 -> String.valueOf(operand1 / operand2);
            default -> throw new IllegalArgumentException("Wrong");
        };
    }
}

