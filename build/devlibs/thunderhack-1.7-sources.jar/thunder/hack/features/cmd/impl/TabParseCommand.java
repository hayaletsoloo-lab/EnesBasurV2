/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.client.network.PlayerListEntry
 *  net.minecraft.command.CommandSource
 *  net.minecraft.scoreboard.AbstractTeam
 *  net.minecraft.scoreboard.Team
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.command.CommandSource;
import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import thunder.hack.core.manager.client.ConfigManager;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.client.ClientSettings;

public class TabParseCommand
extends Command {
    public TabParseCommand() {
        super("tabparse");
    }

    @Override
    public void executeBuild(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            String serverIP = "unknown_server";
            if (mc.getNetworkHandler().getServerInfo() != null && TabParseCommand.mc.getNetworkHandler().getServerInfo().address != null) {
                serverIP = TabParseCommand.mc.getNetworkHandler().getServerInfo().address.replace(':', '_');
            }
            String randomSuffix = this.generateRandomString(5);
            File dir = new File(ConfigManager.TABPARSER_FOLDER, serverIP);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            String fileName = serverIP + "-" + new SimpleDateFormat("dd.MM.yyyy").format(new Date()) + "-" + randomSuffix + ".txt";
            File file = new File(dir, fileName);
            try {
                file.createNewFile();
                OutputStreamWriter writer = new OutputStreamWriter((OutputStream)new FileOutputStream(file), StandardCharsets.UTF_8);
                writer.write("========================\n\n");
                writer.write("Server: " + TabParseCommand.mc.getNetworkHandler().getServerInfo().address + "\n");
                writer.write("Date: " + new SimpleDateFormat("dd.MM.yyyy").format(new Date()) + "\n\n");
                writer.write("========================\n\n");
                ArrayList<PlayerListEntry> sortedPlayers = new ArrayList<>(mc.getNetworkHandler().getPlayerList());
                sortedPlayers.sort((player1, player2) -> {
                    String prefix1 = player1.getScoreboardTeam() != null ? player1.getScoreboardTeam().getPrefix().getString() : "";
                    String prefix2 = player2.getScoreboardTeam() != null ? player2.getScoreboardTeam().getPrefix().getString() : "";
                    return prefix2.compareTo(prefix1);
                });
                for (PlayerListEntry entry : sortedPlayers) {
                    writer.write(Team.decorateName((AbstractTeam)entry.getScoreboardTeam(), (Text)Text.literal((String)entry.getProfile().getName())).getString() + "\n");
                }
                writer.close();
                TabParseCommand.sendMessage(ClientSettings.isRu() ? String.valueOf(Formatting.GREEN) + "\u0422\u0430\u0431 \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d \u0432 " + file.getPath() : String.valueOf(Formatting.GREEN) + "Tab was successfully saved in " + file.getPath());
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return 1;
        });
    }

    private String generateRandomString(int length) {
        char[] chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; ++i) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        return sb.toString();
    }

    private String getPlayerPrefix(PlayerListEntry playerInfo) {
        return playerInfo.getDisplayName() != null ? playerInfo.getDisplayName().getString() : "";
    }
}

