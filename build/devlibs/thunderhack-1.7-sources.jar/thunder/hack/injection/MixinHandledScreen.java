/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.block.ShulkerBoxBlock
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.gui.screen.ingame.HandledScreen
 *  net.minecraft.client.gui.screen.ingame.ScreenHandlerProvider
 *  net.minecraft.client.render.DiffuseLighting
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.ContainerComponent
 *  net.minecraft.component.type.MapIdComponent
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.BlockItem
 *  net.minecraft.item.FilledMapItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.map.MapState
 *  net.minecraft.screen.ScreenHandler
 *  net.minecraft.screen.slot.Slot
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.text.Text
 *  net.minecraft.world.World
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.ScreenHandlerProvider;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.component.type.MapIdComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FilledMapItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.map.MapState;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.core.Core;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.Timer;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

@Mixin(value={HandledScreen.class})
public abstract class MixinHandledScreen<T extends ScreenHandler>
extends Screen
implements ScreenHandlerProvider<T> {
    @Unique
    private final Timer delayTimer = new Timer();
    @Unique
    private Runnable postRender;
    @Shadow
    @Nullable
    protected Slot focusedSlot;
    @Shadow
    protected int x;
    @Shadow
    protected int y;
    private static final ItemStack[] ITEMS = new ItemStack[27];
    private Map<Render2DEngine.Rectangle, Integer> clickableRects = new HashMap<Render2DEngine.Rectangle, Integer>();

    protected MixinHandledScreen(Text title) {
        super(title);
    }

    @Shadow
    protected abstract boolean isPointOverSlot(Slot var1, double var2, double var4);

    @Shadow
    protected abstract void onMouseClick(Slot var1, int var2, int var3, SlotActionType var4);

    @Inject(method={"render"}, at={@At(value="HEAD")})
    private void drawScreenHook(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        for (int i1 = 0; i1 < Module.mc.player.currentScreenHandler.slots.size(); ++i1) {
            Slot slot = (Slot)Module.mc.player.currentScreenHandler.slots.get(i1);
            if (!this.isPointOverSlot(slot, mouseX, mouseY) || !slot.isEnabled() || !ModuleManager.itemScroller.isEnabled() || !this.shit() || !this.attack() || !this.delayTimer.passedMs(ModuleManager.itemScroller.delay.getValue().intValue())) continue;
            this.onMouseClick(slot, slot.id, 0, SlotActionType.QUICK_MOVE);
            this.delayTimer.reset();
        }
    }

    private boolean shit() {
        return InputUtil.isKeyPressed((long)MinecraftClient.getInstance().getWindow().getHandle(), (int)340) || InputUtil.isKeyPressed((long)MinecraftClient.getInstance().getWindow().getHandle(), (int)344);
    }

    private boolean attack() {
        return Core.hold_mouse0;
    }

    @Inject(method={"render"}, at={@At(value="TAIL")})
    private void onRender(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (this.focusedSlot == null || this.focusedSlot.getStack().isEmpty() || this.client.player.playerScreenHandler.getCursorStack().isEmpty()) {
            // empty if block
        }
        boolean xOffset = false;
        int yOffset = 20;
        boolean stage = false;
    }

    @Inject(method={"drawSlot(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/screen/slot/Slot;)V"}, at={@At(value="TAIL")})
    protected void drawSlotHook(DrawContext context, Slot slot, CallbackInfo ci) {
    }

    public boolean renderShulkerToolTip(DrawContext context, int offsetX, int offsetY, int mouseX, int mouseY, ItemStack stack) {
        try {
            BlockItem bi;
            ContainerComponent compoundTag = (ContainerComponent)stack.get(DataComponentTypes.CONTAINER);
            if (compoundTag == null) {
                return false;
            }
            float[] colors = new float[]{1.0f, 1.0f, 1.0f};
            Item focusedItem = stack.getItem();
            if (focusedItem instanceof BlockItem && (bi = (BlockItem)focusedItem).getBlock() instanceof ShulkerBoxBlock) {
                try {
                    Color c = new Color(Objects.requireNonNull(ShulkerBoxBlock.getColor((Item)stack.getItem())).getEntityColor());
                    colors = new float[]{(float)c.getRed() / 255.0f, (float)c.getGreen() / 255.0f, (float)c.getRed() / 255.0f, (float)c.getAlpha() / 255.0f};
                }
                catch (NullPointerException npe) {
                    colors = new float[]{1.0f, 1.0f, 1.0f};
                }
            }
            this.draw(context, compoundTag.stream().toList(), offsetX, offsetY, mouseX, mouseY, colors);
        }
        catch (Exception ignore) {
            return false;
        }
        return true;
    }

    @Inject(method={"drawMouseoverTooltip"}, at={@At(value="HEAD")}, cancellable=true)
    private void onDrawMouseoverTooltip(DrawContext context, int x, int y, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (this.focusedSlot == null || this.focusedSlot.getStack().isEmpty() || this.client.player.playerScreenHandler.getCursorStack().isEmpty()) {
            // empty if block
        }
    }

    @Unique
    private void draw(DrawContext context, List<ItemStack> itemStacks, int offsetX, int offsetY, int mouseX, int mouseY, float[] colors) {
        RenderSystem.disableDepthTest();
        GL11.glClear((int)256);
        this.drawBackground(context, offsetX += 8, offsetY -= 82, colors);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        DiffuseLighting.enableGuiDepthLighting();
        int row = 0;
        int i = 0;
        for (ItemStack itemStack : itemStacks) {
            context.drawItem(itemStack, offsetX + 8 + i * 18, offsetY + 7 + row * 18);
            context.drawItemInSlot(Module.mc.textRenderer, itemStack, offsetX + 8 + i * 18, offsetY + 7 + row * 18);
            if (mouseX > offsetX + 8 + i * 18 && mouseX < offsetX + 28 + i * 18 && mouseY > offsetY + 7 + row * 18 && mouseY < offsetY + 27 + row * 18) {
                this.postRender = () -> context.drawTooltip(this.textRenderer, MixinHandledScreen.getTooltipFromItem((MinecraftClient)Module.mc, (ItemStack)itemStack), itemStack.getTooltipData(), mouseX, mouseY);
            }
            if (++i < 9) continue;
            i = 0;
            ++row;
        }
        DiffuseLighting.disableGuiDepthLighting();
        RenderSystem.enableDepthTest();
    }

    private void drawBackground(DrawContext context, int x, int y, float[] colors) {
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor((float)colors[0], (float)colors[1], (float)colors[2], (float)1.0f);
        RenderSystem.texParameter((int)3553, (int)10240, (int)9729);
        RenderSystem.texParameter((int)3553, (int)10241, (int)9987);
        context.drawTexture(TextureStorage.container, x, y, 0.0f, 0.0f, 176, 67, 176, 67);
        RenderSystem.enableBlend();
    }

    private void drawMapPreview(DrawContext context, ItemStack stack, int x, int y) {
        RenderSystem.enableBlend();
        context.getMatrices().push();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        int y1 = y - 12;
        int x1 = x + 8;
        int z = 300;
        MapState mapState = FilledMapItem.getMapState((ItemStack)stack, (World)(Object)this.client.world);
        if (mapState != null) {
            mapState.getPlayerSyncData((PlayerEntity)(Object)this.client.player);
            z = 310;
            double scale = 0.65625;
            context.getMatrices().translate((float)(x1 += 8), (float)(y1 += 8), (float)z);
            context.getMatrices().scale((float)scale, (float)scale, 0.0f);
            VertexConsumerProvider.Immediate consumer = this.client.getBufferBuilders().getEntityVertexConsumers();
            this.client.gameRenderer.getMapRenderer().draw(context.getMatrices(), (VertexConsumerProvider)consumer, (MapIdComponent)stack.get(DataComponentTypes.MAP_ID), mapState, false, 0xF000F0);
        }
        context.getMatrices().pop();
    }

    @Inject(method={"mouseClicked"}, at={@At(value="HEAD")}, cancellable=true)
    private void mouseClicked(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (button == 2 && this.focusedSlot != null && !this.focusedSlot.getStack().isEmpty() && this.client.player.playerScreenHandler.getCursorStack().isEmpty()) {
            ItemStack itemStack = this.focusedSlot.getStack();
        }
        for (Render2DEngine.Rectangle rect : this.clickableRects.keySet()) {
            if (rect.contains(mouseX, mouseY)) continue;
        }
    }
}

