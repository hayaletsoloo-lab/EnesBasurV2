/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$OnGroundOnly
 *  net.minecraft.network.packet.s2c.play.GameJoinS2CPacket
 *  net.minecraft.network.packet.s2c.play.GameMessageS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket
 *  net.minecraft.sound.SoundCategory
 *  net.minecraft.sound.SoundEvents
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec2f
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.core;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec2f;
import org.jetbrains.annotations.NotNull;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.MacroManager;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventDeath;
import thunder.hack.events.impl.EventKeyPress;
import thunder.hack.events.impl.EventMouse;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.gui.notification.Notification;
import thunder.hack.gui.thundergui.ThunderGui;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;
import thunder.hack.utility.render.animation.CaptureMark;

public final class Core {
    public static boolean lockSprint;
    public static boolean serverSprint;
    public static boolean hold_mouse0;
    public static boolean showSkull;
    public static final Map<String, Identifier> HEADS;
    public ArrayList<Packet<?>> silentPackets = new ArrayList();
    private final Timer skullTimer = new Timer();
    private final Timer lastPacket = new Timer();
    private final Timer autoSave = new Timer();
    private final Timer setBackTimer = new Timer();

    @EventHandler
    public void onTick(PlayerUpdateEvent event) {
        if (Module.fullNullCheck()) {
            return;
        }
        Managers.NOTIFICATION.onUpdate();
        Managers.MODULE.onUpdate();
        ThunderGui.getInstance().onTick();
        if (ModuleManager.clickGui.getBind().getKey() == -1) {
            Command.sendMessage(String.valueOf(Formatting.RED) + (ClientSettings.isRu() ? "\u041f\u0440\u0438\u0432\u044f\u0437\u043a\u0430 \u043a\u043b\u0430\u0432\u0438\u0448 Clickgui \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e -> P" : "Default clickgui keybind --> P"));
            Command.sendMessage(String.valueOf(Formatting.RED) + (ClientSettings.isRu() ? "\u0412\u044b \u043c\u043e\u0436\u0435\u0442\u0435 \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u0433\u043e\u0442\u043e\u0432\u0443\u044e \u043a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044e, \u0432\u044b\u043f\u043e\u043b\u043d\u0438\u0432 \u0441\u043b\u0435\u0434\u0443\u044e\u0449\u0443\u044e \u043a\u043e\u043c\u0430\u043d\u0434\u0443 -> @cfg cloudlist." : "You can obtain a pre-built configuration by executing the following command -> @cfg cloudlist."));
            ModuleManager.clickGui.setBind(InputUtil.fromTranslationKey((String)"key.keyboard.p").getCode(), false, false);
        }
        for (PlayerEntity p : Module.mc.world.getPlayers()) {
            if (!p.isDead() && p.getHealth() != 0.0f) continue;
            ThunderHack.EVENT_BUS.post(new EventDeath(p));
        }
        if (!Objects.equals(Managers.COMMAND.getPrefix(), ClientSettings.prefix.getValue())) {
            Managers.COMMAND.setPrefix(ClientSettings.prefix.getValue());
        }
        new HashMap<BlockPos, Long>(InteractionUtility.awaiting).forEach((bp, time) -> {
            if ((float)(System.currentTimeMillis() - time) > (float)Managers.SERVER.getPing() * 2.0f) {
                InteractionUtility.awaiting.remove(bp);
            }
        });
        if (this.autoSave.every(600000L)) {
            Managers.FRIEND.saveFriends();
            Managers.CONFIG.save(Managers.CONFIG.getCurrentConfig());
            Managers.WAYPOINT.saveWayPoints();
            Managers.MACRO.saveMacro();
            Managers.NOTIFICATION.publicity("AutoSave", ClientSettings.isRu() ? "\u0421\u043e\u0445\u0440\u0430\u043d\u044f\u044e \u043a\u043e\u043d\u0444\u0438\u0433.." : "Saving config..", 3, Notification.Type.INFO);
        }
    }

    @EventHandler
    public void onPacketSend(@NotNull PacketEvent.Send e) {
        ClientCommandC2SPacket c;
        Object t;
        if (e.getPacket() instanceof PlayerMoveC2SPacket && !(e.getPacket() instanceof PlayerMoveC2SPacket.OnGroundOnly)) {
            this.lastPacket.reset();
        }
        if ((t = e.getPacket()) instanceof ClientCommandC2SPacket && ((c = (ClientCommandC2SPacket)t).getMode() == ClientCommandC2SPacket.Mode.START_SPRINTING || c.getMode() == ClientCommandC2SPacket.Mode.STOP_SPRINTING)) {
            if (lockSprint) {
                e.cancel();
                return;
            }
            switch (c.getMode()) {
                case START_SPRINTING: {
                    serverSprint = true;
                    break;
                }
                case STOP_SPRINTING: {
                    serverSprint = false;
                }
            }
        }
    }

    @EventHandler
    public void onSync(EventSync event) {
        if (Module.fullNullCheck()) {
            return;
        }
        CaptureMark.tick();
        Render3DEngine.updateTargetESP();
    }

    public void onRender2D(DrawContext e) {
        this.drawGps(e);
        this.drawSkull(e);
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        GameMessageS2CPacket packet;
        if (Module.fullNullCheck()) {
            return;
        }
        if (e.getPacket() instanceof GameMessageS2CPacket && (packet = (GameMessageS2CPacket)e.getPacket()).content().getString().contains("skull")) {
            showSkull = true;
            this.skullTimer.reset();
            Module.mc.world.playSound((PlayerEntity)Module.mc.player, Module.mc.player.getBlockPos(), SoundEvents.ENTITY_SKELETON_DEATH, SoundCategory.BLOCKS, 1.0f, 1.0f);
        }
        if (e.getPacket() instanceof GameJoinS2CPacket) {
            Managers.MODULE.onLogin();
        }
        if (e.getPacket() instanceof PlayerPositionLookS2CPacket) {
            this.setBackTimer.reset();
        }
    }

    public void drawSkull(DrawContext e) {
        if (showSkull && !this.skullTimer.passedMs(3000L) && ClientSettings.skullEmoji.getValue().booleanValue()) {
            int xPos = (int)((float)Module.mc.getWindow().getScaledWidth() / 2.0f - 150.0f);
            int yPos = (int)((float)Module.mc.getWindow().getScaledHeight() / 2.0f - 150.0f);
            float alpha = 1.0f - (float)this.skullTimer.getPassedTimeMs() / 3000.0f;
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
            e.drawTexture(TextureStorage.skull, xPos, yPos, 0.0f, 0.0f, 300, 300, 300, 300);
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        } else {
            showSkull = false;
        }
    }

    public void drawGps(DrawContext e) {
        if (ThunderHack.gps_position != null) {
            float dst = this.getDistance(ThunderHack.gps_position);
            float xOffset = (float)Module.mc.getWindow().getScaledWidth() / 2.0f;
            float yOffset = (float)Module.mc.getWindow().getScaledHeight() / 2.0f;
            float yaw = Core.getRotations(new Vec2f((float)ThunderHack.gps_position.getX(), (float)ThunderHack.gps_position.getZ())) - Module.mc.player.getYaw();
            e.getMatrices().translate(xOffset, yOffset, 0.0f);
            e.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(yaw));
            e.getMatrices().translate(-xOffset, -yOffset, 0.0f);
            Render2DEngine.drawTracerPointer(e.getMatrices(), xOffset, yOffset - 50.0f, 12.5f, 0.5f, 3.63f, true, true, HudEditor.getColor(1).getRGB());
            e.getMatrices().translate(xOffset, yOffset, 0.0f);
            e.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-yaw));
            e.getMatrices().translate(-xOffset, -yOffset, 0.0f);
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            FontRenderers.modules.drawCenteredString(e.getMatrices(), "gps (" + dst + "m)", (double)((float)(Math.sin(Math.toRadians(yaw)) * 50.0) + xOffset), (double)((float)((double)yOffset - Math.cos(Math.toRadians(yaw)) * 50.0) - 23.0f), -1);
            if (dst < 10.0f) {
                ThunderHack.gps_position = null;
            }
        }
    }

    @EventHandler
    public void onKeyPress(EventKeyPress event) {
        if (event.getKey() == -1) {
            return;
        }
        for (MacroManager.Macro m : Managers.MACRO.getMacros()) {
            if (m.getBind() != event.getKey()) continue;
            m.runMacro();
        }
    }

    @EventHandler
    public void onMouse(EventMouse event) {
        if (event.getAction() == 0) {
            hold_mouse0 = false;
        }
        if (event.getAction() == 1) {
            hold_mouse0 = true;
        }
    }

    public int getDistance(BlockPos bp) {
        double d0 = Module.mc.player.getX() - (double)bp.getX();
        double d2 = Module.mc.player.getZ() - (double)bp.getZ();
        return (int)MathHelper.sqrt((float)((float)(d0 * d0 + d2 * d2)));
    }

    public long getSetBackTime() {
        return this.setBackTimer.getPassedTimeMs();
    }

    public static float getRotations(Vec2f vec) {
        if (Module.mc.player == null) {
            return 0.0f;
        }
        double x = (double)vec.x - Module.mc.player.getPos().x;
        double z = (double)vec.y - Module.mc.player.getPos().z;
        return (float)(-(Math.atan2(x, z) * 57.29577951308232));
    }

    public void bobView(MatrixStack matrices, float tickDelta) {
        Entity class_12972 = Module.mc.getCameraEntity();
        if (!(class_12972 instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity playerEntity = (PlayerEntity)class_12972;
        float g = -(playerEntity.horizontalSpeed + (playerEntity.horizontalSpeed - playerEntity.prevHorizontalSpeed) * tickDelta);
        float h = MathHelper.lerp((float)tickDelta, (float)playerEntity.prevStrideDistance, (float)playerEntity.strideDistance);
        matrices.translate((double)(MathHelper.sin((float)(g * (float)Math.PI)) * h * 0.1f), (double)(-Math.abs(MathHelper.cos((float)(g * (float)Math.PI)) * h)) * 0.3, 0.0);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(MathHelper.sin((float)(g * (float)Math.PI)) * h * 3.0f));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(Math.abs(MathHelper.cos((float)(g * (float)Math.PI - 0.2f)) * h) * 0.3f));
    }

    static {
        HEADS = new ConcurrentHashMap<String, Identifier>();
    }
}

