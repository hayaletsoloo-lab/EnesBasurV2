/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.entity.DamageUtil
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.attribute.EntityAttributes
 *  net.minecraft.entity.damage.DamageSource
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.AxeItem
 *  net.minecraft.item.BedItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.item.PickaxeItem
 *  net.minecraft.item.ShovelItem
 *  net.minecraft.item.SwordItem
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.registry.Registries
 *  net.minecraft.registry.entry.RegistryEntry
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.utility.player;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import net.minecraft.block.Block;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BedItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IInteractionManager;
import thunder.hack.utility.player.SearchInvResult;

public final class InventoryUtility {
    private static int cachedSlot = -1;

    public static int getItemCount(Item item) {
        if (Module.mc.player == null) {
            return 0;
        }
        int counter = 0;
        for (int i = 0; i <= 44; ++i) {
            ItemStack itemStack = Module.mc.player.getInventory().getStack(i);
            if (itemStack.getItem() != item) continue;
            counter += itemStack.getCount();
        }
        return counter;
    }

    public static SearchInvResult getAxe() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 9; b1 < 45; ++b1) {
            Item class_17922;
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1 >= 36 ? b1 - 36 : b1);
            if (itemStack == null || !((class_17922 = itemStack.getItem()) instanceof AxeItem)) continue;
            AxeItem axe = (AxeItem)class_17922;
            float f1 = ((Integer)axe.getComponents().get(DataComponentTypes.MAX_DAMAGE)).intValue();
            if (!((f1 += (float)EnchantmentHelper.getLevel((RegistryEntry)((RegistryEntry)Module.mc.world.getRegistryManager().get(Enchantments.SHARPNESS.getRegistryRef()).getEntry(Enchantments.SHARPNESS).get()), (ItemStack)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot >= 36) {
            slot -= 36;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.player.getInventory().getStack(slot));
    }

    public static SearchInvResult getPickAxeHotbar() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 0; b1 < 9; ++b1) {
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1);
            if (itemStack == null || !(itemStack.getItem() instanceof PickaxeItem)) continue;
            float f1 = 0.0f;
            if (!((f1 += (float)EnchantmentHelper.getLevel((RegistryEntry)((RegistryEntry)Module.mc.world.getRegistryManager().get(Enchantments.EFFICIENCY.getRegistryRef()).getEntry(Enchantments.EFFICIENCY).get()), (ItemStack)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.player.getInventory().getStack(slot));
    }

    public static SearchInvResult getPickAxe() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 9; b1 < 45; ++b1) {
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1);
            if (itemStack == null || !(itemStack.getItem() instanceof PickaxeItem)) continue;
            float f1 = 0.0f;
            if (!((f1 += (float)EnchantmentHelper.getLevel((RegistryEntry)((RegistryEntry)Module.mc.world.getRegistryManager().get(Enchantments.EFFICIENCY.getRegistryRef()).getEntry(Enchantments.EFFICIENCY).get()), (ItemStack)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.player.getInventory().getStack(slot));
    }

    public static SearchInvResult getPickAxeHotBar() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 0; b1 < 9; ++b1) {
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1);
            if (itemStack == null || !(itemStack.getItem() instanceof PickaxeItem)) continue;
            float f1 = 0.0f;
            if (!((f1 += (float)EnchantmentHelper.getLevel((RegistryEntry)((RegistryEntry)Module.mc.world.getRegistryManager().get(Enchantments.EFFICIENCY.getRegistryRef()).getEntry(Enchantments.EFFICIENCY).get()), (ItemStack)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.player.getInventory().getStack(slot));
    }

    public static SearchInvResult getSkull() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        for (int b1 = 0; b1 < 9; ++b1) {
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1);
            if (itemStack == null || !itemStack.getItem().equals(Items.SKELETON_SKULL) && !itemStack.getItem().equals(Items.WITHER_SKELETON_SKULL) && !itemStack.getItem().equals(Items.CREEPER_HEAD) && !itemStack.getItem().equals(Items.PLAYER_HEAD) && !itemStack.getItem().equals(Items.ZOMBIE_HEAD)) continue;
            slot = b1;
            break;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.player.getInventory().getStack(slot));
    }

    public static SearchInvResult getSword() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 9; b1 < 45; ++b1) {
            Item class_17922;
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1);
            if (itemStack == null || !((class_17922 = itemStack.getItem()) instanceof SwordItem)) continue;
            SwordItem sword = (SwordItem)class_17922;
            float f1 = ((Integer)sword.getComponents().get(DataComponentTypes.MAX_DAMAGE)).intValue();
            if (!((f1 += (float)EnchantmentHelper.getLevel((RegistryEntry)((RegistryEntry)Module.mc.world.getRegistryManager().get(Enchantments.SHARPNESS.getRegistryRef()).getEntry(Enchantments.SHARPNESS).get()), (ItemStack)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.player.getInventory().getStack(slot));
    }

    public static SearchInvResult getSwordHotBar() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 0; b1 < 9; ++b1) {
            Item class_17922;
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1);
            if (itemStack == null || !((class_17922 = itemStack.getItem()) instanceof SwordItem)) continue;
            SwordItem sword = (SwordItem)class_17922;
            float f1 = ((Integer)sword.getComponents().get(DataComponentTypes.MAX_DAMAGE)).intValue();
            if (!((f1 += (float)EnchantmentHelper.getLevel((RegistryEntry)((RegistryEntry)Module.mc.world.getRegistryManager().get(Enchantments.SHARPNESS.getRegistryRef()).getEntry(Enchantments.SHARPNESS).get()), (ItemStack)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.player.getInventory().getStack(slot));
    }

    public static SearchInvResult getAxeHotBar() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 0; b1 < 9; ++b1) {
            Item class_17922;
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1);
            if (itemStack == null || !((class_17922 = itemStack.getItem()) instanceof AxeItem)) continue;
            AxeItem axe = (AxeItem)class_17922;
            float f1 = ((Integer)axe.getComponents().get(DataComponentTypes.MAX_DAMAGE)).intValue();
            if (!((f1 += (float)EnchantmentHelper.getLevel((RegistryEntry)((RegistryEntry)Module.mc.world.getRegistryManager().get(Enchantments.SHARPNESS.getRegistryRef()).getEntry(Enchantments.SHARPNESS).get()), (ItemStack)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.player.getInventory().getStack(slot));
    }

    public static int getElytra() {
        for (ItemStack stack : Module.mc.player.getInventory().armor) {
            if (stack.getItem() != Items.ELYTRA || stack.getDamage() >= 430) continue;
            return -2;
        }
        int slot = -1;
        for (int i = 0; i < 36; ++i) {
            ItemStack s = Module.mc.player.getInventory().getStack(i);
            if (s.getItem() != Items.ELYTRA || s.getDamage() >= 430) continue;
            slot = i;
            break;
        }
        if (slot < 9 && slot != -1) {
            slot += 36;
        }
        return slot;
    }

    public static SearchInvResult findInHotBar(Searcher searcher) {
        if (Module.mc.player != null) {
            for (int i = 0; i < 9; ++i) {
                ItemStack stack = Module.mc.player.getInventory().getStack(i);
                if (!searcher.isValid(stack)) continue;
                return new SearchInvResult(i, true, stack);
            }
        }
        return SearchInvResult.notFound();
    }

    public static SearchInvResult findItemInHotBar(List<Item> items) {
        return InventoryUtility.findInHotBar(stack -> items.contains(stack.getItem()));
    }

    public static SearchInvResult findItemInHotBar(Item ... items) {
        return InventoryUtility.findItemInHotBar(Arrays.asList(items));
    }

    public static SearchInvResult findInInventory(Searcher searcher) {
        if (Module.mc.player != null) {
            for (int i = 36; i >= 0; --i) {
                ItemStack stack = Module.mc.player.getInventory().getStack(i);
                if (!searcher.isValid(stack)) continue;
                if (i < 9) {
                    i += 36;
                }
                return new SearchInvResult(i, true, stack);
            }
        }
        return SearchInvResult.notFound();
    }

    public static SearchInvResult findItemInInventory(List<Item> items) {
        return InventoryUtility.findInInventory(stack -> items.contains(stack.getItem()));
    }

    public static SearchInvResult findItemInInventory(Item ... items) {
        return InventoryUtility.findItemInInventory(Arrays.asList(items));
    }

    public static SearchInvResult findBlockInHotBar(@NotNull List<Block> blocks) {
        return InventoryUtility.findItemInHotBar(blocks.stream().map(Block::asItem).toList());
    }

    public static SearchInvResult findBlockInHotBar(Block ... blocks) {
        return InventoryUtility.findItemInHotBar(Arrays.stream(blocks).map(Block::asItem).toList());
    }

    public static SearchInvResult findBlockInInventory(@NotNull List<Block> blocks) {
        return InventoryUtility.findItemInInventory(blocks.stream().map(Block::asItem).toList());
    }

    public static SearchInvResult findBlockInInventory(Block ... blocks) {
        return InventoryUtility.findItemInInventory(Arrays.stream(blocks).map(Block::asItem).toList());
    }

    public static void saveSlot() {
        cachedSlot = Module.mc.player.getInventory().selectedSlot;
    }

    public static void returnSlot() {
        if (cachedSlot != -1) {
            InventoryUtility.switchTo(cachedSlot);
        }
        cachedSlot = -1;
    }

    public static void saveAndSwitchTo(int slot) {
        InventoryUtility.saveSlot();
        if (Module.mc.player == null || Module.mc.getNetworkHandler() == null) {
            return;
        }
        if (Module.mc.player.getInventory().selectedSlot == slot && Managers.PLAYER.serverSideSlot == slot) {
            return;
        }
        Module.mc.player.getInventory().selectedSlot = slot;
        ((IInteractionManager)Module.mc.interactionManager).syncSlot();
    }

    public static void switchTo(int slot) {
        if (Module.mc.player == null || Module.mc.getNetworkHandler() == null) {
            return;
        }
        if (Module.mc.player.getInventory().selectedSlot == slot && Managers.PLAYER.serverSideSlot == slot) {
            return;
        }
        Module.mc.player.getInventory().selectedSlot = slot;
        ((IInteractionManager)Module.mc.interactionManager).syncSlot();
    }

    public static void switchToSilent(int slot) {
        if (Module.mc.player == null || Module.mc.getNetworkHandler() == null) {
            return;
        }
        Module.mc.getNetworkHandler().sendPacket((Packet)new UpdateSelectedSlotC2SPacket(slot));
    }

    public static SearchInvResult getAntiWeaknessItem() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        Item mainHand = Module.mc.player.getMainHandStack().getItem();
        if (mainHand instanceof SwordItem || mainHand instanceof PickaxeItem || mainHand instanceof AxeItem || mainHand instanceof ShovelItem) {
            return new SearchInvResult(Module.mc.player.getInventory().selectedSlot, true, Module.mc.player.getMainHandStack());
        }
        return InventoryUtility.findInHotBar(itemStack -> itemStack.getItem() instanceof SwordItem || itemStack.getItem() instanceof PickaxeItem || itemStack.getItem() instanceof AxeItem || itemStack.getItem() instanceof ShovelItem);
    }

    public static float getHitDamage(@NotNull ItemStack weapon, PlayerEntity ent) {
        if (Module.mc.player == null) {
            return 0.0f;
        }
        float baseDamage = 1.0f;
        Item class_17922 = weapon.getItem();
        if (class_17922 instanceof SwordItem) {
            SwordItem swordItem = (SwordItem)class_17922;
            baseDamage = 7.0f;
        }
        if ((class_17922 = weapon.getItem()) instanceof AxeItem) {
            AxeItem axeItem = (AxeItem)class_17922;
            baseDamage = 9.0f;
        }
        if (Module.mc.player.fallDistance > 0.0f) {
            baseDamage += baseDamage / 2.0f;
        }
        if (Module.mc.player.hasStatusEffect(StatusEffects.STRENGTH)) {
            int strength = Objects.requireNonNull(Module.mc.player.getStatusEffect(StatusEffects.STRENGTH)).getAmplifier() + 1;
            baseDamage += (float)(3 * strength);
        }
        baseDamage = DamageUtil.getDamageLeft((LivingEntity)ent, (float)baseDamage, (DamageSource)Module.mc.world.getDamageSources().generic(), (float)ent.getArmor(), (float)((float)ent.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS).getValue()));
        return baseDamage;
    }

    public static SearchInvResult findBedInHotBar() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        for (int b1 = 0; b1 < 9; ++b1) {
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1);
            if (itemStack == null || !(itemStack.getItem() instanceof BedItem)) continue;
            return new SearchInvResult(b1, true, Module.mc.player.getInventory().getStack(b1));
        }
        return SearchInvResult.notFound();
    }

    public static SearchInvResult findBed() {
        if (Module.mc.player == null) {
            return SearchInvResult.notFound();
        }
        for (int b1 = 9; b1 < 45; ++b1) {
            ItemStack itemStack = Module.mc.player.getInventory().getStack(b1 >= 36 ? b1 - 36 : b1);
            if (itemStack == null || !(itemStack.getItem() instanceof BedItem)) continue;
            return new SearchInvResult(b1, true, Module.mc.player.getInventory().getStack(b1));
        }
        return SearchInvResult.notFound();
    }

    public static Item getItem(String Name2) {
        if (Name2 == null) {
            return Items.AIR;
        }
        for (Block block : Registries.BLOCK) {
            if (!block.getTranslationKey().replace("block.minecraft.", "").equals(Name2.toLowerCase())) continue;
            return Item.fromBlock((Block)block);
        }
        for (Item item : Registries.ITEM) {
            if (!item.getTranslationKey().replace("item.minecraft.", "").equals(Name2.toLowerCase())) continue;
            return item;
        }
        return Items.DIRT;
    }

    public static int getBedsCount() {
        if (Module.mc.player == null) {
            return 0;
        }
        int counter = 0;
        for (int i = 0; i <= 44; ++i) {
            ItemStack itemStack = Module.mc.player.getInventory().getStack(i);
            if (!(itemStack.getItem() instanceof BedItem)) continue;
            counter += itemStack.getCount();
        }
        return counter;
    }

    public static interface Searcher {
        public boolean isValid(ItemStack var1);
    }
}

