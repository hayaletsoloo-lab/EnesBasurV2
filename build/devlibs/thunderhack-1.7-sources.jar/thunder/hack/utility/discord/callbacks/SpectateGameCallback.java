/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sun.jna.Callback
 */
package thunder.hack.utility.discord.callbacks;

import com.sun.jna.Callback;

public interface SpectateGameCallback
extends Callback {
    public void apply(String var1);
}

