/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sun.jna.Callback
 */
package thunder.hack.utility.discord.callbacks;

import com.sun.jna.Callback;

public interface DisconnectedCallback
extends Callback {
    public void apply(int var1, String var2);
}

