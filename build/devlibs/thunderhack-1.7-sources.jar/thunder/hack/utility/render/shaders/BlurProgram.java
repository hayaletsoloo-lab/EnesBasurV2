/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gl.Framebuffer
 *  net.minecraft.client.gl.SimpleFramebuffer
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.util.Identifier
 *  org.lwjgl.opengl.GL30
 */
package thunder.hack.utility.render.shaders;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL30;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.render.WindowResizeCallback;
import thunder.hack.utility.render.shaders.satin.api.managed.ManagedCoreShader;
import thunder.hack.utility.render.shaders.satin.api.managed.ShaderEffectManager;
import thunder.hack.utility.render.shaders.satin.api.managed.uniform.SamplerUniform;
import thunder.hack.utility.render.shaders.satin.api.managed.uniform.Uniform1f;
import thunder.hack.utility.render.shaders.satin.api.managed.uniform.Uniform2f;
import thunder.hack.utility.render.shaders.satin.api.managed.uniform.Uniform4f;

public class BlurProgram {
    private Uniform2f uSize;
    private Uniform2f uLocation;
    private Uniform1f radius;
    private Uniform2f inputResolution;
    private Uniform1f brightness;
    private Uniform1f quality;
    private Uniform4f color1;
    private SamplerUniform sampler;
    private Framebuffer input;
    public static final ManagedCoreShader BLUR = ShaderEffectManager.getInstance().manageCoreShader(Identifier.of((String)"thunderhack", (String)"blur"), VertexFormats.POSITION);

    public BlurProgram() {
        this.setup();
    }

    public void setParameters(float x, float y, float width, float height, float r, Color c1, float blurStrenth, float blurOpacity) {
        if (this.input == null) {
            this.input = new SimpleFramebuffer(Module.mc.getWindow().getScaledWidth(), Module.mc.getWindow().getScaledHeight(), false, MinecraftClient.IS_SYSTEM_MAC);
        }
        float i = (float)Module.mc.getWindow().getScaleFactor();
        this.radius.set(r * i);
        this.uLocation.set(x * i, -y * i + (float)Module.mc.getWindow().getScaledHeight() * i - height * i);
        this.uSize.set(width * i, height * i);
        this.brightness.set(blurOpacity);
        this.quality.set(blurStrenth);
        this.color1.set((float)c1.getRed() / 255.0f, (float)c1.getGreen() / 255.0f, (float)c1.getBlue() / 255.0f, 1.0f);
        this.sampler.set(this.input.getColorAttachment());
    }

    public void use() {
        Framebuffer buffer = MinecraftClient.getInstance().getFramebuffer();
        this.input.beginWrite(false);
        GL30.glBindFramebuffer((int)36008, (int)buffer.fbo);
        GL30.glBlitFramebuffer((int)0, (int)0, (int)buffer.textureWidth, (int)buffer.textureHeight, (int)0, (int)0, (int)buffer.textureWidth, (int)buffer.textureHeight, (int)16384, (int)9729);
        buffer.beginWrite(false);
        if (this.input != null && (this.input.textureWidth != Module.mc.getWindow().getFramebufferWidth() || this.input.textureHeight != Module.mc.getWindow().getFramebufferHeight())) {
            this.input.resize(Module.mc.getWindow().getFramebufferWidth(), Module.mc.getWindow().getFramebufferHeight(), MinecraftClient.IS_SYSTEM_MAC);
        }
        this.inputResolution.set(buffer.textureWidth, buffer.textureHeight);
        this.sampler.set(this.input.getColorAttachment());
        RenderSystem.setShader(BLUR::getProgram);
    }

    protected void setup() {
        this.inputResolution = BLUR.findUniform2f("InputResolution");
        this.brightness = BLUR.findUniform1f("Brightness");
        this.quality = BLUR.findUniform1f("Quality");
        this.color1 = BLUR.findUniform4f("color1");
        this.uSize = BLUR.findUniform2f("uSize");
        this.uLocation = BLUR.findUniform2f("uLocation");
        this.radius = BLUR.findUniform1f("radius");
        this.sampler = BLUR.findSampler("InputSampler");
        WindowResizeCallback.EVENT.register((client, window) -> {
            if (this.input != null) {
                this.input.resize(window.getFramebufferWidth(), window.getFramebufferHeight(), MinecraftClient.IS_SYSTEM_MAC);
            }
        });
    }
}

