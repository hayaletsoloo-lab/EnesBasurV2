/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.particle.BlockDustParticle
 *  net.minecraft.client.particle.CampfireSmokeParticle
 *  net.minecraft.client.particle.ElderGuardianAppearanceParticle
 *  net.minecraft.client.particle.ExplosionLargeParticle
 *  net.minecraft.client.particle.FireworksSparkParticle$FireworkParticle
 *  net.minecraft.client.particle.FireworksSparkParticle$Flash
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.client.particle.ParticleManager
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package thunder.hack.injection;

import net.minecraft.class_3937;
import net.minecraft.class_677;
import net.minecraft.class_691;
import net.minecraft.class_700;
import net.minecraft.class_702;
import net.minecraft.class_703;
import net.minecraft.class_727;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.render.NoRender;

@Mixin(value={class_702.class})
public class MixinParticleManager {
    @Inject(at={@At(value="HEAD")}, method={"addParticle(Lnet/minecraft/client/particle/Particle;)V"}, cancellable=true)
    public void addParticleHook(class_703 p, CallbackInfo e) {
        NoRender nR = ModuleManager.noRender;
        if (!nR.isEnabled()) {
            return;
        }
        if (nR.elderGuardian.getValue().booleanValue() && p instanceof class_700) {
            e.cancel();
        }
        if (nR.explosions.getValue().booleanValue() && p instanceof class_691) {
            e.cancel();
        }
        if (nR.campFire.getValue().booleanValue() && p instanceof class_3937) {
            e.cancel();
        }
        if (nR.breakParticles.getValue().booleanValue() && p instanceof class_727) {
            e.cancel();
        }
        if (nR.fireworks.getValue().booleanValue() && (p instanceof class_677.class_681 || p instanceof class_677.class_678)) {
            e.cancel();
        }
    }
}

