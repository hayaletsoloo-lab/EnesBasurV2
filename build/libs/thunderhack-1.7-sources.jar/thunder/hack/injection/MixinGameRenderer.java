/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.option.Perspective
 *  net.minecraft.client.render.Camera
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.RenderTickCounter
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.resource.ResourceFactory
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec3d
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5498;
import net.minecraft.class_5912;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.utility.math.FrameRateCounter;
import thunder.hack.utility.render.BlockAnimationUtility;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.shaders.satin.impl.ReloadableShaderEffectManager;

@Mixin(value={class_757.class})
public abstract class MixinGameRenderer {
    @Shadow
    private float zoom;
    @Shadow
    private float zoomX;
    @Shadow
    private float zoomY;
    @Shadow
    private float viewDistance;

    @Shadow
    public abstract void tick();

    @Inject(at={@At(value="INVOKE", target="Lnet/minecraft/util/profiler/Profiler;pop()V", ordinal=1, shift=At.Shift.BEFORE)}, method={"render"})
    void postHudRenderHook(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        FrameRateCounter.INSTANCE.recordFrame();
    }

    @Inject(at={@At(value="FIELD", target="Lnet/minecraft/client/render/GameRenderer;renderHand:Z", opcode=180, ordinal=0)}, method={"renderWorld"})
    void render3dHook(class_9779 tickCounter, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        class_4184 camera = Module.mc.field_1773.method_19418();
        class_4587 matrixStack = new class_4587();
        RenderSystem.getModelViewStack().pushMatrix().mul((Matrix4fc)matrixStack.method_23760().method_23761());
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        RenderSystem.applyModelViewMatrix();
        Render3DEngine.lastProjMat.set((Matrix4fc)RenderSystem.getProjectionMatrix());
        Render3DEngine.lastModMat.set((Matrix4fc)RenderSystem.getModelViewMatrix());
        Render3DEngine.lastWorldSpaceMatrix.set((Matrix4fc)matrixStack.method_23760().method_23761());
        Managers.MODULE.onRender3D(matrixStack);
        BlockAnimationUtility.onRender(matrixStack);
        Render3DEngine.onRender3D(matrixStack);
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();
    }

    @Inject(method={"renderWorld"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/GameRenderer;renderHand(Lnet/minecraft/client/render/Camera;FLorg/joml/Matrix4f;)V", shift=At.Shift.AFTER)})
    public void postRender3dHook(class_9779 tickCounter, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        Managers.SHADER.renderShaders();
    }

    @Redirect(method={"renderWorld"}, at=@At(value="INVOKE", target="Lnet/minecraft/util/math/MathHelper;lerp(FFF)F"))
    private float renderWorldHook(float delta, float first, float second) {
        if (ModuleManager.noRender.isEnabled() && ModuleManager.noRender.nausea.getValue().booleanValue()) {
            return 0.0f;
        }
        return class_3532.method_16439((float)delta, (float)first, (float)second);
    }

    @Inject(method={"loadPrograms"}, at={@At(value="RETURN")})
    private void loadSatinPrograms(class_5912 factory, CallbackInfo ci) {
        ReloadableShaderEffectManager.INSTANCE.reload(factory);
    }

    @Inject(method={"updateCrosshairTarget"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/GameRenderer;findCrosshairTarget(Lnet/minecraft/entity/Entity;DDF)Lnet/minecraft/util/hit/HitResult;")}, cancellable=true)
    private void onUpdateTargetedEntity(float tickDelta, CallbackInfo info) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (ModuleManager.freeCam.isEnabled()) {
            Module.mc.method_16011().method_15407();
            info.cancel();
            Module.mc.field_1765 = Managers.PLAYER.getRtxTarget(ModuleManager.freeCam.getFakeYaw(), ModuleManager.freeCam.getFakePitch(), ModuleManager.freeCam.getFakeX(), ModuleManager.freeCam.getFakeY(), ModuleManager.freeCam.getFakeZ());
        }
    }

    @Inject(method={"findCrosshairTarget"}, at={@At(value="HEAD")}, cancellable=true)
    private void findCrosshairTargetHook(class_1297 camera, double blockInteractionRange, double entityInteractionRange, float tickDelta, CallbackInfoReturnable<class_239> cir) {
    }

    @Inject(method={"getBasicProjectionMatrix"}, at={@At(value="TAIL")}, cancellable=true)
    public void getBasicProjectionMatrixHook(double fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (ModuleManager.aspectRatio.isEnabled()) {
            class_4587 matrixStack = new class_4587();
            matrixStack.method_23760().method_23761().identity();
            if (this.zoom != 1.0f) {
                matrixStack.method_46416(this.zoomX, -this.zoomY, 0.0f);
                matrixStack.method_22905(this.zoom, this.zoom, 1.0f);
            }
            matrixStack.method_23760().method_23761().mul((Matrix4fc)new Matrix4f().setPerspective((float)(fov * 0.01745329238474369), ModuleManager.aspectRatio.ratio.getValue().floatValue(), 0.05f, this.viewDistance * 4.0f));
            cir.setReturnValue(matrixStack.method_23760().method_23761());
        }
    }

    @Inject(method={"getFov(Lnet/minecraft/client/render/Camera;FZ)D"}, at={@At(value="TAIL")}, cancellable=true)
    public void getFov(class_4184 camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cb) {
        if (ModuleManager.fov.isEnabled()) {
            if ((Double)cb.getReturnValue() == 70.0 && !ModuleManager.fov.itemFov.getValue().booleanValue() && Module.mc.field_1690.method_31044() != class_5498.field_26664) {
                return;
            }
            if (ModuleManager.fov.itemFov.getValue().booleanValue() && (Double)cb.getReturnValue() == 70.0) {
                cb.setReturnValue(ModuleManager.fov.itemFovModifier.getValue().doubleValue());
                return;
            }
            if (Module.mc.field_1724.method_5869()) {
                return;
            }
            cb.setReturnValue(ModuleManager.fov.fovModifier.getValue().doubleValue());
        }
    }

    @Inject(method={"bobView"}, at={@At(value="HEAD")}, cancellable=true)
    private void bobViewHook(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (ClientSettings.customBob.getValue().booleanValue()) {
            ThunderHack.core.bobView(matrices, tickDelta);
            ci.cancel();
        }
    }

    @Unique
    private class_239 ensureTargetInRangeCustom(class_239 hitResult, class_243 cameraPos, double interactionRange) {
        class_243 vec3d = hitResult.method_17784();
        if (!vec3d.method_24802((class_2374)cameraPos, interactionRange)) {
            class_243 vec3d2 = hitResult.method_17784();
            class_2350 direction = class_2350.method_10142((double)(vec3d2.field_1352 - cameraPos.field_1352), (double)(vec3d2.field_1351 - cameraPos.field_1351), (double)(vec3d2.field_1350 - cameraPos.field_1350));
            return class_3965.method_17778((class_243)vec3d2, (class_2350)direction, (class_2338)class_2338.method_49638((class_2374)vec3d2));
        }
        return hitResult;
    }

    @Inject(method={"showFloatingItem"}, at={@At(value="HEAD")}, cancellable=true)
    private void showFloatingItemHook(class_1799 floatingItem, CallbackInfo info) {
    }

    @Inject(method={"renderFloatingItem"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderFloatingItemHook(class_332 context, float tickDelta, CallbackInfo ci) {
    }

    @Inject(method={"tiltViewWhenHurt"}, at={@At(value="HEAD")}, cancellable=true)
    private void tiltViewWhenHurtHook(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        if (ModuleManager.noRender.isEnabled() && ModuleManager.noRender.hurtCam.getValue().booleanValue()) {
            ci.cancel();
        }
    }
}

