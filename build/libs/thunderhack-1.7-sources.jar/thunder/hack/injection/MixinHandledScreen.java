/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.block.ShulkerBoxBlock
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.gui.screen.ingame.HandledScreen
 *  net.minecraft.client.gui.screen.ingame.ScreenHandlerProvider
 *  net.minecraft.client.render.DiffuseLighting
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.ContainerComponent
 *  net.minecraft.component.type.MapIdComponent
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.BlockItem
 *  net.minecraft.item.FilledMapItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.map.MapState
 *  net.minecraft.screen.ScreenHandler
 *  net.minecraft.screen.slot.Slot
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.text.Text
 *  net.minecraft.world.World
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1806;
import net.minecraft.class_1937;
import net.minecraft.class_22;
import net.minecraft.class_2480;
import net.minecraft.class_2561;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import net.minecraft.class_4597;
import net.minecraft.class_465;
import net.minecraft.class_9209;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.core.Core;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.Timer;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

@Mixin(value={class_465.class})
public abstract class MixinHandledScreen<T extends class_1703>
extends class_437
implements class_3936<T> {
    @Unique
    private final Timer delayTimer = new Timer();
    @Unique
    private Runnable postRender;
    @Shadow
    @Nullable
    protected class_1735 focusedSlot;
    @Shadow
    protected int x;
    @Shadow
    protected int y;
    private static final class_1799[] ITEMS = new class_1799[27];
    private Map<Render2DEngine.Rectangle, Integer> clickableRects = new HashMap<Render2DEngine.Rectangle, Integer>();

    protected MixinHandledScreen(class_2561 title) {
        super(title);
    }

    @Shadow
    protected abstract boolean isPointOverSlot(class_1735 var1, double var2, double var4);

    @Shadow
    protected abstract void onMouseClick(class_1735 var1, int var2, int var3, class_1713 var4);

    @Inject(method={"render"}, at={@At(value="HEAD")})
    private void drawScreenHook(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        for (int i1 = 0; i1 < Module.mc.field_1724.field_7512.field_7761.size(); ++i1) {
            class_1735 slot = (class_1735)Module.mc.field_1724.field_7512.field_7761.get(i1);
            if (!this.isPointOverSlot(slot, mouseX, mouseY) || !slot.method_7682() || !ModuleManager.itemScroller.isEnabled() || !this.shit() || !this.attack() || !this.delayTimer.passedMs(ModuleManager.itemScroller.delay.getValue().intValue())) continue;
            this.onMouseClick(slot, slot.field_7874, 0, class_1713.field_7794);
            this.delayTimer.reset();
        }
    }

    private boolean shit() {
        return class_3675.method_15987((long)class_310.method_1551().method_22683().method_4490(), (int)340) || class_3675.method_15987((long)class_310.method_1551().method_22683().method_4490(), (int)344);
    }

    private boolean attack() {
        return Core.hold_mouse0;
    }

    @Inject(method={"render"}, at={@At(value="TAIL")})
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (this.focusedSlot == null || this.focusedSlot.method_7677().method_7960() || this.field_22787.field_1724.field_7498.method_34255().method_7960()) {
            // empty if block
        }
        boolean xOffset = false;
        int yOffset = 20;
        boolean stage = false;
    }

    @Inject(method={"drawSlot(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/screen/slot/Slot;)V"}, at={@At(value="TAIL")})
    protected void drawSlotHook(class_332 context, class_1735 slot, CallbackInfo ci) {
    }

    public boolean renderShulkerToolTip(class_332 context, int offsetX, int offsetY, int mouseX, int mouseY, class_1799 stack) {
        try {
            class_1747 bi;
            class_9288 compoundTag = (class_9288)stack.method_57824(class_9334.field_49622);
            if (compoundTag == null) {
                return false;
            }
            float[] colors = new float[]{1.0f, 1.0f, 1.0f};
            class_1792 focusedItem = stack.method_7909();
            if (focusedItem instanceof class_1747 && (bi = (class_1747)focusedItem).method_7711() instanceof class_2480) {
                try {
                    Color c = new Color(Objects.requireNonNull(class_2480.method_10527((class_1792)stack.method_7909())).method_7787());
                    colors = new float[]{(float)c.getRed() / 255.0f, (float)c.getGreen() / 255.0f, (float)c.getRed() / 255.0f, (float)c.getAlpha() / 255.0f};
                }
                catch (NullPointerException npe) {
                    colors = new float[]{1.0f, 1.0f, 1.0f};
                }
            }
            this.draw(context, compoundTag.method_57489().toList(), offsetX, offsetY, mouseX, mouseY, colors);
        }
        catch (Exception ignore) {
            return false;
        }
        return true;
    }

    @Inject(method={"drawMouseoverTooltip"}, at={@At(value="HEAD")}, cancellable=true)
    private void onDrawMouseoverTooltip(class_332 context, int x, int y, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (this.focusedSlot == null || this.focusedSlot.method_7677().method_7960() || this.field_22787.field_1724.field_7498.method_34255().method_7960()) {
            // empty if block
        }
    }

    @Unique
    private void draw(class_332 context, List<class_1799> itemStacks, int offsetX, int offsetY, int mouseX, int mouseY, float[] colors) {
        RenderSystem.disableDepthTest();
        GL11.glClear((int)256);
        this.drawBackground(context, offsetX += 8, offsetY -= 82, colors);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        class_308.method_24211();
        int row = 0;
        int i = 0;
        for (class_1799 itemStack : itemStacks) {
            context.method_51427(itemStack, offsetX + 8 + i * 18, offsetY + 7 + row * 18);
            context.method_51431(Module.mc.field_1772, itemStack, offsetX + 8 + i * 18, offsetY + 7 + row * 18);
            if (mouseX > offsetX + 8 + i * 18 && mouseX < offsetX + 28 + i * 18 && mouseY > offsetY + 7 + row * 18 && mouseY < offsetY + 27 + row * 18) {
                this.postRender = () -> context.method_51437(this.field_22793, MixinHandledScreen.method_25408((class_310)Module.mc, (class_1799)itemStack), itemStack.method_32347(), mouseX, mouseY);
            }
            if (++i < 9) continue;
            i = 0;
            ++row;
        }
        class_308.method_24210();
        RenderSystem.enableDepthTest();
    }

    private void drawBackground(class_332 context, int x, int y, float[] colors) {
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor((float)colors[0], (float)colors[1], (float)colors[2], (float)1.0f);
        RenderSystem.texParameter((int)3553, (int)10240, (int)9729);
        RenderSystem.texParameter((int)3553, (int)10241, (int)9987);
        context.method_25290(TextureStorage.container, x, y, 0.0f, 0.0f, 176, 67, 176, 67);
        RenderSystem.enableBlend();
    }

    private void drawMapPreview(class_332 context, class_1799 stack, int x, int y) {
        RenderSystem.enableBlend();
        context.method_51448().method_22903();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        int y1 = y - 12;
        int x1 = x + 8;
        int z = 300;
        class_22 mapState = class_1806.method_8001((class_1799)stack, (class_1937)(Object)this.field_22787.field_1687);
        if (mapState != null) {
            mapState.method_101((class_1657)(Object)this.field_22787.field_1724);
            z = 310;
            double scale = 0.65625;
            context.method_51448().method_46416((float)(x1 += 8), (float)(y1 += 8), (float)z);
            context.method_51448().method_22905((float)scale, (float)scale, 0.0f);
            class_4597.class_4598 consumer = this.field_22787.method_22940().method_23000();
            this.field_22787.field_1773.method_3194().method_1773(context.method_51448(), (class_4597)consumer, (class_9209)stack.method_57824(class_9334.field_49646), mapState, false, 0xF000F0);
        }
        context.method_51448().method_22909();
    }

    @Inject(method={"mouseClicked"}, at={@At(value="HEAD")}, cancellable=true)
    private void mouseClicked(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (button == 2 && this.focusedSlot != null && !this.focusedSlot.method_7677().method_7960() && this.field_22787.field_1724.field_7498.method_34255().method_7960()) {
            class_1799 itemStack = this.focusedSlot.method_7677();
        }
        for (Render2DEngine.Rectangle rect : this.clickableRects.keySet()) {
            if (rect.contains(mouseX, mouseY)) continue;
        }
    }
}

