/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.client.gui.screen.ConfirmScreen
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.gui.screen.TitleScreen
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Util
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package thunder.hack.injection;

import java.net.URI;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_3675;
import net.minecraft.class_410;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import thunder.hack.ThunderHack;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;

@Mixin(value={class_442.class})
public class MixinTitleScreen
extends class_437 {
    protected MixinTitleScreen(class_2561 title) {
        super(title);
    }

    @Inject(method={"init"}, at={@At(value="RETURN")})
    public void postInitHook(CallbackInfo ci) {
        if (ModuleManager.clickGui.getBind().getKey() == -1) {
            ModuleManager.clickGui.setBind(class_3675.method_15981((String)"key.keyboard.p").method_1444(), false, false);
            ClientSettings.language.setValue(ClientSettings.Language.ENG);
        }
        if (ThunderHack.isOutdated && !FabricLoader.getInstance().isDevelopmentEnvironment()) {
            Module.mc.method_1507((class_437)new class_410(confirm -> {
                if (confirm) {
                    class_156.method_668().method_673(URI.create("https://github.com/Pan4ur/ThunderHack-Recode/releases/download/latest/thunderhack-1.7.jar/"));
                } else {
                    Module.mc.method_1490();
                }
            }, class_2561.method_30163((String)(String.valueOf(class_124.field_1061) + "You are using an outdated version of ThunderHack Recode")), class_2561.method_30163((String)"Please update to the latest release"), class_2561.method_30163((String)"Download"), class_2561.method_30163((String)"Quit Game")));
        }
    }
}

