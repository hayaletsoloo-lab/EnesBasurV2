/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.ThunderHack;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventFixVelocity;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.HitBox;
import thunder.hack.features.modules.render.Trails;
import thunder.hack.utility.interfaces.IEntity;

@Mixin(value={class_1297.class})
public abstract class MixinEntity
implements IEntity {
    @Shadow
    private class_238 boundingBox;
    @Unique
    public List<Trails.Trail> trails = new ArrayList<Trails.Trail>();

    @Shadow
    protected abstract class_2338 getVelocityAffectingPos();

    @Override
    public List<Trails.Trail> getTrails() {
        return this.trails;
    }

    @Override
    public class_2338 thunderHack_Recode$getVelocityBP() {
        return this.getVelocityAffectingPos();
    }

    @Inject(method={"updateVelocity"}, at={@At(value="HEAD")}, cancellable=true)
    public void updateVelocityHook(float speed, class_243 movementInput, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if ((Object)this == Module.mc.field_1724) {
            ci.cancel();
            EventFixVelocity event = new EventFixVelocity(movementInput, speed, Module.mc.field_1724.method_36454(), MixinEntity.movementInputToVelocityC(movementInput, speed, Module.mc.field_1724.method_36454()));
            ThunderHack.EVENT_BUS.post(event);
            Module.mc.field_1724.method_18799(Module.mc.field_1724.method_18798().method_1019(event.getVelocity()));
        }
    }

    @Unique
    private static class_243 movementInputToVelocityC(class_243 movementInput, float speed, float yaw) {
        double d = movementInput.method_1027();
        if (d < 1.0E-7) {
            return class_243.field_1353;
        }
        class_243 vec3d = (d > 1.0 ? movementInput.method_1029() : movementInput).method_1021((double)speed);
        float f = class_3532.method_15374((float)(yaw * ((float)Math.PI / 180)));
        float g = class_3532.method_15362((float)(yaw * ((float)Math.PI / 180)));
        return new class_243(vec3d.field_1352 * (double)g - vec3d.field_1350 * (double)f, vec3d.field_1351, vec3d.field_1350 * (double)g + vec3d.field_1352 * (double)f);
    }

    @Inject(method={"getBoundingBox"}, at={@At(value="HEAD")}, cancellable=true)
    public final void getBoundingBox(CallbackInfoReturnable<class_238> cir) {
        if (ModuleManager.hitBox.isEnabled() && Module.mc != null && Module.mc.field_1724 != null && ((class_1297)(Object)this).method_5628() != Module.mc.field_1724.method_5628() && (ModuleManager.aura.isDisabled() || HitBox.affectToAura.getValue().booleanValue())) {
            cir.setReturnValue(new class_238(this.boundingBox.field_1323 - (double)(HitBox.XZExpand.getValue().floatValue() / 2.0f), this.boundingBox.field_1322 - (double)(HitBox.YExpand.getValue().floatValue() / 2.0f), this.boundingBox.field_1321 - (double)(HitBox.XZExpand.getValue().floatValue() / 2.0f), this.boundingBox.field_1320 + (double)(HitBox.XZExpand.getValue().floatValue() / 2.0f), this.boundingBox.field_1325 + (double)(HitBox.YExpand.getValue().floatValue() / 2.0f), this.boundingBox.field_1324 + (double)(HitBox.XZExpand.getValue().floatValue() / 2.0f)));
        }
    }

    @Inject(method={"isGlowing"}, at={@At(value="HEAD")}, cancellable=true)
    public void isGlowingHook(CallbackInfoReturnable<Boolean> cir) {
    }

    @Inject(method={"isOnFire"}, at={@At(value="HEAD")}, cancellable=true)
    public void isOnFireHook(CallbackInfoReturnable<Boolean> cir) {
        if (ModuleManager.noRender.isEnabled() && ModuleManager.noRender.fireEntity.getValue().booleanValue()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method={"isInvisibleTo"}, at={@At(value="HEAD")}, cancellable=true)
    public void isInvisibleToHook(class_1657 player, CallbackInfoReturnable<Boolean> cir) {
    }

    @Inject(method={"isInLava"}, at={@At(value="HEAD")}, cancellable=true)
    public void isInLavaHook(CallbackInfoReturnable<Boolean> cir) {
    }

    @Inject(method={"isTouchingWater"}, at={@At(value="HEAD")}, cancellable=true)
    public void isTouchingWaterHook(CallbackInfoReturnable<Boolean> cir) {
    }

    @Inject(method={"setSwimming"}, at={@At(value="HEAD")}, cancellable=true)
    public void setSwimmingHook(boolean swimming, CallbackInfo ci) {
    }

    @ModifyVariable(method={"changeLookDirection"}, at=@At(value="HEAD"), ordinal=0, argsOnly=true)
    private double changeLookDirectionHook0(double value) {
        return value;
    }

    @ModifyVariable(method={"changeLookDirection"}, at=@At(value="HEAD"), ordinal=1, argsOnly=true)
    private double changeLookDirectionHook1(double value) {
        return value;
    }
}

