/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.MovementType
 *  net.minecraft.util.math.Vec3d
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.ThunderHack;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventTravel;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.features.modules.render.Animations;
import thunder.hack.utility.interfaces.IEntityLiving;

@Mixin(value={class_1309.class})
public class MixinEntityLiving
implements IEntityLiving {
    @Shadow
    protected double serverX;
    @Shadow
    protected double serverY;
    @Shadow
    protected double serverZ;
    @Unique
    double prevServerX;
    @Unique
    double prevServerY;
    @Unique
    double prevServerZ;
    @Unique
    public List<Aura.Position> positonHistory = new ArrayList<Aura.Position>();
    @Unique
    private boolean prevFlying = false;

    @Override
    public List<Aura.Position> getPositionHistory() {
        return this.positonHistory;
    }

    @Inject(method={"getHandSwingDuration"}, at={@At(value="HEAD")}, cancellable=true)
    private void getArmSwingAnimationEnd(CallbackInfoReturnable<Integer> info) {
        if (!ModuleManager.noRender.noSwing.getValue().booleanValue() && ModuleManager.animations.shouldChangeAnimationDuration() && Animations.slowAnimation.getValue().booleanValue()) {
            info.setReturnValue(Animations.slowAnimationVal.getValue());
        }
    }

    @Inject(method={"updateTrackedPositionAndAngles"}, at={@At(value="HEAD")})
    private void updateTrackedPositionAndAnglesHook(double x, double y, double z, float yaw, float pitch, int interpolationSteps, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        this.prevServerX = this.serverX;
        this.prevServerY = this.serverY;
        this.prevServerZ = this.serverZ;
        this.positonHistory.add(new Aura.Position(this.serverX, this.serverY, this.serverZ));
        this.positonHistory.removeIf(Aura.Position::shouldRemove);
    }

    @Override
    public double getPrevServerX() {
        return this.prevServerX;
    }

    @Override
    public double getPrevServerY() {
        return this.prevServerY;
    }

    @Override
    public double getPrevServerZ() {
        return this.prevServerZ;
    }

    @Inject(method={"travel"}, at={@At(value="HEAD")}, cancellable=true)
    public void travelHook(class_243 movementInput, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if ((class_1309)(Object)this != Module.mc.field_1724) {
            return;
        }
        EventTravel event = new EventTravel(Module.mc.field_1724.method_18798(), true);
        ThunderHack.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            Module.mc.field_1724.method_5784(class_1313.field_6308, event.getmVec());
            ci.cancel();
        }
    }

    @Inject(method={"travel"}, at={@At(value="RETURN")}, cancellable=true)
    public void travelPostHook(class_243 movementInput, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if ((class_1309)(Object)this != Module.mc.field_1724) {
            return;
        }
        EventTravel event = new EventTravel(movementInput, false);
        ThunderHack.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            Module.mc.field_1724.method_5784(class_1313.field_6308, Module.mc.field_1724.method_18798());
            ci.cancel();
        }
    }

    @ModifyVariable(method={"setSprinting"}, at=@At(value="HEAD"), ordinal=0, argsOnly=true)
    private boolean setSprintingHook(boolean sprinting) {
        return sprinting;
    }

    @Inject(method={"getHandSwingDuration"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetHandSwingDuration(CallbackInfoReturnable<Integer> cir) {
        if (ModuleManager.noRender.isEnabled() && ModuleManager.noRender.noSwing.getValue().booleanValue()) {
            cir.setReturnValue(0);
            cir.cancel();
        }
    }
}

