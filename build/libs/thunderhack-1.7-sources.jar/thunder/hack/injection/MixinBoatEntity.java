/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.Entity$PositionUpdater
 *  net.minecraft.entity.vehicle.BoatEntity
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package thunder.hack.injection;

import net.minecraft.class_1297;
import net.minecraft.class_1690;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1690.class})
public class MixinBoatEntity {
    @Unique
    private float prevYaw;
    @Unique
    private float prevHeadYaw;

    @Inject(method={"updatePassengerPosition"}, at={@At(value="HEAD")})
    protected void updatePassengerPositionHookPre(class_1297 passenger, class_1297.class_4738 positionUpdater, CallbackInfo ci) {
    }

    @Inject(method={"updatePassengerPosition"}, at={@At(value="RETURN")})
    protected void updatePassengerPositionHookPost(class_1297 passenger, class_1297.class_4738 positionUpdater, CallbackInfo ci) {
    }
}

