/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.RunArgs
 *  net.minecraft.client.gui.screen.Overlay
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.texture.NativeImage
 *  net.minecraft.client.util.Icons
 *  net.minecraft.client.util.MacWindowUtil
 *  net.minecraft.client.util.Window
 *  net.minecraft.resource.InputSupplier
 *  net.minecraft.resource.ResourcePack
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.glfw.GLFW
 *  org.lwjgl.glfw.GLFWImage
 *  org.lwjgl.glfw.GLFWImage$Buffer
 *  org.lwjgl.system.MemoryStack
 *  org.lwjgl.system.MemoryUtil
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_3262;
import net.minecraft.class_4071;
import net.minecraft.class_437;
import net.minecraft.class_542;
import net.minecraft.class_6417;
import net.minecraft.class_7367;
import net.minecraft.class_8518;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.ThunderHack;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventAttack;
import thunder.hack.events.impl.EventHandleBlockBreaking;
import thunder.hack.events.impl.EventPostTick;
import thunder.hack.events.impl.EventScreen;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.clickui.ClickGUI;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.render.WindowResizeCallback;

@Mixin(value={class_310.class})
public abstract class MixinMinecraftClient {
    @Shadow
    @Final
    private class_1041 window;
    @Unique
    private String[] shittyServers = new String[]{"mineblaze", "musteryworld", "dexland", "masedworld", "vimeworld", "hypemc", "vimemc"};

    @Shadow
    public abstract void setScreen(@Nullable class_437 var1);

    @Inject(method={"<init>"}, at={@At(value="TAIL")})
    void postWindowInit(class_542 args, CallbackInfo ci) {
        try {
            FontRenderers.settings = FontRenderers.create(12.0f, "comfortaa");
            FontRenderers.modules = FontRenderers.create(15.0f, "comfortaa");
            FontRenderers.categories = FontRenderers.create(18.0f, "comfortaa");
            FontRenderers.thglitch = FontRenderers.create(36.0f, "glitched");
            FontRenderers.thglitchBig = FontRenderers.create(72.0f, "glitched");
            FontRenderers.monsterrat = FontRenderers.create(18.0f, "monsterrat");
            FontRenderers.sf_bold = FontRenderers.create(16.0f, "sf_bold");
            FontRenderers.sf_medium = FontRenderers.create(16.0f, "sf_medium");
            FontRenderers.sf_medium_mini = FontRenderers.create(12.0f, "sf_medium");
            FontRenderers.sf_medium_modules = FontRenderers.create(14.0f, "sf_medium");
            FontRenderers.sf_bold_mini = FontRenderers.create(14.0f, "sf_bold");
            FontRenderers.sf_bold_micro = FontRenderers.create(12.0f, "sf_bold");
            FontRenderers.profont = FontRenderers.create(16.0f, "profont");
            FontRenderers.icons = FontRenderers.create(20.0f, "icons");
            FontRenderers.mid_icons = FontRenderers.create(46.0f, "icons");
            FontRenderers.big_icons = FontRenderers.create(72.0f, "icons");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    void preTickHook(CallbackInfo ci) {
        if (!Module.fullNullCheck()) {
            ThunderHack.EVENT_BUS.post(new EventTick());
        }
    }

    @Inject(method={"tick"}, at={@At(value="RETURN")})
    void postTickHook(CallbackInfo ci) {
        if (!Module.fullNullCheck()) {
            ThunderHack.EVENT_BUS.post(new EventPostTick());
        }
    }

    @Inject(method={"onResolutionChanged"}, at={@At(value="TAIL")})
    private void captureResize(CallbackInfo ci) {
        ((WindowResizeCallback)WindowResizeCallback.EVENT.invoker()).onResized((class_310)(Object)this, this.window);
    }

    @Inject(method={"doItemPick"}, at={@At(value="HEAD")}, cancellable=true)
    private void doItemPickHook(CallbackInfo ci) {
        if (ModuleManager.middleClick.isEnabled() && ModuleManager.middleClick.antiPickUp.getValue().booleanValue()) {
            ci.cancel();
        }
    }

    @Inject(method={"setOverlay"}, at={@At(value="HEAD")})
    public void setOverlay(class_4071 overlay, CallbackInfo ci) {
    }

    @Inject(method={"setScreen"}, at={@At(value="HEAD")}, cancellable=true)
    public void setScreenHookPre(class_437 screen, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        EventScreen event = new EventScreen(screen);
        ThunderHack.EVENT_BUS.post(event);
        if (event.isCancelled() || ClickGUI.close && screen == null) {
            ci.cancel();
        }
    }

    @Inject(method={"setScreen"}, at={@At(value="RETURN")})
    public void setScreenHookPost(class_437 screen, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
    }

    @Redirect(method={"<init>"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/Window;setIcon(Lnet/minecraft/resource/ResourcePack;Lnet/minecraft/client/util/Icons;)V"))
    private void onChangeIcon(class_1041 instance, class_3262 resourcePack, class_8518 icons) throws IOException {
        if (GLFW.glfwGetPlatform() == 393218) {
            class_6417.method_41718((class_7367)icons.method_51420(resourcePack));
            return;
        }
        this.setWindowIcon(ThunderHack.class.getResourceAsStream("/icon.png"), ThunderHack.class.getResourceAsStream("/icon.png"));
    }

    public void setWindowIcon(InputStream img16x16, InputStream img32x32) {
        try (MemoryStack memorystack = MemoryStack.stackPush();){
            GLFWImage.Buffer buffer = GLFWImage.malloc((int)2, (MemoryStack)memorystack);
            List<InputStream> imgList = List.of(img16x16, img32x32);
            ArrayList<ByteBuffer> buffers = new ArrayList<ByteBuffer>();
            for (int i = 0; i < imgList.size(); ++i) {
                InputStream is = imgList.get(i);
                if (is == null) continue;
                try {
                    class_1011 nativeImage = class_1011.method_4309((InputStream)is);
                    if (nativeImage == null) continue;
                    ByteBuffer bytebuffer = MemoryUtil.memAlloc((int)(nativeImage.method_4307() * nativeImage.method_4323() * 4));
                    bytebuffer.asIntBuffer().put(nativeImage.method_48463());
                    buffer.position(i);
                    buffer.width(nativeImage.method_4307());
                    buffer.height(nativeImage.method_4323());
                    buffer.pixels(bytebuffer);
                    buffers.add(bytebuffer);
                    continue;
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                if (GLFW.glfwGetPlatform() != 393219) {
                    GLFW.glfwSetWindowIcon((long)Module.mc.method_22683().method_4490(), (GLFWImage.Buffer)buffer);
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            buffers.forEach(MemoryUtil::memFree);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Inject(method={"doAttack"}, at={@At(value="HEAD")}, cancellable=true)
    private void doAttackHook(CallbackInfoReturnable<Boolean> cir) {
        EventAttack event = new EventAttack(null, true);
        ThunderHack.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method={"handleBlockBreaking"}, at={@At(value="HEAD")}, cancellable=true)
    private void handleBlockBreakingHook(boolean breaking, CallbackInfo ci) {
        EventHandleBlockBreaking event = new EventHandleBlockBreaking();
        ThunderHack.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}

