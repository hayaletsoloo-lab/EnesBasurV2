/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.scoreboard.ScoreboardEntry
 *  org.spongepowered.asm.mixin.Mixin
 */
package thunder.hack.injection;

import net.minecraft.class_9011;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={class_9011.class})
public class MixinScoreboardPlayerScore {
}

