/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelPart
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.entity.EndCrystalEntityRenderer
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.decoration.EndCrystalEntity
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package thunder.hack.injection;

import net.minecraft.class_1511;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_630;
import net.minecraft.class_892;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import thunder.hack.core.manager.client.ModuleManager;

@Mixin(value={class_892.class})
public class MixinEndCrystalEntityRenderer {
    @Shadow
    @Final
    private static float SINE_45_DEGREES;
    @Shadow
    @Final
    private class_630 core;
    @Shadow
    @Final
    private class_630 frame;

    @Inject(method={"render(Lnet/minecraft/entity/decoration/EndCrystalEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at={@At(value="HEAD")}, cancellable=true)
    public void render(class_1511 endCrystalEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo ci) {
        if (ModuleManager.chams.isEnabled() && ModuleManager.chams.crystals.getValue().booleanValue()) {
            ci.cancel();
            ModuleManager.chams.renderCrystal(endCrystalEntity, f, g, matrixStack, i, this.core, this.frame);
        }
    }
}

