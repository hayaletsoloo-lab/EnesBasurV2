/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.network.OtherClientPlayerEntity
 *  net.minecraft.client.world.ClientWorld
 *  net.minecraft.util.math.Vec3d
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 */
package thunder.hack.injection;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_243;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_745;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.features.modules.misc.FakePlayer;
import thunder.hack.utility.interfaces.IEntityLiving;
import thunder.hack.utility.interfaces.IOtherClientPlayerEntity;

@Mixin(value={class_745.class})
public class MixinOtherClientPlayerEntity
extends class_742
implements IOtherClientPlayerEntity {
    @Unique
    private double backUpX;
    @Unique
    private double backUpY;
    @Unique
    private double backUpZ;

    public MixinOtherClientPlayerEntity(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @Override
    public void resolve(Aura.Resolver mode) {
        if ((Object)this == FakePlayer.fakePlayer) {
            this.backUpY = -999.0;
            return;
        }
        this.backUpX = this.method_23317();
        this.backUpY = this.method_23318();
        this.backUpZ = this.method_23321();
        if (mode == Aura.Resolver.BackTrack) {
            double minDst = 999.0;
            Aura.Position bestPos = null;
            for (Aura.Position p : ((IEntityLiving)((Object)this)).getPositionHistory()) {
                double dst = Module.mc.field_1724.method_5649(p.getX(), p.getY(), p.getZ());
                if (!(dst < minDst)) continue;
                minDst = dst;
                bestPos = p;
            }
            if (bestPos != null) {
                this.method_5814(bestPos.getX(), bestPos.getY(), bestPos.getZ());
                if (Aura.target == this) {
                    ModuleManager.aura.resolvedBox = this.method_5829();
                }
            }
            return;
        }
        class_243 from = new class_243(((IEntityLiving)((Object)this)).getPrevServerX(), ((IEntityLiving)((Object)this)).getPrevServerY(), ((IEntityLiving)((Object)this)).getPrevServerZ());
        class_243 to = new class_243(this.field_6224, this.field_6245, this.field_6263);
        if (mode == Aura.Resolver.Advantage) {
            if (Module.mc.field_1724.method_5707(from) > Module.mc.field_1724.method_5707(to)) {
                this.method_5814(to.field_1352, to.field_1351, to.field_1350);
            } else {
                this.method_5814(from.field_1352, from.field_1351, from.field_1350);
            }
        } else {
            this.method_5814(to.field_1352, to.field_1351, to.field_1350);
        }
        if (Aura.target == this) {
            ModuleManager.aura.resolvedBox = this.method_5829();
        }
    }

    @Override
    public void releaseResolver() {
        if (this.backUpY != -999.0) {
            this.method_5814(this.backUpX, this.backUpY, this.backUpZ);
            this.backUpY = -999.0;
        }
    }
}

