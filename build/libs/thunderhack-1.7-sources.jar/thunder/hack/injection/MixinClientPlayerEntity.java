/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.client.world.ClientWorld
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.MovementType
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.util.math.Vec3d
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.ThunderHack;
import thunder.hack.core.Core;
import thunder.hack.events.impl.EventAfterRotate;
import thunder.hack.events.impl.EventMove;
import thunder.hack.events.impl.EventPostSync;
import thunder.hack.events.impl.EventSprint;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.events.impl.PostPlayerUpdateEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IClientPlayerEntity;

@Mixin(value={class_746.class}, priority=800)
public abstract class MixinClientPlayerEntity
extends class_742 {
    @Unique
    boolean pre_sprint_state = false;
    @Unique
    private boolean updateLock = false;
    @Unique
    private Runnable postAction;

    @Shadow
    public abstract float method_5695(float var1);

    @Shadow
    protected abstract void sendMovementPackets();

    public MixinClientPlayerEntity(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    public void tickHook(CallbackInfo info) {
        if (Module.fullNullCheck()) {
            return;
        }
        ThunderHack.EVENT_BUS.post(new PlayerUpdateEvent());
    }

    @Redirect(method={"tickMovement"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"), require=0)
    private boolean tickMovementHook(class_746 player) {
        return player.method_6115();
    }

    @Inject(method={"shouldSlowDown"}, at={@At(value="HEAD")}, cancellable=true)
    public void shouldSlowDownHook(CallbackInfoReturnable<Boolean> cir) {
    }

    @Inject(method={"move"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/AbstractClientPlayerEntity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V")}, cancellable=true)
    public void onMoveHook(class_1313 movementType, class_243 movement, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        EventMove event = new EventMove(movement.field_1352, movement.field_1351, movement.field_1350);
        ThunderHack.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            super.method_5784(movementType, new class_243(event.getX(), event.getY(), event.getZ()));
            ci.cancel();
        }
    }

    @Inject(method={"sendMovementPackets"}, at={@At(value="HEAD")}, cancellable=true)
    private void sendMovementPacketsHook(CallbackInfo info) {
        if (Module.fullNullCheck()) {
            return;
        }
        EventSync event = new EventSync(this.method_36454(), this.method_36455());
        ThunderHack.EVENT_BUS.post(event);
        this.postAction = event.getPostAction();
        EventSprint e = new EventSprint(this.method_5624());
        ThunderHack.EVENT_BUS.post(e);
        ThunderHack.EVENT_BUS.post(new EventAfterRotate());
        if (e.getSprintState() != ((IClientPlayerEntity)Module.mc.field_1724).getLastSprinting()) {
            if (e.getSprintState()) {
                Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)(Object)this, class_2848.class_2849.field_12981));
            } else {
                Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)(Object)this, class_2848.class_2849.field_12985));
            }
            ((IClientPlayerEntity)Module.mc.field_1724).setLastSprinting(e.getSprintState());
        }
        this.pre_sprint_state = ((IClientPlayerEntity)Module.mc.field_1724).getLastSprinting();
        Core.lockSprint = true;
        if (event.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method={"sendMovementPackets"}, at={@At(value="RETURN")}, cancellable=true)
    private void sendMovementPacketsPostHook(CallbackInfo info) {
        if (Module.fullNullCheck()) {
            return;
        }
        ((IClientPlayerEntity)Module.mc.field_1724).setLastSprinting(this.pre_sprint_state);
        Core.lockSprint = false;
        EventPostSync event = new EventPostSync();
        ThunderHack.EVENT_BUS.post(event);
        if (this.postAction != null) {
            this.postAction.run();
            this.postAction = null;
        }
        if (event.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;sendMovementPackets()V", ordinal=0, shift=At.Shift.AFTER)}, cancellable=true)
    private void PostUpdateHook(CallbackInfo info) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (this.updateLock) {
            return;
        }
        PostPlayerUpdateEvent playerUpdateEvent = new PostPlayerUpdateEvent();
        ThunderHack.EVENT_BUS.post(playerUpdateEvent);
        if (playerUpdateEvent.isCancelled()) {
            info.cancel();
            if (playerUpdateEvent.getIterations() > 0) {
                for (int i = 0; i < playerUpdateEvent.getIterations(); ++i) {
                    this.updateLock = true;
                    this.method_5773();
                    this.updateLock = false;
                    this.sendMovementPackets();
                }
            }
        }
    }

    @Inject(method={"pushOutOfBlocks"}, at={@At(value="HEAD")}, cancellable=true)
    private void onPushOutOfBlocksHook(double x, double d, CallbackInfo info) {
    }

    @Inject(method={"tickNausea"}, at={@At(value="HEAD")}, cancellable=true)
    private void updateNauseaHook(CallbackInfo ci) {
    }
}

