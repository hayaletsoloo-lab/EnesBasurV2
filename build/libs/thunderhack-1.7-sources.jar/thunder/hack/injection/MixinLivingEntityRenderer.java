/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.render.VertexConsumer
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.entity.LivingEntityRenderer
 *  net.minecraft.client.render.entity.feature.FeatureRenderer
 *  net.minecraft.client.render.entity.model.EntityModel
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityPose
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.MathHelper
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package thunder.hack.injection;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3887;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.injection.accesors.IClientPlayerEntity;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

@Mixin(value={class_922.class})
public abstract class MixinLivingEntityRenderer<T extends class_1309, M extends class_583<T>> {
    private class_1309 lastEntity;
    private float originalHeadYaw;
    private float originalPrevHeadYaw;
    private float originalPrevHeadPitch;
    private float originalHeadPitch;
    @Shadow
    protected M model;
    @Shadow
    @Final
    protected List<class_3887<T, M>> features;

    @Inject(method={"render"}, at={@At(value="HEAD")}, cancellable=true)
    public void onRenderPre(T livingEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (Module.mc.field_1724 != null && livingEntity == Module.mc.field_1724 && Module.mc.field_1724.method_49694() == null && ClientSettings.renderRotations.getValue().booleanValue() && !ThunderHack.isFuturePresent()) {
            this.originalHeadYaw = ((class_1309)livingEntity).field_6241;
            this.originalPrevHeadYaw = ((class_1309)livingEntity).field_6259;
            this.originalPrevHeadPitch = ((class_1309)livingEntity).field_6004;
            this.originalHeadPitch = livingEntity.method_36455();
            livingEntity.method_36457(((IClientPlayerEntity)class_310.method_1551().field_1724).getLastPitch());
            ((class_1309)livingEntity).field_6004 = Managers.PLAYER.lastPitch;
            ((class_1309)livingEntity).field_6241 = ((IClientPlayerEntity)class_310.method_1551().field_1724).getLastYaw();
            ((class_1309)livingEntity).field_6283 = Render2DEngine.interpolateFloat(Managers.PLAYER.prevBodyYaw, Managers.PLAYER.bodyYaw, Render3DEngine.getTickDelta());
            ((class_1309)livingEntity).field_6259 = Managers.PLAYER.lastYaw;
            ((class_1309)livingEntity).field_6220 = Render2DEngine.interpolateFloat(Managers.PLAYER.prevBodyYaw, Managers.PLAYER.bodyYaw, Render3DEngine.getTickDelta());
        }
        if (livingEntity != Module.mc.field_1724 && ModuleManager.freeCam.isEnabled() && ModuleManager.freeCam.track.getValue().booleanValue() && ModuleManager.freeCam.trackEntity != null && ModuleManager.freeCam.trackEntity == livingEntity) {
            ci.cancel();
            return;
        }
        this.lastEntity = livingEntity;
        if (livingEntity instanceof class_1657) {
            class_1657 pe = (class_1657)livingEntity;
            if (ModuleManager.chams.isEnabled() && ModuleManager.chams.players.getValue().booleanValue()) {
                ModuleManager.chams.renderPlayer(pe, f, g, matrixStack, i, (class_583)(Object)this.model, ci, () -> this.postRender(livingEntity));
                if (!pe.method_7325()) {
                    float n;
                    class_2350 direction;
                    float l;
                    class_1297 entity;
                    matrixStack.method_22903();
                    float h = class_3532.method_17821((float)g, (float)pe.field_6220, (float)pe.field_6283);
                    float j = class_3532.method_17821((float)g, (float)pe.field_6259, (float)pe.field_6241);
                    float k = j - h;
                    if (pe.method_5765() && (entity = pe.method_5854()) instanceof class_1309) {
                        class_1309 livingEntity2 = (class_1309)entity;
                        h = class_3532.method_17821((float)g, (float)livingEntity2.field_6220, (float)livingEntity2.field_6283);
                        k = j - h;
                        l = class_3532.method_15393((float)k);
                        if (l < -85.0f) {
                            l = -85.0f;
                        }
                        if (l >= 85.0f) {
                            l = 85.0f;
                        }
                        h = j - l;
                        if (l * l > 2500.0f) {
                            h += l * 0.2f;
                        }
                        k = j - h;
                    }
                    float m = class_3532.method_16439((float)g, (float)pe.field_6004, (float)pe.method_36455());
                    if (class_922.method_38563((class_1309)pe)) {
                        m *= -1.0f;
                        k *= -1.0f;
                    }
                    if (pe.method_41328(class_4050.field_18078) && (direction = pe.method_18401()) != null) {
                        n = pe.method_18381(class_4050.field_18076) - 0.1f;
                        matrixStack.method_46416((float)(-direction.method_10148()) * n, 0.0f, (float)(-direction.method_10165()) * n);
                    }
                    l = (float)pe.field_6012 + g;
                    ModuleManager.chams.setupTransforms1(pe, matrixStack, l, h, g);
                    matrixStack.method_22905(-1.0f, -1.0f, 1.0f);
                    matrixStack.method_22905(0.9375f, 0.9375f, 0.9375f);
                    matrixStack.method_46416(0.0f, -1.501f, 0.0f);
                    n = 0.0f;
                    float o = 0.0f;
                    if (!pe.method_5765() && pe.method_5805()) {
                        n = pe.field_42108.method_48570(g);
                        o = pe.field_42108.method_48572(g);
                        if (pe.method_6109()) {
                            o *= 3.0f;
                        }
                        if (n > 1.0f) {
                            n = 1.0f;
                        }
                    }
                    for (class_3887<T, M> featureRenderer : this.features) {
                        featureRenderer.method_4199(matrixStack, vertexConsumerProvider, i, livingEntity, o, n, g, l, k, m);
                    }
                    matrixStack.method_22909();
                }
            }
        }
    }

    @Unique
    public void postRender(T livingEntity) {
        if (Module.fullNullCheck()) {
            return;
        }
        if (Module.mc.field_1724 != null && livingEntity == Module.mc.field_1724 && Module.mc.field_1724.method_49694() == null && ClientSettings.renderRotations.getValue().booleanValue() && !ThunderHack.isFuturePresent()) {
            ((class_1309)livingEntity).field_6004 = this.originalPrevHeadPitch;
            livingEntity.method_36457(this.originalHeadPitch);
            ((class_1309)livingEntity).field_6241 = this.originalHeadYaw;
            ((class_1309)livingEntity).field_6259 = this.originalPrevHeadYaw;
        }
    }

    @Inject(method={"render"}, at={@At(value="TAIL")})
    public void onRenderPost(T livingEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo ci) {
        if (Module.fullNullCheck()) {
            return;
        }
        this.postRender(livingEntity);
    }

    @Redirect(method={"render"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/render/entity/model/EntityModel;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"))
    private void renderModelHook(class_583<T> instance, class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
        class_1657 pl;
        class_1309 class_13092;
        if (Module.fullNullCheck()) {
            return;
        }
        if (ModuleManager.customModels.isEnabled() && this.lastEntity == Module.mc.field_1724) {
            float tickDelta = Module.mc.method_60646().method_60637(true);
            if (ModuleManager.customModels.onRenderModel(matrices, (class_4597)class_310.method_1551().method_22940().method_23000(), light, overlay, this.lastEntity, tickDelta)) {
                return;
            }
        }
        float alpha = -1.0f;
        if (ModuleManager.noRender.isEnabled() && ModuleManager.noRender.antiPlayerCollision.getValue().booleanValue() && this.lastEntity != Module.mc.field_1724 && (class_13092 = this.lastEntity) instanceof class_1657 && !(pl = (class_1657)class_13092).method_5767()) {
            alpha = MathUtility.clamp((float)(Module.mc.field_1724.method_5707(this.lastEntity.method_19538()) / 3.0) + 0.2f, 0.0f, 1.0f);
        }
        if (this.lastEntity != Module.mc.field_1724 && (class_13092 = this.lastEntity) instanceof class_1657 && (pl = (class_1657)class_13092).method_5767()) {
            alpha = 0.3f;
        }
        if (alpha != -1.0f) {
            color = Render2DEngine.applyOpacity(0x26FFFFFF, alpha);
        }
        instance.method_2828(matrices, vertices, light, overlay, color);
    }
}

