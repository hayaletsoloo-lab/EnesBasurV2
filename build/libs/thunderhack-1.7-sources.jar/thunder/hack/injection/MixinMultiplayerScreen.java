/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen
 *  net.minecraft.client.gui.widget.ButtonWidget
 *  net.minecraft.client.gui.widget.ButtonWidget$Builder
 *  net.minecraft.text.Text
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package thunder.hack.injection;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import thunder.hack.core.manager.IManager;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.gui.windows.WindowsScreen;
import thunder.hack.gui.windows.impl.ConfigWindow;
import thunder.hack.gui.windows.impl.FriendsWindow;
import thunder.hack.gui.windows.impl.MacroWindow;
import thunder.hack.gui.windows.impl.ProxyWindow;
import thunder.hack.gui.windows.impl.WaypointWindow;

@Mixin(value={class_500.class})
public abstract class MixinMultiplayerScreen
extends class_437 {
    public MixinMultiplayerScreen(class_2561 title) {
        super(title);
    }

    @Inject(method={"init"}, at={@At(value="RETURN")})
    private void initHook(CallbackInfo ci) {
        class_4185.class_7840 builder = class_4185.method_46430((class_2561)class_2561.method_43470((String)"\u26a1"), button -> IManager.mc.method_1507((class_437)new WindowsScreen(MacroWindow.get(ModuleManager.windows.macroPos.getValue().getX() * (float)IManager.mc.method_22683().method_4486(), ModuleManager.windows.macroPos.getValue().getY() * (float)IManager.mc.method_22683().method_4502(), ModuleManager.windows.macroPos), ConfigWindow.get(ModuleManager.windows.configPos.getValue().getX() * (float)IManager.mc.method_22683().method_4486(), ModuleManager.windows.configPos.getValue().getY() * (float)IManager.mc.method_22683().method_4502(), ModuleManager.windows.configPos), FriendsWindow.get(ModuleManager.windows.friendPos.getValue().getX() * (float)IManager.mc.method_22683().method_4486(), ModuleManager.windows.friendPos.getValue().getY() * (float)IManager.mc.method_22683().method_4502(), ModuleManager.windows.friendPos), WaypointWindow.get(ModuleManager.windows.waypointPos.getValue().getX() * (float)IManager.mc.method_22683().method_4486(), ModuleManager.windows.waypointPos.getValue().getY() * (float)IManager.mc.method_22683().method_4502(), ModuleManager.windows.waypointPos), ProxyWindow.get(ModuleManager.windows.proxyPos.getValue().getX() * (float)IManager.mc.method_22683().method_4486(), ModuleManager.windows.proxyPos.getValue().getY() * (float)IManager.mc.method_22683().method_4502(), ModuleManager.windows.proxyPos)))).method_46437(60, 20);
        if (!ModuleManager.unHook.isEnabled()) {
            this.method_37063(builder.method_46433(this.field_22789 - 65, this.field_22790 - 25).method_46431());
        }
    }
}

