/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.AbstractBlock
 *  net.minecraft.block.BlockState
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.registry.RegistryKeys
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.BlockView
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.player.AutoTool;

@Mixin(value={class_4970.class})
public abstract class MixinAbstractBlock {
    @Inject(method={"calcBlockBreakingDelta"}, at={@At(value="HEAD")}, cancellable=true)
    public void calcBlockBreakingDeltaHook(class_2680 state, class_1657 player, class_1922 world, class_2338 pos, CallbackInfoReturnable<Float> ci) {
        if (ModuleManager.autoTool.isEnabled() && AutoTool.silent.getValue().booleanValue()) {
            float f = state.method_26214(world, pos);
            if (f < 0.0f) {
                ci.setReturnValue(Float.valueOf(0.0f));
            } else {
                float dig_speed = this.getDigSpeed(state, player, player.method_31548().method_5438(AutoTool.itemIndex)) / f;
                ci.setReturnValue(Float.valueOf(player.method_31548().method_5438(AutoTool.itemIndex).method_7951(state) ? dig_speed / 30.0f : dig_speed / 100.0f));
            }
        }
    }

    public float getDigSpeed(class_2680 state, class_1657 player, class_1799 stack) {
        int effect;
        float str = stack.method_7924(state);
        if (str > 1.0f && (effect = class_1890.method_8225((class_6880)((class_6880)player.method_37908().method_30349().method_30530(class_7924.field_41265).method_40264(class_1893.field_9131).get()), (class_1799)stack)) > 0) {
            str += (float)(effect * effect + 1);
        }
        return Math.max(str, 0.0f);
    }
}

