/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.font.TextRenderer
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.text.MutableText
 *  net.minecraft.text.OrderedText
 *  net.minecraft.text.Text
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.gui.font.FontRenderers;

@Mixin(value={class_332.class})
public class MixinDrawContext {
    @Shadow
    @Final
    private class_4587 matrices;

    public void drawTextHook(class_327 textRenderer, class_5481 text, int x, int y, int color, boolean shadow, CallbackInfoReturnable<Integer> cir) {
        class_5250 text1 = class_2561.method_43473();
        text.accept((i, style, codePoint) -> {
            text1.method_10852((class_2561)class_2561.method_43470((String)new String(Character.toChars(codePoint))).method_10862(style));
            return true;
        });
        FontRenderers.sf_medium.drawString(this.matrices, text1.getString(), (double)x, (double)y, color);
        cir.setReturnValue(Math.round(FontRenderers.sf_medium.getStringWidth(text1.getString())));
    }
}

