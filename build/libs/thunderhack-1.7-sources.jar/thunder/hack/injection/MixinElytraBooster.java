/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.ClientPlayerEntity
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package thunder.hack.injection;

import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import thunder.hack.features.modules.movement.ElytraBooster;

@Mixin(value={class_746.class})
public class MixinElytraBooster {
    @Inject(method={"tickMovement"}, at={@At(value="HEAD")})
    private void onTickMovement(CallbackInfo info) {
        class_746 player = (class_746)(Object)this;
        if (!ElytraBooster.getInstance().isEnabled()) {
            return;
        }
        if (player.method_6128()) {
            player.field_3913.field_3905 = 0.0f;
            player.field_3913.field_3907 = 0.0f;
        }
    }
}

