/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.LightmapTextureManager
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.dimension.DimensionType
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package thunder.hack.injection;

import net.minecraft.class_2874;
import net.minecraft.class_3532;
import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.render.Fullbright;

@Mixin(value={class_765.class})
public class MixinLightmapTextureManager {
    @Inject(method={"getDarknessFactor(F)F"}, at={@At(value="HEAD")}, cancellable=true)
    private void getDarknessFactor(float tickDelta, CallbackInfoReturnable<Float> info) {
        if (ModuleManager.noRender.isEnabled() && ModuleManager.noRender.darkness.getValue().booleanValue()) {
            info.setReturnValue(Float.valueOf(0.0f));
        }
    }

    @Inject(method={"getBrightness"}, at={@At(value="HEAD")}, cancellable=true)
    private static void getBrightnessHook(class_2874 type, int lightLevel, CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.fullbright.isEnabled()) {
            float f = (float)lightLevel / 15.0f;
            float g = f / (4.0f - 3.0f * f);
            cir.setReturnValue(Float.valueOf(Math.max(class_3532.method_16439((float)type.comp_656(), (float)g, (float)1.0f), Fullbright.minBright.getValue().floatValue())));
        }
    }
}

