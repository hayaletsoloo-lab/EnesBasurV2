/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.entity.feature.CapeFeatureRenderer
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.MathHelper
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package thunder.hack.injection;

import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_972;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_972.class})
public class MixinCapeFeatureRenderer {
    @ModifyVariable(method={"render"}, at=@At(value="STORE"), ordinal=6)
    private float renderHook(float n, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, class_742 abstractClientPlayerEntity, float f, float g, float h, float j, float k, float l) {
        return class_3532.method_16439((float)h, (float)abstractClientPlayerEntity.field_6220, (float)abstractClientPlayerEntity.field_6283);
    }
}

