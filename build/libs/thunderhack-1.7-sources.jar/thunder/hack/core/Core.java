/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$OnGroundOnly
 *  net.minecraft.network.packet.s2c.play.GameJoinS2CPacket
 *  net.minecraft.network.packet.s2c.play.GameMessageS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket
 *  net.minecraft.sound.SoundCategory
 *  net.minecraft.sound.SoundEvents
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec2f
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.core;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_2596;
import net.minecraft.class_2678;
import net.minecraft.class_2708;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_7439;
import net.minecraft.class_7833;
import org.jetbrains.annotations.NotNull;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.MacroManager;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventDeath;
import thunder.hack.events.impl.EventKeyPress;
import thunder.hack.events.impl.EventMouse;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.gui.notification.Notification;
import thunder.hack.gui.thundergui.ThunderGui;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;
import thunder.hack.utility.render.animation.CaptureMark;

public final class Core {
    public static boolean lockSprint;
    public static boolean serverSprint;
    public static boolean hold_mouse0;
    public static boolean showSkull;
    public static final Map<String, class_2960> HEADS;
    public ArrayList<class_2596<?>> silentPackets = new ArrayList();
    private final Timer skullTimer = new Timer();
    private final Timer lastPacket = new Timer();
    private final Timer autoSave = new Timer();
    private final Timer setBackTimer = new Timer();

    @EventHandler
    public void onTick(PlayerUpdateEvent event) {
        if (Module.fullNullCheck()) {
            return;
        }
        Managers.NOTIFICATION.onUpdate();
        Managers.MODULE.onUpdate();
        ThunderGui.getInstance().onTick();
        if (ModuleManager.clickGui.getBind().getKey() == -1) {
            Command.sendMessage(String.valueOf(class_124.field_1061) + (ClientSettings.isRu() ? "\u041f\u0440\u0438\u0432\u044f\u0437\u043a\u0430 \u043a\u043b\u0430\u0432\u0438\u0448 Clickgui \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e -> P" : "Default clickgui keybind --> P"));
            Command.sendMessage(String.valueOf(class_124.field_1061) + (ClientSettings.isRu() ? "\u0412\u044b \u043c\u043e\u0436\u0435\u0442\u0435 \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u0433\u043e\u0442\u043e\u0432\u0443\u044e \u043a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044e, \u0432\u044b\u043f\u043e\u043b\u043d\u0438\u0432 \u0441\u043b\u0435\u0434\u0443\u044e\u0449\u0443\u044e \u043a\u043e\u043c\u0430\u043d\u0434\u0443 -> @cfg cloudlist." : "You can obtain a pre-built configuration by executing the following command -> @cfg cloudlist."));
            ModuleManager.clickGui.setBind(class_3675.method_15981((String)"key.keyboard.p").method_1444(), false, false);
        }
        for (class_1657 p : Module.mc.field_1687.method_18456()) {
            if (!p.method_29504() && p.method_6032() != 0.0f) continue;
            ThunderHack.EVENT_BUS.post(new EventDeath(p));
        }
        if (!Objects.equals(Managers.COMMAND.getPrefix(), ClientSettings.prefix.getValue())) {
            Managers.COMMAND.setPrefix(ClientSettings.prefix.getValue());
        }
        new HashMap<class_2338, Long>(InteractionUtility.awaiting).forEach((bp, time) -> {
            if ((float)(System.currentTimeMillis() - time) > (float)Managers.SERVER.getPing() * 2.0f) {
                InteractionUtility.awaiting.remove(bp);
            }
        });
        if (this.autoSave.every(600000L)) {
            Managers.FRIEND.saveFriends();
            Managers.CONFIG.save(Managers.CONFIG.getCurrentConfig());
            Managers.WAYPOINT.saveWayPoints();
            Managers.MACRO.saveMacro();
            Managers.NOTIFICATION.publicity("AutoSave", ClientSettings.isRu() ? "\u0421\u043e\u0445\u0440\u0430\u043d\u044f\u044e \u043a\u043e\u043d\u0444\u0438\u0433.." : "Saving config..", 3, Notification.Type.INFO);
        }
    }

    @EventHandler
    public void onPacketSend(@NotNull PacketEvent.Send e) {
        class_2848 c;
        Object t;
        if (e.getPacket() instanceof class_2828 && !(e.getPacket() instanceof class_2828.class_5911)) {
            this.lastPacket.reset();
        }
        if ((t = e.getPacket()) instanceof class_2848 && ((c = (class_2848)t).method_12365() == class_2848.class_2849.field_12981 || c.method_12365() == class_2848.class_2849.field_12985)) {
            if (lockSprint) {
                e.cancel();
                return;
            }
            switch (c.method_12365()) {
                case field_12981: {
                    serverSprint = true;
                    break;
                }
                case field_12985: {
                    serverSprint = false;
                }
            }
        }
    }

    @EventHandler
    public void onSync(EventSync event) {
        if (Module.fullNullCheck()) {
            return;
        }
        CaptureMark.tick();
        Render3DEngine.updateTargetESP();
    }

    public void onRender2D(class_332 e) {
        this.drawGps(e);
        this.drawSkull(e);
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        class_7439 packet;
        if (Module.fullNullCheck()) {
            return;
        }
        if (e.getPacket() instanceof class_7439 && (packet = (class_7439)e.getPacket()).comp_763().getString().contains("skull")) {
            showSkull = true;
            this.skullTimer.reset();
            Module.mc.field_1687.method_8396((class_1657)Module.mc.field_1724, Module.mc.field_1724.method_24515(), class_3417.field_14877, class_3419.field_15245, 1.0f, 1.0f);
        }
        if (e.getPacket() instanceof class_2678) {
            Managers.MODULE.onLogin();
        }
        if (e.getPacket() instanceof class_2708) {
            this.setBackTimer.reset();
        }
    }

    public void drawSkull(class_332 e) {
        if (showSkull && !this.skullTimer.passedMs(3000L) && ClientSettings.skullEmoji.getValue().booleanValue()) {
            int xPos = (int)((float)Module.mc.method_22683().method_4486() / 2.0f - 150.0f);
            int yPos = (int)((float)Module.mc.method_22683().method_4502() / 2.0f - 150.0f);
            float alpha = 1.0f - (float)this.skullTimer.getPassedTimeMs() / 3000.0f;
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
            e.method_25290(TextureStorage.skull, xPos, yPos, 0.0f, 0.0f, 300, 300, 300, 300);
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        } else {
            showSkull = false;
        }
    }

    public void drawGps(class_332 e) {
        if (ThunderHack.gps_position != null) {
            float dst = this.getDistance(ThunderHack.gps_position);
            float xOffset = (float)Module.mc.method_22683().method_4486() / 2.0f;
            float yOffset = (float)Module.mc.method_22683().method_4502() / 2.0f;
            float yaw = Core.getRotations(new class_241((float)ThunderHack.gps_position.method_10263(), (float)ThunderHack.gps_position.method_10260())) - Module.mc.field_1724.method_36454();
            e.method_51448().method_46416(xOffset, yOffset, 0.0f);
            e.method_51448().method_22907(class_7833.field_40718.rotationDegrees(yaw));
            e.method_51448().method_46416(-xOffset, -yOffset, 0.0f);
            Render2DEngine.drawTracerPointer(e.method_51448(), xOffset, yOffset - 50.0f, 12.5f, 0.5f, 3.63f, true, true, HudEditor.getColor(1).getRGB());
            e.method_51448().method_46416(xOffset, yOffset, 0.0f);
            e.method_51448().method_22907(class_7833.field_40718.rotationDegrees(-yaw));
            e.method_51448().method_46416(-xOffset, -yOffset, 0.0f);
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            FontRenderers.modules.drawCenteredString(e.method_51448(), "gps (" + dst + "m)", (double)((float)(Math.sin(Math.toRadians(yaw)) * 50.0) + xOffset), (double)((float)((double)yOffset - Math.cos(Math.toRadians(yaw)) * 50.0) - 23.0f), -1);
            if (dst < 10.0f) {
                ThunderHack.gps_position = null;
            }
        }
    }

    @EventHandler
    public void onKeyPress(EventKeyPress event) {
        if (event.getKey() == -1) {
            return;
        }
        for (MacroManager.Macro m : Managers.MACRO.getMacros()) {
            if (m.getBind() != event.getKey()) continue;
            m.runMacro();
        }
    }

    @EventHandler
    public void onMouse(EventMouse event) {
        if (event.getAction() == 0) {
            hold_mouse0 = false;
        }
        if (event.getAction() == 1) {
            hold_mouse0 = true;
        }
    }

    public int getDistance(class_2338 bp) {
        double d0 = Module.mc.field_1724.method_23317() - (double)bp.method_10263();
        double d2 = Module.mc.field_1724.method_23321() - (double)bp.method_10260();
        return (int)class_3532.method_15355((float)((float)(d0 * d0 + d2 * d2)));
    }

    public long getSetBackTime() {
        return this.setBackTimer.getPassedTimeMs();
    }

    public static float getRotations(class_241 vec) {
        if (Module.mc.field_1724 == null) {
            return 0.0f;
        }
        double x = (double)vec.field_1343 - Module.mc.field_1724.method_19538().field_1352;
        double z = (double)vec.field_1342 - Module.mc.field_1724.method_19538().field_1350;
        return (float)(-(Math.atan2(x, z) * 57.29577951308232));
    }

    public void bobView(class_4587 matrices, float tickDelta) {
        class_1297 class_12972 = Module.mc.method_1560();
        if (!(class_12972 instanceof class_1657)) {
            return;
        }
        class_1657 playerEntity = (class_1657)class_12972;
        float g = -(playerEntity.field_5973 + (playerEntity.field_5973 - playerEntity.field_6039) * tickDelta);
        float h = class_3532.method_16439((float)tickDelta, (float)playerEntity.field_7505, (float)playerEntity.field_7483);
        matrices.method_22904((double)(class_3532.method_15374((float)(g * (float)Math.PI)) * h * 0.1f), (double)(-Math.abs(class_3532.method_15362((float)(g * (float)Math.PI)) * h)) * 0.3, 0.0);
        matrices.method_22907(class_7833.field_40718.rotationDegrees(class_3532.method_15374((float)(g * (float)Math.PI)) * h * 3.0f));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(Math.abs(class_3532.method_15362((float)(g * (float)Math.PI - 0.2f)) * h) * 0.3f));
    }

    static {
        HEADS = new ConcurrentHashMap<String, class_2960>();
    }
}

