/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EquipmentSlot
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.projectile.ProjectileUtil
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket
 *  net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.EntityHitResult
 *  net.minecraft.util.hit.HitResult
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.Vec2f
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext$FluidHandling
 *  net.minecraft.world.RaycastContext$ShapeType
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.core.manager.player;

import java.util.ArrayDeque;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1675;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2735;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.manager.IManager;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventFixVelocity;
import thunder.hack.events.impl.EventKeyboardInput;
import thunder.hack.events.impl.EventPlayerJump;
import thunder.hack.events.impl.EventPlayerTravel;
import thunder.hack.events.impl.EventPostSync;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.EventTick;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.injection.accesors.IClientPlayerEntity;
import thunder.hack.utility.Timer;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.world.ExplosionUtility;

public class PlayerManager
implements IManager {
    public float yaw;
    public float pitch;
    public float lastYaw;
    public float lastPitch;
    public float currentPlayerSpeed;
    public float averagePlayerSpeed;
    public int ticksElytraFlying;
    public int serverSideSlot;
    public final Timer switchTimer = new Timer();
    private final ArrayDeque<Float> speedResult = new ArrayDeque(20);
    public float bodyYaw;
    public float prevBodyYaw;
    public boolean inInventory;

    @EventHandler(priority=200)
    public void onSync(EventSync event) {
        if (Module.fullNullCheck()) {
            return;
        }
        this.yaw = PlayerManager.mc.field_1724.method_36454();
        this.pitch = PlayerManager.mc.field_1724.method_36455();
        this.lastYaw = ((IClientPlayerEntity)PlayerManager.mc.field_1724).getLastYaw();
        this.lastPitch = ((IClientPlayerEntity)PlayerManager.mc.field_1724).getLastPitch();
        if (PlayerManager.mc.field_1755 == null) {
            this.inInventory = false;
        }
        this.ticksElytraFlying = PlayerManager.mc.field_1724.method_6128() && PlayerManager.mc.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833 ? (this.ticksElytraFlying = this.ticksElytraFlying + 1) : 0;
    }

    @EventHandler
    public void onTick(EventTick e) {
        this.currentPlayerSpeed = (float)Math.hypot(PlayerManager.mc.field_1724.method_23317() - PlayerManager.mc.field_1724.field_6014, PlayerManager.mc.field_1724.method_23321() - PlayerManager.mc.field_1724.field_5969);
        if (this.speedResult.size() > 20) {
            this.speedResult.poll();
        }
        this.speedResult.add(Float.valueOf(this.currentPlayerSpeed));
        float average = 0.0f;
        for (Float value : this.speedResult) {
            average += MathUtility.clamp(value.floatValue(), 0.0f, 20.0f);
        }
        this.averagePlayerSpeed = average / (float)this.speedResult.size();
    }

    @EventHandler(priority=-200)
    public void postSync(EventPostSync event) {
        if (PlayerManager.mc.field_1724 == null) {
            return;
        }
        this.prevBodyYaw = this.bodyYaw;
        this.bodyYaw = this.getBodyYaw();
        if (!ModuleManager.rotations.clientLook.getValue().booleanValue()) {
            PlayerManager.mc.field_1724.method_36456(this.yaw);
            PlayerManager.mc.field_1724.method_36457(this.pitch);
        }
        ModuleManager.rotations.fixRotation = Float.NaN;
    }

    @EventHandler
    public void onJump(EventPlayerJump e) {
        ModuleManager.rotations.onJump(e);
    }

    @EventHandler
    public void onPlayerMove(EventFixVelocity e) {
        ModuleManager.rotations.onPlayerMove(e);
    }

    @EventHandler
    public void modifyVelocity(EventPlayerTravel e) {
        ModuleManager.rotations.modifyVelocity(e);
    }

    @EventHandler
    public void onKeyInput(EventKeyboardInput e) {
        ModuleManager.rotations.onKeyInput(e);
    }

    @EventHandler
    public void onSyncWithServer(@NotNull PacketEvent.Send event) {
        Object t;
        if (event.getPacket() instanceof class_2813) {
            this.inInventory = true;
        }
        if ((t = event.getPacket()) instanceof class_2868) {
            class_2868 slot = (class_2868)t;
            this.switchTimer.reset();
            this.serverSideSlot = slot.method_12442();
        }
        if (event.getPacket() instanceof class_2815) {
            this.inInventory = false;
        }
    }

    @EventHandler
    public void onPacketReceive(@NotNull PacketEvent.Receive event) {
        Object t = event.getPacket();
        if (t instanceof class_2735) {
            class_2735 slot = (class_2735)t;
            this.switchTimer.reset();
            this.serverSideSlot = slot.method_11803();
        }
    }

    private float getBodyYaw() {
        double x = PlayerManager.mc.field_1724.method_23317() - PlayerManager.mc.field_1724.field_6014;
        double z = PlayerManager.mc.field_1724.method_23321() - PlayerManager.mc.field_1724.field_5969;
        float offset = this.bodyYaw;
        if (x * x + z * z > 0.002500000176951289) {
            offset = (float)(class_3532.method_15349((double)z, (double)x) * 57.2957763671875 - 90.0);
        }
        if (PlayerManager.mc.field_1724.field_6251 > 0.0f) {
            offset = ((IClientPlayerEntity)class_310.method_1551().field_1724).getLastYaw();
        }
        float f = (float)class_3532.method_15393((float)(((IClientPlayerEntity)class_310.method_1551().field_1724).getLastYaw() - (this.bodyYaw + class_3532.method_15393((float)(offset - this.bodyYaw)) * 0.3f)));
        float deltaBodyYaw = class_3532.method_15363((float)f, (float)-45.0f, (float)75.0f);
        return (f > 50.0f ? deltaBodyYaw * 0.2f : 0.0f) + ((IClientPlayerEntity)class_310.method_1551().field_1724).getLastYaw() - deltaBodyYaw;
    }

    public boolean checkRtx(float yaw, float pitch, float distance, float wallDistance, Aura.RayTrace rt) {
        class_3966 ehr;
        if (rt == Aura.RayTrace.OFF) {
            return true;
        }
        class_239 result = this.rayTrace(distance, yaw, pitch);
        class_243 startPoint = PlayerManager.mc.field_1724.method_19538().method_1031(0.0, (double)PlayerManager.mc.field_1724.method_18381(PlayerManager.mc.field_1724.method_18376()), 0.0);
        double distancePow2 = Math.pow(distance, 2.0);
        if (result != null) {
            distancePow2 = startPoint.method_1025(result.method_17784());
        }
        class_243 rotationVector = this.getRotationVector(pitch, yaw).method_1021((double)distance);
        class_243 endPoint = startPoint.method_1019(rotationVector);
        class_238 entityArea = PlayerManager.mc.field_1724.method_5829().method_18804(rotationVector).method_1009(1.0, 1.0, 1.0);
        double maxDistance = Math.max(distancePow2, Math.pow(wallDistance, 2.0));
        class_3966 entityHitResult = ehr = rt == Aura.RayTrace.OnlyTarget && Aura.target != null ? class_1675.method_18075((class_1297)PlayerManager.mc.field_1724, (class_243)startPoint, (class_243)endPoint, (class_238)entityArea, e -> !e.method_7325() && e.method_5863() && e == Aura.target, (double)maxDistance) : class_1675.method_18075((class_1297)PlayerManager.mc.field_1724, (class_243)startPoint, (class_243)endPoint, (class_238)entityArea, e -> !e.method_7325() && e.method_5863(), (double)maxDistance);
        if (ehr != null) {
            boolean allowedWallDistance = startPoint.method_1025(ehr.method_17784()) <= Math.pow(wallDistance, 2.0);
            boolean wallMissing = result == null;
            boolean wallBehindEntity = startPoint.method_1025(ehr.method_17784()) < distancePow2;
            boolean allowWallHit = wallMissing || allowedWallDistance || wallBehindEntity;
            boolean bl = allowWallHit;
            if (allowWallHit && startPoint.method_1025(ehr.method_17784()) <= Math.pow(distance, 2.0)) {
                return ehr.method_17782() == Aura.target || Aura.target == null || rt == Aura.RayTrace.OnlyTarget;
            }
        }
        return false;
    }

    public boolean checkRtx(float yaw, float pitch, float distance, float wallDistance, class_1297 entity) {
        double maxDistance;
        class_238 entityArea;
        class_243 rotationVector;
        class_243 endPoint;
        class_3966 ehr;
        class_239 result = this.rayTrace(distance, yaw, pitch);
        class_243 startPoint = PlayerManager.mc.field_1724.method_19538().method_1031(0.0, (double)PlayerManager.mc.field_1724.method_18381(PlayerManager.mc.field_1724.method_18376()), 0.0);
        double distancePow2 = Math.pow(distance, 2.0);
        if (result != null) {
            distancePow2 = startPoint.method_1025(result.method_17784());
        }
        if ((ehr = class_1675.method_18075((class_1297)PlayerManager.mc.field_1724, (class_243)startPoint, (class_243)(endPoint = startPoint.method_1019(rotationVector = this.getRotationVector(pitch, yaw).method_1021((double)distance))), (class_238)(entityArea = PlayerManager.mc.field_1724.method_5829().method_18804(rotationVector).method_1009(1.0, 1.0, 1.0)), e -> !e.method_7325() && e.method_5863() && e == entity, (double)(maxDistance = Math.max(distancePow2, Math.pow(wallDistance, 2.0))))) != null) {
            boolean allowedWallDistance = startPoint.method_1025(ehr.method_17784()) <= Math.pow(wallDistance, 2.0);
            boolean wallMissing = result == null;
            boolean wallBehindEntity = startPoint.method_1025(ehr.method_17784()) < distancePow2;
            boolean allowWallHit = wallMissing || allowedWallDistance || wallBehindEntity;
            boolean bl = allowWallHit;
            if (allowWallHit && startPoint.method_1025(ehr.method_17784()) <= Math.pow(distance, 2.0)) {
                return ehr.method_17782() == entity;
            }
        }
        return false;
    }

    public class_1297 getRtxTarget(float yaw, float pitch, float distance, boolean ignoreWalls) {
        class_238 box;
        class_1297 targetedEntity = null;
        class_239 result = ignoreWalls ? null : this.rayTrace(distance, yaw, pitch);
        class_243 vec3d = PlayerManager.mc.field_1724.method_19538().method_1031(0.0, (double)PlayerManager.mc.field_1724.method_18381(PlayerManager.mc.field_1724.method_18376()), 0.0);
        double distancePow2 = Math.pow(distance, 2.0);
        if (result != null) {
            distancePow2 = result.method_17784().method_1025(vec3d);
        }
        class_243 vec3d2 = this.getRotationVector(pitch, yaw);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * (double)distance, vec3d2.field_1351 * (double)distance, vec3d2.field_1350 * (double)distance);
        class_3966 entityHitResult = class_1675.method_18075((class_1297)PlayerManager.mc.field_1724, (class_243)vec3d, (class_243)vec3d3, (class_238)(box = PlayerManager.mc.field_1724.method_5829().method_18804(vec3d2.method_1021((double)distance)).method_1009(1.0, 1.0, 1.0)), entity -> !entity.method_7325() && entity.method_5863(), (double)distancePow2);
        if (entityHitResult != null) {
            class_1297 entity2 = entityHitResult.method_17782();
            class_243 vec3d4 = entityHitResult.method_17784();
            double g = vec3d.method_1025(vec3d4);
            if ((g < distancePow2 || result == null) && entity2 instanceof class_1309) {
                targetedEntity = entity2;
                return targetedEntity;
            }
        }
        return targetedEntity;
    }

    public class_243 getRtxPoint(float yaw, float pitch, float distance) {
        class_238 box;
        class_243 vec3d = PlayerManager.mc.field_1724.method_19538().method_1031(0.0, (double)PlayerManager.mc.field_1724.method_18381(PlayerManager.mc.field_1724.method_18376()), 0.0);
        double distancePow2 = Math.pow(distance, 2.0);
        class_243 vec3d2 = this.getRotationVector(pitch, yaw);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * (double)distance, vec3d2.field_1351 * (double)distance, vec3d2.field_1350 * (double)distance);
        class_3966 entityHitResult = class_1675.method_18075((class_1297)PlayerManager.mc.field_1724, (class_243)vec3d, (class_243)vec3d3, (class_238)(box = PlayerManager.mc.field_1724.method_5829().method_18804(vec3d2.method_1021((double)distance)).method_1009(1.0, 1.0, 1.0)), entity -> !entity.method_7325() && entity.method_5863(), (double)distancePow2);
        if (entityHitResult != null) {
            class_1297 entity2 = entityHitResult.method_17782();
            class_243 vec3d4 = entityHitResult.method_17784();
            if (entity2 instanceof class_1309) {
                return vec3d4;
            }
        }
        return null;
    }

    public boolean isLookingAtBox(float yaw, float pitch, class_2338 blockPos) {
        class_243 vec3d = PlayerManager.mc.field_1724.method_5836(1.0f);
        class_243 vec3d2 = this.getRotationVector(pitch, yaw);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * 7.0, vec3d2.field_1351 * 7.0, vec3d2.field_1350 * 7.0);
        class_3965 result = ExplosionUtility.rayCastBlock(new class_3959(vec3d, vec3d3, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)PlayerManager.mc.field_1724), blockPos);
        return result != null && result.method_17783() == class_239.class_240.field_1332 && result.method_17777().equals(blockPos);
    }

    public class_239 rayTrace(double dst, float yaw, float pitch) {
        class_243 vec3d = PlayerManager.mc.field_1724.method_5836(1.0f);
        class_243 vec3d2 = this.getRotationVector(pitch, yaw);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * dst, vec3d2.field_1351 * dst, vec3d2.field_1350 * dst);
        return PlayerManager.mc.field_1687.method_17742(new class_3959(vec3d, vec3d3, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)PlayerManager.mc.field_1724));
    }

    public class_239 getRtxTarget(float yaw, float pitch, double x, double y, double z) {
        class_238 box;
        class_239 result = this.rayTrace(5.0, yaw, pitch, x, y, z);
        class_243 vec3d = new class_243(x, y, z).method_1031(0.0, (double)PlayerManager.mc.field_1724.method_18381(PlayerManager.mc.field_1724.method_18376()), 0.0);
        double distancePow2 = 25.0;
        if (result != null) {
            distancePow2 = result.method_17784().method_1025(vec3d);
        }
        class_243 vec3d2 = this.getRotationVector(pitch, yaw);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * 5.0, vec3d2.field_1351 * 5.0, vec3d2.field_1350 * 5.0);
        class_3966 entityHitResult = class_1675.method_18075((class_1297)PlayerManager.mc.field_1724, (class_243)vec3d, (class_243)vec3d3, (class_238)(box = new class_238(x - 0.3, y, z - 0.3, x + 0.3, y + 1.8, z + 0.3).method_18804(vec3d2.method_1021(5.0)).method_1009(1.0, 1.0, 1.0)), entity -> !entity.method_7325() && entity.method_5863(), (double)distancePow2);
        if (entityHitResult != null) {
            class_1297 entity2 = entityHitResult.method_17782();
            class_243 vec3d4 = entityHitResult.method_17784();
            double g = vec3d.method_1025(vec3d4);
            if ((g < distancePow2 || result == null) && entity2 instanceof class_1309) {
                return entityHitResult;
            }
        }
        return result;
    }

    public boolean isInWeb() {
        class_238 pBox = PlayerManager.mc.field_1724.method_5829();
        class_2338 pBlockPos = class_2338.method_49638((class_2374)PlayerManager.mc.field_1724.method_19538());
        for (int x = pBlockPos.method_10263() - 2; x <= pBlockPos.method_10263() + 2; ++x) {
            for (int y = pBlockPos.method_10264() - 1; y <= pBlockPos.method_10264() + 4; ++y) {
                for (int z = pBlockPos.method_10260() - 2; z <= pBlockPos.method_10260() + 2; ++z) {
                    class_2338 bp = new class_2338(x, y, z);
                    if (!pBox.method_994(new class_238(bp)) || PlayerManager.mc.field_1687.method_8320(bp).method_26204() != class_2246.field_10343) continue;
                    return true;
                }
            }
        }
        return false;
    }

    public class_239 rayTrace(double dst, float yaw, float pitch, double x, double y, double z) {
        class_243 vec3d = new class_243(x, y, z);
        class_243 vec3d2 = this.getRotationVector(pitch, yaw);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * dst, vec3d2.field_1351 * dst, vec3d2.field_1350 * dst);
        return PlayerManager.mc.field_1687.method_17742(new class_3959(vec3d, vec3d3, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)PlayerManager.mc.field_1724));
    }

    public static float[] calcAngle(class_243 to) {
        if (to == null) {
            return null;
        }
        double difX = to.field_1352 - PlayerManager.mc.field_1724.method_33571().field_1352;
        double difY = (to.field_1351 - PlayerManager.mc.field_1724.method_33571().field_1351) * -1.0;
        double difZ = to.field_1350 - PlayerManager.mc.field_1724.method_33571().field_1350;
        double dist = class_3532.method_15355((float)((float)(difX * difX + difZ * difZ)));
        return new float[]{(float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0)), (float)class_3532.method_15338((double)Math.toDegrees(Math.atan2(difY, dist)))};
    }

    public static class_241 calcAngleVec(class_243 to) {
        if (to == null) {
            return null;
        }
        double difX = to.field_1352 - PlayerManager.mc.field_1724.method_33571().field_1352;
        double difY = (to.field_1351 - PlayerManager.mc.field_1724.method_33571().field_1351) * -1.0;
        double difZ = to.field_1350 - PlayerManager.mc.field_1724.method_33571().field_1350;
        double dist = class_3532.method_15355((float)((float)(difX * difX + difZ * difZ)));
        return new class_241((float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0)), (float)class_3532.method_15338((double)Math.toDegrees(Math.atan2(difY, dist))));
    }

    @NotNull
    public class_243 getRotationVector(float yaw, float pitch) {
        return new class_243((double)(class_3532.method_15374((float)(-pitch * ((float)Math.PI / 180))) * class_3532.method_15362((float)(yaw * ((float)Math.PI / 180)))), (double)(-class_3532.method_15374((float)(yaw * ((float)Math.PI / 180)))), (double)(class_3532.method_15362((float)(-pitch * ((float)Math.PI / 180))) * class_3532.method_15362((float)(yaw * ((float)Math.PI / 180)))));
    }

    public static float[] calcAngle(class_243 from, class_243 to) {
        if (to == null) {
            return null;
        }
        double difX = to.field_1352 - from.field_1352;
        double difY = (to.field_1351 - from.field_1351) * -1.0;
        double difZ = to.field_1350 - from.field_1350;
        double dist = class_3532.method_15355((float)((float)(difX * difX + difZ * difZ)));
        return new float[]{(float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0)), (float)class_3532.method_15338((double)Math.toDegrees(Math.atan2(difY, dist)))};
    }
}

