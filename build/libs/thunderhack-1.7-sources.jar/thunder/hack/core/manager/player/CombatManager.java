/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.World
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package thunder.hack.core.manager.player;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2663;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.IManager;
import thunder.hack.events.impl.EventPostTick;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.events.impl.TotemPopEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.AntiBot;

public class CombatManager
implements IManager {
    public HashMap<String, Integer> popList = new HashMap();

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {
        class_2663 pac;
        if (Module.fullNullCheck()) {
            return;
        }
        Object t = event.getPacket();
        if (t instanceof class_2663 && (pac = (class_2663)t).method_11470() == 35) {
            class_1297 ent = pac.method_11469((class_1937)CombatManager.mc.field_1687);
            if (!(ent instanceof class_1657)) {
                return;
            }
            if (this.popList == null) {
                this.popList = new HashMap();
            }
            if (this.popList.get(ent.method_5477().getString()) == null) {
                this.popList.put(ent.method_5477().getString(), 1);
            } else if (this.popList.get(ent.method_5477().getString()) != null) {
                this.popList.put(ent.method_5477().getString(), this.popList.get(ent.method_5477().getString()) + 1);
            }
            ThunderHack.EVENT_BUS.post(new TotemPopEvent((class_1657)ent, this.popList.get(ent.method_5477().getString())));
        }
    }

    @EventHandler
    public void onPostTick(EventPostTick event) {
        if (Module.fullNullCheck()) {
            return;
        }
        for (class_1657 player : CombatManager.mc.field_1687.method_18456()) {
            if (AntiBot.bots.contains(player) || !(player.method_6032() <= 0.0f) || !this.popList.containsKey(player.method_5477().getString())) continue;
            this.popList.remove(player.method_5477().getString(), this.popList.get(player.method_5477().getString()));
        }
    }

    public int getPops(@NotNull class_1657 entity) {
        if (this.popList.get(entity.method_5477().getString()) == null) {
            return 0;
        }
        return this.popList.get(entity.method_5477().getString());
    }

    public List<class_1657> getTargets(float range) {
        return CombatManager.mc.field_1687.method_18456().stream().filter(e -> !e.method_29504()).filter(entityPlayer -> !Managers.FRIEND.isFriend(entityPlayer.method_5477().getString())).filter(entityPlayer -> entityPlayer != CombatManager.mc.field_1724).filter(entityPlayer -> CombatManager.mc.field_1724.method_5858((class_1297)entityPlayer) < (double)(range * range)).sorted(Comparator.comparing(e -> CombatManager.mc.field_1724.method_5858((class_1297)e))).collect(Collectors.toList());
    }

    @Nullable
    public class_1657 getTarget(float range, @NotNull TargetBy targetBy) {
        class_1657 target = null;
        switch (targetBy.ordinal()) {
            case 1: {
                target = this.getTargetByFOV(range);
                break;
            }
            case 2: {
                target = this.getTargetByHealth(range);
                break;
            }
            case 0: {
                target = this.getNearestTarget(range);
            }
        }
        return target;
    }

    @Nullable
    public class_1657 getNearestTarget(float range) {
        return this.getTargets(range).stream().min(Comparator.comparing(t -> Float.valueOf(CombatManager.mc.field_1724.method_5739((class_1297)t)))).orElse(null);
    }

    public class_1657 getTargetByHealth(float range) {
        return this.getTargets(range).stream().min(Comparator.comparing(t -> Float.valueOf(t.method_6032() + t.method_6067()))).orElse(null);
    }

    public class_1657 getTargetByFOV(float range) {
        return this.getTargets(range).stream().min(Comparator.comparing(this::getFOVAngle)).orElse(null);
    }

    public class_1657 getTargetByFOV(float range, float fov) {
        return this.getTargets(range).stream().filter(entityPlayer -> this.getFOVAngle((class_1309)entityPlayer) < fov).min(Comparator.comparing(this::getFOVAngle)).orElse(null);
    }

    @Nullable
    public class_1657 getTarget(float range, @NotNull TargetBy targetBy, @NotNull Predicate<class_1657> predicate) {
        class_1657 target = null;
        switch (targetBy.ordinal()) {
            case 1: {
                target = this.getTargetByFOV(range, predicate);
                break;
            }
            case 2: {
                target = this.getTargetByHealth(range, predicate);
                break;
            }
            case 0: {
                target = this.getNearestTarget(range, predicate);
            }
        }
        return target;
    }

    @Nullable
    public class_1657 getNearestTarget(float range, Predicate<class_1657> predicate) {
        return this.getTargets(range).stream().filter(predicate).min(Comparator.comparing(t -> Float.valueOf(CombatManager.mc.field_1724.method_5739((class_1297)t)))).orElse(null);
    }

    public class_1657 getTargetByHealth(float range, Predicate<class_1657> predicate) {
        return this.getTargets(range).stream().filter(predicate).min(Comparator.comparing(t -> Float.valueOf(t.method_6032() + t.method_6067()))).orElse(null);
    }

    public class_1657 getTargetByFOV(float range, Predicate<class_1657> predicate) {
        return this.getTargets(range).stream().filter(predicate).min(Comparator.comparing(this::getFOVAngle)).orElse(null);
    }

    private float getFOVAngle(@NotNull class_1309 e) {
        float yaw = (float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(e.method_23321() - CombatManager.mc.field_1724.method_23321(), e.method_23317() - CombatManager.mc.field_1724.method_23317())) - 90.0));
        return Math.abs(yaw - class_3532.method_15393((float)CombatManager.mc.field_1724.method_36454()));
    }

    public static enum TargetBy {
        Distance,
        FOV,
        Health;

    }
}

