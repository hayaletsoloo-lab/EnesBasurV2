/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.registry.Registries
 *  net.minecraft.registry.Registry
 *  net.minecraft.sound.SoundCategory
 *  net.minecraft.sound.SoundEvent
 *  net.minecraft.util.Identifier
 */
package thunder.hack.core.manager.client;

import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import net.minecraft.class_1657;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7923;
import thunder.hack.core.manager.IManager;
import thunder.hack.core.manager.client.ConfigManager;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.client.SoundFX;
import thunder.hack.utility.Timer;
import thunder.hack.utility.math.MathUtility;

public class SoundManager
implements IManager {
    public final class_2960 KEYPRESS_SOUND = class_2960.method_60654((String)"thunderhack:keypress");
    public class_3414 KEYPRESS_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.KEYPRESS_SOUND);
    public final class_2960 KEYRELEASE_SOUND = class_2960.method_60654((String)"thunderhack:keyrelease");
    public class_3414 KEYRELEASE_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.KEYRELEASE_SOUND);
    public final class_2960 UWU_SOUND = class_2960.method_60654((String)"thunderhack:uwu");
    public class_3414 UWU_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.UWU_SOUND);
    public final class_2960 ENABLE_SOUND = class_2960.method_60654((String)"thunderhack:enable");
    public class_3414 ENABLE_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.ENABLE_SOUND);
    public final class_2960 DISABLE_SOUND = class_2960.method_60654((String)"thunderhack:disable");
    public class_3414 DISABLE_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.DISABLE_SOUND);
    public final class_2960 MOAN1_SOUND = class_2960.method_60654((String)"thunderhack:moan1");
    public class_3414 MOAN1_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.MOAN1_SOUND);
    public final class_2960 MOAN2_SOUND = class_2960.method_60654((String)"thunderhack:moan2");
    public class_3414 MOAN2_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.MOAN2_SOUND);
    public final class_2960 MOAN3_SOUND = class_2960.method_60654((String)"thunderhack:moan3");
    public class_3414 MOAN3_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.MOAN3_SOUND);
    public final class_2960 MOAN4_SOUND = class_2960.method_60654((String)"thunderhack:moan4");
    public class_3414 MOAN4_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.MOAN4_SOUND);
    public final class_2960 SKEET_SOUND = class_2960.method_60654((String)"thunderhack:skeet");
    public class_3414 SKEET_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.SKEET_SOUND);
    public final class_2960 ORTHODOX_SOUND = class_2960.method_60654((String)"thunderhack:orthodox");
    public class_3414 ORTHODOX_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.ORTHODOX_SOUND);
    public final class_2960 BOOLEAN_SOUND = class_2960.method_60654((String)"thunderhack:boolean");
    public class_3414 BOOLEAN_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.BOOLEAN_SOUND);
    public final class_2960 SCROLL_SOUND = class_2960.method_60654((String)"thunderhack:scroll");
    public class_3414 SCROLL_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.SCROLL_SOUND);
    public final class_2960 SWIPEIN_SOUND = class_2960.method_60654((String)"thunderhack:swipein");
    public class_3414 SWIPEIN_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.SWIPEIN_SOUND);
    public final class_2960 SWIPEOUT_SOUND = class_2960.method_60654((String)"thunderhack:swipeout");
    public class_3414 SWIPEOUT_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.SWIPEOUT_SOUND);
    public final class_2960 ALERT_SOUND = class_2960.method_60654((String)"thunderhack:alert");
    public class_3414 ALERT_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.ALERT_SOUND);
    public final class_2960 PM_SOUND = class_2960.method_60654((String)"thunderhack:pmsound");
    public class_3414 PM_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.PM_SOUND);
    public final class_2960 RIFK_SOUND = class_2960.method_60654((String)"thunderhack:rifk");
    public class_3414 RIFK_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.RIFK_SOUND);
    public final class_2960 CUTIE_SOUND = class_2960.method_60654((String)"thunderhack:cutie");
    public class_3414 CUTIE_SOUNDEVENT = class_3414.method_47908((class_2960)(Object)this.CUTIE_SOUND);
    private final Timer scrollTimer = new Timer();

    public void registerSounds() {
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.KEYPRESS_SOUND, (Object)this.KEYPRESS_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.KEYRELEASE_SOUND, (Object)this.KEYRELEASE_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.ENABLE_SOUND, (Object)this.ENABLE_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.DISABLE_SOUND, (Object)this.DISABLE_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.MOAN1_SOUND, (Object)this.MOAN1_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.MOAN2_SOUND, (Object)this.MOAN2_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.MOAN3_SOUND, (Object)this.MOAN3_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.MOAN4_SOUND, (Object)this.MOAN4_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.UWU_SOUND, (Object)this.UWU_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.SKEET_SOUND, (Object)this.SKEET_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.ORTHODOX_SOUND, (Object)this.ORTHODOX_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.SCROLL_SOUND, (Object)this.SCROLL_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.BOOLEAN_SOUND, (Object)this.BOOLEAN_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.SWIPEIN_SOUND, (Object)this.SWIPEIN_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.SWIPEOUT_SOUND, (Object)this.SWIPEOUT_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.ALERT_SOUND, (Object)this.ALERT_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.PM_SOUND, (Object)this.PM_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.RIFK_SOUND, (Object)this.RIFK_SOUNDEVENT);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)(Object)this.CUTIE_SOUND, (Object)this.CUTIE_SOUNDEVENT);
    }

    public void playHitSound(SoundFX.HitSound value) {
        switch (value) {
            case UWU: {
                this.playSound(this.UWU_SOUNDEVENT);
                break;
            }
            case SKEET: {
                this.playSound(this.SKEET_SOUNDEVENT);
                break;
            }
            case KEYBOARD: {
                this.playSound(this.KEYPRESS_SOUNDEVENT);
                break;
            }
            case CUTIE: {
                this.playSound(this.CUTIE_SOUNDEVENT);
                break;
            }
            case MOAN: {
                class_3414 sound = switch ((int)MathUtility.random(0.0f, 3.0f)) {
                    case 0 -> this.MOAN1_SOUNDEVENT;
                    case 1 -> this.MOAN2_SOUNDEVENT;
                    case 2 -> this.MOAN3_SOUNDEVENT;
                    default -> this.MOAN4_SOUNDEVENT;
                };
                this.playSound(sound);
                break;
            }
            case RIFK: {
                this.playSound(this.RIFK_SOUNDEVENT);
                break;
            }
            case CUSTOM: {
                this.playSound("hit");
            }
        }
    }

    public void playEnable() {
        if (ModuleManager.soundFX.enableMode.getValue() == SoundFX.OnOffSound.Inertia) {
            this.playSound(this.ENABLE_SOUNDEVENT);
        } else if (ModuleManager.soundFX.enableMode.getValue() == SoundFX.OnOffSound.Custom) {
            this.playSound("enable");
        }
    }

    public void playDisable() {
        if (ModuleManager.soundFX.disableMode.getValue() == SoundFX.OnOffSound.Inertia) {
            this.playSound(this.DISABLE_SOUNDEVENT);
        } else if (ModuleManager.soundFX.disableMode.getValue() == SoundFX.OnOffSound.Custom) {
            this.playSound("disable");
        }
    }

    public void playScroll() {
        if (this.scrollTimer.every(50L)) {
            if (ModuleManager.soundFX.scrollSound.getValue() == SoundFX.ScrollSound.KeyBoard) {
                this.playSound(this.KEYPRESS_SOUNDEVENT);
            } else if (ModuleManager.soundFX.scrollSound.getValue() == SoundFX.ScrollSound.Custom) {
                this.playSound("scroll");
            }
        }
    }

    public void playSound(class_3414 sound) {
        if (SoundManager.mc.field_1724 != null && SoundManager.mc.field_1687 != null) {
            SoundManager.mc.field_1687.method_8396((class_1657)SoundManager.mc.field_1724, SoundManager.mc.field_1724.method_24515(), sound, class_3419.field_15245, (float)ModuleManager.soundFX.volume.getValue().intValue() / 100.0f, 1.0f);
        }
    }

    public void playSound(String name) {
        try {
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(new File(ConfigManager.SOUNDS_FOLDER, name + ".wav").getAbsoluteFile()));
            FloatControl floatControl = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
            floatControl.setValue(floatControl.getMaximum() - floatControl.getMinimum() * ((float)ModuleManager.soundFX.volume.getValue().intValue() / 100.0f) + floatControl.getMinimum());
            clip.start();
        }
        catch (Exception e) {
            Command.sendMessage((ClientSettings.isRu() ? "\u041e\u0448\u0438\u0431\u043a\u0430 \u0432\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u044f \u0437\u0432\u0443\u043a\u0430! \u041f\u0440\u043e\u0432\u0435\u0440\u044c " : "Error with playing sound! Check ") + new File(ConfigManager.SOUNDS_FOLDER, name + ".wav").getAbsolutePath());
        }
    }

    public void playSlider() {
        this.playSound(this.SCROLL_SOUNDEVENT);
    }

    public void playBoolean() {
        this.playSound(this.BOOLEAN_SOUNDEVENT);
    }

    public void playSwipeIn() {
        this.playSound(this.SWIPEIN_SOUNDEVENT);
    }

    public void playSwipeOut() {
        this.playSound(this.SWIPEOUT_SOUNDEVENT);
    }
}

