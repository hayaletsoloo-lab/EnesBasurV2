/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gl.Framebuffer
 *  net.minecraft.client.gl.PostEffectProcessor
 *  net.minecraft.util.Identifier
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.core.manager.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.manager.IManager;
import thunder.hack.utility.interfaces.IShaderEffect;
import thunder.hack.utility.render.shaders.satin.api.managed.ManagedShaderEffect;
import thunder.hack.utility.render.shaders.satin.api.managed.ShaderEffectManager;

public class ShaderManager
implements IManager {
    private static final List<RenderTask> tasks = new ArrayList<RenderTask>();
    private ThunderHackFramebuffer shaderBuffer;
    public float time = 0.0f;
    public static ManagedShaderEffect DEFAULT_OUTLINE;
    public static ManagedShaderEffect SMOKE_OUTLINE;
    public static ManagedShaderEffect GRADIENT_OUTLINE;
    public static ManagedShaderEffect SNOW_OUTLINE;
    public static ManagedShaderEffect FADE_OUTLINE;
    public static ManagedShaderEffect DEFAULT;
    public static ManagedShaderEffect SMOKE;
    public static ManagedShaderEffect GRADIENT;
    public static ManagedShaderEffect SNOW;
    public static ManagedShaderEffect FADE;

    public void renderShader(Runnable runnable, Shader mode) {
        tasks.add(new RenderTask(runnable, mode));
    }

    public void renderShaders() {
        if (DEFAULT == null) {
            this.shaderBuffer = new ThunderHackFramebuffer(ShaderManager.mc.method_1522().field_1482, ShaderManager.mc.method_1522().field_1481);
            this.reloadShaders();
        }
        if (this.shaderBuffer == null) {
            return;
        }
        tasks.forEach(t -> this.applyShader(t.task(), t.shader()));
        tasks.clear();
    }

    public void applyShader(Runnable runnable, Shader mode) {
        class_276 MCBuffer = class_310.method_1551().method_1522();
        RenderSystem.assertOnRenderThreadOrInit();
        if (this.shaderBuffer.field_1482 != MCBuffer.field_1482 || this.shaderBuffer.field_1481 != MCBuffer.field_1481) {
            this.shaderBuffer.method_1234(MCBuffer.field_1482, MCBuffer.field_1481, false);
        }
        GlStateManager._glBindFramebuffer((int)36009, (int)this.shaderBuffer.field_1476);
        this.shaderBuffer.method_1235(true);
        runnable.run();
        this.shaderBuffer.method_1240();
        GlStateManager._glBindFramebuffer((int)36009, (int)MCBuffer.field_1476);
        MCBuffer.method_1235(false);
        ManagedShaderEffect shader = this.getShader(mode);
        class_276 mainBuffer = class_310.method_1551().method_1522();
        class_279 effect = shader.getShaderEffect();
        if (effect != null) {
            ((IShaderEffect)effect).addFakeTargetHook("bufIn", this.shaderBuffer);
        }
        class_276 outBuffer = shader.getShaderEffect().method_1264("bufOut");
        this.setupShader(mode, shader);
        this.shaderBuffer.method_1230(false);
        mainBuffer.method_1235(false);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA, (GlStateManager.class_4535)GlStateManager.class_4535.ZERO, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.backupProjectionMatrix();
        outBuffer.method_22594(outBuffer.field_1482, outBuffer.field_1481, false);
        RenderSystem.restoreProjectionMatrix();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    public ManagedShaderEffect getShader(@NotNull Shader mode) {
        return switch (mode.ordinal()) {
            case 2 -> GRADIENT;
            case 1 -> SMOKE;
            case 3 -> SNOW;
            case 4 -> FADE;
            default -> DEFAULT;
        };
    }

    public ManagedShaderEffect getShaderOutline(@NotNull Shader mode) {
        return switch (mode.ordinal()) {
            case 2 -> GRADIENT_OUTLINE;
            case 1 -> SMOKE_OUTLINE;
            case 3 -> SNOW_OUTLINE;
            case 4 -> FADE_OUTLINE;
            default -> DEFAULT_OUTLINE;
        };
    }

    public void setupShader(Shader shader, ManagedShaderEffect effect) {
    }

    public void reloadShaders() {
        DEFAULT = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/outline.json"));
        SMOKE = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/smoke.json"));
        GRADIENT = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/gradient.json"));
        SNOW = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/snow.json"));
        FADE = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/fade.json"));
        FADE_OUTLINE = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/fade.json"), managedShaderEffect -> {
            class_279 effect = managedShaderEffect.getShaderEffect();
            if (effect == null) {
                return;
            }
            ((IShaderEffect)effect).addFakeTargetHook("bufIn", ShaderManager.mc.field_1769.method_22990());
            ((IShaderEffect)effect).addFakeTargetHook("bufOut", ShaderManager.mc.field_1769.method_22990());
        });
        DEFAULT_OUTLINE = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/outline.json"), managedShaderEffect -> {
            class_279 effect = managedShaderEffect.getShaderEffect();
            if (effect == null) {
                return;
            }
            ((IShaderEffect)effect).addFakeTargetHook("bufIn", ShaderManager.mc.field_1769.method_22990());
            ((IShaderEffect)effect).addFakeTargetHook("bufOut", ShaderManager.mc.field_1769.method_22990());
        });
        SMOKE_OUTLINE = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/smoke.json"), managedShaderEffect -> {
            class_279 effect = managedShaderEffect.getShaderEffect();
            if (effect == null) {
                return;
            }
            ((IShaderEffect)effect).addFakeTargetHook("bufIn", ShaderManager.mc.field_1769.method_22990());
            ((IShaderEffect)effect).addFakeTargetHook("bufOut", ShaderManager.mc.field_1769.method_22990());
        });
        GRADIENT_OUTLINE = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/gradient.json"), managedShaderEffect -> {
            class_279 effect = managedShaderEffect.getShaderEffect();
            if (effect == null) {
                return;
            }
            ((IShaderEffect)effect).addFakeTargetHook("bufIn", ShaderManager.mc.field_1769.method_22990());
            ((IShaderEffect)effect).addFakeTargetHook("bufOut", ShaderManager.mc.field_1769.method_22990());
        });
        SNOW_OUTLINE = ShaderEffectManager.getInstance().manage(class_2960.method_60655((String)"thunderhack", (String)"shaders/post/snow.json"), managedShaderEffect -> {
            class_279 effect = managedShaderEffect.getShaderEffect();
            if (effect == null) {
                return;
            }
            ((IShaderEffect)effect).addFakeTargetHook("bufIn", ShaderManager.mc.field_1769.method_22990());
            ((IShaderEffect)effect).addFakeTargetHook("bufOut", ShaderManager.mc.field_1769.method_22990());
        });
    }

    public boolean fullNullCheck() {
        if (GRADIENT == null || SMOKE == null || DEFAULT == null) {
            this.shaderBuffer = new ThunderHackFramebuffer(ShaderManager.mc.method_1522().field_1482, ShaderManager.mc.method_1522().field_1481);
            this.reloadShaders();
            return true;
        }
        return false;
    }

    public record RenderTask(Runnable task, Shader shader) {
    }

    public static enum Shader {
        Default,
        Smoke,
        Gradient,
        Snow,
        Fade;

    }

    public static class ThunderHackFramebuffer
    extends class_276 {
        public ThunderHackFramebuffer(int width, int height) {
            super(false);
            RenderSystem.assertOnRenderThreadOrInit();
            this.method_1234(width, height, true);
            this.method_1236(0.0f, 0.0f, 0.0f, 0.0f);
        }
    }
}

