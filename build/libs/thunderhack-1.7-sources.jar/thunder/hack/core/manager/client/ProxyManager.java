/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.logging.LogUtils
 *  io.netty.bootstrap.Bootstrap
 *  io.netty.channel.ChannelFuture
 *  io.netty.channel.ChannelHandler
 *  io.netty.channel.ChannelHandlerContext
 *  io.netty.channel.ChannelInboundHandlerAdapter
 *  io.netty.channel.ChannelInitializer
 *  io.netty.channel.EventLoopGroup
 *  io.netty.channel.nio.NioEventLoopGroup
 *  io.netty.channel.socket.SocketChannel
 *  io.netty.channel.socket.nio.NioSocketChannel
 *  io.netty.handler.flow.FlowControlHandler
 *  io.netty.handler.proxy.Socks5ProxyHandler
 *  io.netty.handler.timeout.ReadTimeoutHandler
 *  net.minecraft.network.handler.NetworkStateTransitions$InboundConfigurer
 *  net.minecraft.network.handler.NetworkStateTransitions$OutboundConfigurer
 */
package thunder.hack.core.manager.client;

import com.mojang.logging.LogUtils;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.flow.FlowControlHandler;
import io.netty.handler.proxy.Socks5ProxyHandler;
import io.netty.handler.timeout.ReadTimeoutHandler;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_9130;
import thunder.hack.core.manager.IManager;

public class ProxyManager
implements IManager {
    private final List<ThProxy> proxies = new ArrayList<ThProxy>();
    private ThProxy activeProxy;

    public boolean isActive() {
        return this.getActiveProxy() != null;
    }

    public ThProxy getActiveProxy() {
        return this.activeProxy;
    }

    public void addProxy(ThProxy p) {
        this.proxies.add(p);
    }

    public void removeProxy(ThProxy p) {
        this.proxies.remove(p);
    }

    public List<ThProxy> getProxies() {
        return this.proxies;
    }

    public void setActiveProxy(ThProxy proxy) {
        this.activeProxy = proxy;
    }

    public void onLoad() {
        block10: {
            try {
                File file = new File("ThunderHackRecode/misc/proxies.txt");
                if (!file.exists()) break block10;
                try (BufferedReader reader = new BufferedReader(new FileReader(file));){
                    while (reader.ready()) {
                        String[] line = reader.readLine().split(":");
                        String name = line[0];
                        String ip = line[1];
                        String port = line[2];
                        String login = line[3];
                        String password = line[4];
                        String active = line[5];
                        int p = 80;
                        try {
                            p = Integer.parseInt(port);
                        }
                        catch (Exception e) {
                            LogUtils.getLogger().warn(e.getMessage());
                        }
                        ThProxy proxy = new ThProxy(name, ip, p, login, password);
                        this.addProxy(proxy);
                        if (!Objects.equals(active, "true")) continue;
                        this.setActiveProxy(proxy);
                    }
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public void saveProxies() {
        File file = new File("ThunderHackRecode/misc/proxies.txt");
        try {
            new File("ThunderHackRecode").mkdirs();
            file.createNewFile();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file));){
            for (ThProxy proxy : this.proxies) {
                writer.write(proxy.getName() + ":" + proxy.getIp() + ":" + proxy.getPort() + ":" + proxy.getL() + ":" + proxy.getP() + ":" + (this.getActiveProxy() == proxy) + "\n");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public void checkPing(final ThProxy proxy) {
        long now = System.currentTimeMillis();
        proxy.setPing(-2);
        new Thread(() -> {
            try {
                NioEventLoopGroup group = new NioEventLoopGroup();
                Bootstrap bootstrap = new Bootstrap();
                ((Bootstrap)((Bootstrap)bootstrap.group((EventLoopGroup)group)).channel(NioSocketChannel.class)).handler((ChannelHandler)new ChannelInitializer<SocketChannel>(){

                    protected void initChannel(SocketChannel ch) {
                        ch.pipeline().addLast(new ChannelHandler[]{new FlowControlHandler()}).addLast("timeout_proxy_checker", (ChannelHandler)new ReadTimeoutHandler(8)).addLast("inbound_proxy_checker", (ChannelHandler)new class_9130.class_9131()).addLast("outbound_proxy_checker", (ChannelHandler)new class_9130.class_9133()).addLast(new ChannelHandler[]{new Socks5ProxyHandler((SocketAddress)new InetSocketAddress(proxy.getIp(), proxy.getPort()), proxy.getL(), proxy.getP())}).addLast(new ChannelHandler[]{new ProxyHandler()});
                    }
                });
                ChannelFuture future = bootstrap.connect("mcfunny.su", 25565).sync();
                future.await();
                if (future.isSuccess()) {
                    proxy.setPing((int)(System.currentTimeMillis() - now));
                } else {
                    proxy.setPing(-1);
                }
                group.shutdownGracefully();
            }
            catch (Exception e) {
                proxy.setPing(-1);
            }
        }).start();
    }

    public static class ThProxy {
        private String name;
        private String ip;
        private String l;
        private String p;
        private int port;
        private int ping;

        public ThProxy(String name, String ip, int port, String l, String p) {
            this.ip = ip;
            this.l = l;
            this.p = p;
            this.name = name;
            this.port = port;
        }

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIp() {
            return this.ip;
        }

        public void setIp(String ip) {
            this.ip = ip;
        }

        public String getL() {
            return this.l;
        }

        public void setL(String l) {
            this.l = l;
        }

        public String getP() {
            return this.p;
        }

        public void setP(String p) {
            this.p = p;
        }

        public void setPort(int port) {
            this.port = port;
        }

        public int getPort() {
            return this.port;
        }

        public void setPing(int ping) {
            this.ping = ping;
        }

        public int getPing() {
            return this.ping;
        }
    }

    private static class ProxyHandler
    extends ChannelInboundHandlerAdapter {
        private ProxyHandler() {
        }

        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
            super.channelRead(ctx, msg);
        }

        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
            ctx.close();
        }
    }
}

