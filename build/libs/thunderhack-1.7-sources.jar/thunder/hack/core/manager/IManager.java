/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.MinecraftClient
 */
package thunder.hack.core.manager;

import net.minecraft.class_310;

public interface IManager {
    public static final class_310 mc = class_310.method_1551();
}

