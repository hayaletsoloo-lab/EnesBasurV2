/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.ClickEvent
 *  net.minecraft.text.ClickEvent$Action
 */
package thunder.hack.events.impl;

import net.minecraft.class_2558;

public class ClientClickEvent
extends class_2558 {
    public ClientClickEvent(class_2558.class_2559 action, String value) {
        super(action, value);
    }
}

