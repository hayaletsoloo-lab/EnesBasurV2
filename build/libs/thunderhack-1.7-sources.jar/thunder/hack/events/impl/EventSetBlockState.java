/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockState
 *  net.minecraft.util.math.BlockPos
 */
package thunder.hack.events.impl;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import thunder.hack.events.Event;

public class EventSetBlockState
extends Event {
    private final class_2338 pos;
    private final class_2680 state;
    private final class_2680 prevState;

    public EventSetBlockState(class_2338 pos, class_2680 state, class_2680 prevState) {
        this.pos = pos;
        this.state = state;
        this.prevState = prevState;
    }

    public class_2338 getPos() {
        return this.pos;
    }

    public class_2680 getState() {
        return this.state;
    }

    public class_2680 getPrevState() {
        return this.prevState;
    }
}

