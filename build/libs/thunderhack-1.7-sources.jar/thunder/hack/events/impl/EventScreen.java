/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.Screen
 */
package thunder.hack.events.impl;

import net.minecraft.class_437;
import thunder.hack.events.Event;

public class EventScreen
extends Event {
    private final class_437 screen;

    public EventScreen(class_437 screen) {
        this.screen = screen;
    }

    public class_437 getScreen() {
        return this.screen;
    }
}

