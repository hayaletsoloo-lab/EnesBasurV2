/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.text.Text
 */
package thunder.hack.gui.hud;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClickGui;
import thunder.hack.gui.clickui.AbstractCategory;
import thunder.hack.gui.clickui.Category;
import thunder.hack.gui.clickui.ClickGUI;

public class HudEditorGui
extends class_437 {
    public static HudElement currentlyDragging;
    private final List<AbstractCategory> windows = Lists.newArrayList();
    private static HudEditorGui instance;
    private boolean firstOpen = true;
    private double dWheel;

    public HudEditorGui() {
        super(class_2561.method_30163((String)"HudEditorGui"));
        this.setInstance();
    }

    protected void method_25426() {
        if (this.firstOpen) {
            Category window = new Category(Module.Category.HUD, Managers.MODULE.getModulesByCategory(Module.Category.HUD), (float)Module.mc.method_22683().method_4486() / 2.0f - 50.0f, 20.0f, 100.0f, 18.0f);
            window.setOpen(true);
            this.windows.add(window);
            this.firstOpen = false;
        }
        this.windows.forEach(AbstractCategory::init);
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        ClickGUI.anyHovered = false;
        if (ModuleManager.clickGui.scrollMode.getValue() == ClickGui.scrollModeEn.Old) {
            for (AbstractCategory window : this.windows) {
                if (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)264)) {
                    window.setY(window.getY() + 2.0f);
                }
                if (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)265)) {
                    window.setY(window.getY() - 2.0f);
                }
                if (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)262)) {
                    window.setX(window.getX() + 2.0f);
                }
                if (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)263)) {
                    window.setX(window.getX() - 2.0f);
                }
                if (this.dWheel == 0.0) continue;
                window.setY((float)((double)window.getY() + this.dWheel));
            }
        } else {
            for (AbstractCategory window : this.windows) {
                if (this.dWheel == 0.0) continue;
                window.setModuleOffset((float)this.dWheel, mouseX, mouseY);
            }
        }
        this.dWheel = 0.0;
        for (AbstractCategory window : this.windows) {
            window.render(context, mouseX, mouseY, delta);
        }
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        this.dWheel = (int)(verticalAmount * 5.0);
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        this.windows.forEach(w -> {
            w.mouseClicked((int)mouseX, (int)mouseY, button);
            this.windows.forEach(w1 -> {
                if (w.dragging && w != w1) {
                    w1.dragging = false;
                }
            });
        });
        return super.method_25402(mouseX, mouseY, button);
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        this.windows.forEach(w -> w.mouseReleased((int)mouseX, (int)mouseY, button));
        return super.method_25406(mouseX, mouseY, button);
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        this.windows.forEach(w -> w.keyTyped(keyCode));
        if (keyCode == 256) {
            super.method_25404(keyCode, scanCode, modifiers);
            return true;
        }
        return false;
    }

    public void method_25432() {
        ThunderHack.EVENT_BUS.unsubscribe((Object)this);
    }

    public void hudClicked(Module module) {
        for (AbstractCategory window : this.windows) {
            window.hudClicked(module);
        }
    }

    public static HudEditorGui getInstance() {
        if (instance == null) {
            instance = new HudEditorGui();
        }
        return instance;
    }

    public static HudEditorGui getHudGui() {
        return HudEditorGui.getInstance();
    }

    private void setInstance() {
        instance = this;
    }

    static {
        instance = new HudEditorGui();
    }
}

