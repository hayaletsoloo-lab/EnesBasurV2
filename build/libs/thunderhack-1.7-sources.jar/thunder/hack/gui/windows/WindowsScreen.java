/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.text.Text
 *  net.minecraft.util.Identifier
 */
package thunder.hack.gui.windows;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import thunder.hack.core.manager.IManager;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.clickui.ClickGUI;
import thunder.hack.gui.windows.WindowBase;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

public class WindowsScreen
extends class_437 {
    private List<WindowBase> windows = new ArrayList<WindowBase>();
    public static WindowBase lastClickedWindow;
    public static WindowBase draggingWindow;
    private static final class_2960 clickGuiIcon;

    public WindowsScreen(WindowBase ... windows) {
        super(class_2561.method_30163((String)"THWindows"));
        this.windows.clear();
        lastClickedWindow = null;
        this.windows = Arrays.stream(windows).toList();
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (Module.fullNullCheck()) {
            this.method_25420(context, mouseX, mouseY, delta);
        }
        class_4587 matrices = context.method_51448();
        int i = IManager.mc.method_22683().method_4486() / 2;
        float offset = (float)this.windows.size() * 20.0f / -2.0f - 23.0f;
        Render2DEngine.drawHudBase(matrices, (float)i + offset - 1.5f, IManager.mc.method_22683().method_4502() - 25, (float)this.windows.size() * 20.0f + 23.0f, 19.0f, HudEditor.hudRound.getValue().floatValue());
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(Render2DEngine.isHovered(mouseX, mouseY, (float)i + offset + 1.0f, IManager.mc.method_22683().method_4502() - 23, 15.0, 15.0) ? 0.95f : 0.7f));
        context.method_25293(clickGuiIcon, (int)((float)i + offset) + 1, IManager.mc.method_22683().method_4502() - 23, 15, 15, 0.0f, 0.0f, 15, 15, 15, 15);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.disableBlend();
        Render2DEngine.drawLine((float)i + offset + 20.0f, IManager.mc.method_22683().method_4502() - 23, (float)i + offset + 20.0f, IManager.mc.method_22683().method_4502() - 9, Color.GRAY.getRGB());
        offset += 23.0f;
        for (WindowBase w2 : this.windows) {
            Color c = Render2DEngine.isHovered(mouseX, mouseY, (float)i + offset, IManager.mc.method_22683().method_4502() - 24, 17.0, 17.0) ? new Color(2083467055, true) : (!w2.isVisible() ? new Color(2082348574, true) : new Color(2084256571, true));
            Render2DEngine.drawRect(matrices, (float)i + offset, IManager.mc.method_22683().method_4502() - 24, 17.0f, 17.0f, HudEditor.hudRound.getValue().floatValue(), 0.7f, c, c, c, c);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(Render2DEngine.isHovered(mouseX, mouseY, (float)i + offset + 1.0f, IManager.mc.method_22683().method_4502() - 23, 15.0, 15.0) ? 0.95f : 0.7f));
            context.method_25293(w2.getIcon() != null ? w2.getIcon() : TextureStorage.configIcon, (int)((float)i + offset) + 3, IManager.mc.method_22683().method_4502() - 21, 11, 11, 0.0f, 0.0f, 11, 11, 11, 11);
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            RenderSystem.disableBlend();
            offset += 20.0f;
        }
        this.windows.stream().filter(WindowBase::isVisible).forEach(w -> {
            if (w != lastClickedWindow) {
                w.render(context, mouseX, mouseY);
            }
        });
        if (lastClickedWindow != null && lastClickedWindow.isVisible()) {
            lastClickedWindow.render(context, mouseX, mouseY);
        }
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        this.windows.forEach(w -> w.mouseReleased(mouseX, mouseY, button));
        return super.method_25406(mouseX, mouseY, button);
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        this.windows.stream().filter(WindowBase::isVisible).forEach(w -> w.mouseClicked(mouseX, mouseY, button));
        int i = IManager.mc.method_22683().method_4486() / 2;
        float offset = (float)this.windows.size() * 20.0f / -2.0f - 23.0f;
        if (Render2DEngine.isHovered(mouseX, mouseY, (float)i + offset + 1.0f, IManager.mc.method_22683().method_4502() - 23, 15.0, 15.0)) {
            IManager.mc.method_1507((class_437)ClickGUI.getClickGui());
        }
        offset += 23.0f;
        for (WindowBase w2 : this.windows) {
            if (Render2DEngine.isHovered(mouseX, mouseY, (float)i + offset, IManager.mc.method_22683().method_4502() - 24, 17.0, 17.0)) {
                w2.setVisible(!w2.isVisible());
            }
            offset += 20.0f;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        this.windows.stream().filter(WindowBase::isVisible).forEach(w -> w.keyPressed(keyCode, scanCode, modifiers));
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public boolean method_25400(char key, int keyCode) {
        this.windows.stream().filter(WindowBase::isVisible).forEach(w -> w.charTyped(key, keyCode));
        return super.method_25400(key, keyCode);
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        this.windows.stream().filter(WindowBase::isVisible).forEach(w -> w.mouseScrolled((int)(verticalAmount * 5.0)));
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    static {
        clickGuiIcon = class_2960.method_60655((String)"thunderhack", (String)"textures/gui/elements/clickgui.png");
    }
}

