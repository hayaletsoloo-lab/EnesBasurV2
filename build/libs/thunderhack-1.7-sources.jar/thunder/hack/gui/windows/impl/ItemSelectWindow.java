/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.block.Block
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.BufferRenderer
 *  net.minecraft.client.render.BuiltBuffer
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.resource.language.I18n
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.item.Item
 *  net.minecraft.registry.Registries
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.StringHelper
 */
package thunder.hack.gui.windows.impl;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Objects;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_3544;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_757;
import net.minecraft.class_7923;
import net.minecraft.class_9801;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.gui.clickui.ClickGUI;
import thunder.hack.gui.clickui.impl.SliderElement;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.gui.windows.WindowBase;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ItemSelectSetting;
import thunder.hack.utility.render.Render2DEngine;

public class ItemSelectWindow
extends WindowBase {
    private Setting<ItemSelectSetting> itemSetting;
    private ArrayList<ItemPlate> itemPlates = new ArrayList();
    private ArrayList<ItemPlate> allItems = new ArrayList();
    private boolean allTab = true;
    private boolean listening = false;
    private String search = "Search";

    public ItemSelectWindow(Setting<ItemSelectSetting> itemSetting) {
        this((float)Module.mc.method_22683().method_4486() / 2.0f - 100.0f, (float)Module.mc.method_22683().method_4502() / 2.0f - 150.0f, 200.0f, 300.0f, itemSetting);
    }

    public ItemSelectWindow(float x, float y, float width, float height, Setting<ItemSelectSetting> itemSetting) {
        super(x, y, width, height, "Items / " + String.valueOf(class_124.field_1080) + itemSetting.getModule().getName(), null, null);
        this.itemSetting = itemSetting;
        this.refreshItemPlates();
        int id1 = 0;
        for (class_2248 block : class_7923.field_41175) {
            this.allItems.add(new ItemPlate(id1, id1 * 20, block.method_8389(), block.method_9539()));
            ++id1;
        }
        for (class_1792 item : class_7923.field_41178) {
            this.allItems.add(new ItemPlate(id1, id1 * 20, item, item.method_7876()));
            ++id1;
        }
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY) {
        super.render(context, mouseX, mouseY);
        boolean hover1 = Render2DEngine.isHovered(mouseX, mouseY, this.getX() + this.getWidth() - 90.0f, this.getY() + 3.0f, 70.0, 10.0);
        Render2DEngine.drawRect(context.method_51448(), this.getX() + this.getWidth() - 90.0f, this.getY() + 3.0f, 70.0f, 10.0f, hover1 ? new Color(-981236861, true) : new Color(-984131753, true));
        FontRenderers.sf_medium_mini.drawString(context.method_51448(), this.search, (double)(this.getX() + this.getWidth() - 86.0f), (double)(this.getY() + 7.0f), new Color(0xD5D5D5).getRGB());
        RenderSystem.setShader(class_757::method_34540);
        int tabColor1 = this.allTab ? new Color(0xD5D5D5).getRGB() : Color.GRAY.getRGB();
        int tabColor2 = this.allTab ? Color.GRAY.getRGB() : new Color(0xBDBDBD).getRGB();
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29345, class_290.field_1576);
        bufferBuilder.method_22912(this.getX() + 1.5f, this.getY() + 29.0f, 0.0f).method_39415(Color.DARK_GRAY.getRGB());
        bufferBuilder.method_22912(this.getX() + 8.0f, this.getY() + 29.0f, 0.0f).method_39415(tabColor1);
        bufferBuilder.method_22912(this.getX() + 8.0f, this.getY() + 19.0f, 0.0f).method_39415(tabColor1);
        bufferBuilder.method_22912(this.getX() + 48.0f, this.getY() + 19.0f, 0.0f).method_39415(tabColor1);
        bufferBuilder.method_22912(this.getX() + 54.0f, this.getY() + 29.0f, 0.0f).method_39415(tabColor1);
        bufferBuilder.method_22912(this.getX() + 52.0f, this.getY() + 25.0f, 0.0f).method_39415(tabColor2);
        bufferBuilder.method_22912(this.getX() + 52.0f, this.getY() + 19.0f, 0.0f).method_39415(tabColor2);
        bufferBuilder.method_22912(this.getX() + 92.0f, this.getY() + 19.0f, 0.0f).method_39415(tabColor2);
        bufferBuilder.method_22912(this.getX() + 100.0f, this.getY() + 29.0f, 0.0f).method_39415(Color.GRAY.getRGB());
        bufferBuilder.method_22912(this.getX() + this.getWidth() - 1.0f, this.getY() + 29.0f, 0.0f).method_39415(Color.DARK_GRAY.getRGB());
        class_286.method_43433((class_9801)bufferBuilder.method_60800());
        FontRenderers.sf_medium_mini.drawString(context.method_51448(), "All", (double)(this.getX() + 25.0f), (double)(this.getY() + 25.0f), tabColor1);
        FontRenderers.sf_medium_mini.drawString(context.method_51448(), "Selected", (double)(this.getX() + 60.0f), (double)(this.getY() + 25.0f), tabColor2);
        if (!this.allTab && this.itemPlates.isEmpty()) {
            FontRenderers.sf_medium.drawCenteredString(context.method_51448(), ClientSettings.isRu() ? "\u0422\u0443\u0442 \u043f\u043e\u043a\u0430 \u043f\u0443\u0441\u0442\u043e" : "It's empty here yet", (double)(this.getX() + this.getWidth() / 2.0f), (double)(this.getY() + this.getHeight() / 2.0f), new Color(0xBDBDBD).getRGB());
        }
        Render2DEngine.addWindow(context.method_51448(), this.getX(), this.getY() + 30.0f, this.getX() + this.getWidth(), this.getY() + this.getHeight() - 1.0f, 1.0);
        for (ItemPlate itemPlate : this.allTab ? this.allItems : this.itemPlates) {
            if (itemPlate.offset + this.getY() + 25.0f + this.getScrollOffset() > this.getY() + this.getHeight() || itemPlate.offset + this.getScrollOffset() + this.getY() + 10.0f < this.getY()) continue;
            context.method_51448().method_22903();
            context.method_51448().method_46416(this.getX() + 6.0f, itemPlate.offset + this.getY() + 32.0f + this.getScrollOffset(), 0.0f);
            context.method_51427(itemPlate.item().method_7854(), 0, 0);
            context.method_51448().method_22909();
            FontRenderers.sf_medium.drawString(context.method_51448(), class_1074.method_4662((String)itemPlate.key(), (Object[])new Object[0]), (double)(this.getX() + 26.0f), (double)(itemPlate.offset + this.getY() + 38.0f + this.getScrollOffset()), new Color(0xBDBDBD).getRGB());
            boolean hover2 = Render2DEngine.isHovered(mouseX, mouseY, this.getX() + this.getWidth() - 20.0f, itemPlate.offset + this.getY() + 35.0f + this.getScrollOffset(), 11.0, 11.0);
            Render2DEngine.drawRect(context.method_51448(), this.getX() + this.getWidth() - 20.0f, itemPlate.offset + this.getY() + 35.0f + this.getScrollOffset(), 11.0f, 11.0f, hover2 ? new Color(-981828998, true) : new Color(-984131753, true));
            boolean selected = this.itemPlates.stream().anyMatch(sI -> Objects.equals(sI.key, itemPlate.key));
            if (this.allTab && !selected) {
                FontRenderers.categories.drawString(context.method_51448(), "+", (double)(this.getX() + this.getWidth() - 17.0f), (double)(itemPlate.offset + this.getY() + 39.0f + this.getScrollOffset()), -1);
                continue;
            }
            FontRenderers.icons.drawString(context.method_51448(), "w", (double)(this.getX() + this.getWidth() - 19.5f), (double)(itemPlate.offset + this.getY() + 39.0f + this.getScrollOffset()), -1);
        }
        this.setMaxElementsHeight((this.allTab ? this.allItems : this.itemPlates).size() * 20);
        Render2DEngine.popWindow();
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        super.mouseClicked(mouseX, mouseY, button);
        if (Render2DEngine.isHovered(mouseX, mouseY, this.getX() + 8.0f, this.getY() + 19.0f, 52.0, 19.0)) {
            this.allTab = true;
            this.resetScroll();
            Managers.SOUND.playBoolean();
        }
        if (Render2DEngine.isHovered(mouseX, mouseY, this.getX() + 54.0f, this.getY() + 19.0f, 70.0, 19.0)) {
            this.allTab = false;
            this.resetScroll();
            Managers.SOUND.playBoolean();
        }
        if (Render2DEngine.isHovered(mouseX, mouseY, this.getX() + this.getWidth() - 90.0f, this.getY() + 3.0f, 70.0, 10.0)) {
            this.listening = true;
            this.search = "";
        }
        if (Render2DEngine.isHovered(mouseX, mouseY, this.getX() + this.getWidth() - 15.0f, this.getY() + 3.0f, 10.0, 10.0)) {
            Module.mc.method_1507((class_437)ClickGUI.getClickGui());
        }
        ArrayList<ItemPlate> copy = Lists.newArrayList(this.allTab ? this.allItems : this.itemPlates);
        for (ItemPlate itemPlate : copy) {
            if ((float)((int)(itemPlate.offset + this.getY() + 50.0f)) + this.getScrollOffset() > this.getY() + this.getHeight()) continue;
            String name = itemPlate.key().replace("item.minecraft.", "").replace("block.minecraft.", "");
            if (!Render2DEngine.isHovered(mouseX, mouseY, this.getX() + this.getWidth() - 20.0f, itemPlate.offset + this.getY() + 35.0f + this.getScrollOffset(), 10.0, 10.0)) continue;
            boolean selected = this.itemPlates.stream().anyMatch(sI -> Objects.equals(sI.key(), itemPlate.key));
            if (this.allTab && !selected) {
                if (this.itemSetting.getValue().getItemsById().contains(name)) continue;
                this.itemSetting.getValue().getItemsById().add(name);
                this.refreshItemPlates();
            } else {
                this.itemSetting.getValue().getItemsById().remove(name);
                this.refreshItemPlates();
            }
            Managers.SOUND.playScroll();
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 70 && (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)341) || class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)345))) {
            this.listening = !this.listening;
            return;
        }
        if (this.listening) {
            switch (keyCode) {
                case 256: {
                    this.listening = false;
                    this.search = "Search";
                    this.refreshAllItems();
                    break;
                }
                case 259: {
                    this.search = SliderElement.removeLastChar(this.search);
                    this.refreshAllItems();
                    if (!Objects.equals(this.search, "")) break;
                    this.listening = false;
                    this.search = "Search";
                    break;
                }
                case 32: {
                    this.search = this.search + " ";
                }
            }
        }
    }

    @Override
    public void charTyped(char key, int keyCode) {
        if (class_3544.method_57175((char)key) && this.listening) {
            this.search = this.search + key;
            this.refreshAllItems();
        }
    }

    private void refreshItemPlates() {
        this.itemPlates.clear();
        int id = 0;
        for (class_2248 block : class_7923.field_41175) {
            if (!this.itemSetting.getValue().getItemsById().contains(block.method_9539().replace("block.minecraft.", ""))) continue;
            this.itemPlates.add(new ItemPlate(id, id * 20, block.method_8389(), block.method_9539()));
            ++id;
        }
        for (class_1792 item : class_7923.field_41178) {
            if (!this.itemSetting.getValue().getItemsById().contains(item.method_7876().replace("item.minecraft.", ""))) continue;
            this.itemPlates.add(new ItemPlate(id, id * 20, item, item.method_7876()));
            ++id;
        }
    }

    private void refreshAllItems() {
        this.allItems.clear();
        this.resetScroll();
        int id1 = 0;
        for (class_2248 block : class_7923.field_41175) {
            if (!this.search.equals("Search") && !this.search.isEmpty() && !block.method_9539().contains(this.search) && !class_1074.method_4662((String)block.method_9539(), (Object[])new Object[0]).toLowerCase().contains(this.search.toLowerCase())) continue;
            this.allItems.add(new ItemPlate(id1, id1 * 20, block.method_8389(), block.method_9539()));
            ++id1;
        }
        for (class_1792 item : class_7923.field_41178) {
            if (!this.search.equals("Search") && !this.search.isEmpty() && !item.method_7876().contains(this.search) && !item.method_7848().getString().toLowerCase().contains(this.search.toLowerCase())) continue;
            this.allItems.add(new ItemPlate(id1, id1 * 20, item, item.method_7876()));
            ++id1;
        }
    }

    private record ItemPlate(float id, float offset, class_1792 item, String key) {
    }
}

