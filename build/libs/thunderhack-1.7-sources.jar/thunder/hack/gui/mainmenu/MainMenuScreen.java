/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.gui.screen.TitleScreen
 *  net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen
 *  net.minecraft.client.gui.screen.option.OptionsScreen
 *  net.minecraft.client.gui.screen.world.SelectWorldScreen
 *  net.minecraft.client.resource.language.I18n
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Util
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.gui.mainmenu;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_526;
import org.jetbrains.annotations.NotNull;
import thunder.hack.api.IAddon;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.gui.mainmenu.CreditsScreen;
import thunder.hack.gui.mainmenu.MainMenuButton;
import thunder.hack.utility.ThunderUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

public class MainMenuScreen
extends class_437 {
    private final List<MainMenuButton> buttons = new ArrayList<MainMenuButton>();
    public boolean confirm = false;
    public static int ticksActive;
    private static MainMenuScreen INSTANCE;

    protected MainMenuScreen() {
        super(class_2561.method_30163((String)"THMainMenuScreen"));
        INSTANCE = this;
        this.buttons.add(new MainMenuButton(-110.0f, -70.0f, class_1074.method_4662((String)"menu.singleplayer", (Object[])new Object[0]).toUpperCase(Locale.ROOT), () -> Module.mc.method_1507((class_437)new class_526((class_437)(Object)this))));
        this.buttons.add(new MainMenuButton(4.0f, -70.0f, class_1074.method_4662((String)"menu.multiplayer", (Object[])new Object[0]).toUpperCase(Locale.ROOT), () -> Module.mc.method_1507((class_437)new class_500((class_437)(Object)this))));
        this.buttons.add(new MainMenuButton(-110.0f, -29.0f, class_1074.method_4662((String)"menu.options", (Object[])new Object[0]).toUpperCase(Locale.ROOT).replace(".", ""), () -> Module.mc.method_1507((class_437)new class_429((class_437)(Object)this, Module.mc.field_1690))));
        this.buttons.add(new MainMenuButton(4.0f, -29.0f, "CLICKGUI", () -> ModuleManager.clickGui.setGui()));
        this.buttons.add(new MainMenuButton(-110.0f, 12.0f, class_1074.method_4662((String)"menu.quit", (Object[])new Object[0]).toUpperCase(Locale.ROOT), () -> Module.mc.method_1592(), true));
    }

    public static MainMenuScreen getInstance() {
        ticksActive = 0;
        if (INSTANCE == null) {
            INSTANCE = new MainMenuScreen();
        }
        return INSTANCE;
    }

    public void method_25393() {
        if (++ticksActive > 400) {
            ticksActive = 0;
        }
    }

    public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
        float halfOfWidth = (float)Module.mc.method_22683().method_4486() / 2.0f;
        float halfOfHeight = (float)Module.mc.method_22683().method_4502() / 2.0f;
        float mainX = halfOfWidth - 120.0f;
        float mainY = halfOfHeight - 80.0f;
        float mainWidth = 240.0f;
        float mainHeight = 140.0f;
        this.method_25420(context, mouseX, mouseY, delta);
        Render2DEngine.drawHudBase(context.method_51448(), mainX, mainY, mainWidth, mainHeight, 20.0f);
        this.buttons.forEach(b -> b.onRender(context, mouseX, mouseY));
        boolean hoveredLogo = Render2DEngine.isHovered(mouseX, mouseY, (int)(halfOfWidth - 120.0f), (int)(halfOfHeight - 130.0f), 210.0, 50.0);
        FontRenderers.thglitchBig.drawCenteredString(context.method_51448(), "THUNDERHACK", (double)((int)halfOfWidth), (double)((int)(halfOfHeight - 120.0f)), new Color(255, 255, 255, hoveredLogo ? 230 : 180).getRGB());
        boolean hovered = Render2DEngine.isHovered(mouseX, mouseY, halfOfWidth - 50.0f, halfOfHeight + 70.0f, 100.0, 10.0);
        FontRenderers.sf_medium.drawCenteredString(context.method_51448(), "<-- Back to default menu", (double)halfOfWidth, (double)(halfOfHeight + 70.0f), hovered ? -1 : Render2DEngine.applyOpacity(-1, 0.6f));
        String onlineUsers = String.format("online: %s%s", class_124.field_1077, Managers.TELEMETRY.getOnlinePlayers().size());
        FontRenderers.sf_bold.drawCenteredString(context.method_51448(), onlineUsers, (double)halfOfWidth, (double)(halfOfHeight * 2.0f - 15.0f), Color.GREEN);
        context.method_51448().method_22903();
        context.method_51448().method_46416(halfOfWidth - 10.0f - FontRenderers.sf_medium.getStringWidth(onlineUsers) / 2.0f, halfOfHeight * 2.0f - 17.0f, 0.0f);
        Render2DEngine.drawBloom(context.method_51448(), Render2DEngine.applyOpacity(Color.GREEN, 0.6f), 9.0f);
        context.method_51448().method_22909();
        context.method_51448().method_22903();
        context.method_51448().method_46416(halfOfWidth - 10.0f - FontRenderers.sf_medium.getStringWidth(onlineUsers) / 2.0f, halfOfHeight * 2.0f - 17.0f, 0.0f);
        Render2DEngine.drawBloom(context.method_51448(), Render2DEngine.applyOpacity(Color.GREEN, (float)(0.5 + Math.sin((double)System.currentTimeMillis() / 500.0) / 2.0)), 9.0f);
        context.method_51448().method_22909();
        Render2DEngine.drawHudBase(context.method_51448(), (float)(Module.mc.method_22683().method_4486() - 40), (float)(Module.mc.method_22683().method_4502() - 40), 30.0f, 30.0f, 5.0f, Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 40, Module.mc.method_22683().method_4502() - 40, 30.0, 30.0) ? 0.7f : 1.0f);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 40, Module.mc.method_22683().method_4502() - 40, 30.0, 30.0) ? 0.7f : 1.0f));
        context.method_25293(TextureStorage.thTeam, Module.mc.method_22683().method_4486() - 40, Module.mc.method_22683().method_4502() - 40, 30, 30, 0.0f, 0.0f, 30, 30, 30, 30);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Render2DEngine.drawHudBase(context.method_51448(), (float)(Module.mc.method_22683().method_4486() - 80), (float)(Module.mc.method_22683().method_4502() - 40), 30.0f, 30.0f, 5.0f, Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 80, Module.mc.method_22683().method_4502() - 40, 30.0, 30.0) ? 0.7f : 1.0f);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 80, Module.mc.method_22683().method_4502() - 40, 30.0, 30.0) ? 0.7f : 1.0f));
        context.method_25293(TextureStorage.donation, Module.mc.method_22683().method_4486() - 79, Module.mc.method_22683().method_4502() - 39, 28, 28, 0.0f, 0.0f, 30, 30, 30, 30);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        int offsetY = 10;
        for (String change : ThunderUtility.changeLog) {
            String prefix = MainMenuScreen.getPrefix(change);
            FontRenderers.sf_medium.drawString(context.method_51448(), prefix, 10.0, (double)offsetY, Render2DEngine.applyOpacity(-1, 0.4f));
            offsetY += 10;
        }
        int totalAddonsLoaded = Managers.ADDON.getTotalAddons();
        String addonsText = "Addons Loaded: " + totalAddonsLoaded;
        int screenWidth = Module.mc.method_22683().method_4486();
        int textWidth = (int)FontRenderers.sf_bold.getStringWidth(addonsText);
        int textX = screenWidth - textWidth - 5;
        FontRenderers.sf_bold.drawString(context.method_51448(), addonsText, (double)textX, 5.0, Color.WHITE.getRGB());
        int offset = 0;
        for (IAddon addon : Managers.ADDON.getAddons()) {
            textWidth = (int)FontRenderers.sf_bold.getStringWidth(addon.getName() + " |");
            textX = screenWidth - textWidth - 5;
            FontRenderers.sf_bold.drawString(context.method_51448(), addon.getName() + String.valueOf(class_124.field_1068) + " |", (double)textX, (double)(13 + offset), Color.GRAY.getRGB());
            offset += 9;
        }
    }

    @NotNull
    private static String getPrefix(@NotNull String change) {
        Object prefix = "";
        if (change.contains("[+]")) {
            change = change.replace("[+] ", "");
            prefix = String.valueOf(class_124.field_1060) + "[+] " + String.valueOf(class_124.field_1070);
        } else if (change.contains("[-]")) {
            change = change.replace("[-] ", "");
            prefix = String.valueOf(class_124.field_1061) + "[-] " + String.valueOf(class_124.field_1070);
        } else if (change.contains("[/]")) {
            change = change.replace("[/] ", "");
            prefix = String.valueOf(class_124.field_1076) + "[/] " + String.valueOf(class_124.field_1070);
        } else if (change.contains("[*]")) {
            change = change.replace("[*] ", "");
            prefix = String.valueOf(class_124.field_1065) + "[*] " + String.valueOf(class_124.field_1070);
        }
        return (String)prefix + change;
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        float halfOfWidth = (float)Module.mc.method_22683().method_4486() / 2.0f;
        float halfOfHeight = (float)Module.mc.method_22683().method_4502() / 2.0f;
        this.buttons.forEach(b -> b.onClick((int)mouseX, (int)mouseY));
        if (Render2DEngine.isHovered(mouseX, mouseY, halfOfWidth - 50.0f, halfOfHeight + 70.0f, 100.0, 10.0)) {
            this.confirm = true;
            Module.mc.method_1507((class_437)new class_442());
            this.confirm = false;
        }
        if (Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 40, Module.mc.method_22683().method_4502() - 40, 40.0, 40.0)) {
            Module.mc.method_1507((class_437)CreditsScreen.getInstance());
        }
        if (Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 90, Module.mc.method_22683().method_4502() - 40, 40.0, 40.0)) {
            class_156.method_668().method_673(URI.create("https://www.donationalerts.com/r/06ed/"));
        }
        if (Render2DEngine.isHovered(mouseX, mouseY, (int)(halfOfWidth - 157.0f), (int)(halfOfHeight - 140.0f), 300.0, 70.0)) {
            class_156.method_668().method_673(URI.create("https://thunderhack-site.vercel.app/"));
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    static {
        INSTANCE = new MainMenuScreen();
    }
}

