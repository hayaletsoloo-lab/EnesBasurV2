/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.texture.NativeImage
 *  net.minecraft.client.texture.NativeImageBackedTexture
 *  net.minecraft.text.Text
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.Util
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.gui.mainmenu;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;
import thunder.hack.ThunderHack;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.gui.mainmenu.MainMenuScreen;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;

public class CreditsScreen
extends class_437 {
    public ArrayList<Contributor> contributors = new ArrayList();
    private static int scroll;
    private static final int SCROLL_SPEED = 1;
    private static CreditsScreen INSTANCE;

    protected CreditsScreen() {
        super(class_2561.method_30163((String)"CreditsScreen"));
        INSTANCE = this;
        for (String line : ThunderHack.contributors) {
            if (line == null) continue;
            String name = line.split(";")[0];
            String avatar = line.split(";")[1];
            String role = line.split(";")[2];
            String description = line.split(";")[3];
            String clickAction = line.split(";")[4];
            CreditsScreen.getInstance().contributors.add(new Contributor(name, CreditsScreen.getAvatar(avatar), role, description.replace('\u0442', '\n'), clickAction));
        }
    }

    public static CreditsScreen getInstance() {
        scroll = 150;
        if (INSTANCE == null) {
            INSTANCE = new CreditsScreen();
        }
        return INSTANCE;
    }

    public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
        float halfOfWidth = (float)Module.mc.method_22683().method_4486() / 2.0f;
        float halfOfHeight = (float)Module.mc.method_22683().method_4502() / 2.0f;
        float globalOffset = (float)(this.contributors.size() * 150) / 2.0f;
        this.method_25420(context, mouseX, mouseY, delta);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        int offset = 0;
        for (Contributor contributor : this.contributors) {
            float cX = halfOfWidth + (float)offset - globalOffset + (float)scroll;
            float cY = halfOfHeight - 120.0f;
            Render2DEngine.drawHudBase(context.method_51448(), cX, cY, 140.0f, 240.0f, 20.0f, false);
            FontRenderers.sf_medium.drawGradientString(context.method_51448(), contributor.name, cX + 70.0f - FontRenderers.sf_medium.getStringWidth(contributor.name) / 2.0f, halfOfHeight - 57.0f, 30);
            FontRenderers.sf_medium.drawCenteredString(context.method_51448(), contributor.role, (double)(cX + 70.0f), (double)(halfOfHeight - 48.0f), new Color(0x818181).getRGB());
            Render2DEngine.horizontalGradient(context.method_51448(), cX + 2.0f, cY + 90.0f, cX + 70.0f, cY + 91.0f, Render2DEngine.injectAlpha(new Color(-1), 0), new Color(-1));
            Render2DEngine.horizontalGradient(context.method_51448(), cX + 70.0f, cY + 90.0f, cX + 138.0f, cY + 91.0f, new Color(-1), Render2DEngine.injectAlpha(new Color(-1), 0));
            Render2DEngine.drawRound(context.method_51448(), cX + 5.0f, cY + 100.0f, 130.0f, 130.0f, 8.0f, new Color(0x73000000, true));
            FontRenderers.sf_medium.drawString(context.method_51448(), contributor.description, (double)(cX + 10.0f), (double)(cY + 108.0f), new Color(0x818182).getRGB());
            if (contributor.avatar != null) {
                context.method_25293(contributor.avatar, (int)(cX + 70.0f - 24.0f), (int)(halfOfHeight - 110.0f), 48, 48, 0.0f, 0.0f, 96, 96, 96, 96);
            }
            if (Render2DEngine.isHovered(mouseX, mouseY, cX, cY, 140.0, 240.0) && !Objects.equals(contributor.clickAction, "")) {
                Render2DEngine.drawRound(context.method_51448(), cX, cY, 140.0f, 240.0f, 8.0f, new Color(0x5FFFFFF, true));
            }
            offset += 150;
        }
        RenderSystem.disableBlend();
        Render2DEngine.drawHudBase(context.method_51448(), (float)(Module.mc.method_22683().method_4486() - 40), (float)(Module.mc.method_22683().method_4502() - 40), 30.0f, 30.0f, 5.0f, Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 60, Module.mc.method_22683().method_4502() - 60, 40.0, 40.0) ? 0.7f : 1.0f);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 40, Module.mc.method_22683().method_4502() - 40, 30.0, 30.0) ? 0.7f : 1.0f));
        context.method_25293(TextureStorage.thTeam, Module.mc.method_22683().method_4486() - 40, Module.mc.method_22683().method_4502() - 40, 30, 30, 0.0f, 0.0f, 30, 30, 30, 30);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        float halfOfWidth = (float)Module.mc.method_22683().method_4486() / 2.0f;
        float halfOfHeight = (float)Module.mc.method_22683().method_4502() / 2.0f;
        float globalOffset = (float)(this.contributors.size() * 150) / 2.0f;
        int offset = 0;
        for (Contributor contributor : this.contributors) {
            float cY;
            float cX = (float)((double)(halfOfWidth + (float)offset - globalOffset) + Render2DEngine.interpolate(scroll, scroll + 1, Render3DEngine.getTickDelta()));
            if (Render2DEngine.isHovered(mouseX, mouseY, cX, cY = halfOfHeight - 120.0f, 140.0, 240.0) && !Objects.equals(contributor.clickAction, "none")) {
                class_156.method_668().method_673(URI.create(contributor.clickAction));
            }
            offset += 150;
        }
        if (Render2DEngine.isHovered(mouseX, mouseY, Module.mc.method_22683().method_4486() - 40, Module.mc.method_22683().method_4502() - 40, 40.0, 40.0)) {
            Module.mc.method_1507((class_437)MainMenuScreen.getInstance());
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    public static class_2960 getAvatar(String name) {
        try {
            class_1043 nIBT = CreditsScreen.getAvatarFromURL("https://cdn.discordapp.com/avatars/" + name + ".png?size=96");
            if (nIBT != null) {
                return class_310.method_1551().method_1531().method_4617("th-contributors-" + (int)MathUtility.random(0.0f, 1000000.0f), nIBT);
            }
            return null;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static class_1043 getAvatarFromURL(String HeadStringURL) {
        try {
            return CreditsScreen.getAvatarFromStream(new URL(HeadStringURL).openStream());
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static class_1043 getAvatarFromStream(InputStream image) {
        class_1011 pic = null;
        try {
            pic = class_1011.method_4309((InputStream)(Object)image);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        if (pic != null) {
            return new class_1043(CreditsScreen.parseAvatar(pic));
        }
        return null;
    }

    public static class_1011 parseAvatar(class_1011 image) {
        class_1011 imgNew = new class_1011(96, 96, true);
        for (int x = 0; x < 96; ++x) {
            for (int y = 0; y < 96; ++y) {
                if (Math.hypot(x - 48, y - 48) > 45.0) {
                    imgNew.method_4305(x, y, Render2DEngine.injectAlpha(new Color(image.method_4315(x, y)), (int)((float)(48.0 - Math.hypot(x - 48, y - 48)) / 3.0f * 255.0f)).getRGB());
                    continue;
                }
                imgNew.method_4305(x, y, image.method_4315(x, y));
            }
        }
        image.close();
        return imgNew;
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll += (int)(verticalAmount * 5.0);
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public void method_25393() {
        if (--scroll <= -(this.contributors.size() * 150) + 100) {
            scroll = 0;
        }
    }

    static {
        INSTANCE = new CreditsScreen();
    }

    public record Contributor(String name, class_2960 avatar, String role, String description, String clickAction) {
    }
}

