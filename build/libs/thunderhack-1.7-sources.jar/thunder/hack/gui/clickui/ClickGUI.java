/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.text.Text
 *  net.minecraft.util.Identifier
 *  org.lwjgl.glfw.GLFW
 */
package thunder.hack.gui.clickui;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClickGui;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.clickui.AbstractCategory;
import thunder.hack.gui.clickui.Category;
import thunder.hack.gui.clickui.impl.SearchBar;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.animation.AnimationUtility;
import thunder.hack.utility.render.animation.EaseOutBack;

public class ClickGUI
extends class_437 {
    public static List<AbstractCategory> windows;
    public static boolean anyHovered;
    private boolean firstOpen;
    private float scrollY;
    private float closeAnimation;
    private float prevYaw;
    private float prevPitch;
    private float closeDirectionX;
    private float closeDirectionY;
    public static boolean close;
    public static boolean imageDirection;
    public static String currentDescription;
    public EaseOutBack imageAnimation = new EaseOutBack(6);
    private static ClickGUI INSTANCE;
    public SearchBar searchBar = new SearchBar();

    public ClickGUI() {
        super(class_2561.method_30163((String)"NewClickGUI"));
        windows = Lists.newArrayList();
        this.firstOpen = true;
        this.setInstance();
    }

    public static ClickGUI getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ClickGUI();
        }
        imageDirection = true;
        return INSTANCE;
    }

    public static ClickGUI getClickGui() {
        windows.forEach(AbstractCategory::init);
        return ClickGUI.getInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    protected void method_25426() {
        if (this.firstOpen) {
            float offset = 0.0f;
            int windowHeight = 18;
            int halfWidth = Module.mc.method_22683().method_4486() / 2;
            int halfWidthCats = (int)(((float)Module.Category.values().size() - 1.0f) / 2.0f * ((float)ModuleManager.clickGui.moduleWidth.getValue().intValue() + 4.0f));
            for (Module.Category category : Managers.MODULE.getCategories()) {
                if (category == Module.Category.HUD) continue;
                Category window = new Category(category, Managers.MODULE.getModulesByCategory(category), (float)(halfWidth - halfWidthCats) + offset, 20.0f, 100.0f, windowHeight);
                window.setOpen(true);
                windows.add(window);
                if (!((offset += (float)(ModuleManager.clickGui.moduleWidth.getValue() + 2)) > (float)Module.mc.method_22683().method_4486())) continue;
                offset = 0.0f;
            }
            this.firstOpen = false;
        } else if (windows.getFirst().getX() < 0.0f || windows.getFirst().getY() < 0.0f) {
            float offset = 0.0f;
            int halfWidth = Module.mc.method_22683().method_4486() / 2;
            int halfWidthCats = (int)(3.0f * ((float)ModuleManager.clickGui.moduleWidth.getValue().intValue() + 4.0f));
            for (AbstractCategory w : windows) {
                w.setX((float)(halfWidth - halfWidthCats) + offset);
                w.setY(20.0f);
                if (!((offset += (float)(ModuleManager.clickGui.moduleWidth.getValue() + 2)) > (float)Module.mc.method_22683().method_4486())) continue;
                offset = 0.0f;
            }
        }
        windows.forEach(AbstractCategory::init);
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25393() {
        windows.forEach(AbstractCategory::tick);
        this.imageAnimation.update(imageDirection);
        if (close) {
            if (Module.mc.field_1724 != null) {
                if (Module.mc.field_1724.method_36455() > this.prevPitch) {
                    this.closeDirectionY = (this.prevPitch - Module.mc.field_1724.method_36455()) * 300.0f;
                }
                if (Module.mc.field_1724.method_36455() < this.prevPitch) {
                    this.closeDirectionY = (this.prevPitch - Module.mc.field_1724.method_36455()) * 300.0f;
                }
                if (Module.mc.field_1724.method_36454() > this.prevYaw) {
                    this.closeDirectionX = (this.prevYaw - Module.mc.field_1724.method_36454()) * 300.0f;
                }
                if (Module.mc.field_1724.method_36454() < this.prevYaw) {
                    this.closeDirectionX = (this.prevYaw - Module.mc.field_1724.method_36454()) * 300.0f;
                }
            }
            if (this.closeDirectionX < 1.0f && this.closeDirectionY < 1.0f && this.closeAnimation > 2.0f) {
                this.closeDirectionY = -3000.0f;
            }
            this.closeAnimation += 1.0f;
            if (this.closeAnimation > 6.0f) {
                close = false;
                windows.forEach(AbstractCategory::restorePos);
                this.method_25419();
            }
        }
        if (this.searchBar != null) {
            this.searchBar.tick();
        }
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (ModuleManager.clickGui.blur.getValue().booleanValue()) {
            this.method_57734(delta);
        }
        anyHovered = false;
        ClickGui.Image image = ModuleManager.clickGui.image.getValue();
        if (image != ClickGui.Image.None) {
            RenderSystem.setShaderTexture((int)0, (class_2960)(Object)image.file);
            Render2DEngine.renderTexture(context.method_51448(), (double)Module.mc.method_22683().method_4486() - (double)image.fileWidth * this.imageAnimation.getAnimationd(), Module.mc.method_22683().method_4502() - image.fileHeight, image.fileWidth, image.fileHeight, 0.0f, 0.0f, image.fileWidth, image.fileHeight, image.fileWidth, image.fileHeight);
        }
        if (this.closeAnimation <= 6.0f) {
            windows.forEach(w -> {
                w.setX(w.getX() + this.closeDirectionX * AnimationUtility.deltaTime());
                w.setY(w.getY() + this.closeDirectionY * AnimationUtility.deltaTime());
            });
        }
        if (Module.fullNullCheck()) {
            this.method_25420(context, mouseX, mouseY, delta);
        }
        if (ModuleManager.clickGui.scrollMode.getValue() == ClickGui.scrollModeEn.Old) {
            for (AbstractCategory window : windows) {
                if (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)264)) {
                    window.setY(window.getY() + 2.0f);
                }
                if (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)265)) {
                    window.setY(window.getY() - 2.0f);
                }
                if (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)262)) {
                    window.setX(window.getX() + 2.0f);
                }
                if (class_3675.method_15987((long)Module.mc.method_22683().method_4490(), (int)263)) {
                    window.setX(window.getX() - 2.0f);
                }
                if (this.scrollY == 0.0f) continue;
                window.setY(window.getY() + this.scrollY);
            }
        } else {
            for (AbstractCategory window : windows) {
                if (this.scrollY == 0.0f) continue;
                window.setModuleOffset(this.scrollY, mouseX, mouseY);
            }
        }
        this.scrollY = 0.0f;
        windows.forEach(w -> w.render(context, mouseX, mouseY, delta));
        if (!Objects.equals(currentDescription, "") && ModuleManager.clickGui.descriptions.getValue().booleanValue()) {
            Render2DEngine.drawHudBase(context.method_51448(), (float)(mouseX + 7), (float)(mouseY + 5), FontRenderers.sf_medium.getStringWidth(currentDescription) + 6.0f, 11.0f, 1.0f, false);
            FontRenderers.sf_medium.drawString(context.method_51448(), currentDescription, (double)(mouseX + 10), (double)(mouseY + 8), HudEditor.getColor(0).getRGB());
            currentDescription = "";
        }
        if (this.searchBar != null) {
            this.searchBar.setX((float)Module.mc.method_22683().method_4486() / 2.0f - 75.0f);
            this.searchBar.setY(Module.mc.method_22683().method_4502() - 22);
            this.searchBar.setWidth(150.0f);
            this.searchBar.setHeight(14.0f);
            this.searchBar.render(context, mouseX, mouseY, delta);
            FontRenderers.sf_medium_mini.drawString(context.method_51448(), "Left Click: Toggle | Right Click: Settings | Middle Click: Bind | Ctrl+F: Search", (double)((float)Module.mc.method_22683().method_4486() / 2.0f - 350.0f), (double)(Module.mc.method_22683().method_4502() - 12), new Color(150, 150, 150).getRGB());
        }
        if (!HudElement.anyHovered && !anyHovered && GLFW.glfwGetPlatform() != 393219) {
            GLFW.glfwSetCursor((long)Module.mc.method_22683().method_4490(), (long)GLFW.glfwCreateStandardCursor((int)221185));
        }
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        this.scrollY += (float)((int)(verticalAmount * 5.0));
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        windows.forEach(w -> {
            w.mouseClicked((int)mouseX, (int)mouseY, button);
            windows.forEach(w1 -> {
                if (w.dragging && w != w1) {
                    w1.dragging = false;
                }
            });
        });
        if (this.searchBar != null) {
            this.searchBar.mouseClicked((int)mouseX, (int)mouseY, button);
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        windows.forEach(w -> w.mouseReleased((int)mouseX, (int)mouseY, button));
        return super.method_25406(mouseX, mouseY, button);
    }

    public boolean method_25400(char key, int modifier) {
        if (this.searchBar != null) {
            this.searchBar.charTyped(key, modifier);
        }
        windows.forEach(w -> w.charTyped(key, modifier));
        return true;
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        windows.forEach(w -> w.keyTyped(keyCode));
        if (this.searchBar != null) {
            this.searchBar.keyTyped(keyCode);
        }
        if (keyCode == 256 && SearchBar.listening) {
            SearchBar.listening = false;
            return true;
        }
        if (keyCode == 256) {
            if (Module.mc.field_1724 == null || !ModuleManager.clickGui.closeAnimation.getValue().booleanValue()) {
                imageDirection = false;
                this.imageAnimation.reset();
                super.method_25404(keyCode, scanCode, modifiers);
                return true;
            }
            if (close) {
                return true;
            }
            imageDirection = false;
            windows.forEach(AbstractCategory::savePos);
            this.closeDirectionX = 0.0f;
            this.closeDirectionY = 0.0f;
            close = true;
            Module.mc.field_1729.method_1612();
            this.closeAnimation = 0.0f;
            if (Module.mc.field_1724 != null) {
                this.prevYaw = Module.mc.field_1724.method_36454();
                this.prevPitch = Module.mc.field_1724.method_36455();
            }
            return true;
        }
        return false;
    }

    static {
        close = false;
        currentDescription = "";
        INSTANCE = new ClickGUI();
    }
}

