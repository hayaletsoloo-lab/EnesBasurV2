/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Identifier
 */
package thunder.hack.gui.font;

import net.minecraft.class_2960;

public class Texture {
    final class_2960 id;

    public Texture(String path) {
        this.id = class_2960.method_60655((String)"thunderhack", (String)(Object)this.validatePath(path));
    }

    public Texture(class_2960 i) {
        this.id = class_2960.method_60655((String)i.method_12836(), (String)i.method_12832());
    }

    String validatePath(String path) {
        if (class_2960.method_20208((String)path)) {
            return path;
        }
        StringBuilder ret = new StringBuilder();
        for (char c : path.toLowerCase().toCharArray()) {
            if (!class_2960.method_29184((char)c)) continue;
            ret.append(c);
        }
        return ret.toString();
    }

    public class_2960 getId() {
        return this.id;
    }
}

