/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.client.gui.screen.ingame.ShulkerBoxScreen
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.ShulkerBoxScreenHandler
 *  net.minecraft.text.Text
 */
package thunder.hack.gui.misc;

import net.minecraft.class_1661;
import net.minecraft.class_1733;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_495;

public class PeekScreen
extends class_495 {
    private static final class_1799[] ITEMS = new class_1799[27];

    public PeekScreen(class_1733 handler, class_1661 inventory, class_2561 title, class_2248 block) {
        super(handler, inventory, title);
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 2 && this.field_2787 != null && !this.field_2787.method_7677().method_7960() && this.field_22787.field_1724.field_7498.method_34255().method_7960()) {
            class_1799 itemStack = this.field_2787.method_7677();
        }
        return false;
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        return false;
    }
}

