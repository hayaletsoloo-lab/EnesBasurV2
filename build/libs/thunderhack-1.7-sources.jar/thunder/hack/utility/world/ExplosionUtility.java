/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockState
 *  net.minecraft.block.Blocks
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.entity.DamageUtil
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.attribute.EntityAttributes
 *  net.minecraft.entity.damage.DamageSource
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.shape.VoxelShape
 *  net.minecraft.util.shape.VoxelShapes
 *  net.minecraft.world.BlockView
 *  net.minecraft.world.Difficulty
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext$FluidHandling
 *  net.minecraft.world.RaycastContext$ShapeType
 *  net.minecraft.world.World
 *  net.minecraft.world.explosion.Explosion
 *  net.minecraft.world.explosion.Explosion$DestructionType
 *  org.apache.commons.lang3.mutable.MutableInt
 */
package thunder.hack.utility.world;

import java.util.Objects;
import net.minecraft.class_1267;
import net.minecraft.class_1280;
import net.minecraft.class_1282;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import org.apache.commons.lang3.mutable.MutableInt;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IExplosion;
import thunder.hack.utility.math.PredictUtility;

public final class ExplosionUtility {
    public static boolean terrainIgnore = false;
    public static class_1927 explosion;

    public static float getAutoCrystalDamage(class_243 crystalPos, class_1657 target, int predictTicks, boolean optimized) {
        if (predictTicks == 0) {
            return ExplosionUtility.getExplosionDamage(crystalPos, target, optimized);
        }
        return ExplosionUtility.getExplosionDamageWPredict(crystalPos, target, PredictUtility.predictBox(target, predictTicks), optimized);
    }

    public static float getSelfExplosionDamage(class_243 explosionPos, int predictTicks, boolean optimized) {
        return ExplosionUtility.getAutoCrystalDamage(explosionPos, (class_1657)Module.mc.field_1724, predictTicks, optimized);
    }

    public static float getExplosionDamage(class_243 explosionPos, class_1657 target, boolean optimized) {
        if (Module.mc.field_1687.method_8407() == class_1267.field_5801 || target == null) {
            return 0.0f;
        }
        if (explosion == null) {
            explosion = new class_1927((class_1937)Module.mc.field_1687, (class_1297)Module.mc.field_1724, 1.0, 33.0, 7.0, 6.0f, false, class_1927.class_4179.field_18687);
        }
        ((IExplosion)explosion).setX(explosionPos.field_1352);
        ((IExplosion)explosion).setY(explosionPos.field_1351);
        ((IExplosion)explosion).setZ(explosionPos.field_1350);
        if (((IExplosion)explosion).getWorld() != Module.mc.field_1687) {
            ((IExplosion)explosion).setWorld((class_1937)Module.mc.field_1687);
        }
        if (!new class_238((double)class_3532.method_15357((double)(explosionPos.field_1352 - 11.0)), (double)class_3532.method_15357((double)(explosionPos.field_1351 - 11.0)), (double)class_3532.method_15357((double)(explosionPos.field_1350 - 11.0)), (double)class_3532.method_15357((double)(explosionPos.field_1352 + 13.0)), (double)class_3532.method_15357((double)(explosionPos.field_1351 + 13.0)), (double)class_3532.method_15357((double)(explosionPos.field_1350 + 13.0))).method_994(target.method_5829())) {
            return 0.0f;
        }
        if (!target.method_5659(explosion) && !target.method_5655()) {
            double d = (double)((float)target.method_5707(explosionPos)) / 144.0;
            if (d <= 1.0) {
                double exposure = ExplosionUtility.getExposure(explosionPos, target.method_5829(), optimized);
                terrainIgnore = false;
                double finalExposure = (1.0 - d) * exposure;
                float toDamage = (float)Math.floor((finalExposure * finalExposure + finalExposure) / 2.0 * 7.0 * 12.0 + 1.0);
                if (Module.mc.field_1687.method_8407() == class_1267.field_5805) {
                    toDamage = Math.min(toDamage / 2.0f + 1.0f, toDamage);
                } else if (Module.mc.field_1687.method_8407() == class_1267.field_5807) {
                    toDamage = toDamage * 3.0f / 2.0f;
                }
                toDamage = class_1280.method_5496((class_1309)target, (float)toDamage, (class_1282)((IExplosion)explosion).getDamageSource(), (float)target.method_6096(), (float)((float)target.method_5996(class_5134.field_23725).method_6194()));
                if (target.method_6059(class_1294.field_5907)) {
                    int resistance = 25 - (target.method_6112(class_1294.field_5907).method_5578() + 1) * 5;
                    float resistance_1 = toDamage * (float)resistance;
                    toDamage = Math.max(resistance_1 / 25.0f, 0.0f);
                }
                if (toDamage <= 0.0f) {
                    toDamage = 0.0f;
                } else {
                    float protAmount = ExplosionUtility.getProtectionAmount(target.method_5661());
                    if (protAmount > 0.0f) {
                        toDamage = class_1280.method_5497((float)toDamage, (float)protAmount);
                    }
                }
                return toDamage;
            }
        }
        return 0.0f;
    }

    public static float getExplosionDamageWPredict(class_243 explosionPos, class_1657 target, class_238 predict, boolean optimized) {
        if (Module.mc.field_1687.method_8407() == class_1267.field_5801) {
            return 0.0f;
        }
        if (target == null || predict == null) {
            return 0.0f;
        }
        if (explosion == null) {
            explosion = new class_1927((class_1937)Module.mc.field_1687, (class_1297)Module.mc.field_1724, 1.0, 33.0, 7.0, 6.0f, false, class_1927.class_4179.field_18687);
        }
        ((IExplosion)explosion).setX(explosionPos.field_1352);
        ((IExplosion)explosion).setY(explosionPos.field_1351);
        ((IExplosion)explosion).setZ(explosionPos.field_1350);
        if (((IExplosion)explosion).getWorld() != Module.mc.field_1687) {
            ((IExplosion)explosion).setWorld((class_1937)Module.mc.field_1687);
        }
        if (!new class_238((double)class_3532.method_15357((double)(explosionPos.field_1352 - 11.0)), (double)class_3532.method_15357((double)(explosionPos.field_1351 - 11.0)), (double)class_3532.method_15357((double)(explosionPos.field_1350 - 11.0)), (double)class_3532.method_15357((double)(explosionPos.field_1352 + 13.0)), (double)class_3532.method_15357((double)(explosionPos.field_1351 + 13.0)), (double)class_3532.method_15357((double)(explosionPos.field_1350 + 13.0))).method_994(predict)) {
            return 0.0f;
        }
        if (!target.method_5659(explosion) && !target.method_5655()) {
            double d = predict.method_1005().method_1031(0.0, -0.9, 0.0).method_1025(explosionPos) / 144.0;
            if (d <= 1.0) {
                double exposure = ExplosionUtility.getExposure(explosionPos, predict, optimized);
                terrainIgnore = false;
                double finalExposure = (1.0 - d) * exposure;
                float toDamage = (float)Math.floor((finalExposure * finalExposure + finalExposure) / 2.0 * 7.0 * 12.0 + 1.0);
                if (Module.mc.field_1687.method_8407() == class_1267.field_5805) {
                    toDamage = Math.min(toDamage / 2.0f + 1.0f, toDamage);
                } else if (Module.mc.field_1687.method_8407() == class_1267.field_5807) {
                    toDamage = toDamage * 3.0f / 2.0f;
                }
                toDamage = class_1280.method_5496((class_1309)target, (float)toDamage, (class_1282)((IExplosion)explosion).getDamageSource(), (float)target.method_6096(), (float)((float)Objects.requireNonNull(target.method_5996(class_5134.field_23725)).method_6194()));
                if (target.method_6059(class_1294.field_5907)) {
                    int resistance = 25 - (Objects.requireNonNull(target.method_6112(class_1294.field_5907)).method_5578() + 1) * 5;
                    float resistance_1 = toDamage * (float)resistance;
                    toDamage = Math.max(resistance_1 / 25.0f, 0.0f);
                }
                if (toDamage <= 0.0f) {
                    toDamage = 0.0f;
                } else {
                    float protAmount = ExplosionUtility.getProtectionAmount(target.method_5661());
                    if (protAmount > 0.0f) {
                        toDamage = class_1280.method_5497((float)toDamage, (float)protAmount);
                    }
                }
                return toDamage;
            }
        }
        return 0.0f;
    }

    public static class_3965 rayCastBlock(class_3959 context, class_2338 block) {
        return (class_3965)class_1922.method_17744((class_243)context.method_17750(), (class_243)context.method_17747(), context, (raycastContext, blockPos) -> {
            class_2680 blockState = !blockPos.equals(block) ? class_2246.field_10124.method_9564() : class_2246.field_10540.method_9564();
            class_243 vec3d = raycastContext.method_17750();
            class_243 vec3d2 = raycastContext.method_17747();
            class_265 voxelShape = raycastContext.method_17748(blockState, (class_1922)Module.mc.field_1687, blockPos);
            class_3965 blockHitResult = Module.mc.field_1687.method_17745(vec3d, vec3d2, blockPos, voxelShape, blockState);
            class_265 voxelShape2 = class_259.method_1073();
            class_3965 blockHitResult2 = voxelShape2.method_1092(vec3d, vec3d2, blockPos);
            double d = blockHitResult == null ? Double.MAX_VALUE : raycastContext.method_17750().method_1025(blockHitResult.method_17784());
            double e = blockHitResult2 == null ? Double.MAX_VALUE : raycastContext.method_17750().method_1025(blockHitResult2.method_17784());
            return d <= e ? blockHitResult : blockHitResult2;
        }, raycastContext -> {
            class_243 vec3d = raycastContext.method_17750().method_1020(raycastContext.method_17747());
            return class_3965.method_17778((class_243)raycastContext.method_17747(), (class_2350)class_2350.method_10142((double)vec3d.field_1352, (double)vec3d.field_1351, (double)vec3d.field_1350), (class_2338)class_2338.method_49638((class_2374)raycastContext.method_17747()));
        });
    }

    public static float getDamageOfGhostBlock(class_243 explosionPos, class_1657 target, class_2338 bp) {
        if (Module.mc.field_1687.method_8407() == class_1267.field_5801) {
            return 0.0f;
        }
        if (explosion == null) {
            explosion = new class_1927((class_1937)Module.mc.field_1687, (class_1297)Module.mc.field_1724, 1.0, 33.0, 7.0, 6.0f, false, class_1927.class_4179.field_18687);
        }
        ((IExplosion)explosion).setX(explosionPos.field_1352);
        ((IExplosion)explosion).setY(explosionPos.field_1351);
        ((IExplosion)explosion).setZ(explosionPos.field_1350);
        if (((IExplosion)explosion).getWorld() != Module.mc.field_1687) {
            ((IExplosion)explosion).setWorld((class_1937)Module.mc.field_1687);
        }
        double maxDist = 12.0;
        if (!new class_238((double)class_3532.method_15357((double)(explosionPos.field_1352 - 12.0 - 1.0)), (double)class_3532.method_15357((double)(explosionPos.field_1351 - maxDist - 1.0)), (double)class_3532.method_15357((double)(explosionPos.field_1350 - maxDist - 1.0)), (double)class_3532.method_15357((double)(explosionPos.field_1352 + maxDist + 1.0)), (double)class_3532.method_15357((double)(explosionPos.field_1351 + maxDist + 1.0)), (double)class_3532.method_15357((double)(explosionPos.field_1350 + maxDist + 1.0))).method_994(target.method_5829())) {
            return 0.0f;
        }
        if (!target.method_5659(explosion) && !target.method_5655()) {
            double d = target.method_5707(explosionPos) / 144.0;
            if (d <= 1.0) {
                double exposure = ExplosionUtility.getExposureGhost(explosionPos, (class_1297)target, bp);
                terrainIgnore = false;
                double finalExposure = (1.0 - d) * exposure;
                float toDamage = (float)Math.floor((finalExposure * finalExposure + finalExposure) / 2.0 * 7.0 * maxDist + 1.0);
                if (Module.mc.field_1687.method_8407() == class_1267.field_5805) {
                    toDamage = Math.min(toDamage / 2.0f + 1.0f, toDamage);
                } else if (Module.mc.field_1687.method_8407() == class_1267.field_5807) {
                    toDamage = toDamage * 3.0f / 2.0f;
                }
                toDamage = class_1280.method_5496((class_1309)target, (float)toDamage, (class_1282)((IExplosion)explosion).getDamageSource(), (float)target.method_6096(), (float)((float)target.method_5996(class_5134.field_23725).method_6194()));
                if (target.method_6059(class_1294.field_5907)) {
                    int resistance = 25 - (target.method_6112(class_1294.field_5907).method_5578() + 1) * 5;
                    float resistance_1 = toDamage * (float)resistance;
                    toDamage = Math.max(resistance_1 / 25.0f, 0.0f);
                }
                if (toDamage <= 0.0f) {
                    toDamage = 0.0f;
                } else {
                    float protAmount = ExplosionUtility.getProtectionAmount(target.method_5661());
                    if (protAmount > 0.0f) {
                        toDamage = class_1280.method_5497((float)toDamage, (float)protAmount);
                    }
                }
                return toDamage;
            }
        }
        return 0.0f;
    }

    private static float getExposureGhost(class_243 source, class_1297 entity, class_2338 pos) {
        class_238 box = entity.method_5829();
        double d = 1.0 / ((box.field_1320 - box.field_1323) * 2.0 + 1.0);
        double e = 1.0 / ((box.field_1325 - box.field_1322) * 2.0 + 1.0);
        double f = 1.0 / ((box.field_1324 - box.field_1321) * 2.0 + 1.0);
        double g = (1.0 - Math.floor(1.0 / d) * d) / 2.0;
        double h = (1.0 - Math.floor(1.0 / f) * f) / 2.0;
        if (d < 0.0 || e < 0.0 || f < 0.0) {
            return 0.0f;
        }
        int i = 0;
        int j = 0;
        for (double k = 0.0; k <= 1.0; k += d) {
            for (double l = 0.0; l <= 1.0; l += e) {
                for (double m = 0.0; m <= 1.0; m += f) {
                    double p;
                    double o;
                    double n = class_3532.method_16436((double)k, (double)box.field_1323, (double)box.field_1320);
                    class_243 vec3d = new class_243(n + g, o = class_3532.method_16436((double)l, (double)box.field_1322, (double)box.field_1325), (p = class_3532.method_16436((double)m, (double)box.field_1321, (double)box.field_1324)) + h);
                    if (ExplosionUtility.raycastGhost(new class_3959(vec3d, source, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, entity), pos).method_17783() == class_239.class_240.field_1333) {
                        ++i;
                    }
                    ++j;
                }
            }
        }
        return (float)i / (float)j;
    }

    public static float getExposure(class_243 source, class_238 box, boolean optimized) {
        if (!optimized) {
            return ExplosionUtility.getExposure(source, box);
        }
        int miss = 0;
        int hit = 0;
        for (int k = 0; k <= 1; ++k) {
            for (int l = 0; l <= 1; ++l) {
                for (int m = 0; m <= 1; ++m) {
                    double p;
                    double o;
                    double n = class_3532.method_16436((double)k, (double)box.field_1323, (double)box.field_1320);
                    class_243 vec3d = new class_243(n, o = class_3532.method_16436((double)l, (double)box.field_1322, (double)box.field_1325), p = class_3532.method_16436((double)m, (double)box.field_1321, (double)box.field_1324));
                    if (ExplosionUtility.raycast(vec3d, source, false) == class_239.class_240.field_1333) {
                        ++miss;
                    }
                    ++hit;
                }
            }
        }
        return (float)miss / (float)hit;
    }

    public static float getExposure(class_243 source, class_238 box) {
        double d = 0.4545454446934474;
        double e = 0.21739130885479366;
        double f = 0.4545454446934474;
        int i = 0;
        int j = 0;
        for (double k = 0.0; k <= 1.0; k += d) {
            for (double l = 0.0; l <= 1.0; l += e) {
                for (double m = 0.0; m <= 1.0; m += f) {
                    double p;
                    double o;
                    double n = class_3532.method_16436((double)k, (double)box.field_1323, (double)box.field_1320);
                    class_243 vec3d = new class_243(n + 0.045454555306552624, o = class_3532.method_16436((double)l, (double)box.field_1322, (double)box.field_1325), (p = class_3532.method_16436((double)m, (double)box.field_1321, (double)box.field_1324)) + 0.045454555306552624);
                    if (ExplosionUtility.raycast(vec3d, source, false) == class_239.class_240.field_1333) {
                        ++i;
                    }
                    ++j;
                }
            }
        }
        return (float)i / (float)j;
    }

    private static class_3965 raycastGhost(class_3959 context, class_2338 bPos) {
        return (class_3965)class_1922.method_17744((class_243)context.method_17750(), (class_243)context.method_17747(), context, (innerContext, pos) -> {
            class_243 vec3d = innerContext.method_17750();
            class_243 vec3d2 = innerContext.method_17747();
            class_2680 blockState = !pos.equals(bPos) ? Module.mc.field_1687.method_8320(bPos) : class_2246.field_10540.method_9564();
            class_265 voxelShape = innerContext.method_17748(blockState, (class_1922)Module.mc.field_1687, pos);
            class_3965 blockHitResult = Module.mc.field_1687.method_17745(vec3d, vec3d2, pos, voxelShape, blockState);
            class_3965 blockHitResult2 = class_259.method_1073().method_1092(vec3d, vec3d2, pos);
            double d = blockHitResult == null ? Double.MAX_VALUE : innerContext.method_17750().method_1025(blockHitResult.method_17784());
            double e = blockHitResult2 == null ? Double.MAX_VALUE : innerContext.method_17750().method_1025(blockHitResult2.method_17784());
            return d <= e ? blockHitResult : blockHitResult2;
        }, innerContext -> {
            class_243 vec3d = innerContext.method_17750().method_1020(innerContext.method_17747());
            return class_3965.method_17778((class_243)innerContext.method_17747(), (class_2350)class_2350.method_10142((double)vec3d.field_1352, (double)vec3d.field_1351, (double)vec3d.field_1350), (class_2338)class_2338.method_49638((class_2374)innerContext.method_17747()));
        });
    }

    public static class_239.class_240 raycast(class_243 start, class_243 end, boolean ignoreTerrain) {
        return (class_239.class_240)class_1922.method_17744((class_243)start, (class_243)end, null, (innerContext, blockPos) -> {
            class_2680 blockState = Module.mc.field_1687.method_8320(blockPos);
            if (blockState.method_26204().method_9520() < 600.0f && ignoreTerrain) {
                return null;
            }
            class_3965 hitResult = blockState.method_26220((class_1922)Module.mc.field_1687, blockPos).method_1092(start, end, blockPos);
            return hitResult == null ? null : hitResult.method_17783();
        }, innerContext -> class_239.class_240.field_1333);
    }

    public static int getProtectionAmount(Iterable<class_1799> equipment) {
        MutableInt mutableInt = new MutableInt();
        equipment.forEach(i -> mutableInt.add(ExplosionUtility.getProtectionAmount(i)));
        return mutableInt.intValue();
    }

    public static int getProtectionAmount(class_1799 stack) {
        int modifierBlast = class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9107.method_58273()).method_40264(class_1893.field_9107).get()), (class_1799)stack);
        int modifier = class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9111.method_58273()).method_40264(class_1893.field_9111).get()), (class_1799)stack);
        return modifierBlast * 2 + modifier;
    }
}

