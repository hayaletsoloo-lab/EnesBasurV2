/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gl.Framebuffer
 */
package thunder.hack.utility.interfaces;

import net.minecraft.class_276;

public interface IShaderEffect {
    public void addFakeTargetHook(String var1, class_276 var2);
}

