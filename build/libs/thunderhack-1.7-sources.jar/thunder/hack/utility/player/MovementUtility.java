/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.util.math.MathHelper
 */
package thunder.hack.utility.player;

import net.minecraft.class_1294;
import net.minecraft.class_3532;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventMove;
import thunder.hack.features.modules.Module;

public final class MovementUtility {
    public static boolean isMoving() {
        return Module.mc.field_1724 != null && Module.mc.field_1687 != null && Module.mc.field_1724.field_3913 != null && ((double)Module.mc.field_1724.field_3913.field_3905 != 0.0 || (double)Module.mc.field_1724.field_3913.field_3907 != 0.0);
    }

    public static double getSpeed() {
        return Math.hypot(Module.mc.field_1724.method_18798().field_1352, Module.mc.field_1724.method_18798().field_1350);
    }

    public static double[] forward(double d) {
        float f = Module.mc.field_1724.field_3913.field_3905;
        float f2 = Module.mc.field_1724.field_3913.field_3907;
        float f3 = Module.mc.field_1724.method_36454();
        if (f != 0.0f) {
            if (f2 > 0.0f) {
                f3 += (float)(f > 0.0f ? -45 : 45);
            } else if (f2 < 0.0f) {
                f3 += (float)(f > 0.0f ? 45 : -45);
            }
            f2 = 0.0f;
            if (f > 0.0f) {
                f = 1.0f;
            } else if (f < 0.0f) {
                f = -1.0f;
            }
        }
        double d2 = Math.sin(Math.toRadians(f3 + 90.0f));
        double d3 = Math.cos(Math.toRadians(f3 + 90.0f));
        double d4 = (double)f * d * d3 + (double)f2 * d * d2;
        double d5 = (double)f * d * d2 - (double)f2 * d * d3;
        return new double[]{d4, d5};
    }

    public static void setMotion(double speed) {
        double forward = Module.mc.field_1724.field_3913.field_3905;
        double strafe = Module.mc.field_1724.field_3913.field_3907;
        float yaw = Module.mc.field_1724.method_36454();
        if (forward == 0.0 && strafe == 0.0) {
            Module.mc.field_1724.method_18800(0.0, Module.mc.field_1724.method_18798().field_1351, 0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            double sin = class_3532.method_15374((float)((float)Math.toRadians(yaw + 90.0f)));
            double cos = class_3532.method_15362((float)((float)Math.toRadians(yaw + 90.0f)));
            Module.mc.field_1724.method_18800(forward * speed * cos + strafe * speed * sin, Module.mc.field_1724.method_18798().field_1351, forward * speed * sin - strafe * speed * cos);
        }
    }

    public static float getMoveDirection() {
        double forward = Module.mc.field_1724.field_3913.field_3905;
        double strafe = Module.mc.field_1724.field_3913.field_3907;
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        float yaw = Module.mc.field_1724.method_36454();
        if (forward == 0.0 && strafe == 0.0) {
            return yaw;
        }
        if (forward != 0.0) {
            if (strafe > 0.0) {
                yaw += forward > 0.0 ? -45.0f : -135.0f;
            } else if (strafe < 0.0) {
                yaw += forward > 0.0 ? 45.0f : 135.0f;
            } else if (forward < 0.0) {
                yaw += 180.0f;
            }
        }
        if (forward == 0.0) {
            if (strafe > 0.0) {
                yaw -= 90.0f;
            } else if (strafe < 0.0) {
                yaw += 90.0f;
            }
        }
        return yaw;
    }

    public static double[] forwardWithoutStrafe(double d) {
        float f3 = Module.mc.field_1724.method_36454();
        double d4 = d * Math.cos(Math.toRadians(f3 + 90.0f));
        double d5 = d * Math.sin(Math.toRadians(f3 + 90.0f));
        return new double[]{d4, d5};
    }

    public static double getJumpSpeed() {
        double jumpSpeed = 0.3999999463558197;
        if (Module.mc.field_1724.method_6059(class_1294.field_5913)) {
            double amplifier = Module.mc.field_1724.method_6112(class_1294.field_5913).method_5578();
            jumpSpeed += (amplifier + 1.0) * 0.1;
        }
        return jumpSpeed;
    }

    public static void modifyEventSpeed(EventMove event, double d) {
        double d2 = Module.mc.field_1724.field_3913.field_3905;
        double d3 = Module.mc.field_1724.field_3913.field_3907;
        float f = Module.mc.field_1724.method_36454();
        if (d2 == 0.0 && d3 == 0.0) {
            event.setX(0.0);
            event.setZ(0.0);
        } else {
            if (d2 != 0.0) {
                if (d3 > 0.0) {
                    f += (float)(d2 > 0.0 ? -45 : 45);
                } else if (d3 < 0.0) {
                    f += (float)(d2 > 0.0 ? 45 : -45);
                }
                d3 = 0.0;
                if (d2 > 0.0) {
                    d2 = 1.0;
                } else if (d2 < 0.0) {
                    d2 = -1.0;
                }
            }
            double sin = Math.sin(Math.toRadians(f + 90.0f));
            double cos = Math.cos(Math.toRadians(f + 90.0f));
            event.setX(d2 * d * cos + d3 * d * sin);
            event.setZ(d2 * d * sin - d3 * d * cos);
        }
    }

    public static double getBaseMoveSpeed() {
        int n;
        double d = 0.2873;
        if (Module.fullNullCheck()) {
            return d;
        }
        if (Module.mc.field_1724.method_6059(class_1294.field_5904)) {
            n = Module.mc.field_1724.method_6112(class_1294.field_5904).method_5578();
            d *= 1.0 + 0.2 * (double)(n + 1);
        }
        if (Module.mc.field_1724.method_6059(class_1294.field_5913)) {
            n = Module.mc.field_1724.method_6112(class_1294.field_5913).method_5578();
            d /= 1.0 + 0.2 * (double)(n + 1);
        }
        if (Module.mc.field_1724.method_6059(class_1294.field_5909)) {
            n = Module.mc.field_1724.method_6112(class_1294.field_5909).method_5578();
            d /= 1.0 + 0.2 * (double)(n + 1);
        }
        return d;
    }

    public static boolean sprintIsLegit(float yaw) {
        return Math.abs(Math.abs(class_3532.method_15393((float)yaw)) - Math.abs(class_3532.method_15393((float)Managers.PLAYER.yaw))) < 40.0f;
    }
}

