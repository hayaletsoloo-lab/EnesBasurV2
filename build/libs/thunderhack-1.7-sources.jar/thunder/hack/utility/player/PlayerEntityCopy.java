/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.OtherClientPlayerEntity
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.Entity$RemovalReason
 */
package thunder.hack.utility.player;

import java.util.Objects;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_745;
import thunder.hack.features.modules.Module;

public class PlayerEntityCopy
extends class_745 {
    public PlayerEntityCopy() {
        super(Objects.requireNonNull(Module.mc.field_1687), Objects.requireNonNull(Module.mc.field_1724).method_7334());
        this.method_5878((class_1297)Module.mc.field_1724);
        this.method_3123();
        this.field_6011.method_12778(field_7518, ((Byte)Module.mc.field_1724.method_5841().method_12789(field_7518)));
        this.method_5826(UUID.randomUUID());
    }

    public void spawn() {
        if (Module.mc.field_1687 == null) {
            return;
        }
        this.method_31482();
        Module.mc.field_1687.method_53875((class_1297)(Object)this);
    }

    public void deSpawn() {
        if (Module.mc.field_1687 == null) {
            return;
        }
        Module.mc.field_1687.method_2945(this.method_5628(), class_1297.class_5529.field_26999);
    }
}

