/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.network.PendingUpdateManager
 *  net.minecraft.client.network.SequencedPacketCreator
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ExperienceOrbEntity
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.c2s.play.HandSwingC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$Full
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$LookAndOnGround
 *  net.minecraft.util.Hand
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext$FluidHandling
 *  net.minecraft.world.RaycastContext$ShapeType
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package thunder.hack.utility.player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1542;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_7202;
import net.minecraft.class_7204;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IClientWorldMixin;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.SearchInvResult;
import thunder.hack.utility.world.ExplosionUtility;

public final class InteractionUtility {
    private static final List<class_2248> SHIFT_BLOCKS = Arrays.asList(class_2246.field_10443, class_2246.field_10034, class_2246.field_10380, class_2246.field_9980, class_2246.field_10486, class_2246.field_40285, class_2246.field_10246, class_2246.field_42740, class_2246.field_10535, class_2246.field_10333, class_2246.field_10312, class_2246.field_10228, class_2246.field_10200, class_2246.field_10608, class_2246.field_10485, class_2246.field_10199, class_2246.field_10407, class_2246.field_10063, class_2246.field_10203, class_2246.field_10600, class_2246.field_10275, class_2246.field_10051, class_2246.field_10140, class_2246.field_10532, class_2246.field_10268, class_2246.field_10605, class_2246.field_10373, class_2246.field_10055, class_2246.field_10068, class_2246.field_10371);
    public static Map<class_2338, Long> awaiting = new HashMap<class_2338, Long>();

    public static boolean canSee(class_243 vec) {
        return InteractionUtility.canSee(vec, vec);
    }

    public static boolean canSee(class_1297 entity) {
        class_243 entityEyes = InteractionUtility.getEyesPos(entity);
        class_243 entityPos = entity.method_19538();
        return InteractionUtility.canSee(entityEyes, entityPos);
    }

    public static boolean canSee(class_243 entityEyes, class_243 entityPos) {
        if (Module.mc.field_1724 == null || Module.mc.field_1687 == null) {
            return false;
        }
        class_243 playerEyes = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724);
        if (ExplosionUtility.raycast(playerEyes, entityEyes, false) == class_239.class_240.field_1333) {
            return true;
        }
        if (playerEyes.method_10214() > entityPos.method_10214()) {
            return ExplosionUtility.raycast(playerEyes, entityEyes, false) == class_239.class_240.field_1333;
        }
        return false;
    }

    public static class_243 getEyesPos(@NotNull class_1297 entity) {
        return entity.method_19538().method_1031(0.0, (double)entity.method_18381(entity.method_18376()), 0.0);
    }

    public static float @NotNull [] calculateAngle(class_243 to) {
        return InteractionUtility.calculateAngle(InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724), to);
    }

    public static float @NotNull [] calculateAngle(@NotNull class_243 from, @NotNull class_243 to) {
        double difX = to.field_1352 - from.field_1352;
        double difY = (to.field_1351 - from.field_1351) * -1.0;
        double difZ = to.field_1350 - from.field_1350;
        double dist = class_3532.method_15355((float)((float)(difX * difX + difZ * difZ)));
        float yD = (float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0));
        float pD = (float)class_3532.method_15350((double)class_3532.method_15338((double)Math.toDegrees(Math.atan2(difY, dist))), (double)-90.0, (double)90.0);
        return new float[]{yD, pD};
    }

    public static boolean placeBlock(class_2338 bp, Rotate rotate, Interact interact, PlaceMode mode, int slot, boolean returnSlot, boolean ignoreEntities) {
        int prevItem = Module.mc.field_1724.method_31548().field_7545;
        if (slot == -1) {
            return false;
        }
        InventoryUtility.switchTo(slot);
        boolean result = InteractionUtility.placeBlock(bp, rotate, interact, mode, ignoreEntities);
        if (returnSlot) {
            InventoryUtility.switchTo(prevItem);
        }
        return result;
    }

    public static boolean placeBlock(class_2338 bp, Rotate rotate, Interact interact, PlaceMode mode, @NotNull SearchInvResult invResult, boolean returnSlot, boolean ignoreEntities) {
        int prevItem = Module.mc.field_1724.method_31548().field_7545;
        invResult.switchTo();
        boolean result = InteractionUtility.placeBlock(bp, rotate, interact, mode, ignoreEntities);
        if (returnSlot) {
            InventoryUtility.switchTo(prevItem);
        }
        return result;
    }

    public static boolean placeBlock(class_2338 bp, Rotate rotate, Interact interact, PlaceMode mode, boolean ignoreEntities) {
        class_3965 result = InteractionUtility.getPlaceResult(bp, interact, ignoreEntities);
        if (result == null || Module.mc.field_1687 == null || Module.mc.field_1761 == null || Module.mc.field_1724 == null) {
            return false;
        }
        boolean sprint = Module.mc.field_1724.method_5624();
        boolean sneak = InteractionUtility.needSneak(Module.mc.field_1687.method_8320(result.method_17777()).method_26204()) && !Module.mc.field_1724.method_5715();
        boolean bl = sneak;
        if (sprint) {
            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)Module.mc.field_1724, class_2848.class_2849.field_12985));
        }
        if (sneak) {
            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)Module.mc.field_1724, class_2848.class_2849.field_12979));
        }
        float[] angle = InteractionUtility.calculateAngle(result.method_17784());
        switch (rotate.ordinal()) {
            case 0: {
                break;
            }
            case 1: {
                Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2831(angle[0], angle[1], Module.mc.field_1724.method_24828()));
                break;
            }
            case 2: {
                Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(Module.mc.field_1724.method_23317(), Module.mc.field_1724.method_23318(), Module.mc.field_1724.method_23321(), angle[0], angle[1], Module.mc.field_1724.method_24828()));
            }
        }
        if (mode == PlaceMode.Normal) {
            Module.mc.field_1761.method_2896(Module.mc.field_1724, class_1268.field_5808, result);
        }
        if (mode == PlaceMode.Packet) {
            InteractionUtility.sendSequencedPacket(id -> new class_2885(class_1268.field_5808, result, id));
        }
        awaiting.put(bp, System.currentTimeMillis());
        if (rotate == Rotate.Grim) {
            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2830(Module.mc.field_1724.method_23317(), Module.mc.field_1724.method_23318(), Module.mc.field_1724.method_23321(), Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455(), Module.mc.field_1724.method_24828()));
        }
        if (sneak) {
            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)Module.mc.field_1724, class_2848.class_2849.field_12984));
        }
        if (sprint) {
            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)Module.mc.field_1724, class_2848.class_2849.field_12981));
        }
        Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
        return true;
    }

    public static boolean canPlaceBlock(@NotNull class_2338 bp, Interact interact, boolean ignoreEntities) {
        if (awaiting.containsKey(bp)) {
            return false;
        }
        return InteractionUtility.getPlaceResult(bp, interact, ignoreEntities) != null;
    }

    public static float @Nullable [] getPlaceAngle(@NotNull class_2338 bp, Interact interact, boolean ignoreEntities) {
        class_3965 result = InteractionUtility.getPlaceResult(bp, interact, ignoreEntities);
        if (result != null) {
            return InteractionUtility.calculateAngle(result.method_17784());
        }
        return null;
    }

    public static void sendSequencedPacket(class_7204 packetCreator) {
        if (Module.mc.method_1562() == null || Module.mc.field_1687 == null) {
            return;
        }
        try (class_7202 pendingUpdateManager = ((IClientWorldMixin)Module.mc.field_1687).getPendingUpdateManager().method_41937();){
            int i = pendingUpdateManager.method_41942();
            Module.mc.method_1562().method_52787(packetCreator.predict(i));
        }
    }

    @Nullable
    public static class_3965 getPlaceResult(@NotNull class_2338 bp, Interact interact, boolean ignoreEntities) {
        if (!ignoreEntities) {
            for (class_1297 entity : Module.mc.field_1687.method_18467(class_1297.class, new class_238(bp))) {
                if (entity instanceof class_1542 || entity instanceof class_1303) continue;
                return null;
            }
        }
        if (!Module.mc.field_1687.method_8320(bp).method_45474()) {
            return null;
        }
        if (interact == Interact.AirPlace) {
            return ExplosionUtility.rayCastBlock(new class_3959(InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724), bp.method_46558(), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)Module.mc.field_1724), bp);
        }
        ArrayList<BlockPosWithFacing> supports = InteractionUtility.getSupportBlocks(bp);
        for (BlockPosWithFacing support : supports) {
            if (interact != Interact.Vanilla) {
                @NotNull List<class_2350> dirs = InteractionUtility.getStrictDirections(bp);
                if (dirs.isEmpty()) {
                    return null;
                }
                if (!dirs.contains(support.facing)) continue;
            }
            class_3965 result = null;
            if (interact == Interact.Legit) {
                class_243 p = InteractionUtility.getVisibleDirectionPoint(support.facing, support.position, 0.0f, 6.0f);
                if (p != null) {
                    return new class_3965(p, support.facing, support.position, false);
                }
            } else {
                class_243 directionVec = new class_243((double)support.position.method_10263() + 0.5 + (double)support.facing.method_10163().method_10263() * 0.5, (double)support.position.method_10264() + 0.5 + (double)support.facing.method_10163().method_10264() * 0.5, (double)support.position.method_10260() + 0.5 + (double)support.facing.method_10163().method_10260() * 0.5);
                result = new class_3965(directionVec, support.facing, support.position, false);
            }
            return result;
        }
        return null;
    }

    @NotNull
    public static ArrayList<BlockPosWithFacing> getSupportBlocks(@NotNull class_2338 bp) {
        ArrayList<BlockPosWithFacing> list = new ArrayList<BlockPosWithFacing>();
        if (Module.mc.field_1687.method_8320(bp.method_10069(0, -1, 0)).method_51367() || awaiting.containsKey(bp.method_10069(0, -1, 0))) {
            list.add(new BlockPosWithFacing(bp.method_10069(0, -1, 0), class_2350.field_11036));
        }
        if (Module.mc.field_1687.method_8320(bp.method_10069(0, 1, 0)).method_51367() || awaiting.containsKey(bp.method_10069(0, 1, 0))) {
            list.add(new BlockPosWithFacing(bp.method_10069(0, 1, 0), class_2350.field_11033));
        }
        if (Module.mc.field_1687.method_8320(bp.method_10069(-1, 0, 0)).method_51367() || awaiting.containsKey(bp.method_10069(-1, 0, 0))) {
            list.add(new BlockPosWithFacing(bp.method_10069(-1, 0, 0), class_2350.field_11034));
        }
        if (Module.mc.field_1687.method_8320(bp.method_10069(1, 0, 0)).method_51367() || awaiting.containsKey(bp.method_10069(1, 0, 0))) {
            list.add(new BlockPosWithFacing(bp.method_10069(1, 0, 0), class_2350.field_11039));
        }
        if (Module.mc.field_1687.method_8320(bp.method_10069(0, 0, 1)).method_51367() || awaiting.containsKey(bp.method_10069(0, 0, 1))) {
            list.add(new BlockPosWithFacing(bp.method_10069(0, 0, 1), class_2350.field_11043));
        }
        if (Module.mc.field_1687.method_8320(bp.method_10069(0, 0, -1)).method_51367() || awaiting.containsKey(bp.method_10069(0, 0, -1))) {
            list.add(new BlockPosWithFacing(bp.method_10069(0, 0, -1), class_2350.field_11035));
        }
        return list;
    }

    @Nullable
    public static BlockPosWithFacing checkNearBlocks(@NotNull class_2338 blockPos) {
        if (Module.mc.field_1687.method_8320(blockPos.method_10069(0, -1, 0)).method_51367()) {
            return new BlockPosWithFacing(blockPos.method_10069(0, -1, 0), class_2350.field_11036);
        }
        if (Module.mc.field_1687.method_8320(blockPos.method_10069(-1, 0, 0)).method_51367()) {
            return new BlockPosWithFacing(blockPos.method_10069(-1, 0, 0), class_2350.field_11034);
        }
        if (Module.mc.field_1687.method_8320(blockPos.method_10069(1, 0, 0)).method_51367()) {
            return new BlockPosWithFacing(blockPos.method_10069(1, 0, 0), class_2350.field_11039);
        }
        if (Module.mc.field_1687.method_8320(blockPos.method_10069(0, 0, 1)).method_51367()) {
            return new BlockPosWithFacing(blockPos.method_10069(0, 0, 1), class_2350.field_11043);
        }
        if (Module.mc.field_1687.method_8320(blockPos.method_10069(0, 0, -1)).method_51367()) {
            return new BlockPosWithFacing(blockPos.method_10069(0, 0, -1), class_2350.field_11035);
        }
        return null;
    }

    public static float squaredDistanceFromEyes(@NotNull class_243 vec) {
        double d0 = vec.field_1352 - Module.mc.field_1724.method_23317();
        double d1 = vec.field_1350 - Module.mc.field_1724.method_23321();
        double d2 = vec.field_1351 - (Module.mc.field_1724.method_23318() + (double)Module.mc.field_1724.method_18381(Module.mc.field_1724.method_18376()));
        return (float)(d0 * d0 + d1 * d1 + d2 * d2);
    }

    public static float squaredDistanceFromEyes2d(@NotNull class_243 vec) {
        double d0 = vec.field_1352 - Module.mc.field_1724.method_23317();
        double d1 = vec.field_1350 - Module.mc.field_1724.method_23321();
        return (float)(d0 * d0 + d1 * d1);
    }

    @NotNull
    public static List<class_2350> getStrictDirections(@NotNull class_2338 bp) {
        ArrayList<class_2350> visibleSides = new ArrayList<class_2350>();
        class_243 positionVector = bp.method_46558();
        double westDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1352 - positionVector.method_1031((double)0.5, (double)0.0, (double)0.0).field_1352;
        double eastDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1352 - positionVector.method_1031((double)-0.5, (double)0.0, (double)0.0).field_1352;
        double northDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1350 - positionVector.method_1031((double)0.0, (double)0.0, (double)0.5).field_1350;
        double southDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1350 - positionVector.method_1031((double)0.0, (double)0.0, (double)-0.5).field_1350;
        double upDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1351 - positionVector.method_1031((double)0.0, (double)0.5, (double)0.0).field_1351;
        double downDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1351 - positionVector.method_1031((double)0.0, (double)-0.5, (double)0.0).field_1351;
        if (westDelta > 0.0 && InteractionUtility.isSolid(bp.method_10067())) {
            visibleSides.add(class_2350.field_11034);
        }
        if (westDelta < 0.0 && InteractionUtility.isSolid(bp.method_10078())) {
            visibleSides.add(class_2350.field_11039);
        }
        if (eastDelta < 0.0 && InteractionUtility.isSolid(bp.method_10078())) {
            visibleSides.add(class_2350.field_11039);
        }
        if (eastDelta > 0.0 && InteractionUtility.isSolid(bp.method_10067())) {
            visibleSides.add(class_2350.field_11034);
        }
        if (northDelta > 0.0 && InteractionUtility.isSolid(bp.method_10095())) {
            visibleSides.add(class_2350.field_11035);
        }
        if (northDelta < 0.0 && InteractionUtility.isSolid(bp.method_10072())) {
            visibleSides.add(class_2350.field_11043);
        }
        if (southDelta < 0.0 && InteractionUtility.isSolid(bp.method_10072())) {
            visibleSides.add(class_2350.field_11043);
        }
        if (southDelta > 0.0 && InteractionUtility.isSolid(bp.method_10095())) {
            visibleSides.add(class_2350.field_11035);
        }
        if (upDelta > 0.0 && InteractionUtility.isSolid(bp.method_10074())) {
            visibleSides.add(class_2350.field_11036);
        }
        if (upDelta < 0.0 && InteractionUtility.isSolid(bp.method_10084())) {
            visibleSides.add(class_2350.field_11033);
        }
        if (downDelta < 0.0 && InteractionUtility.isSolid(bp.method_10084())) {
            visibleSides.add(class_2350.field_11033);
        }
        if (downDelta > 0.0 && InteractionUtility.isSolid(bp.method_10074())) {
            visibleSides.add(class_2350.field_11036);
        }
        return visibleSides;
    }

    public static boolean isSolid(class_2338 bp) {
        return Module.mc.field_1687.method_8320(bp).method_51367() || awaiting.containsKey(bp);
    }

    @NotNull
    public static List<class_2350> getStrictBlockDirections(@NotNull class_2338 bp) {
        ArrayList<class_2350> visibleSides = new ArrayList<class_2350>();
        class_243 pV = bp.method_46558();
        double westDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1352 - pV.method_1031((double)0.5, (double)0.0, (double)0.0).field_1352;
        double eastDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1352 - pV.method_1031((double)-0.5, (double)0.0, (double)0.0).field_1352;
        double northDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1350 - pV.method_1031((double)0.0, (double)0.0, (double)0.5).field_1350;
        double southDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1350 - pV.method_1031((double)0.0, (double)0.0, (double)-0.5).field_1350;
        double upDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1351 - pV.method_1031((double)0.0, (double)0.5, (double)0.0).field_1351;
        double downDelta = InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724).field_1351 - pV.method_1031((double)0.0, (double)-0.5, (double)0.0).field_1351;
        if (westDelta > 0.0 && Module.mc.field_1687.method_8320(bp.method_10078()).method_45474()) {
            visibleSides.add(class_2350.field_11034);
        }
        if (eastDelta < 0.0 && Module.mc.field_1687.method_8320(bp.method_10067()).method_45474()) {
            visibleSides.add(class_2350.field_11039);
        }
        if (northDelta > 0.0 && Module.mc.field_1687.method_8320(bp.method_10072()).method_45474()) {
            visibleSides.add(class_2350.field_11035);
        }
        if (southDelta < 0.0 && Module.mc.field_1687.method_8320(bp.method_10095()).method_45474()) {
            visibleSides.add(class_2350.field_11043);
        }
        if (upDelta > 0.0 && Module.mc.field_1687.method_8320(bp.method_10084()).method_45474()) {
            visibleSides.add(class_2350.field_11036);
        }
        if (downDelta < 0.0 && Module.mc.field_1687.method_8320(bp.method_10074()).method_45474()) {
            visibleSides.add(class_2350.field_11033);
        }
        return visibleSides;
    }

    @Nullable
    public static BreakData getBreakData(class_2338 bp, Interact interact) {
        if (interact == Interact.Vanilla) {
            return new BreakData(class_2350.field_11036, bp.method_46558().method_1031(0.0, 0.5, 0.0));
        }
        if (interact == Interact.Strict) {
            float bestDistance = 999.0f;
            class_2350 bestDirection = class_2350.field_11036;
            class_243 bestVector = null;
            for (class_2350 dir : class_2350.values()) {
                class_243 directionVec = new class_243((double)bp.method_10263() + 0.5 + (double)dir.method_10163().method_10263() * 0.5, (double)bp.method_10264() + 0.5 + (double)dir.method_10163().method_10264() * 0.5, (double)bp.method_10260() + 0.5 + (double)dir.method_10163().method_10260() * 0.5);
                float distance = InteractionUtility.squaredDistanceFromEyes(directionVec);
                if (!(bestDistance > distance)) continue;
                bestDirection = dir;
                bestVector = directionVec;
                bestDistance = distance;
            }
            if (bestVector == null) {
                return null;
            }
            return new BreakData(bestDirection, bestVector);
        }
        if (interact == Interact.Legit) {
            float bestDistance = 999.0f;
            BreakData bestData = null;
            for (float x = 0.0f; x <= 1.0f; x += 0.2f) {
                for (float y = 0.0f; y <= 1.0f; y += 0.2f) {
                    for (float z = 0.0f; z <= 1.0f; z += 0.2f) {
                        class_243 point = new class_243((double)((float)bp.method_10263() + x), (double)((float)bp.method_10264() + y), (double)((float)bp.method_10260() + z));
                        class_3965 wallCheck = Module.mc.field_1687.method_17742(new class_3959(InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724), point, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)Module.mc.field_1724));
                        if (wallCheck != null && wallCheck.method_17783() == class_239.class_240.field_1332 && !wallCheck.method_17777().equals(bp)) continue;
                        class_3965 result = ExplosionUtility.rayCastBlock(new class_3959(InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724), point, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)Module.mc.field_1724), bp);
                        if (!(InteractionUtility.squaredDistanceFromEyes(point) < bestDistance) || result == null || result.method_17783() != class_239.class_240.field_1332) continue;
                        bestData = new BreakData(result.method_17780(), result.method_17784());
                    }
                }
            }
            if (bestData == null) {
                return null;
            }
            if (bestData.vector == null || bestData.dir == null) {
                return null;
            }
            return bestData;
        }
        return null;
    }

    @Nullable
    public static class_243 getVisibleDirectionPoint(@NotNull class_2350 dir, @NotNull class_2338 bp, float wallRange, float range) {
        double x;
        class_243 point;
        double z;
        double y;
        class_238 brutBox = InteractionUtility.getDirectionBox(dir);
        if (brutBox.field_1320 - brutBox.field_1323 == 0.0) {
            for (y = brutBox.field_1322; y < brutBox.field_1325; y += (double)0.1f) {
                for (z = brutBox.field_1321; z < brutBox.field_1324; z += (double)0.1f) {
                    point = new class_243((double)bp.method_10263() + brutBox.field_1323, (double)bp.method_10264() + y, (double)bp.method_10260() + z);
                    if (InteractionUtility.shouldSkipPoint(point, bp, dir, wallRange, range)) continue;
                    return point;
                }
            }
        }
        if (brutBox.field_1325 - brutBox.field_1322 == 0.0) {
            for (x = brutBox.field_1323; x < brutBox.field_1320; x += (double)0.1f) {
                for (z = brutBox.field_1321; z < brutBox.field_1324; z += (double)0.1f) {
                    point = new class_243((double)bp.method_10263() + x, (double)bp.method_10264() + brutBox.field_1322, (double)bp.method_10260() + z);
                    if (InteractionUtility.shouldSkipPoint(point, bp, dir, wallRange, range)) continue;
                    return point;
                }
            }
        }
        if (brutBox.field_1324 - brutBox.field_1321 == 0.0) {
            for (x = brutBox.field_1323; x < brutBox.field_1320; x += (double)0.1f) {
                for (y = brutBox.field_1322; y < brutBox.field_1325; y += (double)0.1f) {
                    point = new class_243((double)bp.method_10263() + x, (double)bp.method_10264() + y, (double)bp.method_10260() + brutBox.field_1321);
                    if (InteractionUtility.shouldSkipPoint(point, bp, dir, wallRange, range)) continue;
                    return point;
                }
            }
        }
        return null;
    }

    @NotNull
    private static class_238 getDirectionBox(class_2350 dir) {
        return switch (dir) {
            default -> throw new MatchException(null, null);
            case class_2350.field_11036 -> new class_238((double)0.15f, 1.0, (double)0.15f, (double)0.85f, 1.0, (double)0.85f);
            case class_2350.field_11033 -> new class_238((double)0.15f, 0.0, (double)0.15f, (double)0.85f, 0.0, (double)0.85f);
            case class_2350.field_11034 -> new class_238(1.0, (double)0.15f, (double)0.15f, 1.0, (double)0.85f, (double)0.85f);
            case class_2350.field_11039 -> new class_238(0.0, (double)0.15f, (double)0.15f, 0.0, (double)0.85f, (double)0.85f);
            case class_2350.field_11043 -> new class_238((double)0.15f, (double)0.15f, 0.0, (double)0.85f, (double)0.85f, 0.0);
            case class_2350.field_11035 -> new class_238((double)0.15f, (double)0.15f, 1.0, (double)0.85f, (double)0.85f, 1.0);
        };
    }

    private static boolean shouldSkipPoint(class_243 point, class_2338 bp, class_2350 dir, float wallRange, float range) {
        class_3959 context = new class_3959(InteractionUtility.getEyesPos((class_1297)Module.mc.field_1724), point, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)Module.mc.field_1724);
        class_3965 result = Module.mc.field_1687.method_17742(context);
        float dst = InteractionUtility.squaredDistanceFromEyes(point);
        if (result != null && result.method_17783() == class_239.class_240.field_1332 && !result.method_17777().equals(bp) && dst > wallRange * wallRange) {
            return true;
        }
        return dst > range * range;
    }

    public static boolean needSneak(class_2248 in) {
        return SHIFT_BLOCKS.contains(in);
    }

    public static void lookAt(class_2338 bp) {
        if (bp != null) {
            float[] angle = InteractionUtility.calculateAngle(bp.method_46558());
            Module.mc.field_1724.method_36456(angle[0]);
            Module.mc.field_1724.method_36457(angle[1]);
        }
    }

    public static boolean isVecInFOV(class_243 pos, Integer fov) {
        double deltaX = pos.method_10216() - Module.mc.field_1724.method_23317();
        double deltaZ = pos.method_10215() - Module.mc.field_1724.method_23321();
        float yawDelta = class_3532.method_15393((float)((float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0)) - class_3532.method_15393((float)Module.mc.field_1724.method_36454())));
        return Math.abs(yawDelta) <= (float)fov.intValue();
    }

    public static enum Rotate {
        None,
        Default,
        Grim;

    }

    public static enum Interact {
        Vanilla,
        Strict,
        Legit,
        AirPlace;

    }

    public static enum PlaceMode {
        Packet,
        Normal;

    }

    public record BlockPosWithFacing(class_2338 position, class_2350 facing) {
    }

    public record BreakData(class_2350 dir, class_243 vector) {
    }
}

