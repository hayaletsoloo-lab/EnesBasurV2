/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.entity.DamageUtil
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.attribute.EntityAttributes
 *  net.minecraft.entity.damage.DamageSource
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.AxeItem
 *  net.minecraft.item.BedItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.item.PickaxeItem
 *  net.minecraft.item.ShovelItem
 *  net.minecraft.item.SwordItem
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.registry.Registries
 *  net.minecraft.registry.entry.RegistryEntry
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.utility.player;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1280;
import net.minecraft.class_1282;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1748;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IInteractionManager;
import thunder.hack.utility.player.SearchInvResult;

public final class InventoryUtility {
    private static int cachedSlot = -1;

    public static int getItemCount(class_1792 item) {
        if (Module.mc.field_1724 == null) {
            return 0;
        }
        int counter = 0;
        for (int i = 0; i <= 44; ++i) {
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7909() != item) continue;
            counter += itemStack.method_7947();
        }
        return counter;
    }

    public static SearchInvResult getAxe() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 9; b1 < 45; ++b1) {
            class_1792 class_17922;
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1 >= 36 ? b1 - 36 : b1);
            if (itemStack == null || !((class_17922 = itemStack.method_7909()) instanceof class_1743)) continue;
            class_1743 axe = (class_1743)class_17922;
            float f1 = ((Integer)axe.method_57347().method_57829(class_9334.field_50072)).intValue();
            if (!((f1 += (float)class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9118.method_58273()).method_40264(class_1893.field_9118).get()), (class_1799)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot >= 36) {
            slot -= 36;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.field_1724.method_31548().method_5438(slot));
    }

    public static SearchInvResult getPickAxeHotbar() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 0; b1 < 9; ++b1) {
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1);
            if (itemStack == null || !(itemStack.method_7909() instanceof class_1810)) continue;
            float f1 = 0.0f;
            if (!((f1 += (float)class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9131.method_58273()).method_40264(class_1893.field_9131).get()), (class_1799)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.field_1724.method_31548().method_5438(slot));
    }

    public static SearchInvResult getPickAxe() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 9; b1 < 45; ++b1) {
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1);
            if (itemStack == null || !(itemStack.method_7909() instanceof class_1810)) continue;
            float f1 = 0.0f;
            if (!((f1 += (float)class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9131.method_58273()).method_40264(class_1893.field_9131).get()), (class_1799)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.field_1724.method_31548().method_5438(slot));
    }

    public static SearchInvResult getPickAxeHotBar() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 0; b1 < 9; ++b1) {
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1);
            if (itemStack == null || !(itemStack.method_7909() instanceof class_1810)) continue;
            float f1 = 0.0f;
            if (!((f1 += (float)class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9131.method_58273()).method_40264(class_1893.field_9131).get()), (class_1799)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.field_1724.method_31548().method_5438(slot));
    }

    public static SearchInvResult getSkull() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        for (int b1 = 0; b1 < 9; ++b1) {
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1);
            if (itemStack == null || !itemStack.method_7909().equals(class_1802.field_8398) && !itemStack.method_7909().equals(class_1802.field_8791) && !itemStack.method_7909().equals(class_1802.field_8681) && !itemStack.method_7909().equals(class_1802.field_8575) && !itemStack.method_7909().equals(class_1802.field_8470)) continue;
            slot = b1;
            break;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.field_1724.method_31548().method_5438(slot));
    }

    public static SearchInvResult getSword() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 9; b1 < 45; ++b1) {
            class_1792 class_17922;
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1);
            if (itemStack == null || !((class_17922 = itemStack.method_7909()) instanceof class_1829)) continue;
            class_1829 sword = (class_1829)class_17922;
            float f1 = ((Integer)sword.method_57347().method_57829(class_9334.field_50072)).intValue();
            if (!((f1 += (float)class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9118.method_58273()).method_40264(class_1893.field_9118).get()), (class_1799)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.field_1724.method_31548().method_5438(slot));
    }

    public static SearchInvResult getSwordHotBar() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 0; b1 < 9; ++b1) {
            class_1792 class_17922;
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1);
            if (itemStack == null || !((class_17922 = itemStack.method_7909()) instanceof class_1829)) continue;
            class_1829 sword = (class_1829)class_17922;
            float f1 = ((Integer)sword.method_57347().method_57829(class_9334.field_50072)).intValue();
            if (!((f1 += (float)class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9118.method_58273()).method_40264(class_1893.field_9118).get()), (class_1799)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.field_1724.method_31548().method_5438(slot));
    }

    public static SearchInvResult getAxeHotBar() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        int slot = -1;
        float f = 1.0f;
        for (int b1 = 0; b1 < 9; ++b1) {
            class_1792 class_17922;
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1);
            if (itemStack == null || !((class_17922 = itemStack.method_7909()) instanceof class_1743)) continue;
            class_1743 axe = (class_1743)class_17922;
            float f1 = ((Integer)axe.method_57347().method_57829(class_9334.field_50072)).intValue();
            if (!((f1 += (float)class_1890.method_8225((class_6880)((class_6880)Module.mc.field_1687.method_30349().method_30530(class_1893.field_9118.method_58273()).method_40264(class_1893.field_9118).get()), (class_1799)itemStack)) > f)) continue;
            f = f1;
            slot = b1;
        }
        if (slot == -1) {
            return SearchInvResult.notFound();
        }
        return new SearchInvResult(slot, true, Module.mc.field_1724.method_31548().method_5438(slot));
    }

    public static int getElytra() {
        for (class_1799 stack : Module.mc.field_1724.method_31548().field_7548) {
            if (stack.method_7909() != class_1802.field_8833 || stack.method_7919() >= 430) continue;
            return -2;
        }
        int slot = -1;
        for (int i = 0; i < 36; ++i) {
            class_1799 s = Module.mc.field_1724.method_31548().method_5438(i);
            if (s.method_7909() != class_1802.field_8833 || s.method_7919() >= 430) continue;
            slot = i;
            break;
        }
        if (slot < 9 && slot != -1) {
            slot += 36;
        }
        return slot;
    }

    public static SearchInvResult findInHotBar(Searcher searcher) {
        if (Module.mc.field_1724 != null) {
            for (int i = 0; i < 9; ++i) {
                class_1799 stack = Module.mc.field_1724.method_31548().method_5438(i);
                if (!searcher.isValid(stack)) continue;
                return new SearchInvResult(i, true, stack);
            }
        }
        return SearchInvResult.notFound();
    }

    public static SearchInvResult findItemInHotBar(List<class_1792> items) {
        return InventoryUtility.findInHotBar(stack -> items.contains(stack.method_7909()));
    }

    public static SearchInvResult findItemInHotBar(class_1792 ... items) {
        return InventoryUtility.findItemInHotBar(Arrays.asList(items));
    }

    public static SearchInvResult findInInventory(Searcher searcher) {
        if (Module.mc.field_1724 != null) {
            for (int i = 36; i >= 0; --i) {
                class_1799 stack = Module.mc.field_1724.method_31548().method_5438(i);
                if (!searcher.isValid(stack)) continue;
                if (i < 9) {
                    i += 36;
                }
                return new SearchInvResult(i, true, stack);
            }
        }
        return SearchInvResult.notFound();
    }

    public static SearchInvResult findItemInInventory(List<class_1792> items) {
        return InventoryUtility.findInInventory(stack -> items.contains(stack.method_7909()));
    }

    public static SearchInvResult findItemInInventory(class_1792 ... items) {
        return InventoryUtility.findItemInInventory(Arrays.asList(items));
    }

    public static SearchInvResult findBlockInHotBar(@NotNull List<class_2248> blocks) {
        return InventoryUtility.findItemInHotBar(blocks.stream().map(class_2248::method_8389).toList());
    }

    public static SearchInvResult findBlockInHotBar(class_2248 ... blocks) {
        return InventoryUtility.findItemInHotBar(Arrays.stream(blocks).map(class_2248::method_8389).toList());
    }

    public static SearchInvResult findBlockInInventory(@NotNull List<class_2248> blocks) {
        return InventoryUtility.findItemInInventory(blocks.stream().map(class_2248::method_8389).toList());
    }

    public static SearchInvResult findBlockInInventory(class_2248 ... blocks) {
        return InventoryUtility.findItemInInventory(Arrays.stream(blocks).map(class_2248::method_8389).toList());
    }

    public static void saveSlot() {
        cachedSlot = Module.mc.field_1724.method_31548().field_7545;
    }

    public static void returnSlot() {
        if (cachedSlot != -1) {
            InventoryUtility.switchTo(cachedSlot);
        }
        cachedSlot = -1;
    }

    public static void saveAndSwitchTo(int slot) {
        InventoryUtility.saveSlot();
        if (Module.mc.field_1724 == null || Module.mc.method_1562() == null) {
            return;
        }
        if (Module.mc.field_1724.method_31548().field_7545 == slot && Managers.PLAYER.serverSideSlot == slot) {
            return;
        }
        Module.mc.field_1724.method_31548().field_7545 = slot;
        ((IInteractionManager)Module.mc.field_1761).syncSlot();
    }

    public static void switchTo(int slot) {
        if (Module.mc.field_1724 == null || Module.mc.method_1562() == null) {
            return;
        }
        if (Module.mc.field_1724.method_31548().field_7545 == slot && Managers.PLAYER.serverSideSlot == slot) {
            return;
        }
        Module.mc.field_1724.method_31548().field_7545 = slot;
        ((IInteractionManager)Module.mc.field_1761).syncSlot();
    }

    public static void switchToSilent(int slot) {
        if (Module.mc.field_1724 == null || Module.mc.method_1562() == null) {
            return;
        }
        Module.mc.method_1562().method_52787((class_2596)new class_2868(slot));
    }

    public static SearchInvResult getAntiWeaknessItem() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        class_1792 mainHand = Module.mc.field_1724.method_6047().method_7909();
        if (mainHand instanceof class_1829 || mainHand instanceof class_1810 || mainHand instanceof class_1743 || mainHand instanceof class_1821) {
            return new SearchInvResult(Module.mc.field_1724.method_31548().field_7545, true, Module.mc.field_1724.method_6047());
        }
        return InventoryUtility.findInHotBar(itemStack -> itemStack.method_7909() instanceof class_1829 || itemStack.method_7909() instanceof class_1810 || itemStack.method_7909() instanceof class_1743 || itemStack.method_7909() instanceof class_1821);
    }

    public static float getHitDamage(@NotNull class_1799 weapon, class_1657 ent) {
        if (Module.mc.field_1724 == null) {
            return 0.0f;
        }
        float baseDamage = 1.0f;
        class_1792 class_17922 = weapon.method_7909();
        if (class_17922 instanceof class_1829) {
            class_1829 swordItem = (class_1829)class_17922;
            baseDamage = 7.0f;
        }
        if ((class_17922 = weapon.method_7909()) instanceof class_1743) {
            class_1743 axeItem = (class_1743)class_17922;
            baseDamage = 9.0f;
        }
        if (Module.mc.field_1724.field_6017 > 0.0f) {
            baseDamage += baseDamage / 2.0f;
        }
        if (Module.mc.field_1724.method_6059(class_1294.field_5910)) {
            int strength = Objects.requireNonNull(Module.mc.field_1724.method_6112(class_1294.field_5910)).method_5578() + 1;
            baseDamage += (float)(3 * strength);
        }
        baseDamage = class_1280.method_5496((class_1309)ent, (float)baseDamage, (class_1282)Module.mc.field_1687.method_48963().method_48830(), (float)ent.method_6096(), (float)((float)ent.method_5996(class_5134.field_23725).method_6194()));
        return baseDamage;
    }

    public static SearchInvResult findBedInHotBar() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        for (int b1 = 0; b1 < 9; ++b1) {
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1);
            if (itemStack == null || !(itemStack.method_7909() instanceof class_1748)) continue;
            return new SearchInvResult(b1, true, Module.mc.field_1724.method_31548().method_5438(b1));
        }
        return SearchInvResult.notFound();
    }

    public static SearchInvResult findBed() {
        if (Module.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        for (int b1 = 9; b1 < 45; ++b1) {
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(b1 >= 36 ? b1 - 36 : b1);
            if (itemStack == null || !(itemStack.method_7909() instanceof class_1748)) continue;
            return new SearchInvResult(b1, true, Module.mc.field_1724.method_31548().method_5438(b1));
        }
        return SearchInvResult.notFound();
    }

    public static class_1792 getItem(String Name2) {
        if (Name2 == null) {
            return class_1802.field_8162;
        }
        for (class_2248 block : class_7923.field_41175) {
            if (!block.method_9539().replace("block.minecraft.", "").equals(Name2.toLowerCase())) continue;
            return class_1792.method_7867((class_2248)block);
        }
        for (class_1792 item : class_7923.field_41178) {
            if (!item.method_7876().replace("item.minecraft.", "").equals(Name2.toLowerCase())) continue;
            return item;
        }
        return class_1802.field_8831;
    }

    public static int getBedsCount() {
        if (Module.mc.field_1724 == null) {
            return 0;
        }
        int counter = 0;
        for (int i = 0; i <= 44; ++i) {
            class_1799 itemStack = Module.mc.field_1724.method_31548().method_5438(i);
            if (!(itemStack.method_7909() instanceof class_1748)) continue;
            counter += itemStack.method_7947();
        }
        return counter;
    }

    public static interface Searcher {
        public boolean isValid(class_1799 var1);
    }
}

