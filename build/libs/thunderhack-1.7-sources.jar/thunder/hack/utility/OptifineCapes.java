/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.texture.NativeImage
 *  net.minecraft.client.texture.NativeImageBackedTexture
 *  net.minecraft.util.Identifier
 */
package thunder.hack.utility;

import com.mojang.authlib.GameProfile;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class OptifineCapes {
    public static void loadPlayerCape(GameProfile player, ReturnCapeTexture response) {
        try {
            String uuid = player.getId().toString();
            class_1043 nIBT = OptifineCapes.getCapeFromURL(String.format("http://s.optifine.net/capes/%s.png", player.getName()));
            class_2960 capeTexture = class_310.method_1551().method_1531().method_4617("th-cape-" + uuid, nIBT);
            response.response(capeTexture);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static class_1043 getCapeFromURL(String capeStringURL) {
        try {
            URL capeURL = new URL(capeStringURL);
            return OptifineCapes.getCapeFromStream(capeURL.openStream());
        }
        catch (IOException e) {
            return null;
        }
    }

    public static class_1043 getCapeFromStream(InputStream image) {
        class_1011 cape = null;
        try {
            cape = class_1011.method_4309((InputStream)(Object)image);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        if (cape != null) {
            return new class_1043(OptifineCapes.parseCape(cape));
        }
        return null;
    }

    public static class_1011 parseCape(class_1011 image) {
        int imageHeight;
        int imageWidth = 64;
        int imageSrcWidth = image.method_4307();
        int srcHeight = image.method_4323();
        int imageSrcHeight = image.method_4323();
        for (imageHeight = 32; imageWidth < imageSrcWidth || imageHeight < imageSrcHeight; imageWidth *= 2, imageHeight *= 2) {
        }
        class_1011 imgNew = new class_1011(imageWidth, imageHeight, true);
        for (int x = 0; x < imageSrcWidth; ++x) {
            for (int y = 0; y < srcHeight; ++y) {
                imgNew.method_4305(x, y, image.method_4315(x, y));
            }
        }
        image.close();
        return imgNew;
    }

    public static interface ReturnCapeTexture {
        public void response(class_2960 var1);
    }
}

