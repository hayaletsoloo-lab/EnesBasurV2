/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.BufferRenderer
 *  net.minecraft.client.render.BuiltBuffer
 *  net.minecraft.client.render.Camera
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.RotationAxis
 *  org.joml.Matrix4f
 */
package thunder.hack.utility.render.animation;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1297;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;

public class CaptureMark {
    private static float espValue = 1.0f;
    private static float prevEspValue;
    private static float espSpeed;
    private static boolean flipSpeed;

    public static void render(class_1297 target) {
        class_4184 camera = Module.mc.field_1773.method_19418();
        double tPosX = Render2DEngine.interpolate(target.field_6014, target.method_23317(), Render3DEngine.getTickDelta()) - camera.method_19326().field_1352;
        double tPosY = Render2DEngine.interpolate(target.field_6036, target.method_23318(), Render3DEngine.getTickDelta()) - camera.method_19326().field_1351;
        double tPosZ = Render2DEngine.interpolate(target.field_5969, target.method_23321(), Render3DEngine.getTickDelta()) - camera.method_19326().field_1350;
        class_4587 matrices = new class_4587();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        matrices.method_22904(tPosX, tPosY + (double)(target.method_18381(target.method_18376()) / 2.0f), tPosZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22907(class_7833.field_40718.rotationDegrees(Render2DEngine.interpolateFloat(prevEspValue, espValue, Render3DEngine.getTickDelta())));
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.capture);
        matrices.method_22904(-0.75, -0.75, -0.01);
        Matrix4f matrix = matrices.method_23760().method_23761();
        RenderSystem.setShader(class_757::method_34543);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        buffer.method_22918(matrix, 0.0f, 1.5f, 0.0f).method_22913(0.0f, 1.0f).method_39415(HudEditor.getColor(90).getRGB());
        buffer.method_22918(matrix, 1.5f, 1.5f, 0.0f).method_22913(1.0f, 1.0f).method_39415(HudEditor.getColor(0).getRGB());
        buffer.method_22918(matrix, 1.5f, 0.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(HudEditor.getColor(180).getRGB());
        buffer.method_22918(matrix, 0.0f, 0.0f, 0.0f).method_22913(0.0f, 0.0f).method_39415(HudEditor.getColor(270).getRGB());
        class_286.method_43433((class_9801)buffer.method_60800());
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void tick() {
        prevEspValue = espValue;
        espValue += espSpeed;
        if (espSpeed > 25.0f) {
            flipSpeed = true;
        }
        if (espSpeed < -25.0f) {
            flipSpeed = false;
        }
        espSpeed = flipSpeed ? espSpeed - 0.5f : espSpeed + 0.5f;
    }

    static {
        espSpeed = 1.0f;
    }
}

