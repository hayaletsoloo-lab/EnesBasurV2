/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gl.Framebuffer
 *  net.minecraft.client.texture.AbstractTexture
 */
package thunder.hack.utility.render.shaders.satin.api.managed.uniform;

import net.minecraft.class_1044;
import net.minecraft.class_276;

public interface SamplerUniform {
    public void set(class_1044 var1);

    public void set(class_276 var1);

    public void set(int var1);
}

