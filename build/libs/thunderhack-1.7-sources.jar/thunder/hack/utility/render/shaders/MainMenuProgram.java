/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.util.Identifier
 */
package thunder.hack.utility.render.shaders;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.render.animation.AnimationUtility;
import thunder.hack.utility.render.shaders.satin.api.managed.ManagedCoreShader;
import thunder.hack.utility.render.shaders.satin.api.managed.ShaderEffectManager;
import thunder.hack.utility.render.shaders.satin.api.managed.uniform.Uniform1f;
import thunder.hack.utility.render.shaders.satin.api.managed.uniform.Uniform2f;
import thunder.hack.utility.render.shaders.satin.api.managed.uniform.Uniform4f;

public class MainMenuProgram {
    private Uniform1f Time;
    private Uniform2f uSize;
    private Uniform4f color;
    public static float time_ = 10000.0f;
    public static final ManagedCoreShader MAIN_MENU = ShaderEffectManager.getInstance().manageCoreShader(class_2960.method_60655((String)"thunderhack", (String)"mainmenu"), class_290.field_1592);

    public MainMenuProgram() {
        this.setup();
    }

    public void setParameters(float x, float y, float width, float height) {
        float i = (float)Module.mc.method_22683().method_4495();
        this.uSize.set(width * i, height * i);
        this.Time.set(time_ += (float)(0.55 * (double)AnimationUtility.deltaTime()));
    }

    public void use() {
        RenderSystem.setShader(MAIN_MENU::getProgram);
    }

    protected void setup() {
        this.uSize = MAIN_MENU.findUniform2f("uSize");
        this.Time = MAIN_MENU.findUniform1f("Time");
        this.color = MAIN_MENU.findUniform4f("color");
    }
}

