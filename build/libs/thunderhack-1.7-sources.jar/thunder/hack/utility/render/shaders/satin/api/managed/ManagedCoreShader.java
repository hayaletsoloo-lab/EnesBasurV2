/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gl.ShaderProgram
 */
package thunder.hack.utility.render.shaders.satin.api.managed;

import net.minecraft.class_5944;
import thunder.hack.utility.render.shaders.satin.api.managed.uniform.UniformFinder;

public interface ManagedCoreShader
extends UniformFinder {
    public class_5944 getProgram();

    public void release();
}

