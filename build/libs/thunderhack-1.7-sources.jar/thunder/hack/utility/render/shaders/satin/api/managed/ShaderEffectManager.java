/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.VertexFormat
 *  net.minecraft.util.Identifier
 */
package thunder.hack.utility.render.shaders.satin.api.managed;

import java.util.function.Consumer;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import thunder.hack.utility.render.shaders.satin.api.managed.ManagedCoreShader;
import thunder.hack.utility.render.shaders.satin.api.managed.ManagedShaderEffect;
import thunder.hack.utility.render.shaders.satin.impl.ReloadableShaderEffectManager;

public interface ShaderEffectManager {
    public static ShaderEffectManager getInstance() {
        return ReloadableShaderEffectManager.INSTANCE;
    }

    public ManagedShaderEffect manage(class_2960 var1);

    public ManagedShaderEffect manage(class_2960 var1, Consumer<ManagedShaderEffect> var2);

    public ManagedCoreShader manageCoreShader(class_2960 var1);

    public ManagedCoreShader manageCoreShader(class_2960 var1, class_293 var2);

    public ManagedCoreShader manageCoreShader(class_2960 var1, class_293 var2, Consumer<ManagedCoreShader> var3);
}

