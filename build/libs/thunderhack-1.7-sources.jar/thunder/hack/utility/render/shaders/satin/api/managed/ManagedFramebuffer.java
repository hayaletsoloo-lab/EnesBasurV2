/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gl.Framebuffer
 */
package thunder.hack.utility.render.shaders.satin.api.managed;

import net.minecraft.class_276;

public interface ManagedFramebuffer {
    public class_276 getFramebuffer();

    public void beginWrite(boolean var1);

    public void draw();

    public void draw(int var1, int var2, boolean var3);

    public void clear();

    public void clear(boolean var1);
}

