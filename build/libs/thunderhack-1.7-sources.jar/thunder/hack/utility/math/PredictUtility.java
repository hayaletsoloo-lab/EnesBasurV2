/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 */
package thunder.hack.utility.math;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_243;
import thunder.hack.features.modules.Module;

public class PredictUtility {
    public static class_1657 movePlayer(class_1657 entity, class_243 newPos) {
        if (entity == null || newPos == null) {
            return null;
        }
        return PredictUtility.equipAndReturn(entity, newPos);
    }

    public static class_1657 predictPlayer(class_1657 entity, int ticks) {
        class_243 posVec = PredictUtility.predictPosition(entity, ticks);
        if (posVec == null) {
            return null;
        }
        return PredictUtility.equipAndReturn(entity, posVec);
    }

    public static class_243 predictPosition(class_1657 entity, int ticks) {
        if (entity == null) {
            return null;
        }
        class_243 posVec = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        double motionX = entity.method_18798().method_10216();
        double motionZ = entity.method_18798().method_10215();
        for (int i = 0; i < ticks; ++i) {
            float hbDeltaX = motionX > 0.0 ? 0.3f : -0.3f;
            float hbDeltaZ = motionZ > 0.0 ? 0.3f : -0.3f;
            float f = hbDeltaZ;
            if (!Module.mc.field_1687.method_22347(class_2338.method_49638((class_2374)posVec.method_1031(motionX + (double)hbDeltaX, 0.1, motionZ + (double)hbDeltaZ))) || !Module.mc.field_1687.method_22347(class_2338.method_49638((class_2374)posVec.method_1031(motionX + (double)hbDeltaX, 1.0, motionZ + (double)hbDeltaZ)))) {
                motionX = 0.0;
                motionZ = 0.0;
            }
            posVec = posVec.method_1031(motionX, 0.0, motionZ);
        }
        return posVec;
    }

    public static class_238 predictBox(class_1657 entity, int ticks) {
        class_243 posVec = PredictUtility.predictPosition(entity, ticks);
        if (posVec == null) {
            return null;
        }
        return PredictUtility.createBox(posVec, (class_1297)entity);
    }

    public static class_1657 equipAndReturn(class_1657 original, class_243 posVec) {
        class_1657 copyEntity = new class_1657((class_1937)Module.mc.field_1687, original.method_24515(), original.method_36454(), new GameProfile(UUID.fromString("66123666-1234-5432-6666-667563866600"), "PredictEntity339")){

            public boolean method_7325() {
                return false;
            }

            public boolean method_7337() {
                return false;
            }
        };
        copyEntity.method_33574(posVec);
        copyEntity.method_6033(original.method_6032());
        copyEntity.field_6014 = original.field_6014;
        copyEntity.field_5969 = original.field_5969;
        copyEntity.field_6036 = original.field_6036;
        copyEntity.method_31548().method_7377(original.method_31548());
        for (class_1293 se : original.method_6026()) {
            copyEntity.method_6092(se);
        }
        return copyEntity;
    }

    public static class_238 createBox(class_243 vec, class_1297 entity) {
        return entity.method_5829().method_997(entity.method_19538().method_1035(vec));
    }
}

