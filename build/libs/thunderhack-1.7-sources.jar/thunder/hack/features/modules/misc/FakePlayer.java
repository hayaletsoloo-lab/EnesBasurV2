/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.network.OtherClientPlayerEntity
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.Entity$RemovalReason
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemConvertible
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.network.listener.ClientPlayPacketListener
 *  net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket
 *  net.minecraft.network.packet.s2c.play.ExplosionS2CPacket
 *  net.minecraft.sound.SoundCategory
 *  net.minecraft.sound.SoundEvents
 *  net.minecraft.util.Hand
 *  net.minecraft.util.math.Vec3d
 */
package thunder.hack.features.modules.misc;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_243;
import net.minecraft.class_2602;
import net.minecraft.class_2663;
import net.minecraft.class_2664;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_745;
import thunder.hack.ThunderHack;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventAttack;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.events.impl.TotemPopEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.ILivingEntity;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.world.ExplosionUtility;

public class FakePlayer
extends Module {
    private final Setting<Boolean> copyInventory = new Setting<Boolean>("CopyInventory", false);
    public static class_745 fakePlayer;
    private Setting<Boolean> record = new Setting<Boolean>("Record", false);
    private Setting<Boolean> play = new Setting<Boolean>("Play", false);
    private Setting<Boolean> autoTotem = new Setting<Boolean>("AutoTotem", false);
    private Setting<String> name = new Setting<String>("Name", "Hell_Raider");
    private final List<PlayerState> positions = new ArrayList<PlayerState>();
    int movementTick;
    int deathTime;

    public FakePlayer() {
        super("FakePlayer", Module.Category.MISC);
    }

    @Override
    public void onEnable() {
        fakePlayer = new class_745(FakePlayer.mc.field_1687, new GameProfile(UUID.fromString("66123666-6666-6666-6666-666666666600"), this.name.getValue()));
        fakePlayer.method_5719((class_1297)FakePlayer.mc.field_1724);
        if (this.copyInventory.getValue().booleanValue()) {
            fakePlayer.method_6122(class_1268.field_5808, FakePlayer.mc.field_1724.method_6047().method_7972());
            fakePlayer.method_6122(class_1268.field_5810, FakePlayer.mc.field_1724.method_6079().method_7972());
            fakePlayer.method_31548().method_5447(36, FakePlayer.mc.field_1724.method_31548().method_5438(36).method_7972());
            fakePlayer.method_31548().method_5447(37, FakePlayer.mc.field_1724.method_31548().method_5438(37).method_7972());
            fakePlayer.method_31548().method_5447(38, FakePlayer.mc.field_1724.method_31548().method_5438(38).method_7972());
            fakePlayer.method_31548().method_5447(39, FakePlayer.mc.field_1724.method_31548().method_5438(39).method_7972());
        }
        FakePlayer.mc.field_1687.method_53875((class_1297)fakePlayer);
        fakePlayer.method_6092(new class_1293(class_1294.field_5924, 9999, 2));
        fakePlayer.method_6092(new class_1293(class_1294.field_5898, 9999, 4));
        fakePlayer.method_6092(new class_1293(class_1294.field_5907, 9999, 1));
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        Object t = e.getPacket();
        if (t instanceof class_2664) {
            class_2664 explosion = (class_2664)t;
            if (fakePlayer != null && FakePlayer.fakePlayer.field_6235 == 0) {
                fakePlayer.method_48922(FakePlayer.mc.field_1687.method_48963().method_48830());
                fakePlayer.method_6033(fakePlayer.method_6032() + fakePlayer.method_6067() - ExplosionUtility.getAutoCrystalDamage(new class_243(explosion.method_11475(), explosion.method_11477(), explosion.method_11478()), (class_1657)fakePlayer, 0, false));
                if (fakePlayer.method_6032() <= 0.0f && ((ILivingEntity)fakePlayer).invokeTryUseTotem(FakePlayer.mc.field_1687.method_48963().method_48830())) {
                    fakePlayer.method_6033(10.0f);
                    ThunderHack.EVENT_BUS.post(new TotemPopEvent((class_1657)fakePlayer, 1));
                }
            }
        }
    }

    @EventHandler
    public void onSync(EventSync e) {
        if (this.record.getValue().booleanValue()) {
            this.positions.add(new PlayerState(FakePlayer.mc.field_1724.method_23317(), FakePlayer.mc.field_1724.method_23318(), FakePlayer.mc.field_1724.method_23321(), FakePlayer.mc.field_1724.method_36454(), FakePlayer.mc.field_1724.method_36455()));
            return;
        }
        if (fakePlayer != null) {
            if (this.play.getValue().booleanValue() && !this.positions.isEmpty()) {
                ++this.movementTick;
                if (this.movementTick >= this.positions.size()) {
                    this.movementTick = 0;
                    return;
                }
                PlayerState p = this.positions.get(this.movementTick);
                fakePlayer.method_36456(p.yaw);
                fakePlayer.method_36457(p.pitch);
                fakePlayer.method_5847(p.yaw);
                fakePlayer.method_43391(p.x, p.y, p.z);
                fakePlayer.method_5759(p.x, p.y, p.z, p.yaw, p.pitch, 3);
            } else {
                this.movementTick = 0;
            }
            if (this.autoTotem.getValue().booleanValue() && fakePlayer.method_6079().method_7909() != class_1802.field_8288) {
                fakePlayer.method_6122(class_1268.field_5810, new class_1799((class_1935)class_1802.field_8288));
            }
            if (fakePlayer.method_29504()) {
                ++this.deathTime;
                if (this.deathTime > 10) {
                    this.disable();
                }
            }
        }
    }

    @EventHandler
    public void onAttack(EventAttack e) {
        if (fakePlayer != null && e.getEntity() == fakePlayer && FakePlayer.fakePlayer.field_6235 == 0 && !e.isPre()) {
            FakePlayer.mc.field_1687.method_43128((class_1657)FakePlayer.mc.field_1724, fakePlayer.method_23317(), fakePlayer.method_23318(), fakePlayer.method_23321(), class_3417.field_15115, class_3419.field_15248, 1.0f, 1.0f);
            if (FakePlayer.mc.field_1724.field_6017 > 0.0f) {
                FakePlayer.mc.field_1687.method_43128((class_1657)FakePlayer.mc.field_1724, fakePlayer.method_23317(), fakePlayer.method_23318(), fakePlayer.method_23321(), class_3417.field_15016, class_3419.field_15248, 1.0f, 1.0f);
            }
            fakePlayer.method_48922(FakePlayer.mc.field_1687.method_48963().method_48830());
            if ((double)ModuleManager.aura.getAttackCooldown() >= 0.85) {
                fakePlayer.method_6033(fakePlayer.method_6032() + fakePlayer.method_6067() - InventoryUtility.getHitDamage(FakePlayer.mc.field_1724.method_6047(), (class_1657)fakePlayer));
            } else {
                fakePlayer.method_6033(fakePlayer.method_6032() + fakePlayer.method_6067() - 1.0f);
            }
            if (fakePlayer.method_6032() <= 0.0f && ((ILivingEntity)fakePlayer).invokeTryUseTotem(FakePlayer.mc.field_1687.method_48963().method_48830())) {
                fakePlayer.method_6033(10.0f);
                new class_2663((class_1297)fakePlayer, (byte)35).method_11471((class_2602)FakePlayer.mc.field_1724.field_3944);
            }
        }
    }

    @Override
    public void onDisable() {
        if (fakePlayer == null) {
            return;
        }
        fakePlayer.method_5768();
        fakePlayer.method_31745(class_1297.class_5529.field_26998);
        fakePlayer.method_36209();
        fakePlayer = null;
        this.positions.clear();
        this.deathTime = 0;
    }

    private record PlayerState(double x, double y, double z, float yaw, float pitch) {
    }
}

