/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.PotionContentsComponent
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.HandSwingC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$LookAndOnGround
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.Hand
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.EntityHitResult
 *  net.minecraft.util.hit.HitResult
 */
package thunder.hack.features.modules.misc;

import java.util.function.Consumer;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2886;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_746;
import net.minecraft.class_9334;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.AsyncManager;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventSync;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.PlayerUtility;

public class MiddleClick
extends Module {
    private final Setting<Action> onBlock = new Setting<Action>("OnBlock", Action.Xp);
    private final Setting<Action> onAir = new Setting<Action>("OnAir", Action.Pearl);
    private final Setting<Action> onEntity = new Setting<Action>("OnEntity", Action.Friend);
    private final Setting<Action> onFlying = new Setting<Action>("OnElytra", Action.None);
    private final Setting<Boolean> silent = new Setting<Boolean>("Silent", true);
    private final Setting<Boolean> inventory = new Setting<Boolean>("Inventory", true);
    private final Setting<Integer> swapDelay = new Setting<Integer>("SwapDelay", 100, 0, 1000, v -> this.silent.getValue() == false);
    private final Setting<BooleanSettingGroup> antiWaste = new Setting<BooleanSettingGroup>("AntiWaste", new BooleanSettingGroup(true));
    private final Setting<Integer> durability = new Setting<Integer>("StopOn", 90, 0, 100).addToGroup(this.antiWaste);
    public final Setting<Boolean> antiPickUp = new Setting<Boolean>("AntiPickUp", true);
    private final Setting<Boolean> feetExp = new Setting<Boolean>("FeetXP", false);
    private static final Timer timer = new Timer();
    private String state = "none";

    public MiddleClick() {
        super("MiddleClick", Module.Category.MISC);
    }

    @Override
    public String getDisplayInfo() {
        return this.state;
    }

    @EventHandler
    private void onSync(EventSync event) {
        if (MiddleClick.mc.field_1755 == null) {
            class_3966 ehr;
            class_239 target = MiddleClick.mc.field_1765;
            if (MiddleClick.mc.field_1724.method_6128()) {
                if (MiddleClick.mc.field_1690.field_1871.method_1434()) {
                    this.onFlying.getValue().doAction(event);
                }
                this.state = this.onFlying.getValue().toString();
                return;
            }
            if (target instanceof class_3966 && (ehr = (class_3966)target).method_17782() instanceof class_1657) {
                if (MiddleClick.mc.field_1690.field_1871.method_1434()) {
                    this.onEntity.getValue().doAction(event);
                }
                this.state = this.onEntity.getValue().toString();
                return;
            }
            if (target instanceof class_3965) {
                class_3965 bhr = (class_3965)target;
                if (MiddleClick.mc.field_1687.method_22347(bhr.method_17777())) {
                    if (MiddleClick.mc.field_1690.field_1871.method_1434()) {
                        this.onAir.getValue().doAction(event);
                    }
                    this.state = this.onAir.getValue().toString();
                } else {
                    if (MiddleClick.mc.field_1690.field_1871.method_1434()) {
                        this.onBlock.getValue().doAction(event);
                    }
                    this.state = this.onBlock.getValue().toString();
                }
                return;
            }
            if (MiddleClick.mc.field_1690.field_1871.method_1434()) {
                this.onAir.getValue().doAction(event);
            }
            this.state = this.onAir.getValue().toString();
        }
    }

    private static boolean needXp() {
        for (class_1799 stack : MiddleClick.mc.field_1724.method_5661()) {
            if (!(PlayerUtility.calculatePercentage(stack) < (float)ModuleManager.middleClick.durability.getValue().intValue())) continue;
            return true;
        }
        return false;
    }

    private static int getHpSlot() {
        for (int i = 0; i < 9; ++i) {
            if (!MiddleClick.isStackPotion(MiddleClick.mc.field_1724.method_31548().method_5438(i))) continue;
            return i;
        }
        return -1;
    }

    private static int findHpInInventory() {
        for (int i = 36; i >= 0; --i) {
            if (!MiddleClick.isStackPotion(MiddleClick.mc.field_1724.method_31548().method_5438(i))) continue;
            return i < 9 ? i + 36 : i;
        }
        return -1;
    }

    private static boolean isStackPotion(class_1799 stack) {
        if (stack == null) {
            return false;
        }
        if (stack.method_7909() == class_1802.field_8436) {
            class_1844 potionContentsComponent = (class_1844)stack.method_57825(class_9334.field_49651, class_1844.field_49274);
            for (class_1293 effect : potionContentsComponent.method_57397()) {
                if (effect.method_5579().comp_349() != class_1294.field_5915.comp_349()) continue;
                return true;
            }
        }
        return false;
    }

    public static enum Action {
        HealingPot(e -> {
            if (timer.every(250L)) {
                if (MiddleClick.getHpSlot() != -1) {
                    int hpSlot = MiddleClick.getHpSlot();
                    int originalSlot = Module.mc.field_1724.method_31548().field_7545;
                    if (hpSlot != -1) {
                        InventoryUtility.switchTo(hpSlot);
                        InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                        InventoryUtility.switchTo(originalSlot);
                    }
                } else {
                    int hpSlot = MiddleClick.findHpInInventory();
                    if (hpSlot != -1) {
                        Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, hpSlot, Module.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)Module.mc.field_1724);
                        InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                        Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
                        Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, hpSlot, Module.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)Module.mc.field_1724);
                    }
                }
            }
        }),
        Firework(e -> {
            if (timer.every(250L)) {
                int epSlot1 = InventoryUtility.findItemInHotBar(class_1802.field_8639).slot();
                if (ModuleManager.middleClick.silent.getValue().booleanValue()) {
                    if (!ModuleManager.middleClick.inventory.getValue().booleanValue() || ModuleManager.middleClick.inventory.getValue().booleanValue() && epSlot1 != -1) {
                        int originalSlot = Module.mc.field_1724.method_31548().field_7545;
                        if (epSlot1 != -1) {
                            Module.mc.field_1724.method_31548().field_7545 = epSlot1;
                            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(epSlot1));
                            InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
                            Module.mc.field_1724.method_31548().field_7545 = originalSlot;
                            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(originalSlot));
                        }
                    } else {
                        int epSlot = InventoryUtility.findItemInInventory(class_1802.field_8639).slot();
                        if (epSlot != -1) {
                            Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, epSlot, Module.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)Module.mc.field_1724);
                            InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
                            Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, epSlot, Module.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)Module.mc.field_1724);
                        }
                    }
                } else if (!ModuleManager.middleClick.inventory.getValue().booleanValue() || ModuleManager.middleClick.inventory.getValue().booleanValue() && epSlot1 != -1) {
                    if (epSlot1 != -1) {
                        new PearlThread(Module.mc.field_1724, epSlot1, Module.mc.field_1724.method_31548().field_7545, ModuleManager.middleClick.swapDelay.getValue(), false).start();
                    }
                } else {
                    int epSlot = InventoryUtility.findItemInInventory(class_1802.field_8639).slot();
                    if (epSlot != -1) {
                        new PearlThread(Module.mc.field_1724, epSlot, Module.mc.field_1724.method_31548().field_7545, ModuleManager.middleClick.swapDelay.getValue(), true).start();
                    }
                }
            }
        }),
        Friend(e -> {
            class_3966 ehr;
            class_239 patt0$temp;
            if (timer.every(800L) && (patt0$temp = Module.mc.field_1765) instanceof class_3966 && (ehr = (class_3966)patt0$temp).method_17782() instanceof class_1657) {
                if (Managers.FRIEND.isFriend(ehr.method_17782().method_5477().getString())) {
                    Managers.FRIEND.removeFriend(ehr.method_17782().method_5477().getString());
                    Command.sendMessage(ClientSettings.isRu() ? "\u00a7b" + ehr.method_17782().method_5477().getString() + "\u00a7r \u0443\u0434\u0430\u043b\u0435\u043d \u0438\u0437 \u0434\u0440\u0443\u0437\u0435\u0439!" : "\u00a7b" + ehr.method_17782().method_5477().getString() + "\u00a7r removed from friends!");
                } else {
                    Managers.FRIEND.addFriend(ehr.method_17782().method_5477().getString());
                    Command.sendMessage(ClientSettings.isRu() ? "\u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0434\u0440\u0443\u0433 \u00a7b" + ehr.method_17782().method_5477().getString() : "Added friend \u00a7b" + ehr.method_17782().method_5477().getString());
                }
            }
        }),
        Pearl(e -> {
            if (timer.every(500L)) {
                if (ModuleManager.aura.isEnabled() && Aura.target != null) {
                    Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2831(Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455(), Module.mc.field_1724.method_24828()));
                }
                int epSlot1 = InventoryUtility.findItemInHotBar(class_1802.field_8634).slot();
                if (ModuleManager.middleClick.silent.getValue().booleanValue()) {
                    if (!ModuleManager.middleClick.inventory.getValue().booleanValue() || ModuleManager.middleClick.inventory.getValue().booleanValue() && epSlot1 != -1) {
                        int originalSlot = Module.mc.field_1724.method_31548().field_7545;
                        if (epSlot1 != -1) {
                            Module.mc.field_1724.method_31548().field_7545 = epSlot1;
                            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(epSlot1));
                            InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
                            Module.mc.field_1724.method_31548().field_7545 = originalSlot;
                            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(originalSlot));
                        }
                    } else {
                        int epSlot = InventoryUtility.findItemInInventory(class_1802.field_8634).slot();
                        if (epSlot != -1) {
                            Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, epSlot, Module.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)Module.mc.field_1724);
                            InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                            Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
                            Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, epSlot, Module.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)Module.mc.field_1724);
                        }
                    }
                } else if (!ModuleManager.middleClick.inventory.getValue().booleanValue() || ModuleManager.middleClick.inventory.getValue().booleanValue() && epSlot1 != -1) {
                    if (epSlot1 != -1) {
                        new PearlThread(Module.mc.field_1724, epSlot1, Module.mc.field_1724.method_31548().field_7545, ModuleManager.middleClick.swapDelay.getValue(), false).start();
                    }
                } else {
                    int epSlot = InventoryUtility.findItemInInventory(class_1802.field_8634).slot();
                    if (epSlot != -1) {
                        new PearlThread(Module.mc.field_1724, epSlot, Module.mc.field_1724.method_31548().field_7545, ModuleManager.middleClick.swapDelay.getValue(), true).start();
                    }
                }
            }
        }),
        Xp(e -> {
            if (ModuleManager.middleClick.feetExp.getValue().booleanValue() && (!ModuleManager.middleClick.antiWaste.getValue().isEnabled() || MiddleClick.needXp())) {
                Module.mc.field_1724.method_36457(90.0f);
            }
            e.addPostAction(() -> {
                int slot;
                if (ModuleManager.middleClick.antiWaste.getValue().isEnabled() && !MiddleClick.needXp()) {
                    return;
                }
                if (Module.mc.field_1690.field_1871.method_1434() && (slot = InventoryUtility.findItemInHotBar(class_1802.field_8287).slot()) != -1) {
                    int lastSlot = Module.mc.field_1724.method_31548().field_7545;
                    InventoryUtility.switchTo(slot);
                    InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                    if (ModuleManager.middleClick.silent.getValue().booleanValue()) {
                        InventoryUtility.switchTo(lastSlot);
                    }
                }
            });
        }),
        None(e -> {});

        private final Consumer<EventSync> r;

        private Action(Consumer<EventSync> r) {
            this.r = r;
        }

        public void doAction(EventSync e) {
            this.r.accept(e);
        }
    }

    public static class PearlThread
    extends Thread {
        public class_746 player;
        int epSlot;
        int originalSlot;
        int delay;
        boolean inv;

        public PearlThread(class_746 entityPlayer, int epSlot, int originalSlot, int delay, boolean inventory) {
            this.player = entityPlayer;
            this.epSlot = epSlot;
            this.originalSlot = originalSlot;
            this.delay = delay;
            this.inv = inventory;
        }

        @Override
        public void run() {
            if (!this.inv) {
                InventoryUtility.switchTo(this.epSlot);
                AsyncManager.sleep(this.delay);
                InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
                AsyncManager.sleep(this.delay);
                InventoryUtility.switchTo(this.originalSlot);
            } else {
                Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, this.epSlot, this.originalSlot, class_1713.field_7791, (class_1657)Module.mc.field_1724);
                AsyncManager.sleep(this.delay);
                if (ModuleManager.aura.isEnabled() && Aura.target != null) {
                    Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2831(Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455(), Module.mc.field_1724.method_24828()));
                }
                InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, Module.mc.field_1724.method_36454(), Module.mc.field_1724.method_36455()));
                Module.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
                AsyncManager.sleep(this.delay);
                Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, this.epSlot, this.originalSlot, class_1713.field_7791, (class_1657)Module.mc.field_1724);
            }
            super.run();
        }
    }
}

