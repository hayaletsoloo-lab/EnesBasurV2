/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.Item
 *  net.minecraft.screen.slot.Slot
 *  net.minecraft.screen.slot.SlotActionType
 */
package thunder.hack.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import thunder.hack.events.impl.EventClickSlot;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class ItemScroller
extends Module {
    public Setting<Integer> delay = new Setting<Integer>("Delay", 80, 0, 500);
    private boolean pauseListening = false;

    public ItemScroller() {
        super("ItemScroller", Module.Category.MISC);
    }

    @EventHandler
    public void onClick(EventClickSlot e) {
        if ((this.isKeyPressed(340) || this.isKeyPressed(344)) && (this.isKeyPressed(341) || this.isKeyPressed(345)) && e.getSlotActionType() == class_1713.field_7795 && !this.pauseListening) {
            class_1792 copy = ((class_1735)ItemScroller.mc.field_1724.field_7512.field_7761.get(e.getSlot())).method_7677().method_7909();
            this.pauseListening = true;
            for (int i2 = 0; i2 < ItemScroller.mc.field_1724.field_7512.field_7761.size(); ++i2) {
                if (((class_1735)ItemScroller.mc.field_1724.field_7512.field_7761.get(i2)).method_7677().method_7909() != copy) continue;
                ItemScroller.mc.field_1761.method_2906(ItemScroller.mc.field_1724.field_7512.field_7763, i2, 1, class_1713.field_7795, (class_1657)ItemScroller.mc.field_1724);
            }
            this.pauseListening = false;
        }
    }
}

