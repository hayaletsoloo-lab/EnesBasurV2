/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.sound.SoundCategory
 *  net.minecraft.sound.SoundEvents
 *  net.minecraft.util.Formatting
 */
package thunder.hack.features.modules.misc;

import java.util.ArrayList;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventEntityRemoved;
import thunder.hack.events.impl.EventEntitySpawn;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.misc.NameProtect;
import thunder.hack.gui.notification.Notification;
import thunder.hack.setting.Setting;

public class VisualRange
extends Module {
    private static final ArrayList<String> entities = new ArrayList();
    private final Setting<Boolean> leave = new Setting<Boolean>("Leave", true);
    private final Setting<Boolean> enter = new Setting<Boolean>("Enter", true);
    private final Setting<Boolean> friends = new Setting<Boolean>("Friends", true);
    private final Setting<Boolean> soundpl = new Setting<Boolean>("Sound", true);
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Notification);

    public VisualRange() {
        super("VisualRange", Module.Category.MISC);
    }

    @EventHandler
    public void onEntityAdded(EventEntitySpawn event) {
        if (!this.isValid(event.getEntity())) {
            return;
        }
        if (entities.contains(event.getEntity().method_5477().getString())) {
            return;
        }
        entities.add(event.getEntity().method_5477().getString());
        if (this.enter.getValue().booleanValue()) {
            this.notify(event.getEntity(), true);
        }
    }

    @EventHandler
    public void onEntityRemoved(EventEntityRemoved event) {
        if (!this.isValid(event.entity)) {
            return;
        }
        if (!entities.contains(event.entity.method_5477().getString())) {
            return;
        }
        entities.remove(event.entity.method_5477().getString());
        if (this.leave.getValue().booleanValue()) {
            this.notify(event.entity, false);
        }
    }

    public void notify(class_1297 entity, boolean enter) {
        Object message = "";
        if (ModuleManager.nameProtect.isEnabled() && NameProtect.hideFriends.getValue().booleanValue()) {
            message = String.valueOf(class_124.field_1075) + NameProtect.newName.getValue();
        }
        message = Managers.FRIEND.isFriend(entity.method_5477().getString()) ? String.valueOf(class_124.field_1075) + entity.method_5477().getString() : String.valueOf(class_124.field_1080) + entity.method_5477().getString();
        Object object = message = enter ? (String)message + String.valueOf(class_124.field_1060) + " was found!" : (String)message + String.valueOf(class_124.field_1061) + " left to X:" + (int)entity.method_23317() + " Z:" + (int)entity.method_23321();
        if (this.mode.is(Mode.Chat) || this.mode.is(Mode.Both)) {
            this.sendMessage((String)message);
        }
        if (this.mode.is(Mode.Notification) || this.mode.is(Mode.Both)) {
            Managers.NOTIFICATION.publicity("VisualRange", (String)message, 2, Notification.Type.WARNING);
        }
        if (this.soundpl.getValue().booleanValue()) {
            try {
                if (enter) {
                    VisualRange.mc.field_1687.method_8396((class_1657)VisualRange.mc.field_1724, VisualRange.mc.field_1724.method_24515(), class_3417.field_14709, class_3419.field_15245, 1.0f, 1.0f);
                } else {
                    VisualRange.mc.field_1687.method_8396((class_1657)VisualRange.mc.field_1724, VisualRange.mc.field_1724.method_24515(), class_3417.field_14627, class_3419.field_15245, 1.0f, 1.0f);
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public boolean isValid(class_1297 entity) {
        if (!(entity instanceof class_1657)) {
            return false;
        }
        return entity != VisualRange.mc.field_1724 && (!Managers.FRIEND.isFriend(entity.method_5477().getString()) || this.friends.getValue() != false);
    }

    public static enum Mode {
        Chat,
        Notification,
        Both;

    }
}

