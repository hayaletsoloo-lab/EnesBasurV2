/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 */
package thunder.hack.features.modules.misc;

import net.minecraft.class_2596;
import net.minecraft.class_2868;
import thunder.hack.features.modules.Module;

public class ItemSwapFix
extends Module {
    public ItemSwapFix() {
        super("ItemSwapFix", Module.Category.MISC);
    }

    public void forceSync() {
        if (!this.isEnabled() || ItemSwapFix.mc.field_1724 == null || mc.method_1562() == null) {
            return;
        }
        mc.method_1562().method_52787((class_2596)new class_2868(ItemSwapFix.mc.field_1724.method_31548().field_7545));
    }
}

