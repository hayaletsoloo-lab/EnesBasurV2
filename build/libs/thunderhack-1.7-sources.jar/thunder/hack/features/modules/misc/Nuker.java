/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockState
 *  net.minecraft.block.Blocks
 *  net.minecraft.block.FluidBlock
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Hand
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext$FluidHandling
 *  net.minecraft.world.RaycastContext$ShapeType
 */
package thunder.hack.features.modules.misc;

import java.awt.Color;
import java.util.ArrayList;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventAttackBlock;
import thunder.hack.events.impl.EventSetBlockState;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.player.SpeedMine;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.setting.impl.ItemSelectSetting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.PlayerUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.world.ExplosionUtility;

public class Nuker
extends Module {
    public final Setting<ItemSelectSetting> selectedBlocks = new Setting<ItemSelectSetting>("SelectedBlocks", new ItemSelectSetting(new ArrayList<String>()));
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Default);
    private final Setting<Integer> delay = new Setting<Integer>("Delay", 25, 0, 1000);
    private final Setting<BlockSelection> blocks = new Setting<BlockSelection>("Blocks", BlockSelection.Select);
    private final Setting<Boolean> ignoreWalls = new Setting<Boolean>("IgnoreWalls", false);
    private final Setting<Boolean> flatten = new Setting<Boolean>("Flatten", false);
    private final Setting<Boolean> creative = new Setting<Boolean>("Creative", false);
    private final Setting<Boolean> avoidLava = new Setting<Boolean>("AvoidLava", false);
    private final Setting<Float> range = new Setting<Float>("Range", Float.valueOf(4.2f), Float.valueOf(1.5f), Float.valueOf(25.0f));
    private final Setting<ColorMode> colorMode = new Setting<ColorMode>("ColorMode", ColorMode.Sync);
    public final Setting<ColorSetting> color = new Setting<ColorSetting>("Color", new ColorSetting(575714484), v -> this.colorMode.getValue() == ColorMode.Custom);
    private class_2248 targetBlockType;
    private BlockData blockData;
    private Timer breakTimer = new Timer();
    private NukerThread nukerThread = new NukerThread();
    private float rotationYaw;
    private float rotationPitch;

    public Nuker() {
        super("Nuker", Module.Category.MISC);
    }

    @Override
    public void onEnable() {
        this.nukerThread = new NukerThread();
        this.nukerThread.setName("ThunderHack-NukerThread");
        this.nukerThread.setDaemon(true);
        this.nukerThread.start();
    }

    @Override
    public void onDisable() {
        this.nukerThread.interrupt();
    }

    @Override
    public void onUpdate() {
        if (!this.nukerThread.isAlive()) {
            this.nukerThread = new NukerThread();
            this.nukerThread.setName("ThunderHack-NukerThread");
            this.nukerThread.setDaemon(true);
            this.nukerThread.start();
        }
    }

    @EventHandler
    public void onBlockInteract(EventAttackBlock e) {
        if (Nuker.mc.field_1687.method_22347(e.getBlockPos())) {
            return;
        }
        if (this.blocks.getValue().equals(BlockSelection.Select) && this.targetBlockType != Nuker.mc.field_1687.method_8320(e.getBlockPos()).method_26204()) {
            this.targetBlockType = Nuker.mc.field_1687.method_8320(e.getBlockPos()).method_26204();
            this.sendMessage(ClientSettings.isRu() ? "\u0412\u044b\u0431\u0440\u0430\u043d \u0431\u043b\u043e\u043a: " + String.valueOf(class_124.field_1075) + this.targetBlockType.method_9518().getString() : "Selected block: " + String.valueOf(class_124.field_1075) + this.targetBlockType.method_9518().getString());
        }
    }

    @EventHandler
    public void onBlockDestruct(EventSetBlockState e) {
        if (this.blockData != null && e.getPos() == this.blockData.bp && e.getState().method_26215()) {
            this.blockData = null;
            new Thread(() -> {
                if ((this.targetBlockType != null || this.blocks.getValue().equals(BlockSelection.All)) && !Nuker.mc.field_1690.field_1886.method_1434() && this.blockData == null) {
                    this.blockData = this.getNukerBlockPos();
                }
            }).start();
        }
    }

    @EventHandler
    public void onSync(EventSync e) {
        if (this.rotationYaw != -999.0f) {
            Nuker.mc.field_1724.method_36456(this.rotationYaw);
            Nuker.mc.field_1724.method_36457(this.rotationPitch);
            this.rotationYaw = -999.0f;
        }
    }

    @EventHandler
    public void onPlayerUpdate(PlayerUpdateEvent e) {
        if (this.blockData != null && (Nuker.mc.field_1687.method_8320(this.blockData.bp).method_26204() != this.targetBlockType && this.blocks.getValue().equals(BlockSelection.Select) || PlayerUtility.squaredDistanceFromEyes(this.blockData.bp.method_46558()) > this.range.getPow2Value() || Nuker.mc.field_1687.method_22347(this.blockData.bp))) {
            this.blockData = null;
        }
        if (this.blockData == null || Nuker.mc.field_1690.field_1886.method_1434()) {
            return;
        }
        float[] angle = InteractionUtility.calculateAngle(this.blockData.vec3d);
        this.rotationYaw = angle[0];
        this.rotationPitch = angle[1];
        ModuleManager.rotations.fixRotation = this.rotationYaw;
        if (this.mode.getValue() == Mode.Default) {
            this.breakBlock();
        }
        if (this.mode.getValue() == Mode.FastAF) {
            int intRange = (int)(Math.floor(this.range.getValue().floatValue()) + 1.0);
            Iterable<class_2338> blocks_ = class_2338.method_25996((class_2338)new class_2338((class_2382)class_2338.method_49638((class_2374)Nuker.mc.field_1724.method_19538()).method_10084()), (int)intRange, (int)intRange, (int)intRange);
            for (class_2338 b : blocks_) {
                if (this.flatten.getValue().booleanValue() && (double)b.method_10264() < Nuker.mc.field_1724.method_23318() || this.avoidLava.getValue().booleanValue() && this.checkLava(b)) continue;
                class_2680 state = Nuker.mc.field_1687.method_8320(b);
                if (!(PlayerUtility.squaredDistanceFromEyes(b.method_46558()) <= this.range.getPow2Value()) || !this.isAllowed(state.method_26204())) continue;
                try {
                    this.sendSequencedPacket(id -> new class_2846(class_2846.class_2847.field_12968, b, class_2350.field_11036, id));
                    Nuker.mc.field_1761.method_2899(b);
                    Nuker.mc.field_1724.method_6104(class_1268.field_5808);
                }
                catch (Exception exception) {}
            }
        }
    }

    public synchronized void breakBlock() {
        if (this.blockData == null || Nuker.mc.field_1690.field_1886.method_1434()) {
            return;
        }
        if (ModuleManager.speedMine.isEnabled() && ModuleManager.speedMine.mode.getValue() == SpeedMine.Mode.Packet) {
            if (!ModuleManager.speedMine.alreadyActing(this.blockData.bp)) {
                Nuker.mc.field_1761.method_2910(this.blockData.bp, this.blockData.dir);
                Nuker.mc.field_1724.method_6104(class_1268.field_5808);
            }
        } else {
            class_2338 cache = this.blockData.bp;
            Nuker.mc.field_1761.method_2902(this.blockData.bp, this.blockData.dir);
            Nuker.mc.field_1724.method_6104(class_1268.field_5808);
            if (this.creative.getValue().booleanValue()) {
                Nuker.mc.field_1761.method_2899(cache);
            }
        }
    }

    @Override
    public void onRender3D(class_4587 stack) {
        class_2338 renderBp = null;
        if (this.blockData != null && this.blockData.bp != null) {
            renderBp = this.blockData.bp;
        }
        if (renderBp != null) {
            Color color1 = this.colorMode.getValue() == ColorMode.Sync ? HudEditor.getColor(1) : this.color.getValue().getColorObject();
            Render3DEngine.drawBoxOutline(new class_238(this.blockData.bp), color1, 2.0f);
            Render3DEngine.drawFilledBox(stack, new class_238(this.blockData.bp), Render2DEngine.injectAlpha(color1, 100));
        }
        if (this.mode.getValue() == Mode.Fast && this.breakTimer.passedMs(this.delay.getValue().intValue())) {
            this.breakBlock();
            this.breakTimer.reset();
        }
    }

    public BlockData getNukerBlockPos() {
        int intRange = (int)(Math.floor(this.range.getValue().floatValue()) + 1.0);
        Iterable<class_2338> blocks_ = class_2338.method_25996((class_2338)new class_2338((class_2382)class_2338.method_49638((class_2374)Nuker.mc.field_1724.method_19538()).method_10084()), (int)intRange, (int)intRange, (int)intRange);
        for (class_2338 b : blocks_) {
            class_2680 state = Nuker.mc.field_1687.method_8320(b);
            if (this.flatten.getValue().booleanValue() && (double)b.method_10264() < Nuker.mc.field_1724.method_23318() || !(PlayerUtility.squaredDistanceFromEyes(b.method_46558()) <= this.range.getPow2Value()) || this.avoidLava.getValue().booleanValue() && this.checkLava(b) || !this.isAllowed(state.method_26204())) continue;
            if (this.ignoreWalls.getValue().booleanValue()) {
                class_3965 result = ExplosionUtility.rayCastBlock(new class_3959(InteractionUtility.getEyesPos((class_1297)Nuker.mc.field_1724), b.method_46558(), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)Nuker.mc.field_1724), b);
                if (result == null) continue;
                return new BlockData(b, result.method_17784(), result.method_17780());
            }
            for (float x1 = 0.0f; x1 <= 1.0f; x1 += 0.2f) {
                for (float y1 = 0.0f; y1 <= 1.0f; y1 += 0.2f) {
                    for (float z1 = 0.0f; z1 <= 1.0f; z1 += 0.2f) {
                        class_243 p = new class_243((double)((float)b.method_10263() + x1), (double)((float)b.method_10264() + y1), (double)((float)b.method_10260() + z1));
                        class_3965 bhr = Nuker.mc.field_1687.method_17742(new class_3959(InteractionUtility.getEyesPos((class_1297)Nuker.mc.field_1724), p, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)Nuker.mc.field_1724));
                        if (bhr == null || bhr.method_17783() != class_239.class_240.field_1332 || !bhr.method_17777().equals(b)) continue;
                        return new BlockData(b, p, bhr.method_17780());
                    }
                }
            }
        }
        return null;
    }

    private boolean checkLava(class_2338 base) {
        for (class_2350 dir : class_2350.values()) {
            if (Nuker.mc.field_1687.method_8320(base.method_10093(dir)).method_26204() != class_2246.field_10164) continue;
            return true;
        }
        return false;
    }

    private boolean isAllowed(class_2248 block) {
        boolean allowed = this.selectedBlocks.getValue().getItemsById().contains(block.method_9539().replace("block.minecraft.", ""));
        return switch (this.blocks.getValue().ordinal()) {
            case 1 -> {
                if (block != class_2246.field_9987 && block != class_2246.field_10124 && block != class_2246.field_10543 && !(block instanceof class_2404)) {
                    yield true;
                }
                yield false;
            }
            case 0 -> {
                if (block == this.targetBlockType) {
                    yield true;
                }
                yield false;
            }
            case 3 -> allowed;
            default -> !allowed && block != class_2246.field_9987 && block != class_2246.field_10124 && block != class_2246.field_10543 && !(block instanceof class_2404);
        };
    }

    private static enum Mode {
        Default,
        Fast,
        FastAF;

    }

    private static enum BlockSelection {
        Select,
        All,
        BlackList,
        WhiteList;

    }

    private static enum ColorMode {
        Custom,
        Sync;

    }

    public class NukerThread
    extends Thread {
        @Override
        public void run() {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    if (!Module.fullNullCheck()) {
                        while (Managers.ASYNC.ticking.get()) {
                        }
                        if (Nuker.this.targetBlockType == null && Nuker.this.blocks.getValue().equals(BlockSelection.Select) || Module.mc.field_1690.field_1886.method_1434() || Nuker.this.blockData != null) continue;
                        Nuker.this.blockData = Nuker.this.getNukerBlockPos();
                        continue;
                    }
                    Thread.yield();
                }
                catch (Exception exception) {}
            }
        }
    }

    public record BlockData(class_2338 bp, class_243 vec3d, class_2350 dir) {
    }
}

