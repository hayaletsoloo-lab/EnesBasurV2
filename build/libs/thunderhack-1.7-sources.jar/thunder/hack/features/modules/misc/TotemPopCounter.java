/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.Formatting
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.TotemPopEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.combat.AntiBot;
import thunder.hack.gui.notification.Notification;
import thunder.hack.setting.Setting;

public class TotemPopCounter
extends Module {
    public Setting<Boolean> notification = new Setting<Boolean>("Notification", true);

    public TotemPopCounter() {
        super("TotemPopCounter", Module.Category.MISC);
    }

    @EventHandler
    public void onTotemPop(@NotNull TotemPopEvent event) {
        if (event.getEntity() == TotemPopCounter.mc.field_1724) {
            return;
        }
        String s = ClientSettings.isRu() ? String.valueOf(class_124.field_1060) + event.getEntity().method_5477().getString() + String.valueOf(class_124.field_1068) + " \u043f\u043e\u043f\u043d\u0443\u043b " + String.valueOf(class_124.field_1075) + (event.getPops() > 1 ? event.getPops() + String.valueOf(class_124.field_1068) + " \u0442\u043e\u0442\u0435\u043c\u043e\u0432!" : String.valueOf(class_124.field_1068) + "\u0442\u043e\u0442\u0435\u043c!") : String.valueOf(class_124.field_1060) + event.getEntity().method_5477().getString() + String.valueOf(class_124.field_1068) + " popped " + String.valueOf(class_124.field_1075) + (event.getPops() > 1 ? event.getPops() + String.valueOf(class_124.field_1068) + " totems!" : String.valueOf(class_124.field_1068) + " a totem!");
        this.sendMessage(s);
        if (this.notification.getValue().booleanValue()) {
            Managers.NOTIFICATION.publicity("TotemPopCounter", s, 2, Notification.Type.INFO);
        }
    }

    @Override
    public void onUpdate() {
        for (class_1657 player : TotemPopCounter.mc.field_1687.method_18456()) {
            if (player == TotemPopCounter.mc.field_1724 || AntiBot.bots.contains(player) || player.method_6032() > 0.0f || !Managers.COMBAT.popList.containsKey(player.method_5477().getString())) continue;
            String s = ClientSettings.isRu() ? String.valueOf(class_124.field_1060) + player.method_5477().getString() + String.valueOf(class_124.field_1068) + " \u043f\u043e\u043f\u043d\u0443\u043b " + (Managers.COMBAT.popList.get(player.method_5477().getString()) > 1 ? String.valueOf(Managers.COMBAT.popList.get(player.method_5477().getString())) + String.valueOf(class_124.field_1068) + " \u0442\u043e\u0442\u0435\u043c\u043e\u0432 \u0438 \u0441\u0434\u043e\u0445!" : String.valueOf(class_124.field_1068) + "\u0442\u043e\u0442\u0435\u043c \u0438 \u0441\u0434\u043e\u0445!") : String.valueOf(class_124.field_1060) + player.method_5477().getString() + String.valueOf(class_124.field_1068) + " popped " + (Managers.COMBAT.popList.get(player.method_5477().getString()) > 1 ? String.valueOf(Managers.COMBAT.popList.get(player.method_5477().getString())) + String.valueOf(class_124.field_1068) + " totems and died EZ LMAO!" : String.valueOf(class_124.field_1068) + "totem and died EZ LMAO!");
            this.sendMessage(s);
            if (!this.notification.getValue().booleanValue()) continue;
            Managers.NOTIFICATION.publicity("TotemPopCounter", s, 2, Notification.Type.INFO);
        }
    }
}

