/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.Screen
 */
package thunder.hack.features.modules.client;

import net.minecraft.class_437;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.windows.WindowsScreen;
import thunder.hack.gui.windows.impl.ConfigWindow;
import thunder.hack.gui.windows.impl.FriendsWindow;
import thunder.hack.gui.windows.impl.MacroWindow;
import thunder.hack.gui.windows.impl.ProxyWindow;
import thunder.hack.gui.windows.impl.WaypointWindow;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.PositionSetting;

public class Windows
extends Module {
    public final Setting<PositionSetting> macroPos = new Setting<PositionSetting>("macroPos", new PositionSetting(0.3f, 0.3f), v -> false);
    public final Setting<PositionSetting> configPos = new Setting<PositionSetting>("configPos", new PositionSetting(0.35f, 0.35f), v -> false);
    public final Setting<PositionSetting> friendPos = new Setting<PositionSetting>("friendPos", new PositionSetting(0.4f, 0.4f), v -> false);
    public final Setting<PositionSetting> waypointPos = new Setting<PositionSetting>("waypointPos", new PositionSetting(0.45f, 0.45f), v -> false);
    public final Setting<PositionSetting> proxyPos = new Setting<PositionSetting>("proxyPos", new PositionSetting(0.5f, 0.5f), v -> false);

    public Windows() {
        super("Windows", Module.Category.CLIENT);
    }

    @Override
    public void onEnable() {
        mc.method_1507((class_437)new WindowsScreen(MacroWindow.get(this.macroPos.getValue().getX() * (float)mc.method_22683().method_4486(), this.macroPos.getValue().getY() * (float)mc.method_22683().method_4502(), this.macroPos), ConfigWindow.get(this.configPos.getValue().getX() * (float)mc.method_22683().method_4486(), this.configPos.getValue().getY() * (float)mc.method_22683().method_4502(), this.configPos), FriendsWindow.get(this.friendPos.getValue().getX() * (float)mc.method_22683().method_4486(), this.friendPos.getValue().getY() * (float)mc.method_22683().method_4502(), this.friendPos), WaypointWindow.get(this.waypointPos.getValue().getX() * (float)mc.method_22683().method_4486(), this.waypointPos.getValue().getY() * (float)mc.method_22683().method_4502(), this.waypointPos), ProxyWindow.get(this.proxyPos.getValue().getX() * (float)mc.method_22683().method_4486(), this.proxyPos.getValue().getY() * (float)mc.method_22683().method_4502(), this.proxyPos)));
        this.disable();
    }
}

