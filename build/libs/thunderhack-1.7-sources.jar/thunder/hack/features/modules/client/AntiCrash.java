/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.network.packet.s2c.play.ExplosionS2CPacket
 *  net.minecraft.network.packet.s2c.play.ParticleS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.client;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2664;
import net.minecraft.class_2675;
import net.minecraft.class_2708;
import org.jetbrains.annotations.NotNull;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;

public class AntiCrash
extends Module {
    public final Setting<Boolean> debug = new Setting<Boolean>("Debug", false);
    private Timer debugTimer = new Timer();

    public AntiCrash() {
        super("AntiCrash", Module.Category.CLIENT);
    }

    @EventHandler
    public void onPacketReceive(@NotNull PacketEvent.Receive receive) {
        class_2664 exp;
        Object t = receive.getPacket();
        if (t instanceof class_2664 && ((exp = (class_2664)t).method_11475() > 1.0E9 || exp.method_11477() > 1.0E9 || exp.method_11478() > 1.0E9 || (double)exp.method_11476() > 1.0E9)) {
            if (this.debug.getValue().booleanValue() && this.debugTimer.passedMs(1000L)) {
                this.sendMessage("ExplosionS2CPacket canceled");
                this.debugTimer.reset();
            }
            receive.cancel();
        } else {
            class_2675 p;
            t = receive.getPacket();
            if (t instanceof class_2675 && ((p = (class_2675)t).method_11544() > 1.0E9 || p.method_11547() > 1.0E9 || p.method_11546() > 1.0E9 || (double)p.method_11543() > 1.0E9 || (double)p.method_11548() > 1.0E9 || (double)p.method_11549() > 1.0E9 || (double)p.method_11550() > 1.0E9)) {
                if (this.debug.getValue().booleanValue() && this.debugTimer.passedMs(1000L)) {
                    this.sendMessage("ParticleS2CPacket canceled");
                    this.debugTimer.reset();
                }
                receive.cancel();
            } else {
                class_2708 pos;
                t = receive.getPacket();
                if (t instanceof class_2708 && ((pos = (class_2708)t).method_11734() > 1.0E9 || pos.method_11735() > 1.0E9 || pos.method_11738() > 1.0E9 || (double)pos.method_11736() > 1.0E9 || (double)pos.method_11739() > 1.0E9)) {
                    if (this.debug.getValue().booleanValue() && this.debugTimer.passedMs(1000L)) {
                        this.sendMessage("PlayerPositionLookS2CPacket canceled");
                        this.debugTimer.reset();
                    }
                    receive.cancel();
                }
            }
        }
    }
}

