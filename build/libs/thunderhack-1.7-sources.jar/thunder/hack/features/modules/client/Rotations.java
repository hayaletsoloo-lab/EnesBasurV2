/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 */
package thunder.hack.features.modules.client;

import net.minecraft.class_243;
import net.minecraft.class_3532;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventFixVelocity;
import thunder.hack.events.impl.EventKeyboardInput;
import thunder.hack.events.impl.EventPlayerJump;
import thunder.hack.events.impl.EventPlayerTravel;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.setting.Setting;

public class Rotations
extends Module {
    private final Setting<MoveFix> moveFix = new Setting<MoveFix>("MoveFix", MoveFix.Off);
    public final Setting<Boolean> clientLook = new Setting<Boolean>("ClientLook", false);
    public float fixRotation;
    private float prevYaw;
    private float prevPitch;

    public Rotations() {
        super("Rotations", Module.Category.CLIENT);
    }

    public void onJump(EventPlayerJump e) {
        if (Rotations.fullNullCheck() || Float.isNaN(this.fixRotation) || this.moveFix.getValue() == MoveFix.Off || Rotations.mc.field_1724.method_3144()) {
            return;
        }
        if (e.isPre()) {
            this.prevYaw = Rotations.mc.field_1724.method_36454();
            Rotations.mc.field_1724.method_36456(this.fixRotation);
        } else {
            Rotations.mc.field_1724.method_36456(this.prevYaw);
        }
    }

    public void onPlayerMove(EventFixVelocity event) {
        if (this.moveFix.getValue() == MoveFix.Free) {
            if (Rotations.fullNullCheck() || Float.isNaN(this.fixRotation) || Rotations.mc.field_1724.method_3144()) {
                return;
            }
            event.setVelocity(this.fix(this.fixRotation, event.getMovementInput(), event.getSpeed()));
        }
    }

    public void modifyVelocity(EventPlayerTravel e) {
        if (ModuleManager.aura.isEnabled() && Aura.target != null && ModuleManager.aura.rotationMode.not(Aura.Mode.None) && ModuleManager.aura.elytraTarget.getValue().booleanValue() && Managers.PLAYER.ticksElytraFlying > 5) {
            if (e.isPre()) {
                this.prevYaw = Rotations.mc.field_1724.method_36454();
                this.prevPitch = Rotations.mc.field_1724.method_36455();
                Rotations.mc.field_1724.method_36456(this.fixRotation);
                Rotations.mc.field_1724.method_36457(ModuleManager.aura.rotationPitch);
            } else {
                Rotations.mc.field_1724.method_36456(this.prevYaw);
                Rotations.mc.field_1724.method_36457(this.prevPitch);
            }
            return;
        }
        if (Rotations.fullNullCheck()) {
            return;
        }
        if (this.moveFix.getValue() == MoveFix.Focused && !Float.isNaN(this.fixRotation) && !Rotations.mc.field_1724.method_3144()) {
            if (e.isPre()) {
                this.prevYaw = Rotations.mc.field_1724.method_36454();
                Rotations.mc.field_1724.method_36456(this.fixRotation);
            } else {
                Rotations.mc.field_1724.method_36456(this.prevYaw);
            }
        }
    }

    public void onKeyInput(EventKeyboardInput e) {
        if (this.moveFix.getValue() == MoveFix.Free) {
            if (Rotations.fullNullCheck() || Float.isNaN(this.fixRotation) || Rotations.mc.field_1724.method_3144()) {
                return;
            }
            float mF = Rotations.mc.field_1724.field_3913.field_3905;
            float mS = Rotations.mc.field_1724.field_3913.field_3907;
            float delta = (Rotations.mc.field_1724.method_36454() - this.fixRotation) * ((float)Math.PI / 180);
            float cos = class_3532.method_15362((float)delta);
            float sin = class_3532.method_15374((float)delta);
            Rotations.mc.field_1724.field_3913.field_3907 = Math.round(mS * cos - mF * sin);
            Rotations.mc.field_1724.field_3913.field_3905 = Math.round(mF * cos + mS * sin);
        }
    }

    private class_243 fix(float yaw, class_243 movementInput, float speed) {
        double d = movementInput.method_1027();
        if (d < 1.0E-7) {
            return class_243.field_1353;
        }
        class_243 vec3d = (d > 1.0 ? movementInput.method_1029() : movementInput).method_1021((double)speed);
        float f = class_3532.method_15374((float)(yaw * ((float)Math.PI / 180)));
        float g = class_3532.method_15362((float)(yaw * ((float)Math.PI / 180)));
        return new class_243(vec3d.field_1352 * (double)g - vec3d.field_1350 * (double)f, vec3d.field_1351, vec3d.field_1350 * (double)g + vec3d.field_1352 * (double)f);
    }

    private static enum MoveFix {
        Off,
        Focused,
        Free;

    }
}

