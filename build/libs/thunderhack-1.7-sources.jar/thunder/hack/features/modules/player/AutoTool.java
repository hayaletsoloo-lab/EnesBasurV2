/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.AirBlock
 *  net.minecraft.block.EnderChestBlock
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.math.BlockPos
 */
package thunder.hack.features.modules.player;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2189;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_3965;
import net.minecraft.class_6880;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class AutoTool
extends Module {
    public static Setting<Boolean> swapBack = new Setting<Boolean>("SwapBack", true);
    public static Setting<Boolean> saveItem = new Setting<Boolean>("SaveItem", true);
    public static Setting<Boolean> silent = new Setting<Boolean>("Silent", false);
    public static Setting<Boolean> echestSilk = new Setting<Boolean>("EchestSilk", true);
    public static int itemIndex;
    private boolean swap;
    private long swapDelay;
    private final List<Integer> lastItem = new ArrayList<Integer>();

    public AutoTool() {
        super("AutoTool", Module.Category.PLAYER);
    }

    @Override
    public void onUpdate() {
        if (!(AutoTool.mc.field_1765 instanceof class_3965)) {
            return;
        }
        class_3965 result = (class_3965)AutoTool.mc.field_1765;
        class_2338 pos = result.method_17777();
        if (AutoTool.mc.field_1687.method_8320(pos).method_26215()) {
            return;
        }
        if (AutoTool.getTool(pos) != -1 && AutoTool.mc.field_1690.field_1886.method_1434()) {
            this.lastItem.add(AutoTool.mc.field_1724.method_31548().field_7545);
            if (silent.getValue().booleanValue()) {
                AutoTool.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(AutoTool.getTool(pos)));
            } else {
                AutoTool.mc.field_1724.method_31548().field_7545 = AutoTool.getTool(pos);
            }
            itemIndex = AutoTool.getTool(pos);
            this.swap = true;
            this.swapDelay = System.currentTimeMillis();
        } else if (this.swap && !this.lastItem.isEmpty() && System.currentTimeMillis() >= this.swapDelay + 300L && swapBack.getValue().booleanValue()) {
            if (silent.getValue().booleanValue()) {
                AutoTool.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(this.lastItem.get(0).intValue()));
            } else {
                AutoTool.mc.field_1724.method_31548().field_7545 = this.lastItem.get(0);
            }
            itemIndex = this.lastItem.get(0);
            this.lastItem.clear();
            this.swap = false;
        }
    }

    public static int getTool(class_2338 pos) {
        int index = -1;
        float CurrentFastest = 1.0f;
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = AutoTool.mc.field_1724.method_31548().method_5438(i);
            if (stack == class_1799.field_8037 || AutoTool.mc.field_1724.method_31548().method_5438(i).method_7936() - AutoTool.mc.field_1724.method_31548().method_5438(i).method_7919() <= 10 && saveItem.getValue().booleanValue()) continue;
            float digSpeed = class_1890.method_8225((class_6880)((class_6880)AutoTool.mc.field_1687.method_30349().method_30530(class_1893.field_9131.method_58273()).method_40264(class_1893.field_9131).get()), (class_1799)stack);
            float destroySpeed = stack.method_7924(AutoTool.mc.field_1687.method_8320(pos));
            if (AutoTool.mc.field_1687.method_8320(pos).method_26204() instanceof class_2189) {
                return -1;
            }
            if (AutoTool.mc.field_1687.method_8320(pos).method_26204() instanceof class_2336 && echestSilk.getValue().booleanValue()) {
                if (class_1890.method_8225((class_6880)((class_6880)AutoTool.mc.field_1687.method_30349().method_30530(class_1893.field_9099.method_58273()).method_40264(class_1893.field_9099).get()), (class_1799)stack) <= 0 || !(digSpeed + destroySpeed > CurrentFastest)) continue;
                CurrentFastest = digSpeed + destroySpeed;
                index = i;
                continue;
            }
            if (!(digSpeed + destroySpeed > CurrentFastest)) continue;
            CurrentFastest = digSpeed + destroySpeed;
            index = i;
        }
        return index;
    }
}

