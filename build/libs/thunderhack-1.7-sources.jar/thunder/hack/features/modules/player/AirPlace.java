/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.item.BlockItem
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.HandSwingC2SPacket
 *  net.minecraft.util.Hand
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult
 *  net.minecraft.util.math.Box
 */
package thunder.hack.features.modules.player;

import java.awt.Color;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_2246;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2879;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.setting.impl.SettingGroup;
import thunder.hack.utility.render.Render3DEngine;

public class AirPlace
extends Module {
    private final Setting<Float> range = new Setting<Float>("Range", Float.valueOf(5.0f), Float.valueOf(0.0f), Float.valueOf(6.0f));
    private final Setting<SettingGroup> renderGroup = new Setting<SettingGroup>("Render", new SettingGroup(false, 0));
    private final Setting<Boolean> swing = new Setting<Boolean>("Swing", true).addToGroup(this.renderGroup);
    private final Setting<ColorSetting> fillColor = new Setting<ColorSetting>("Fill Color", new ColorSetting(new Color(100, 50, 255, 50))).addToGroup(this.renderGroup);
    private final Setting<ColorSetting> lineColor = new Setting<ColorSetting>("Line Color", new ColorSetting(new Color(100, 50, 255, 150))).addToGroup(this.renderGroup);
    private final Setting<Integer> lineWidth = new Setting<Integer>("Line Width", 2, 1, 5).addToGroup(this.renderGroup);
    private class_3965 hit;
    private int cooldown;

    public AirPlace() {
        super("AirPlace", Module.Category.PLAYER);
    }

    @Override
    public void onUpdate() {
        class_3965 bhr;
        class_239 hitResult;
        if (this.cooldown > 0) {
            --this.cooldown;
        }
        if (!((hitResult = mc.method_1560().method_5745((double)this.range.getValue().floatValue(), 0.0f, false)) instanceof class_3965)) {
            return;
        }
        this.hit = bhr = (class_3965)hitResult;
        boolean main = AirPlace.mc.field_1724.method_6047().method_7909() instanceof class_1747;
        boolean off = AirPlace.mc.field_1724.method_6079().method_7909() instanceof class_1747;
        if (AirPlace.mc.field_1690.field_1904.method_1434() && (main || off) && this.cooldown <= 0) {
            AirPlace.mc.field_1761.method_2896(AirPlace.mc.field_1724, main ? class_1268.field_5808 : class_1268.field_5810, this.hit);
            if (this.swing.getValue().booleanValue()) {
                AirPlace.mc.field_1724.method_6104(main ? class_1268.field_5808 : class_1268.field_5810);
            } else {
                this.sendPacket((class_2596<?>)new class_2879(main ? class_1268.field_5808 : class_1268.field_5810));
            }
            this.cooldown = ModuleManager.fastUse.isEnabled() && (ModuleManager.fastUse.blocks.getValue() != false || ModuleManager.fastUse.all.getValue() != false) ? 0 : 4;
        }
    }

    @Override
    public void onRender3D(class_4587 stack) {
        if (this.hit == null || !AirPlace.mc.field_1687.method_8320(this.hit.method_17777()).method_26204().equals(class_2246.field_10124) || !(AirPlace.mc.field_1724.method_6047().method_7909() instanceof class_1747) && !(AirPlace.mc.field_1724.method_6079().method_7909() instanceof class_1747)) {
            return;
        }
        Render3DEngine.FILLED_QUEUE.add(new Render3DEngine.FillAction(new class_238(this.hit.method_17777()), this.fillColor.getValue().getColorObject()));
        Render3DEngine.OUTLINE_QUEUE.add(new Render3DEngine.OutlineAction(new class_238(this.hit.method_17777()), this.lineColor.getValue().getColorObject(), this.lineWidth.getValue().intValue()));
    }
}

