/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.AirBlock
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockState
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.entity.attribute.EntityAttributes
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.Hand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Direction
 *  net.minecraft.world.BlockView
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.player;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Objects;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2815;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_4587;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.core.manager.player.PlayerManager;
import thunder.hack.events.impl.EventAttackBlock;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IInteractionManager;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.setting.impl.SettingGroup;
import thunder.hack.utility.Timer;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.PlayerUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public final class SpeedMine
extends Module {
    public final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Packet);
    public final Setting<Boolean> doubleMine = new Setting<Boolean>("DoubleMine", false);
    private final Setting<StartMode> startMode = new Setting<StartMode>("StartMode", StartMode.StartAbort, v -> this.mode.is(Mode.Packet) && this.doubleMine.getValue() == false);
    private final Setting<SwitchMode> switchMode = new Setting<SwitchMode>("SwitchMode", SwitchMode.Alternative, v -> this.mode.not(Mode.Damage));
    private final Setting<Integer> swapDelay = new Setting<Integer>("SwapDelay", 50, 0, 1000, v -> this.mode.getValue() != Mode.Damage);
    private final Setting<Float> factor = new Setting<Float>("Factor", Float.valueOf(1.0f), Float.valueOf(0.5f), Float.valueOf(2.0f), v -> this.mode.getValue() != Mode.Damage);
    private final Setting<Float> speed = new Setting<Float>("Speed", Float.valueOf(0.5f), Float.valueOf(0.0f), Float.valueOf(1.0f), v -> this.mode.getValue() == Mode.Damage);
    public final Setting<Float> range = new Setting<Float>("Range", Float.valueOf(4.2f), Float.valueOf(3.0f), Float.valueOf(10.0f), v -> this.mode.getValue() != Mode.Damage);
    private final Setting<Boolean> rotate = new Setting<Boolean>("Rotate", false, v -> this.mode.getValue() != Mode.Damage);
    private final Setting<Boolean> resetOnSwitch = new Setting<Boolean>("ResetOnSwitch", true, v -> this.mode.getValue() != Mode.Damage);
    private final Setting<Integer> breakAttempts = new Setting<Integer>("BreakAttempts", 10, 1, 50, v -> this.mode.getValue() == Mode.Packet);
    private final Setting<Boolean> pauseEat = new Setting<Boolean>("Pause On Eat", false);
    private final Setting<Boolean> clientRemove = new Setting<Boolean>("ClientRemove", true);
    private final Setting<SettingGroup> packets = new Setting<SettingGroup>("Packets", new SettingGroup(false, 0), v -> this.mode.is(Mode.Packet) && this.doubleMine.getValue() == false);
    private final Setting<Boolean> stop = new Setting<Boolean>("Stop", true, v -> this.mode.is(Mode.Packet) && this.doubleMine.getValue() == false).addToGroup(this.packets);
    private final Setting<Boolean> abort = new Setting<Boolean>("Abort", true, v -> this.mode.is(Mode.Packet) && this.doubleMine.getValue() == false).addToGroup(this.packets);
    private final Setting<Boolean> start = new Setting<Boolean>("Start", true, v -> this.mode.is(Mode.Packet) && this.doubleMine.getValue() == false).addToGroup(this.packets);
    private final Setting<Boolean> stop2 = new Setting<Boolean>("Stop2", true, v -> this.mode.is(Mode.Packet) && this.doubleMine.getValue() == false).addToGroup(this.packets);
    private final Setting<BooleanSettingGroup> render = new Setting<BooleanSettingGroup>("Render", new BooleanSettingGroup(false), v -> this.mode.getValue() != Mode.Damage);
    private final Setting<Boolean> smooth = new Setting<Boolean>("Smooth", true, v -> this.mode.getValue() != Mode.Damage).addToGroup(this.render);
    private final Setting<RenderMode> renderMode = new Setting<RenderMode>("Render Mode", RenderMode.Shrink, v -> this.mode.getValue() != Mode.Damage).addToGroup(this.render);
    private final Setting<ColorSetting> startLineColor = new Setting<ColorSetting>("Start Line Color", new ColorSetting(new Color(255, 0, 0, 200)), v -> this.mode.getValue() != Mode.Damage).addToGroup(this.render);
    private final Setting<ColorSetting> endLineColor = new Setting<ColorSetting>("End Line Color", new ColorSetting(new Color(47, 255, 0, 200)), v -> this.mode.getValue() != Mode.Damage).addToGroup(this.render);
    private final Setting<Integer> lineWidth = new Setting<Integer>("Line Width", 2, 1, 10, v -> this.mode.getValue() != Mode.Damage).addToGroup(this.render);
    private final Setting<ColorSetting> startFillColor = new Setting<ColorSetting>("Start Fill Color", new ColorSetting(new Color(255, 0, 0, 120)), v -> this.mode.getValue() != Mode.Damage).addToGroup(this.render);
    private final Setting<ColorSetting> endFillColor = new Setting<ColorSetting>("End Fill Color", new ColorSetting(new Color(47, 255, 0, 120)), v -> this.mode.getValue() != Mode.Damage).addToGroup(this.render);
    public ArrayList<MineAction> actions = new ArrayList();

    public SpeedMine() {
        super("SpeedMine", Module.Category.PLAYER);
    }

    @Override
    public void onDisable() {
        this.actions.forEach(MineAction::reset);
        this.actions.clear();
    }

    @Override
    public void onEnable() {
        this.actions.forEach(MineAction::reset);
        this.actions.clear();
    }

    @Override
    public void onUpdate() {
        if (SpeedMine.fullNullCheck() || SpeedMine.mc.field_1724.method_31549().field_7477) {
            return;
        }
        if (PlayerUtility.isEating() && this.pauseEat.getValue().booleanValue()) {
            return;
        }
        if (this.mode.getValue() == Mode.Damage && ((IInteractionManager)SpeedMine.mc.field_1761).getCurBlockDamageMP() < this.speed.getValue().floatValue()) {
            ((IInteractionManager)SpeedMine.mc.field_1761).setCurBlockDamageMP(this.speed.getValue().floatValue());
        }
        this.actions.removeIf(MineAction::update);
    }

    @Override
    public void onRender3D(class_4587 stack) {
        if (this.mode.is(Mode.Damage) || SpeedMine.mc.field_1687 == null) {
            return;
        }
        this.actions.forEach(a -> {
            if (!SpeedMine.mc.field_1687.method_22347(a.getPos())) {
                float noom = (float)MathUtility.clamp(Render2DEngine.interpolate(a.getPrevProgress(), a.getProgress(), Render3DEngine.getTickDelta()), 0.0, 1.0);
                class_238 renderBox = switch (this.renderMode.getValue().ordinal()) {
                    default -> throw new MatchException(null, null);
                    case 0 -> new class_238(a.getPos());
                    case 2 -> new class_238((double)a.getPos().method_10263(), (double)a.getPos().method_10264(), (double)a.getPos().method_10260(), (double)(a.getPos().method_10263() + 1), (double)((float)a.getPos().method_10264() + noom), (double)(a.getPos().method_10260() + 1));
                    case 1 -> new class_238((double)a.getPos().method_10263(), (double)a.getPos().method_10264(), (double)a.getPos().method_10260(), (double)a.getPos().method_10263(), (double)a.getPos().method_10264(), (double)a.getPos().method_10260()).method_1002((double)noom, (double)noom, (double)noom).method_989(0.5 + (double)noom * 0.5, 0.5 + (double)noom * 0.5, 0.5 + (double)noom * 0.5);
                };
                Render3DEngine.FILLED_QUEUE.add(new Render3DEngine.FillAction(renderBox, Render2DEngine.getColor(this.startFillColor.getValue().getColorObject(), this.endFillColor.getValue().getColorObject(), a.getProgress(), this.smooth.getValue())));
                Render3DEngine.OUTLINE_QUEUE.add(new Render3DEngine.OutlineAction(renderBox, Render2DEngine.getColor(this.startLineColor.getValue().getColorObject(), this.endLineColor.getValue().getColorObject(), a.getProgress(), this.smooth.getValue()), this.lineWidth.getValue().intValue()));
            }
        });
    }

    @EventHandler
    public void onAttackBlock(@NotNull EventAttackBlock event) {
        if (SpeedMine.fullNullCheck() || !this.canBreak(event.getBlockPos()) || SpeedMine.mc.field_1724.method_31549().field_7477 || this.mode.is(Mode.Damage)) {
            return;
        }
        if (!this.alreadyActing(event.getBlockPos())) {
            if (!(this.doubleMine.getValue().booleanValue() && this.actions.size() < 2 || this.actions.isEmpty())) {
                this.actions.removeFirst().cancel();
            }
            this.actions.add(new MineAction(event.getBlockPos(), event.getEnumFacing()));
        }
        event.cancel();
    }

    public boolean alreadyActing(class_2338 blockPos) {
        return this.actions.stream().anyMatch(a -> a.pos.equals(blockPos));
    }

    @EventHandler(priority=-100)
    private void onSync(EventSync event) {
        this.actions.forEach(MineAction::onSync);
    }

    @EventHandler
    private void onPacketSend(@NotNull PacketEvent.SendPost e) {
        if (e.getPacket() instanceof class_2868 && this.resetOnSwitch.getValue().booleanValue() && !this.switchMode.is(SwitchMode.Silent) && !this.mode.is(Mode.GrimInstant)) {
            this.actions.forEach(MineAction::reset);
        }
    }

    private void closeScreen() {
        if (SpeedMine.mc.field_1724 == null) {
            return;
        }
        this.sendPacket((class_2596<?>)new class_2815(SpeedMine.mc.field_1724.field_7512.field_7763));
    }

    public float getBlockStrength(@NotNull class_2680 state, class_2338 position) {
        if (state == class_2246.field_10124.method_9564()) {
            return 0.02f;
        }
        float hardness = state.method_26214((class_1922)SpeedMine.mc.field_1687, position);
        if (hardness < 0.0f) {
            return 0.0f;
        }
        return this.getDigSpeed(state, position) / hardness / (this.canBreak(position) ? 30.0f : 100.0f);
    }

    private float getDestroySpeed(class_2338 position, class_2680 state) {
        float destroySpeed = 1.0f;
        int slot = this.getTool(position);
        if (SpeedMine.mc.field_1724 == null) {
            return 0.0f;
        }
        if (slot != -1 && SpeedMine.mc.field_1724.method_31548().method_5438(slot) != null && !SpeedMine.mc.field_1724.method_31548().method_5438(slot).method_7960()) {
            destroySpeed *= SpeedMine.mc.field_1724.method_31548().method_5438(slot).method_7924(state);
        }
        return destroySpeed;
    }

    public float getDigSpeed(class_2680 state, class_2338 position) {
        int slot;
        if (SpeedMine.mc.field_1724 == null) {
            return 0.0f;
        }
        float digSpeed = this.getDestroySpeed(position, state);
        if (digSpeed > 1.0f && (slot = this.getTool(position)) != -1) {
            class_1799 itemstack = SpeedMine.mc.field_1724.method_31548().method_5438(slot);
            int efficiencyModifier = class_1890.method_8225((class_6880)((class_6880)SpeedMine.mc.field_1687.method_30349().method_30530(class_1893.field_9131.method_58273()).method_40264(class_1893.field_9131).get()), (class_1799)itemstack);
            if (efficiencyModifier > 0 && !itemstack.method_7960()) {
                digSpeed += (float)(StrictMath.pow(efficiencyModifier, 2.0) + 1.0);
            }
        }
        if (SpeedMine.mc.field_1724.method_6059(class_1294.field_5917)) {
            digSpeed *= 1.0f + (float)(Objects.requireNonNull(SpeedMine.mc.field_1724.method_6112(class_1294.field_5917)).method_5578() + 1) * 0.2f;
        }
        if (SpeedMine.mc.field_1724.method_6059(class_1294.field_5901)) {
            digSpeed *= (float)Math.pow(0.3f, Objects.requireNonNull(SpeedMine.mc.field_1724.method_6112(class_1294.field_5901)).method_5578() + 1);
        }
        if (SpeedMine.mc.field_1724.method_5869()) {
            digSpeed *= (float)SpeedMine.mc.field_1724.method_5996(class_5134.field_51576).method_6194();
        }
        if (!SpeedMine.mc.field_1724.method_24828() && ModuleManager.freeCam.isDisabled()) {
            digSpeed /= 5.0f;
        }
        return digSpeed < 0.0f ? 0.0f : digSpeed * this.factor.getValue().floatValue();
    }

    public int getTool(class_2338 pos) {
        int index = -1;
        float currentFastest = 1.0f;
        if (SpeedMine.mc.field_1687 == null || SpeedMine.mc.field_1724 == null || SpeedMine.mc.field_1687.method_8320(pos).method_26204() instanceof class_2189) {
            return -1;
        }
        for (int i = 9; i < 45; ++i) {
            float destroySpeed;
            float digSpeed;
            class_1799 stack = SpeedMine.mc.field_1724.method_31548().method_5438(i >= 36 ? i - 36 : i);
            if (stack == class_1799.field_8037 || stack.method_7936() - stack.method_7919() <= 10 || !((digSpeed = (float)class_1890.method_8225((class_6880)((class_6880)SpeedMine.mc.field_1687.method_30349().method_30530(class_1893.field_9111.method_58273()).method_40264(class_1893.field_9131).get()), (class_1799)stack)) + (destroySpeed = stack.method_7924(SpeedMine.mc.field_1687.method_8320(pos))) > currentFastest)) continue;
            currentFastest = digSpeed + destroySpeed;
            index = i;
        }
        return index >= 36 ? index - 36 : index;
    }

    private boolean canBreak(class_2338 pos) {
        if (SpeedMine.mc.field_1687 == null || PlayerUtility.squaredDistanceFromEyes(pos.method_46558()) > this.range.getPow2Value()) {
            return false;
        }
        class_2680 blockState = SpeedMine.mc.field_1687.method_8320(pos);
        class_2248 block = blockState.method_26204();
        return block.method_36555() != -1.0f;
    }

    public void placeCrystal() {
    }

    public Object getCevData() {
        return null;
    }

    public Object getBestData() {
        return null;
    }

    public boolean isBlockDrop(class_1297 ent) {
        if (ent instanceof class_1542 && this.isOn() && ent.field_6012 < 3) {
            for (MineAction a : this.actions) {
                if (!(a.getPos().method_46558().method_1025(ent.method_19538()) <= 1.0)) continue;
                return true;
            }
        }
        return false;
    }

    public static enum Mode {
        Packet,
        GrimInstant,
        Damage;

    }

    public static enum StartMode {
        StartAbort,
        StartStop;

    }

    public static enum SwitchMode {
        Silent,
        Normal,
        Alternative;

    }

    public static enum RenderMode {
        Block,
        Shrink,
        Grow;

    }

    public class MineAction {
        @NotNull
        private final class_2338 pos;
        private float progress;
        private float prevProgress;
        private int mineBreaks;
        private final Timer attackTimer = new Timer();

        public MineAction(class_2338 pos, class_2350 direction) {
            this.pos = pos;
            this.progress = 0.0f;
            this.mineBreaks = 0;
            this.start(direction);
        }

        public void start(class_2350 direction) {
            class_2350 startDirection = direction == null ? Module.mc.field_1724.method_5735() : direction;
            class_2350 class_23502 = startDirection;
            if (startDirection != null) {
                if (SpeedMine.this.doubleMine.getValue().booleanValue()) {
                    SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, this.pos, startDirection));
                    SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12968, this.pos, startDirection));
                    SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, this.pos, startDirection));
                } else {
                    SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12968, this.pos, startDirection));
                    SpeedMine.this.sendPacket((class_2596)new class_2846(SpeedMine.this.startMode.getValue() == StartMode.StartAbort ? class_2846.class_2847.field_12971 : class_2846.class_2847.field_12973, this.pos, startDirection));
                }
            }
        }

        public boolean update() {
            class_2350 dir = InteractionUtility.getStrictDirections(this.pos).stream().findFirst().orElse(Module.mc.field_1724.method_5735());
            if (this.mineBreaks >= SpeedMine.this.breakAttempts.getValue() && SpeedMine.this.mode.not(Mode.GrimInstant)) {
                return true;
            }
            if (PlayerUtility.squaredDistanceFromEyes(this.pos.method_46558()) > SpeedMine.this.range.getPow2Value()) {
                this.cancel();
                return true;
            }
            if (Module.mc.field_1687.method_22347(this.pos)) {
                this.progress = 0.0f;
                this.prevProgress = -1.0f;
                return false;
            }
            if (this.progress == 0.0f && this.prevProgress == -1.0f && SpeedMine.this.mode.is(Mode.Packet) && this.attackTimer.every(800L)) {
                this.start(dir);
                Module.mc.field_1724.method_6104(class_1268.field_5808);
            }
            int pickSlot = SpeedMine.this.getTool(this.pos);
            int prevSlot = Module.mc.field_1724.method_31548().field_7545;
            if (pickSlot == -1) {
                return false;
            }
            boolean instant = this.mineBreaks > 0 && SpeedMine.this.mode.is(Mode.GrimInstant);
            boolean bl = instant;
            if (this.progress >= 1.0f || instant) {
                this.switchTo(pickSlot, -1);
                if (SpeedMine.this.mode.getValue() == Mode.GrimInstant || SpeedMine.this.doubleMine.getValue().booleanValue()) {
                    SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, this.pos, dir));
                } else {
                    if (SpeedMine.this.stop.getValue().booleanValue()) {
                        SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, this.pos, dir));
                    }
                    if (SpeedMine.this.abort.getValue().booleanValue()) {
                        SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12971, this.pos, dir));
                    }
                    if (SpeedMine.this.start.getValue().booleanValue()) {
                        SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12968, this.pos, dir));
                    }
                    if (SpeedMine.this.stop2.getValue().booleanValue()) {
                        SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, this.pos, dir));
                    }
                }
                if (SpeedMine.this.clientRemove.getValue().booleanValue()) {
                    Module.mc.field_1761.method_2899(this.pos);
                }
                int delay = SpeedMine.this.doubleMine.getValue() != false ? 100 : SpeedMine.this.swapDelay.getValue();
                int n = delay;
                if (delay != 0) {
                    Managers.ASYNC.run(() -> this.switchTo(prevSlot, pickSlot), delay);
                } else {
                    this.switchTo(prevSlot, pickSlot);
                }
                ++this.mineBreaks;
                this.prevProgress = 0.0f;
                this.progress = 0.0f;
                if (SpeedMine.this.doubleMine.getValue().booleanValue() && SpeedMine.this.mode.is(Mode.GrimInstant) && SpeedMine.this.actions.size() >= 2) {
                    return true;
                }
            } else {
                this.prevProgress = this.progress;
                this.progress += SpeedMine.this.getBlockStrength(Module.mc.field_1687.method_8320(this.pos), this.pos);
            }
            this.fixMovement();
            return false;
        }

        private void switchTo(int slot, int from) {
            if (SpeedMine.this.switchMode.getValue() == SwitchMode.Alternative || slot >= 9) {
                if (from == -1) {
                    Module.clickSlot(slot < 9 ? slot + 36 : slot, Module.mc.field_1724.method_31548().field_7545, class_1713.field_7791);
                } else {
                    Module.clickSlot(from < 9 ? from + 36 : from, Module.mc.field_1724.method_31548().field_7545, class_1713.field_7791);
                }
                SpeedMine.this.closeScreen();
            } else if (SpeedMine.this.switchMode.is(SwitchMode.Silent)) {
                InventoryUtility.switchToSilent(slot);
            } else {
                InventoryUtility.switchTo(slot);
            }
        }

        public void fixMovement() {
            if (SpeedMine.this.rotate.getValue().booleanValue() && (double)this.progress > 0.95) {
                ModuleManager.rotations.fixRotation = PlayerManager.calcAngle(Module.mc.field_1724.method_33571(), this.pos.method_46558())[0];
            }
        }

        public class_2338 getPos() {
            return this.pos;
        }

        public float getPrevProgress() {
            return this.prevProgress;
        }

        public float getProgress() {
            return this.progress;
        }

        public void onSync() {
            if (SpeedMine.this.rotate.getValue().booleanValue() && (double)this.progress > 0.95) {
                float[] angle = PlayerManager.calcAngle(Module.mc.field_1724.method_33571(), this.pos.method_46558().method_1031(0.0, -0.25, 0.0));
                Module.mc.field_1724.method_36456(angle[0]);
                Module.mc.field_1724.method_36457(angle[1]);
            }
        }

        public void reset() {
            if (this.progress == 0.0f) {
                return;
            }
            this.progress = 0.0f;
            this.prevProgress = 0.0f;
            class_2350 dir = InteractionUtility.getStrictDirections(this.pos).stream().findFirst().orElse(Module.mc.field_1724.method_5735());
            SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12971, this.pos, dir));
            this.start(dir);
        }

        public void cancel() {
            if (this.progress != 0.0f) {
                SpeedMine.this.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12971, this.pos, class_2350.field_11033));
            }
        }

        public boolean instantBreaking() {
            return this.mineBreaks > 0 && SpeedMine.this.mode.is(Mode.GrimInstant);
        }
    }
}

