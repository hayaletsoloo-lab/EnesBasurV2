/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.Item
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.Hand
 */
package thunder.hack.features.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2815;
import net.minecraft.class_2886;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.Bind;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.SearchInvResult;

public class ElytraHelper
extends Module {
    private static ElytraHelper INSTANCE = new ElytraHelper();
    private final Setting<Bind> switchButton = new Setting<Bind>("SwitchButton", new Bind(-1, false, false));
    private final Setting<Bind> fireWorkButton = new Setting<Bind>("FireWorkButton", new Bind(-1, false, false));
    private final Setting<FireWorkMode> fireWorkMode = new Setting<FireWorkMode>("FireWorkMode", FireWorkMode.Normal);
    private final Setting<Boolean> autoFirework = new Setting<Boolean>("AutoFirework", false);
    private final Setting<Bind> legitFireworkKey = new Setting<Bind>("Legit Key", new Bind(-1, false, false), v -> this.fireWorkMode.getValue() == FireWorkMode.Legit);
    private final Setting<Boolean> slotReturn = new Setting<Boolean>("SlotReturn", true, v -> this.fireWorkMode.getValue() == FireWorkMode.Normal);
    private final Setting<Integer> delay = new Setting<Integer>("Delay", 100, 1, 1000, v -> this.fireWorkMode.getValue() == FireWorkMode.Normal && this.slotReturn.getValue() != false || this.autoFirework.getValue() != false);
    private final Setting<Boolean> swing = new Setting<Boolean>("Swing", true);
    private final Timer switchTimer = new Timer();
    private final Timer fireworkTimer = new Timer();
    private final Timer returnTimer = new Timer();
    private int returnSlot = -1;
    private int returnInvSlot = -1;
    public static boolean swapping = false;

    public static ElytraHelper getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ElytraHelper();
        }
        return INSTANCE;
    }

    public ElytraHelper() {
        super("ElytraHelper", Module.Category.PLAYER);
        INSTANCE = this;
    }

    @Override
    public void onUpdate() {
        if (ElytraHelper.mc.field_1724 == null || ElytraHelper.mc.field_1687 == null) {
            return;
        }
        if (ElytraHelper.mc.field_1755 == null) {
            if (this.switchButton.getValue().getKey() != -1 && this.isKeyPressed(this.switchButton.getValue().getKey())) {
                this.swapChest(false);
            }
            if (this.fireWorkButton.getValue().getKey() != -1 && this.isKeyPressed(this.fireWorkButton.getValue().getKey()) && ElytraHelper.mc.field_1724.method_6128()) {
                this.useFireWork();
            }
            if (this.legitFireworkKey.getValue().getKey() != -1 && this.isKeyPressed(this.legitFireworkKey.getValue().getKey()) && ElytraHelper.mc.field_1724.method_6128()) {
                this.useFireWork();
            }
        }
        if (this.autoFirework.getValue().booleanValue() && ElytraHelper.mc.field_1724.method_6128() && ElytraHelper.mc.field_1755 == null) {
            float tps = Managers.SERVER.getTPS();
            float tpsFactor = 20.0f / (tps <= 0.0f ? 20.0f : tps);
            long syncedDelay = (long)((float)this.delay.getValue().intValue() * tpsFactor);
            if (this.fireworkTimer.passedMs(syncedDelay)) {
                this.useFireWork();
                this.fireworkTimer.reset();
            }
        }
        if (this.returnSlot != -1 && this.returnTimer.passedMs(this.delay.getValue().intValue())) {
            if (this.returnInvSlot != -1) {
                ElytraHelper.mc.field_1761.method_2906(ElytraHelper.mc.field_1724.field_7512.field_7763, this.returnInvSlot, ElytraHelper.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)ElytraHelper.mc.field_1724);
                this.sendPacket((class_2596<?>)new class_2815(ElytraHelper.mc.field_1724.field_7512.field_7763));
                this.returnInvSlot = -1;
            }
            this.returnSlot = -1;
        }
    }

    public void useFireWork() {
        SearchInvResult fireWorkResult = InventoryUtility.findItemInInventory(class_1802.field_8639);
        if (!fireWorkResult.found()) {
            this.sendMessage(ClientSettings.isRu() ? "\u0423 \u0442\u0435\u0431\u044f \u043d\u0435\u0442 \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a\u043e\u0432!" : "You've got no fireworks!");
            return;
        }
        if (this.fireWorkMode.getValue() == FireWorkMode.Legit) {
            int currentSlot = ElytraHelper.mc.field_1724.method_31548().field_7545;
            int fireworkSlot = fireWorkResult.slot();
            if (fireworkSlot == currentSlot + 36) {
                ElytraHelper.mc.field_1761.method_2919((class_1657)ElytraHelper.mc.field_1724, class_1268.field_5808);
                if (this.swing.getValue().booleanValue()) {
                    ElytraHelper.mc.field_1724.method_6104(class_1268.field_5808);
                }
                return;
            }
            ElytraHelper.mc.field_1761.method_2906(ElytraHelper.mc.field_1724.field_7512.field_7763, fireworkSlot, currentSlot, class_1713.field_7791, (class_1657)ElytraHelper.mc.field_1724);
            InteractionUtility.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, ElytraHelper.mc.field_1724.method_36454(), ElytraHelper.mc.field_1724.method_36455()));
            if (this.swing.getValue().booleanValue()) {
                ElytraHelper.mc.field_1724.method_6104(class_1268.field_5808);
            }
            ElytraHelper.mc.field_1761.method_2906(ElytraHelper.mc.field_1724.field_7512.field_7763, fireworkSlot, currentSlot, class_1713.field_7791, (class_1657)ElytraHelper.mc.field_1724);
            return;
        }
        SearchInvResult hotbarFireWorkResult = InventoryUtility.findItemInHotBar(class_1802.field_8639);
        if (this.fireWorkMode.getValue() == FireWorkMode.Normal && this.slotReturn.getValue().booleanValue()) {
            this.returnSlot = ElytraHelper.mc.field_1724.method_31548().field_7545;
            this.returnInvSlot = hotbarFireWorkResult.found() ? -1 : (fireWorkResult.found() ? fireWorkResult.slot() : -1);
            this.returnTimer.reset();
        }
        InventoryUtility.saveSlot();
        if (hotbarFireWorkResult.found()) {
            hotbarFireWorkResult.switchTo();
        } else {
            ElytraHelper.mc.field_1761.method_2906(ElytraHelper.mc.field_1724.field_7512.field_7763, fireWorkResult.slot(), ElytraHelper.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)ElytraHelper.mc.field_1724);
            this.sendPacket((class_2596<?>)new class_2815(ElytraHelper.mc.field_1724.field_7512.field_7763));
        }
        ElytraHelper.mc.field_1761.method_2919((class_1657)ElytraHelper.mc.field_1724, class_1268.field_5808);
        if (this.swing.getValue().booleanValue()) {
            ElytraHelper.mc.field_1724.method_6104(class_1268.field_5808);
        }
        if (this.fireWorkMode.getValue() == FireWorkMode.Silent) {
            InventoryUtility.returnSlot();
            if (!hotbarFireWorkResult.found()) {
                ElytraHelper.mc.field_1761.method_2906(ElytraHelper.mc.field_1724.field_7512.field_7763, fireWorkResult.slot(), ElytraHelper.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)ElytraHelper.mc.field_1724);
                this.sendPacket((class_2596<?>)new class_2815(ElytraHelper.mc.field_1724.field_7512.field_7763));
            }
        }
    }

    public static int getChestPlateSlot() {
        class_1792[] items = new class_1792[]{class_1802.field_22028, class_1802.field_8058, class_1802.field_8873, class_1802.field_8523, class_1802.field_8678, class_1802.field_8577};
        class_1792[] var1 = items;
        int var2 = items.length;
        for (int var3 = 0; var3 < var2; ++var3) {
            class_1792 item = var1[var3];
            SearchInvResult slot = InventoryUtility.findItemInInventory(item);
            if (!slot.found()) continue;
            return slot.slot();
        }
        return -1;
    }

    private void swapChest(boolean disable) {
        SearchInvResult result = InventoryUtility.findItemInInventory(class_1802.field_8833);
        if (ElytraHelper.mc.field_1724.method_31548().method_5438(38).method_7909() == class_1802.field_8833) {
            int slot = ElytraHelper.getChestPlateSlot();
            if (slot == -1) {
                if (disable) {
                    this.disable(ClientSettings.isRu() ? "\u0423 \u0442\u0435\u0431\u044f \u043d\u0435\u0442 \u043d\u0430\u0433\u0440\u0443\u0434\u043d\u0438\u043a\u0430!" : "You don't have keyCodec chestplate!");
                } else {
                    this.sendMessage(ClientSettings.isRu() ? "\u0423 \u0442\u0435\u0431\u044f \u043d\u0435\u0442 \u043d\u0430\u0433\u0440\u0443\u0434\u043d\u0438\u043a\u0430!" : "You don't have keyCodec chestplate!");
                }
                return;
            }
            ElytraHelper.clickSlot(slot);
            ElytraHelper.clickSlot(6);
            ElytraHelper.clickSlot(slot);
            this.sendPacket((class_2596<?>)new class_2815(ElytraHelper.mc.field_1724.field_7512.field_7763));
        } else {
            if (!result.found()) {
                if (disable) {
                    this.disable(ClientSettings.isRu() ? "\u0423 \u0442\u0435\u0431\u044f \u043d\u0435\u0442 \u044d\u043b\u0438\u0442\u0440\u044b!" : "You don't have an elytra!");
                } else {
                    this.sendMessage(ClientSettings.isRu() ? "\u0423 \u0442\u0435\u0431\u044f \u043d\u0435\u0442 \u044d\u043b\u0438\u0442\u0440\u044b!" : "You don't have an elytra!");
                }
                return;
            }
            ElytraHelper.clickSlot(result.slot());
            ElytraHelper.clickSlot(6);
            ElytraHelper.clickSlot(result.slot());
            this.sendPacket((class_2596<?>)new class_2815(ElytraHelper.mc.field_1724.field_7512.field_7763));
        }
        if (disable) {
            this.disable(ClientSettings.isRu() ? "\u0421\u0432\u0430\u043f\u043d\u0443\u043b! \u041e\u0442\u043a\u043b\u044e\u0447\u0430\u044e.." : "Swapped! Disabling..");
        }
    }

    public String getFireWorkMode() {
        return this.fireWorkMode.getValue().name();
    }

    public boolean isSwingEnabled() {
        return this.swing.getValue();
    }

    public static enum FireWorkMode {
        Silent,
        Normal,
        Legit;

    }
}

