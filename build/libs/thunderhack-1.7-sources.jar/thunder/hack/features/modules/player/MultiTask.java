/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.Hand
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.EntityHitResult
 *  net.minecraft.util.hit.HitResult
 */
package thunder.hack.features.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import thunder.hack.features.modules.Module;

public class MultiTask
extends Module {
    public MultiTask() {
        super("MultiTask", Module.Category.PLAYER);
    }

    @Override
    public void onUpdate() {
        class_3966 ehr;
        class_3965 crossHair;
        class_239 ItemStackParticleEffect = MultiTask.mc.field_1765;
        if (ItemStackParticleEffect instanceof class_3965 && (crossHair = (class_3965)ItemStackParticleEffect).method_17777() != null && MultiTask.mc.field_1690.field_1886.method_1434() && !MultiTask.mc.field_1687.method_8320(crossHair.method_17777()).method_26215()) {
            MultiTask.mc.field_1761.method_2910(crossHair.method_17777(), crossHair.method_17780());
            MultiTask.mc.field_1724.method_6104(class_1268.field_5808);
        }
        if ((ItemStackParticleEffect = MultiTask.mc.field_1765) instanceof class_3966 && (ehr = (class_3966)ItemStackParticleEffect).method_17782() != null && MultiTask.mc.field_1690.field_1886.method_1434() && MultiTask.mc.field_1724.method_7261(0.5f) > 0.9f) {
            MultiTask.mc.field_1761.method_2918((class_1657)MultiTask.mc.field_1724, ehr.method_17782());
            MultiTask.mc.field_1724.method_6104(class_1268.field_5808);
        }
    }
}

