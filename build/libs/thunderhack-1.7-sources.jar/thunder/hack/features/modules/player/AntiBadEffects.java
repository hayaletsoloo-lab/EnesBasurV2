/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.effect.StatusEffects
 */
package thunder.hack.features.modules.player;

import net.minecraft.class_1294;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class AntiBadEffects
extends Module {
    private final Setting<Boolean> blindness = new Setting<Boolean>("Blindness", true);
    private final Setting<Boolean> nausea = new Setting<Boolean>("Nausea", true);
    private final Setting<Boolean> miningFatigue = new Setting<Boolean>("MiningFatigue", true);
    private final Setting<Boolean> levitation = new Setting<Boolean>("Levitation", true);
    private final Setting<Boolean> slowness = new Setting<Boolean>("Slowness", true);
    private final Setting<Boolean> jumpBoost = new Setting<Boolean>("JumpBoost", true);

    public AntiBadEffects() {
        super("AntiBadEffects", Module.Category.PLAYER);
    }

    @Override
    public void onUpdate() {
        if (AntiBadEffects.mc.field_1724.method_6059(class_1294.field_5919) && this.blindness.getValue().booleanValue()) {
            AntiBadEffects.mc.field_1724.method_6016(class_1294.field_5919);
        }
        if (AntiBadEffects.mc.field_1724.method_6059(class_1294.field_5916) && this.nausea.getValue().booleanValue()) {
            AntiBadEffects.mc.field_1724.method_6016(class_1294.field_5916);
        }
        if (AntiBadEffects.mc.field_1724.method_6059(class_1294.field_5901) && this.miningFatigue.getValue().booleanValue()) {
            AntiBadEffects.mc.field_1724.method_6016(class_1294.field_5901);
        }
        if (AntiBadEffects.mc.field_1724.method_6059(class_1294.field_5902) && this.levitation.getValue().booleanValue()) {
            AntiBadEffects.mc.field_1724.method_6016(class_1294.field_5902);
        }
        if (AntiBadEffects.mc.field_1724.method_6059(class_1294.field_5909) && this.slowness.getValue().booleanValue()) {
            AntiBadEffects.mc.field_1724.method_6016(class_1294.field_5909);
        }
        if (AntiBadEffects.mc.field_1724.method_6059(class_1294.field_5913) && this.jumpBoost.getValue().booleanValue()) {
            AntiBadEffects.mc.field_1724.method_6016(class_1294.field_5913);
        }
    }
}

