/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.Vec3d
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package thunder.hack.features.modules.base;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import thunder.hack.events.impl.EventPostSync;
import thunder.hack.events.impl.EventSync;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.base.PlaceModule;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.world.HoleUtility;

public abstract class TrapModule
extends PlaceModule {
    protected final Setting<PlaceTiming> placeTiming = new Setting<PlaceTiming>("Place Timing", PlaceTiming.Default);
    protected final Setting<Integer> blocksPerTick = new Setting<Integer>("Block/Tick", 8, 1, 12, v -> this.placeTiming.getValue() == PlaceTiming.Default);
    protected final Setting<Integer> placeDelay = new Setting<Integer>("Delay/Place", 3, 0, 10);
    protected final Setting<TrapMode> trapMode = new Setting<TrapMode>("Trap Mode", TrapMode.Full);
    private int delay;
    protected class_1657 target;
    private final ArrayList<class_2338> sequentialBlocks = new ArrayList();

    public TrapModule(@NotNull String name, @NotNull Module.Category category) {
        super(name, category);
    }

    protected abstract boolean needNewTarget();

    @Nullable
    protected abstract class_1657 getTarget();

    @Override
    public void onDisable() {
        this.target = null;
        this.delay = 0;
        this.sequentialBlocks.clear();
    }

    @EventHandler
    private void onSync(EventSync event) {
        class_3965 result;
        class_2338 targetBlock;
        if (this.needNewTarget()) {
            this.target = this.getTarget();
            return;
        }
        if (this.placeTiming.getValue() == PlaceTiming.Vanilla && !this.rotate.is(InteractionUtility.Rotate.None) && (targetBlock = this.getBlockToPlace()) != null && TrapModule.mc.field_1724 != null && (result = InteractionUtility.getPlaceResult(targetBlock, (InteractionUtility.Interact)((Object)this.interact.getValue()), false)) != null) {
            float[] angle = InteractionUtility.calculateAngle(result.method_17784());
            TrapModule.mc.field_1724.method_36456(angle[0]);
            TrapModule.mc.field_1724.method_36457(angle[1]);
        }
    }

    @EventHandler
    private void onPostSync(EventPostSync event) {
        class_2338 targetBlock;
        if (this.delay > 0) {
            --this.delay;
            return;
        }
        InteractionUtility.Rotate rotateMod = this.placeTiming.is(PlaceTiming.Vanilla) && !this.rotate.is(InteractionUtility.Rotate.None) ? InteractionUtility.Rotate.None : (InteractionUtility.Rotate)((Object)this.rotate.getValue());
        InteractionUtility.Rotate rotate = rotateMod;
        if (this.placeTiming.getValue() == PlaceTiming.Default) {
            class_2338 targetBlock2;
            for (int placed = 0; placed < this.blocksPerTick.getValue() && (targetBlock2 = this.getBlockToPlace()) != null && this.placeBlock(targetBlock2, rotateMod); ++placed) {
                this.delay = this.placeDelay.getValue();
                this.inactivityTimer.reset();
            }
        } else if (this.placeTiming.getValue() == PlaceTiming.Vanilla && (targetBlock = this.getBlockToPlace()) != null && this.placeBlock(targetBlock, rotateMod)) {
            this.sequentialBlocks.add(targetBlock);
            this.delay = this.placeDelay.getValue();
            this.inactivityTimer.reset();
        }
    }

    @Nullable
    protected class_2338 getBlockToPlace() {
        if (this.target == null || TrapModule.mc.field_1724 == null) {
            return null;
        }
        return this.getBlocks(this.target).stream().filter(pos -> pos.method_19770((class_2374)TrapModule.mc.field_1724.method_19538()) < (double)this.range.getPow2Value()).filter(pos -> InteractionUtility.canPlaceBlock(pos, (InteractionUtility.Interact)(((Object)this.interact.getValue())), true)).max(Comparator.comparing(pos -> TrapModule.mc.field_1724.method_5707(pos.method_46558()))).orElse(null);
    }

    protected List<class_2338> getBlocks(@NotNull class_1657 player) {
        class_243 playerPos = player.method_19538();
        ArrayList<class_2338> offsets = new ArrayList<class_2338>();
        List<class_2338> holePoses = HoleUtility.getHolePoses(playerPos);
        List<class_2338> surroundPoses = HoleUtility.getSurroundPoses(playerPos);
        if (TrapModule.mc.field_1724 == null || TrapModule.mc.field_1687 == null) {
            return offsets;
        }
        switch (this.trapMode.getValue().ordinal()) {
            case 0: {
                offsets.addAll(holePoses.stream().map(class_2338::method_10074).toList());
                if (this.interact.getValue() != InteractionUtility.Interact.AirPlace) {
                    offsets.addAll(this.addHelpOffsets(surroundPoses));
                }
                offsets.addAll(surroundPoses);
                offsets.addAll(surroundPoses.stream().map(class_2338::method_10084).toList());
                if (this.interact.getValue() != InteractionUtility.Interact.AirPlace) {
                    surroundPoses.stream().map(pos -> pos.method_10086(2)).filter(pos -> pos.method_19770((class_2374)TrapModule.mc.field_1724.method_19538()) < (double)this.range.getPow2Value()).max(Comparator.comparing(pos -> TrapModule.mc.field_1724.method_5707(pos.method_46558()))).ifPresent(pos -> {
                        offsets.add((class_2338)pos);
                        offsets.add(pos.method_10074());
                    });
                }
                offsets.addAll(holePoses.stream().map(pos -> pos.method_10086(2)).toList());
                break;
            }
            case 1: {
                offsets.addAll(holePoses.stream().map(class_2338::method_10074).toList());
                if (this.interact.getValue() != InteractionUtility.Interact.AirPlace) {
                    surroundPoses.stream().filter(pos -> pos.method_19770((class_2374)TrapModule.mc.field_1724.method_19538()) < (double)this.range.getPow2Value()).max(Comparator.comparing(pos -> player.method_5707(pos.method_46558()))).ifPresent(pos -> {
                        offsets.add((class_2338)pos);
                        offsets.add(pos.method_10084());
                        offsets.add(pos.method_10086(2));
                    });
                    offsets.addAll(this.addHelpOffsets(surroundPoses));
                }
                offsets.addAll(surroundPoses);
                offsets.addAll(holePoses.stream().map(pos -> pos.method_10086(2)).toList());
                break;
            }
            case 2: {
                offsets.addAll(holePoses.stream().map(class_2338::method_10074).toList());
                if (this.interact.getValue() != InteractionUtility.Interact.AirPlace) {
                    surroundPoses.stream().map(class_2338::method_10074).filter(pos -> pos.method_19770((class_2374)TrapModule.mc.field_1724.method_19538()) < (double)this.range.getPow2Value()).max(Comparator.comparing(pos -> player.method_5707(pos.method_46558()))).ifPresent(pos -> {
                        offsets.add((class_2338)pos);
                        offsets.add(pos.method_10084());
                        offsets.add(pos.method_10086(3));
                    });
                }
                offsets.addAll(surroundPoses.stream().map(class_2338::method_10084).toList());
                offsets.addAll(holePoses.stream().map(pos -> pos.method_10086(2)).toList());
            }
        }
        return offsets;
    }

    @NotNull
    private List<class_2338> addHelpOffsets(@NotNull List<class_2338> surroundPoses) {
        ArrayList<class_2338> helpOffsets = new ArrayList<class_2338>();
        if (TrapModule.mc.field_1687 == null || TrapModule.mc.field_1724 == null) {
            return helpOffsets;
        }
        surroundPoses.stream().map(class_2338::method_10074).filter(pos -> pos.method_19770((class_2374)TrapModule.mc.field_1724.method_19538()) < (double)this.range.getPow2Value()).filter(pos -> {
            for (class_2350 dir : class_2350.values()) {
                if (TrapModule.mc.field_1687.method_8320(pos.method_10081(dir.method_10163().method_30931())).method_45474()) continue;
                return false;
            }
            return true;
        }).forEach(helpOffsets::add);
        return helpOffsets;
    }

    protected static enum PlaceTiming {
        Default,
        Vanilla;

    }

    protected static enum TrapMode {
        Full,
        Legs,
        Head;

    }
}

