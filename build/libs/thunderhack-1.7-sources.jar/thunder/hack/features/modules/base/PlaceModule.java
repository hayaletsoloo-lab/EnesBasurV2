/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.Blocks
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.Entity$RemovalReason
 *  net.minecraft.entity.decoration.EndCrystalEntity
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.BlockItem
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.HandSwingC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket
 *  net.minecraft.util.Hand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.base;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import org.jetbrains.annotations.NotNull;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.setting.impl.SettingGroup;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.PlayerUtility;
import thunder.hack.utility.player.SearchInvResult;
import thunder.hack.utility.render.BlockAnimationUtility;

public abstract class PlaceModule
extends Module {
    protected final Setting<Float> range = new Setting<Float>("Range", Float.valueOf(5.0f), Float.valueOf(0.0f), Float.valueOf(7.0f));
    protected final Setting<InteractionUtility.Interact> interact = new Setting<InteractionUtility.Interact>("Interact", InteractionUtility.Interact.Strict);
    protected final Setting<InteractMode> placeMode = new Setting<InteractMode>("Place Mode", InteractMode.Normal);
    protected final Setting<InteractionUtility.Rotate> rotate = new Setting<InteractionUtility.Rotate>("Rotate", InteractionUtility.Rotate.None);
    protected final Setting<Boolean> swing = new Setting<Boolean>("Swing", false);
    protected final Setting<BooleanSettingGroup> crystalBreaker = new Setting<BooleanSettingGroup>("Crystal Breaker", new BooleanSettingGroup(false));
    protected final Setting<Integer> crystalAge = new Setting<Integer>("CrystalAge", 0, 0, 20).addToGroup(this.crystalBreaker);
    protected final Setting<Integer> breakDelay = new Setting<Integer>("Break Delay", 100, 1, 1000).addToGroup(this.crystalBreaker);
    protected final Setting<Boolean> remove = new Setting<Boolean>("Remove", false).addToGroup(this.crystalBreaker);
    protected final Setting<InteractMode> breakCrystalMode = new Setting<InteractMode>("Break Mode", InteractMode.Normal).addToGroup(this.crystalBreaker);
    protected final Setting<Boolean> antiWeakness = new Setting<Boolean>("Anti Weakness", false).addToGroup(this.crystalBreaker);
    protected final Setting<SettingGroup> blocks = new Setting<SettingGroup>("Blocks", new SettingGroup(false, 0));
    protected final Setting<Boolean> obsidian = new Setting<Boolean>("Obsidian", true).addToGroup(this.blocks);
    protected final Setting<Boolean> anchor = new Setting<Boolean>("Anchor", false).addToGroup(this.blocks);
    protected final Setting<Boolean> enderChest = new Setting<Boolean>("EnderChest", true).addToGroup(this.blocks);
    protected final Setting<Boolean> netherite = new Setting<Boolean>("Netherite", false).addToGroup(this.blocks);
    protected final Setting<Boolean> cryingObsidian = new Setting<Boolean>("Crying Obsidian", true).addToGroup(this.blocks);
    protected final Setting<Boolean> dirt = new Setting<Boolean>("Dirt", false).addToGroup(this.blocks);
    protected final Setting<Boolean> oakPlanks = new Setting<Boolean>("OakPlanks", false).addToGroup(this.blocks);
    protected final Setting<SettingGroup> pause = new Setting<SettingGroup>("Pause", new SettingGroup(false, 0));
    protected final Setting<Boolean> eatPause = new Setting<Boolean>("On Eat", false).addToGroup(this.pause);
    protected final Setting<Boolean> breakPause = new Setting<Boolean>("On Break", false).addToGroup(this.pause);
    protected final Setting<BooleanSettingGroup> render = new Setting<BooleanSettingGroup>("Render", new BooleanSettingGroup(true));
    protected final Setting<BlockAnimationUtility.BlockRenderMode> renderMode = new Setting<BlockAnimationUtility.BlockRenderMode>("Render Mode", BlockAnimationUtility.BlockRenderMode.All).addToGroup(this.render);
    protected final Setting<BlockAnimationUtility.BlockAnimationMode> animationMode = new Setting<BlockAnimationUtility.BlockAnimationMode>("Animation Mode", BlockAnimationUtility.BlockAnimationMode.Fade).addToGroup(this.render);
    protected final Setting<ColorSetting> renderFillColor = new Setting<ColorSetting>("Fill Color", new ColorSetting(HudEditor.getColor(0))).addToGroup(this.render);
    protected final Setting<ColorSetting> renderLineColor = new Setting<ColorSetting>("Line Color", new ColorSetting(HudEditor.getColor(0))).addToGroup(this.render);
    protected final Setting<Integer> renderLineWidth = new Setting<Integer>("Line Width", 2, 1, 5).addToGroup(this.render);
    public final Timer inactivityTimer = new Timer();
    public final Timer pauseTimer = new Timer();
    protected final Timer attackTimer = new Timer();

    public PlaceModule(@NotNull String name, @NotNull Module.Category category) {
        super(name, category);
    }

    protected boolean shouldPause() {
        return this.eatPause.getValue() != false && PlayerUtility.isEating() || this.breakPause.getValue() != false && PlayerUtility.isMining() || !this.pauseTimer.passedMs(350L);
    }

    protected boolean placeBlock(class_2338 pos) {
        return this.placeBlock(pos, this.crystalBreaker.getValue().isEnabled(), this.placeMode.getValue(), this.rotate.getValue());
    }

    protected boolean placeBlock(class_2338 pos, boolean ignoreEntities) {
        return this.placeBlock(pos, ignoreEntities, this.placeMode.getValue(), this.rotate.getValue());
    }

    protected boolean placeBlock(class_2338 pos, InteractionUtility.Rotate rotate) {
        return this.placeBlock(pos, this.crystalBreaker.getValue().isEnabled(), this.placeMode.getValue(), rotate);
    }

    protected boolean placeBlock(class_2338 pos, InteractMode mode) {
        return this.placeBlock(pos, this.crystalBreaker.getValue().isEnabled(), mode, this.rotate.getValue());
    }

    protected boolean placeBlock(class_2338 pos, boolean ignoreEntities, InteractMode mode, InteractionUtility.Rotate rotate) {
        if (this.shouldPause()) {
            return false;
        }
        boolean validInteraction = false;
        SearchInvResult result = this.getBlockResult();
        if (!result.found()) {
            return false;
        }
        if (this.crystalBreaker.getValue().isEnabled() && PlaceModule.mc.field_1687 != null && this.attackTimer.passedMs(this.breakDelay.getValue().intValue())) {
            PlaceModule.mc.field_1687.method_18467(class_1511.class, new class_238(pos)).stream().findFirst().ifPresent(this::breakCrystal);
        }
        if (mode == InteractMode.Packet) {
            validInteraction = InteractionUtility.placeBlock(pos, rotate, this.interact.getValue(), InteractionUtility.PlaceMode.Packet, result.slot(), true, ignoreEntities);
        }
        if (mode == InteractMode.Normal) {
            validInteraction = InteractionUtility.placeBlock(pos, rotate, this.interact.getValue(), InteractionUtility.PlaceMode.Normal, result.slot(), true, ignoreEntities);
        }
        if (validInteraction && PlaceModule.mc.field_1724 != null) {
            if (this.render.getValue().isEnabled()) {
                this.renderBlock(pos);
            }
            if (this.swing.getValue().booleanValue()) {
                PlaceModule.mc.field_1724.method_6104(class_1268.field_5808);
            }
        }
        return validInteraction;
    }

    protected void breakCrystal(class_1511 entity) {
        if (PlaceModule.mc.field_1724 == null || PlaceModule.mc.field_1687 == null || PlaceModule.mc.field_1761 == null || this.shouldPause() || !this.attackTimer.passedMs(this.breakDelay.getValue().intValue()) || PlaceModule.mc.field_1724.method_5858((class_1297)entity) > (double)this.range.getPow2Value() || entity.field_6012 < this.crystalAge.getValue()) {
            return;
        }
        int preSlot = PlaceModule.mc.field_1724.method_31548().field_7545;
        if (this.antiWeakness.getValue().booleanValue() && PlaceModule.mc.field_1724.method_6059(class_1294.field_5911)) {
            SearchInvResult result = InventoryUtility.getAntiWeaknessItem();
            if (!result.found()) {
                return;
            }
            result.switchTo();
        }
        if (this.breakCrystalMode.getValue() == InteractMode.Packet) {
            this.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)entity, (boolean)PlaceModule.mc.field_1724.method_5715()));
        }
        if (this.breakCrystalMode.getValue() == InteractMode.Normal) {
            PlaceModule.mc.field_1761.method_2918((class_1657)PlaceModule.mc.field_1724, (class_1297)entity);
        }
        this.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        this.attackTimer.reset();
        if (this.remove.getValue().booleanValue()) {
            entity.method_5768();
            entity.method_31745(class_1297.class_5529.field_26998);
            entity.method_36209();
        }
        if (this.antiWeakness.getValue().booleanValue() && PlaceModule.mc.field_1724.method_6059(class_1294.field_5911)) {
            InventoryUtility.switchTo(preSlot);
        }
    }

    protected boolean canPlaceBlock(class_2338 pos, boolean ignoreEntities) {
        return InteractionUtility.canPlaceBlock(pos, this.interact.getValue(), ignoreEntities);
    }

    protected void renderBlock(class_2338 pos) {
        BlockAnimationUtility.renderBlock(pos, this.renderLineColor.getValue().getColorObject(), this.renderLineWidth.getValue(), this.renderFillColor.getValue().getColorObject(), this.animationMode.getValue(), this.renderMode.getValue());
    }

    protected SearchInvResult getBlockResult() {
        class_2248 blockFromMainHandItem;
        class_1799 mainHandStack;
        ArrayList<class_2248> canUseBlocks = new ArrayList<class_2248>();
        if (PlaceModule.mc.field_1724 == null) {
            return SearchInvResult.notFound();
        }
        if (this.obsidian.getValue().booleanValue()) {
            canUseBlocks.add(class_2246.field_10540);
        }
        if (this.enderChest.getValue().booleanValue()) {
            canUseBlocks.add(class_2246.field_10443);
        }
        if (this.cryingObsidian.getValue().booleanValue()) {
            canUseBlocks.add(class_2246.field_22423);
        }
        if (this.netherite.getValue().booleanValue()) {
            canUseBlocks.add(class_2246.field_22108);
        }
        if (this.anchor.getValue().booleanValue()) {
            canUseBlocks.add(class_2246.field_23152);
        }
        if (this.dirt.getValue().booleanValue()) {
            canUseBlocks.addAll(List.of(class_2246.field_10566, class_2246.field_10219, class_2246.field_10520));
        }
        if (this.oakPlanks.getValue().booleanValue()) {
            canUseBlocks.addAll(List.of(class_2246.field_10161, class_2246.field_10148, class_2246.field_10075));
        }
        if ((mainHandStack = PlaceModule.mc.field_1724.method_6047()) != class_1799.field_8037 && mainHandStack.method_7909() instanceof class_1747 && canUseBlocks.contains(blockFromMainHandItem = ((class_1747)mainHandStack.method_7909()).method_7711())) {
            return new SearchInvResult(PlaceModule.mc.field_1724.method_31548().field_7545, true, mainHandStack);
        }
        return InventoryUtility.findBlockInHotBar(canUseBlocks);
    }

    public void pause() {
        this.pauseTimer.reset();
    }

    protected static enum InteractMode {
        Packet,
        Normal;

    }
}

