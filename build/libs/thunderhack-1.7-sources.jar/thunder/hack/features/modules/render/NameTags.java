/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Ordering
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.block.ShulkerBoxBlock
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.network.PlayerListEntry
 *  net.minecraft.client.render.DiffuseLighting
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.ContainerComponent
 *  net.minecraft.component.type.ItemEnchantmentsComponent
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.attribute.EntityAttributes
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.passive.HorseEntity
 *  net.minecraft.entity.passive.TameableEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.projectile.ProjectileEntity
 *  net.minecraft.item.BlockItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.registry.RegistryKey
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.scoreboard.ReadableScoreboardScore
 *  net.minecraft.scoreboard.ScoreHolder
 *  net.minecraft.scoreboard.Scoreboard
 *  net.minecraft.scoreboard.ScoreboardDisplaySlot
 *  net.minecraft.scoreboard.ScoreboardObjective
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.GameMode
 *  org.jetbrains.annotations.NotNull
 *  org.joml.Vector4d
 *  org.lwjgl.opengl.GL11
 */
package thunder.hack.features.modules.render;

import com.google.common.collect.Ordering;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1498;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1934;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_640;
import net.minecraft.class_6880;
import net.minecraft.class_8646;
import net.minecraft.class_9013;
import net.minecraft.class_9015;
import net.minecraft.class_9288;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector4d;
import org.lwjgl.opengl.GL11;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.core.manager.player.FriendManager;
import thunder.hack.features.hud.impl.PotionHud;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.misc.NameProtect;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;

public class NameTags
extends Module {
    private final Map<class_5321<class_1887>, String> encMap = new HashMap<class_5321<class_1887>, String>();
    private final Setting<Boolean> self = new Setting<Boolean>("Self", false);
    private final Setting<Float> scale = new Setting<Float>("Scale", Float.valueOf(1.0f), Float.valueOf(0.1f), Float.valueOf(10.0f));
    private final Setting<Boolean> resize = new Setting<Boolean>("Resize", false);
    private final Setting<Float> height = new Setting<Float>("Height", Float.valueOf(2.0f), Float.valueOf(0.1f), Float.valueOf(10.0f));
    private final Setting<Boolean> gamemode = new Setting<Boolean>("Gamemode", false);
    private final Setting<Boolean> spawners = new Setting<Boolean>("SpawnerNameTag", false);
    private final Setting<Boolean> entityOwner = new Setting<Boolean>("EntityOwner", false);
    private final Setting<Boolean> ping = new Setting<Boolean>("Ping", false);
    private final Setting<Boolean> hp = new Setting<Boolean>("HP", true);
    private final Setting<Boolean> distance = new Setting<Boolean>("Distance", true);
    private final Setting<Boolean> pops = new Setting<Boolean>("TotemPops", true);
    private final Setting<OutlineColor> outline = new Setting<OutlineColor>("OutlineType", OutlineColor.New);
    private final Setting<OutlineColor> friendOutline = new Setting<OutlineColor>("FriendOutline", OutlineColor.None);
    private final Setting<ColorSetting> outlineColor = new Setting<ColorSetting>("OutlineColor", new ColorSetting(Integer.MIN_VALUE));
    private final Setting<ColorSetting> friendOutlineColor = new Setting<ColorSetting>("FriendOutlineColor", new ColorSetting(Integer.MIN_VALUE));
    private final Setting<Boolean> enchantss = new Setting<Boolean>("Enchants", true);
    private final Setting<Boolean> onlyHands = new Setting<Boolean>("OnlyHands", false, v -> this.enchantss.getValue());
    private final Setting<Boolean> scoreboardHp = new Setting<Boolean>("ScoreboardHp", false);
    private final Setting<Boolean> ignoreBots = new Setting<Boolean>("IgnoreBots", false);
    private final Setting<Boolean> potions = new Setting<Boolean>("Potions", true);
    private final Setting<Boolean> shulkers = new Setting<Boolean>("Shulkers", true);
    private final Setting<ColorSetting> fillColorA = new Setting<ColorSetting>("Fill", new ColorSetting(Integer.MIN_VALUE));
    private final Setting<ColorSetting> fillColorF = new Setting<ColorSetting>("FriendFill", new ColorSetting(Integer.MIN_VALUE));
    private final Setting<Font> font = new Setting<Font>("FontMode", Font.Fancy);
    private final Setting<Armor> armorMode = new Setting<Armor>("ArmorMode", Armor.Full);
    private final Setting<Health> health = new Setting<Health>("Health", Health.Number);

    public NameTags() {
        super("NameTags", Module.Category.RENDER);
        this.encMap.put((class_5321<class_1887>)class_1893.field_9107, "B");
        this.encMap.put((class_5321<class_1887>)class_1893.field_9111, "P");
        this.encMap.put((class_5321<class_1887>)class_1893.field_9118, "S");
        this.encMap.put((class_5321<class_1887>)class_1893.field_9131, "E");
        this.encMap.put((class_5321<class_1887>)class_1893.field_9119, "U");
        this.encMap.put((class_5321<class_1887>)class_1893.field_9103, "PO");
        this.encMap.put((class_5321<class_1887>)class_1893.field_9097, "T");
    }

    @Override
    public void onRender2D(class_332 context) {
        if (NameTags.mc.field_1690.field_1842) {
            return;
        }
        for (class_1657 ent : NameTags.mc.field_1687.method_18456()) {
            if (ent == NameTags.mc.field_1724 && (NameTags.mc.field_1690.method_31044().method_31034() || !this.self.getValue().booleanValue()) || NameTags.getEntityPing(ent) <= 0 && this.ignoreBots.getValue().booleanValue()) continue;
            double x = ent.field_6014 + (ent.method_23317() - ent.field_6014) * (double)Render3DEngine.getTickDelta();
            double y = ent.field_6036 + (ent.method_23318() - ent.field_6036) * (double)Render3DEngine.getTickDelta();
            double z = ent.field_5969 + (ent.method_23321() - ent.field_5969) * (double)Render3DEngine.getTickDelta();
            float scale = this.resize.getValue() != false ? this.scale.getValue().floatValue() / NameTags.mc.field_1724.method_5739((class_1297)ent) : this.scale.getValue().floatValue();
            class_243 vector = new class_243(x, y + (double)this.height.getValue().floatValue(), z);
            Vector4d position = null;
            vector = Render3DEngine.worldSpaceToScreenSpace(vector);
            if (vector.field_1350 > 0.0 && vector.field_1350 < 1.0) {
                position = new Vector4d(vector.field_1352, vector.field_1351, vector.field_1350, 0.0);
                position.x = Math.min(vector.field_1352, position.x);
                position.y = Math.min(vector.field_1351, position.y);
                position.z = Math.max(vector.field_1352, position.z);
            }
            Object final_string = "";
            if (this.ping.getValue().booleanValue()) {
                final_string = (String)final_string + this.getPingColor(NameTags.getEntityPing(ent)) + NameTags.getEntityPing(ent) + "ms " + String.valueOf(class_124.field_1068);
            }
            if (this.gamemode.getValue().booleanValue()) {
                final_string = (String)final_string + this.translateGamemode(NameTags.getEntityGamemode(ent)) + " ";
            }
            Object object = final_string = FriendManager.friends.stream().anyMatch(i -> i.contains(ent.method_5476().getString())) && NameProtect.hideFriends.getValue() != false && ModuleManager.nameProtect.isEnabled() ? (String)final_string + NameProtect.getCustomName() + " " : (String)final_string + ent.method_5476().getString() + " ";
            if (this.hp.getValue().booleanValue() && this.health.is(Health.Number)) {
                final_string = (String)final_string + this.getHealthColor(this.getHealth(ent)) + NameTags.round2(this.getHealth(ent)) + " ";
            }
            if (this.distance.getValue().booleanValue()) {
                final_string = (String)final_string + String.format("%.1f", Float.valueOf(NameTags.mc.field_1724.method_5739((class_1297)ent))) + "m ";
            }
            if (this.pops.getValue().booleanValue() && Managers.COMBAT.getPops(ent) != 0) {
                final_string = (String)final_string + String.valueOf(class_124.field_1070) + Managers.COMBAT.getPops(ent);
            }
            if (position == null) continue;
            double posX = position.x;
            double posY = position.y;
            double endPosX = position.z;
            double maxEnchantY = 0.0;
            float diff = (float)(endPosX - posX) / 2.0f;
            float textWidth = this.font.getValue() == Font.Fancy ? FontRenderers.sf_bold.getStringWidth((String)final_string) * 1.0f : (float)NameTags.mc.field_1772.method_1727((String)final_string);
            float tagX = (float)((posX + (double)diff - (double)(textWidth / 2.0f)) * 1.0);
            ArrayList<class_1799> stacks = new ArrayList<class_1799>();
            if (this.armorMode.getValue() != Armor.Durability) {
                stacks.add(ent.method_6079());
            }
            stacks.add((class_1799)ent.method_31548().field_7548.get(0));
            stacks.add((class_1799)ent.method_31548().field_7548.get(1));
            stacks.add((class_1799)ent.method_31548().field_7548.get(2));
            stacks.add((class_1799)ent.method_31548().field_7548.get(3));
            if (this.armorMode.getValue() != Armor.Durability) {
                stacks.add(ent.method_6047());
            }
            context.method_51448().method_22903();
            context.method_51448().method_46416(tagX - 2.0f + (textWidth + 4.0f) / 2.0f, (float)(posY - 13.0) + 6.5f, 0.0f);
            context.method_51448().method_22905(scale, scale, 1.0f);
            context.method_51448().method_46416(-(tagX - 2.0f + (textWidth + 4.0f) / 2.0f), -((float)(posY - 13.0 + 6.5)), 0.0f);
            float item_offset = 0.0f;
            if (this.armorMode.getValue() != Armor.None) {
                for (class_1799 armorComponent : stacks) {
                    if (!armorComponent.method_7960()) {
                        if (this.armorMode.getValue() == Armor.Full) {
                            context.method_51448().method_22903();
                            context.method_51448().method_22904(posX - 55.0 + (double)item_offset, (double)((float)(posY - 33.0)), 0.0);
                            context.method_51448().method_22905(1.1f, 1.1f, 1.1f);
                            class_308.method_24210();
                            context.method_51427(armorComponent, 0, 0);
                            context.method_51431(NameTags.mc.field_1772, armorComponent, 0, 0);
                            context.method_51448().method_22909();
                        } else {
                            context.method_51448().method_22903();
                            context.method_51448().method_22904(posX - 35.0 + (double)item_offset, (double)((float)(posY - 20.0)), 0.0);
                            context.method_51448().method_22905(0.7f, 0.7f, 0.7f);
                            float durability = armorComponent.method_7936() - armorComponent.method_7919();
                            int percent = (int)(durability / (float)armorComponent.method_7936() * 100.0f);
                            Color color = percent < 33 ? Color.RED : (percent > 33 && percent < 66 ? Color.YELLOW : Color.GREEN);
                            context.method_51433(NameTags.mc.field_1772, percent + "%", 0, 0, color.getRGB(), false);
                            context.method_51448().method_22909();
                        }
                        float enchantmentY = 0.0f;
                        class_9304 enchants = class_1890.method_57532((class_1799)armorComponent);
                        if (this.enchantss.getValue().booleanValue() && (!this.onlyHands.getValue().booleanValue() || armorComponent == ent.method_6079() || armorComponent == ent.method_6047())) {
                            for (class_5321 registryKey : this.encMap.keySet()) {
                                if (!enchants.method_57534().contains(NameTags.mc.field_1687.method_30349().method_30530(class_1893.field_9111.method_58273()).method_40264(registryKey).get())) continue;
                                String id = this.encMap.get(registryKey);
                                int level = enchants.method_57536((class_6880)NameTags.mc.field_1687.method_30349().method_30530(class_1893.field_9111.method_58273()).method_40264(registryKey).get());
                                String encName = id + level;
                                if (this.font.getValue() == Font.Fancy) {
                                    FontRenderers.sf_bold.drawString(context.method_51448(), encName, posX - 50.0 + (double)item_offset, (double)((float)posY - 45.0f + enchantmentY), -1);
                                } else {
                                    context.method_51448().method_22903();
                                    context.method_51448().method_22904(posX - 50.0 + (double)item_offset, posY - 45.0 + (double)enchantmentY, 0.0);
                                    context.method_51433(NameTags.mc.field_1772, encName, 0, 0, -1, false);
                                    context.method_51448().method_22909();
                                }
                                if (!(maxEnchantY > (double)(enchantmentY -= 8.0f))) continue;
                                maxEnchantY = enchantmentY;
                            }
                        }
                    }
                    item_offset += 18.0f;
                }
            }
            Color color = Managers.FRIEND.isFriend(ent) ? this.fillColorF.getValue().getColorObject() : this.fillColorA.getValue().getColorObject();
            OutlineColor cl = Managers.FRIEND.isFriend(ent) ? this.friendOutline.getValue() : this.outline.getValue();
            OutlineColor outlineColor = cl;
            if (cl == OutlineColor.New) {
                Render2DEngine.drawRectWithOutline(context.method_51448(), tagX - 2.0f, (float)(posY - 13.0), textWidth + 4.0f, 11.0f, color, this.outlineColor.getValue().getColorObject());
            } else {
                Render2DEngine.drawRect(context.method_51448(), tagX - 2.0f, (float)(posY - 13.0), textWidth + 4.0f, 11.0f, color);
            }
            if (Managers.TELEMETRY.getOnlinePlayers().contains(ent.method_7334().getName())) {
                Render2DEngine.drawRect(context.method_51448(), tagX - 14.0f, (float)(posY - 13.0), 12.0f, 11.0f, color.brighter().brighter());
                RenderSystem.enableBlend();
                RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
                Color lColor = HudEditor.getColor(0);
                RenderSystem.setShaderColor((float)((float)lColor.getRed() / 255.0f), (float)((float)lColor.getGreen() / 255.0f), (float)((float)lColor.getBlue() / 255.0f), (float)1.0f);
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.miniLogo);
                Render2DEngine.renderTexture(context.method_51448(), tagX - 13.0f, (float)(posY - 12.5), 10.0, 10.0, 0.0f, 0.0f, 256.0, 256.0, 256.0, 256.0);
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                RenderSystem.disableBlend();
            }
            switch (cl.ordinal()) {
                case 2: 
                case 3: {
                    break;
                }
                case 0: {
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 14.0), textWidth + 6.0f, 1.0f, HudEditor.getColor(270));
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 3.0), textWidth + 6.0f, 1.0f, HudEditor.getColor(0));
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 14.0), 1.0f, 11.0f, HudEditor.getColor(180));
                    Render2DEngine.drawRect(context.method_51448(), tagX + textWidth + 2.0f, (float)(posY - 14.0), 1.0f, 11.0f, HudEditor.getColor(90));
                    break;
                }
                case 1: {
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 14.0), textWidth + 6.0f, 1.0f, Managers.FRIEND.isFriend(ent) ? this.friendOutlineColor.getValue().getColorObject() : this.outlineColor.getValue().getColorObject());
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 3.0), textWidth + 6.0f, 1.0f, Managers.FRIEND.isFriend(ent) ? this.friendOutlineColor.getValue().getColorObject() : this.outlineColor.getValue().getColorObject());
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 14.0), 1.0f, 11.0f, Managers.FRIEND.isFriend(ent) ? this.friendOutlineColor.getValue().getColorObject() : this.outlineColor.getValue().getColorObject());
                    Render2DEngine.drawRect(context.method_51448(), tagX + textWidth + 2.0f, (float)(posY - 14.0), 1.0f, 11.0f, Managers.FRIEND.isFriend(ent) ? this.friendOutlineColor.getValue().getColorObject() : this.outlineColor.getValue().getColorObject());
                }
            }
            if (this.font.getValue() == Font.Fancy) {
                FontRenderers.sf_bold.drawString(context.method_51448(), (String)final_string, (double)tagX, (double)((float)posY - 10.0f), -1);
            } else {
                context.method_51448().method_22903();
                context.method_51448().method_46416(tagX, (float)posY - 11.0f, 0.0f);
                context.method_51433(NameTags.mc.field_1772, (String)final_string, 0, 0, -1, false);
                context.method_51448().method_22909();
            }
            if (!this.health.is(Health.Number)) {
                int i2 = class_3532.method_15386((float)ent.method_6032());
                float f = (float)ent.method_45325(class_5134.field_23716);
                int p = class_3532.method_15386((float)ent.method_6067());
                context.method_51448().method_22903();
                context.method_51448().method_22904(posX - 44.0, posY, 0.0);
                context.method_51448().method_22905(1.1f, 1.1f, 1.0f);
                this.renderHealthBar(context, ent, f, i2, p);
                context.method_51448().method_22909();
            }
            if (this.potions.getValue().booleanValue()) {
                this.renderStatusEffectOverlay(context, (float)posX, (float)(posY + maxEnchantY - 60.0), ent);
            }
            class_1792 handItem = ent.method_6047().method_7909();
            if (this.shulkers.getValue().booleanValue()) {
                class_1747 bi;
                this.renderShulkerToolTip(context, (int)posX - 90, (int)posY - 120, handItem instanceof class_1747 && (bi = (class_1747)handItem).method_7711() instanceof class_2480 ? ent.method_6047() : ent.method_6079());
            }
            context.method_51448().method_22909();
        }
        if (this.spawners.getValue().booleanValue()) {
            this.drawSpawnerNameTag(context);
        }
        if (this.entityOwner.getValue().booleanValue()) {
            this.drawEntityOwner(context);
        }
    }

    private void drawSpawnerNameTag(class_332 context) {
    }

    public void drawEntityOwner(class_332 context) {
        for (class_1297 ent : NameTags.mc.field_1687.method_18112()) {
            String ownerName = "";
            if (ent instanceof class_1676) {
                class_1676 pe = (class_1676)ent;
                if (pe.method_24921() != null) {
                    ownerName = pe.method_24921().method_5476().getString();
                }
            } else if (ent instanceof class_1498) {
                class_1498 he = (class_1498)ent;
                if (he.method_6139() != null) {
                    ownerName = he.method_6139().toString();
                }
            } else {
                class_1321 te;
                if (!(ent instanceof class_1321) || !(te = (class_1321)ent).method_6181() || te.method_35057() == null) continue;
                ownerName = te.method_35057().method_5476().getString();
            }
            String final_string = "Owned by " + ownerName;
            double x = ent.field_6014 + (ent.method_23317() - ent.field_6014) * (double)Render3DEngine.getTickDelta();
            double y = ent.field_6036 + (ent.method_23318() - ent.field_6036) * (double)Render3DEngine.getTickDelta();
            double z = ent.field_5969 + (ent.method_23321() - ent.field_5969) * (double)Render3DEngine.getTickDelta();
            class_243 vector = new class_243(x, y + 2.0, z);
            Vector4d position = null;
            vector = Render3DEngine.worldSpaceToScreenSpace(new class_243(vector.field_1352, vector.field_1351, vector.field_1350));
            if (vector.field_1350 > 0.0 && vector.field_1350 < 1.0) {
                position = new Vector4d(vector.field_1352, vector.field_1351, vector.field_1350, 0.0);
                position.x = Math.min(vector.field_1352, position.x);
                position.y = Math.min(vector.field_1351, position.y);
                position.z = Math.max(vector.field_1352, position.z);
            }
            if (position == null) continue;
            double posX = position.x;
            double posY = position.y;
            double endPosX = position.z;
            float diff = (float)(endPosX - posX) / 2.0f;
            float textWidth = FontRenderers.sf_bold.getStringWidth(final_string) * 1.0f;
            float tagX = (float)((posX + (double)diff - (double)(textWidth / 2.0f)) * 1.0);
            Render2DEngine.drawRect(context.method_51448(), tagX - 2.0f, (float)(posY - 13.0), textWidth + 4.0f, 11.0f, this.fillColorA.getValue().getColorObject());
            switch (this.outline.getValue().ordinal()) {
                case 2: {
                    break;
                }
                case 0: {
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 14.0), textWidth + 6.0f, 1.0f, HudEditor.getColor(270));
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 3.0), textWidth + 6.0f, 1.0f, HudEditor.getColor(0));
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 14.0), 1.0f, 11.0f, HudEditor.getColor(180));
                    Render2DEngine.drawRect(context.method_51448(), tagX + textWidth + 2.0f, (float)(posY - 14.0), 1.0f, 11.0f, HudEditor.getColor(90));
                    break;
                }
                case 1: {
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 14.0), textWidth + 6.0f, 1.0f, this.outlineColor.getValue().getColorObject());
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 3.0), textWidth + 6.0f, 1.0f, this.outlineColor.getValue().getColorObject());
                    Render2DEngine.drawRect(context.method_51448(), tagX - 3.0f, (float)(posY - 14.0), 1.0f, 11.0f, this.outlineColor.getValue().getColorObject());
                    Render2DEngine.drawRect(context.method_51448(), tagX + textWidth + 2.0f, (float)(posY - 14.0), 1.0f, 11.0f, this.outlineColor.getValue().getColorObject());
                }
            }
            FontRenderers.sf_bold.drawString(context.method_51448(), final_string, (double)tagX, (double)((float)posY - 10.0f), -1);
        }
    }

    public static int getEntityPing(class_1657 entity) {
        if (mc.method_1562() == null) {
            return 0;
        }
        class_640 playerListEntry = mc.method_1562().method_2871(entity.method_5667());
        if (playerListEntry == null) {
            return 0;
        }
        return playerListEntry.method_2959();
    }

    public static class_1934 getEntityGamemode(class_1657 entity) {
        if (entity == null) {
            return null;
        }
        class_640 playerListEntry = mc.method_1562().method_2871(entity.method_5667());
        return playerListEntry == null ? null : playerListEntry.method_2958();
    }

    private String translateGamemode(class_1934 gamemode) {
        if (gamemode == null) {
            return "[BOT]";
        }
        return switch (gamemode) {
            default -> throw new MatchException(null, null);
            case class_1934.field_9215 -> "[S]";
            case class_1934.field_9220 -> "[C]";
            case class_1934.field_9219 -> "[SP]";
            case class_1934.field_9216 -> "[A]";
        };
    }

    public float getHealth(class_1657 ent) {
        if (mc.method_1562() != null && mc.method_1562().method_45734() != null && (NameTags.mc.method_1562().method_45734().field_3761.contains("funtime") || NameTags.mc.method_1562().method_45734().field_3761.contains("boxpvp")) || this.scoreboardHp.getValue().booleanValue()) {
            try {
                class_9013 score;
                class_269 scoreboard = NameTags.mc.field_1687.method_8428();
                class_266 healthObjective = scoreboard.method_1189(class_8646.field_45158);
                if (healthObjective != null && (score = scoreboard.method_55430((class_9015)ent, healthObjective)) != null) {
                    return (float)score.method_55397() + ent.method_6067();
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return ent.method_6032() + ent.method_6067();
    }

    private void renderHealthBar(class_332 context, class_1657 player, float maxHealth, int lastHealth, int absorption) {
        int i = class_3532.method_15384((double)((double)maxHealth / 2.0));
        int j = class_3532.method_15384((double)((double)absorption / 2.0));
        int k = i * 2;
        int cont = 0;
        for (int l = i + j - 1; l >= 0; --l) {
            int q;
            int n = l % 10;
            int o = n * 8;
            if (cont < 10) {
                this.drawHeart(context, HeartType.CONTAINER, o, false, player);
                ++cont;
            }
            if ((q = l * 2) < lastHealth) {
                this.drawHeart(context, HeartType.NORMAL, o, q + 1 == lastHealth, player);
            }
            if (l < i) continue;
            int r = q - k;
            if (q - k >= absorption) continue;
            context.method_51448().method_22903();
            context.method_51448().method_46416(0.0f, 0.0f, 0.001f);
            this.drawHeart(context, HeartType.ABSORBING, o, r + 1 == absorption, player);
            context.method_51448().method_22909();
        }
    }

    private void drawHeart(class_332 context, HeartType type, int x, boolean half, class_1657 player) {
        if (this.health.is(Health.Dots)) {
            Color color = Managers.FRIEND.isFriend(player) ? this.fillColorF.getValue().getColorObject() : this.fillColorA.getValue().getColorObject();
            Color color2 = color;
            if (type == HeartType.CONTAINER) {
                Render2DEngine.drawRect(context.method_51448(), x, 0.0f, 7.0f, 3.0f, color);
            } else if (type == HeartType.NORMAL) {
                if (half) {
                    Render2DEngine.drawRect(context.method_51448(), x, 0.0f, 3.0f, 3.0f, this.getHealthColor2(player.method_6032() + player.method_6067()));
                    Render2DEngine.drawRect(context.method_51448(), x + 3, 0.0f, 4.0f, 3.0f, color);
                } else {
                    Render2DEngine.drawRect(context.method_51448(), x, 0.0f, 7.0f, 3.0f, this.getHealthColor2(player.method_6032() + player.method_6067()));
                }
            }
        } else {
            context.method_52706(type.getTexture(half), x, 0, 9, 9);
        }
    }

    @NotNull
    public String getHealthColor(float health) {
        if (health <= 15.0f && health > 7.0f) {
            return String.valueOf(class_124.field_1054);
        }
        if (health > 15.0f) {
            return String.valueOf(class_124.field_1060);
        }
        return String.valueOf(class_124.field_1061);
    }

    @NotNull
    public String getPingColor(int ping) {
        if (ping <= 60) {
            return String.valueOf(class_124.field_1060);
        }
        if (ping > 60 && ping < 120) {
            return String.valueOf(class_124.field_1054);
        }
        return String.valueOf(class_124.field_1061);
    }

    @NotNull
    private Color getHealthColor2(float health) {
        if (health <= 15.0f && health > 7.0f) {
            return Color.YELLOW;
        }
        if (health > 15.0f) {
            return Color.GREEN;
        }
        return Color.RED;
    }

    public static float round2(float value) {
        if (Float.isNaN(value) || Float.isInfinite(value)) {
            return 1.0f;
        }
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(1, RoundingMode.HALF_UP);
        return bd.floatValue();
    }

    private void renderStatusEffectOverlay(class_332 context, float x, float y, class_1657 player) {
        ArrayList<class_1293> effects = new ArrayList<>(player.method_6026());
        if (effects.isEmpty()) {
            return;
        }
        x += (float)effects.size() * 12.5f;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        for (class_1293 statusEffectInstance : Ordering.natural().reverse().sortedCopy(effects)) {
            x -= 25.0f;
            String power = "";
            switch (statusEffectInstance.method_5578()) {
                case 0: {
                    power = "I";
                    break;
                }
                case 1: {
                    power = "II";
                    break;
                }
                case 2: {
                    power = "III";
                    break;
                }
                case 3: {
                    power = "IV";
                    break;
                }
                case 4: {
                    power = "V";
                }
            }
            context.method_51448().method_22903();
            context.method_51448().method_46416(x, y, 0.0f);
            context.method_25298(0, 0, 0, 18, 18, mc.method_18505().method_18663(statusEffectInstance.method_5579()));
            FontRenderers.sf_bold_mini.drawCenteredString(context.method_51448(), PotionHud.getDuration(statusEffectInstance), 9.0, -8.0, -1);
            FontRenderers.categories.drawCenteredString(context.method_51448(), power, 9.0, -16.0, -1);
            context.method_51448().method_22909();
        }
        RenderSystem.disableBlend();
    }

    public boolean renderShulkerToolTip(class_332 context, int offsetX, int offsetY, class_1799 stack) {
        try {
            class_1747 bi;
            class_9288 compoundTag = (class_9288)stack.method_57824(class_9334.field_49622);
            if (compoundTag == null) {
                return false;
            }
            float[] colors = new float[]{1.0f, 1.0f, 1.0f};
            class_1792 focusedItem = stack.method_7909();
            if (focusedItem instanceof class_1747 && (bi = (class_1747)focusedItem).method_7711() instanceof class_2480) {
                try {
                    Color c = new Color(Objects.requireNonNull(class_2480.method_10527((class_1792)stack.method_7909())).method_7787());
                    colors = new float[]{(float)c.getRed() / 255.0f, (float)c.getGreen() / 255.0f, (float)c.getRed() / 255.0f, (float)c.getAlpha() / 255.0f};
                }
                catch (NullPointerException npe) {
                    colors = new float[]{1.0f, 1.0f, 1.0f};
                }
            } else {
                return false;
            }
            this.draw(context, compoundTag.method_57489().toList(), offsetX, offsetY, colors);
        }
        catch (Exception ignore) {
            return false;
        }
        return true;
    }

    private void draw(class_332 context, List<class_1799> itemStacks, int offsetX, int offsetY, float[] colors) {
        RenderSystem.disableDepthTest();
        GL11.glClear((int)256);
        this.drawBackground(context, offsetX += 8, offsetY -= 82, colors);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        class_308.method_24211();
        int row = 0;
        int i = 0;
        for (class_1799 itemStack : itemStacks) {
            context.method_51427(itemStack, offsetX + 8 + i * 18, offsetY + 7 + row * 18);
            context.method_51431(NameTags.mc.field_1772, itemStack, offsetX + 8 + i * 18, offsetY + 7 + row * 18);
            if (++i < 9) continue;
            i = 0;
            ++row;
        }
        class_308.method_24210();
        RenderSystem.enableDepthTest();
    }

    private void drawBackground(class_332 context, int x, int y, float[] colors) {
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor((float)colors[0], (float)colors[1], (float)colors[2], (float)1.0f);
        RenderSystem.texParameter((int)3553, (int)10240, (int)9729);
        RenderSystem.texParameter((int)3553, (int)10241, (int)9987);
        context.method_25290(TextureStorage.container, x, y, 0.0f, 0.0f, 176, 67, 176, 67);
        RenderSystem.enableBlend();
    }

    private static enum OutlineColor {
        Sync,
        Custom,
        None,
        New;

    }

    public static enum Font {
        Fancy,
        Fast;

    }

    public static enum Armor {
        None,
        Full,
        Durability;

    }

    public static enum Health {
        Number,
        Hearts,
        Dots;

    }

    private static enum HeartType {
        CONTAINER(class_2960.method_60654((String)"hud/heart/container"), class_2960.method_60654((String)"hud/heart/container")),
        NORMAL(class_2960.method_60654((String)"hud/heart/full"), class_2960.method_60654((String)"hud/heart/half")),
        ABSORBING(class_2960.method_60654((String)"hud/heart/absorbing_full"), class_2960.method_60654((String)"hud/heart/absorbing_half"));

        private final class_2960 fullTexture;
        private final class_2960 halfTexture;

        private HeartType(class_2960 fullTexture, class_2960 halfTexture) {
            this.fullTexture = fullTexture;
            this.halfTexture = halfTexture;
        }

        public class_2960 getTexture(boolean half) {
            return half ? this.halfTexture : this.fullTexture;
        }
    }
}

