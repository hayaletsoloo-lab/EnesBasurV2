/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  net.minecraft.block.AirBlock
 *  net.minecraft.block.BarrierBlock
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockState
 *  net.minecraft.block.Blocks
 *  net.minecraft.block.CommandBlock
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.Util
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Vec3d
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.render;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.class_156;
import net.minecraft.class_2189;
import net.minecraft.class_2213;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2288;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import org.jetbrains.annotations.NotNull;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.setting.impl.ItemSelectSetting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.PlayerUtility;
import thunder.hack.utility.render.Render3DEngine;

public class BlockESP
extends Module {
    public final Setting<ItemSelectSetting> selectedBlocks = new Setting<ItemSelectSetting>("SelectedBlocks", new ItemSelectSetting(new ArrayList<String>()));
    public static ArrayList<BlockVec> blocks = new ArrayList();
    private final Setting<Integer> range = new Setting<Integer>("Range", 100, 1, 128);
    private final Setting<BooleanSettingGroup> limit = new Setting<BooleanSettingGroup>("Limit", new BooleanSettingGroup(true));
    private final Setting<Integer> limitCount = new Setting<Integer>("LimitCount", 50, 1, 2048).addToGroup(this.limit);
    private final Setting<ColorSetting> color = new Setting<ColorSetting>("Color", new ColorSetting(-16711681));
    private final Setting<Boolean> illegals = new Setting<Boolean>("Illegals", true);
    private final Setting<Boolean> tracers = new Setting<Boolean>("Tracers", false);
    private final Setting<Boolean> fill = new Setting<Boolean>("Fill", true);
    private final Setting<Boolean> outline = new Setting<Boolean>("Outline", true);
    private final ExecutorService searchThread = Executors.newSingleThreadExecutor();
    private final Timer searchTimer = new Timer();
    private long lastFrameTime;
    private boolean canContinue;

    public BlockESP() {
        super("BlockESP", Module.Category.RENDER);
    }

    @Override
    public void onEnable() {
        blocks.clear();
        this.lastFrameTime = System.currentTimeMillis();
        this.canContinue = true;
    }

    @Override
    public void onUpdate() {
        if (this.searchTimer.every(1000L) && this.canContinue) {
            CompletableFuture.supplyAsync(this::scan, this.searchThread).thenAcceptAsync(this::sync, (Executor)class_156.method_18349());
            this.canContinue = false;
        }
    }

    private ArrayList<BlockVec> scan() {
        ArrayList<BlockVec> blocks = new ArrayList<BlockVec>();
        int startX = (int)Math.floor(BlockESP.mc.field_1724.method_23317() - (double)this.range.getValue().intValue());
        int endX = (int)Math.ceil(BlockESP.mc.field_1724.method_23317() + (double)this.range.getValue().intValue());
        int startY = BlockESP.mc.field_1687.method_31607() + 1;
        int endY = BlockESP.mc.field_1687.method_31600();
        int startZ = (int)Math.floor(BlockESP.mc.field_1724.method_23321() - (double)this.range.getValue().intValue());
        int endZ = (int)Math.ceil(BlockESP.mc.field_1724.method_23321() + (double)this.range.getValue().intValue());
        for (int x = startX; x <= endX; ++x) {
            for (int y = startY; y <= endY; ++y) {
                for (int z = startZ; z <= endZ; ++z) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 bs = BlockESP.mc.field_1687.method_8320(pos);
                    if (!this.shouldAdd(bs.method_26204(), pos)) continue;
                    blocks.add(new BlockVec(pos.method_10263(), pos.method_10264(), pos.method_10260()));
                }
            }
        }
        return blocks;
    }

    private void sync(ArrayList<BlockVec> b) {
        blocks = b;
        this.canContinue = true;
    }

    @Override
    public void onRender3D(class_4587 stack) {
        if (BlockESP.fullNullCheck() || blocks.isEmpty()) {
            return;
        }
        int count = 0;
        if (mc.method_47599() < 8 && BlockESP.mc.field_1724.field_6012 > 100) {
            this.disable(ClientSettings.isRu() ? "\u0421\u043f\u0430\u0441\u0430\u0435\u043c \u0442\u0432\u043e\u0439 \u041f\u041a :)" : "Saving ur pc :)");
            return;
        }
        if (this.fill.getValue().booleanValue() || this.outline.getValue().booleanValue()) {
            for (BlockVec vec : Lists.newArrayList(blocks)) {
                if (count > this.limitCount.getValue() && this.limit.getValue().isEnabled()) continue;
                if (vec.getDistance(BlockESP.mc.field_1724.method_19538()) > (double)this.range.getPow2Value()) {
                    blocks.remove(vec);
                    continue;
                }
                class_238 b = new class_238(vec.x, vec.y, vec.z, vec.x + 1.0, vec.y + 1.0, vec.z + 1.0);
                if (this.fill.getValue().booleanValue()) {
                    Render3DEngine.FILLED_QUEUE.add(new Render3DEngine.FillAction(b, this.color.getValue().getColorObject()));
                }
                if (this.outline.getValue().booleanValue()) {
                    Render3DEngine.OUTLINE_QUEUE.add(new Render3DEngine.OutlineAction(b, this.color.getValue().getColorObject(), 2.0f));
                }
                if (this.tracers.getValue().booleanValue()) {
                    class_243 vec2 = new class_243(0.0, 0.0, 75.0).method_1037(-((float)Math.toRadians(BlockESP.mc.field_1773.method_19418().method_19329()))).method_1024(-((float)Math.toRadians(BlockESP.mc.field_1773.method_19418().method_19330()))).method_1019(BlockESP.mc.field_1719.method_33571());
                    Render3DEngine.drawLineDebug(vec2, vec.getVector(), this.color.getValue().getColorObject());
                }
                ++count;
            }
        }
        this.lastFrameTime = System.currentTimeMillis();
    }

    private boolean shouldAdd(class_2248 block, class_2338 pos) {
        if (block instanceof class_2189) {
            return false;
        }
        if (this.selectedBlocks.getValue().contains(block)) {
            return true;
        }
        if (this.illegals.getValue().booleanValue()) {
            return this.isIllegal(block, pos);
        }
        return false;
    }

    private boolean isIllegal(class_2248 block, class_2338 pos) {
        if (block instanceof class_2288 || block instanceof class_2213) {
            return true;
        }
        if (block == class_2246.field_9987) {
            if (!PlayerUtility.isInHell()) {
                return pos.method_10264() > 4;
            }
            return pos.method_10264() > 127 || pos.method_10264() < 123 && pos.method_10264() > 4;
        }
        return false;
    }

    public record BlockVec(double x, double y, double z) {
        public double getDistance(@NotNull class_243 v) {
            double dx = this.x - v.field_1352;
            double dy = this.y - v.field_1351;
            double dz = this.z - v.field_1350;
            return dx * dx + dy * dy + dz * dz;
        }

        public class_243 getVector() {
            return new class_243(this.x + 0.5, this.y + 0.5, this.z + 0.5);
        }
    }
}

