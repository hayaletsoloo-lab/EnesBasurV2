/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.block.AirBlock
 *  net.minecraft.block.Block
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.RotationAxis
 */
package thunder.hack.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.animation.AnimationUtility;

public class HitParticles
extends Module {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Stars);
    private final Setting<Physics> physics = new Setting<Physics>("Physics", Physics.Fall);
    private final Setting<ColorSetting> colorrr = new Setting<ColorSetting>("Color", new ColorSetting(-2013200640));
    private final Setting<Boolean> onlySelf = new Setting<Boolean>("Self", false);
    private final Setting<Integer> amount = new Setting<Integer>("Amount", 2, 1, 5);
    private final Setting<Integer> lifeTime = new Setting<Integer>("LifeTime", 2, 1, 10);
    private final Setting<Integer> speed = new Setting<Integer>("Speed", 2, 1, 20);
    private final Setting<Float> starsScale = new Setting<Float>("Scale", Float.valueOf(3.0f), Float.valueOf(1.0f), Float.valueOf(10.0f), v -> this.mode.getValue() != Mode.Orbiz);
    private final Setting<ColorMode> colorMode = new Setting<ColorMode>("ColorMode", ColorMode.Sync);
    private final Setting<ColorSetting> colorH = new Setting<ColorSetting>("HealColor", new ColorSetting(3142544), v -> this.mode.is(Mode.Text));
    private final Setting<ColorSetting> colorD = new Setting<ColorSetting>("DamageColor", new ColorSetting(15811379), v -> this.mode.is(Mode.Text));
    private final HashMap<Integer, Float> healthMap = new HashMap();
    private final CopyOnWriteArrayList<Particle> particles = new CopyOnWriteArrayList();

    public HitParticles() {
        super("HitParticles", Module.Category.RENDER);
    }

    @Override
    public void onUpdate() {
        this.particles.removeIf(Particle::update);
        if (this.mode.is(Mode.Text)) {
            for (class_1297 entity : HitParticles.mc.field_1687.method_18112()) {
                if (entity == null || HitParticles.mc.field_1724.method_5858(entity) > 256.0 || !entity.method_5805() || !(entity instanceof class_1309)) continue;
                class_1309 lent = (class_1309)entity;
                Color c = this.colorMode.getValue() == ColorMode.Sync ? HudEditor.getColor((int)MathUtility.random(1.0f, 228.0f)) : this.colorrr.getValue().getColorObject();
                float health = lent.method_6032() + lent.method_6067();
                float lastHealth = this.healthMap.getOrDefault(entity.method_5628(), Float.valueOf(health)).floatValue();
                this.healthMap.put(entity.method_5628(), Float.valueOf(health));
                if (lastHealth == health) continue;
                this.particles.add(new Particle((float)lent.method_23317(), MathUtility.random((float)(lent.method_23318() + (double)lent.method_17682()), (float)lent.method_23318()), (float)lent.method_23321(), c, MathUtility.random(0.0f, 180.0f), MathUtility.random(10.0f, 60.0f), health - lastHealth));
            }
            return;
        }
        for (class_1657 player : HitParticles.mc.field_1687.method_18456()) {
            if (this.onlySelf.getValue().booleanValue() && player != HitParticles.mc.field_1724 || player.field_6235 <= 0) continue;
            Color c = this.colorMode.getValue() == ColorMode.Sync ? HudEditor.getColor((int)MathUtility.random(1.0f, 228.0f)) : this.colorrr.getValue().getColorObject();
            for (int i = 0; i < this.amount.getValue(); ++i) {
                this.particles.add(new Particle((float)player.method_23317(), MathUtility.random((float)(player.method_23318() + (double)player.method_17682()), (float)player.method_23318()), (float)player.method_23321(), c, MathUtility.random(0.0f, 180.0f), MathUtility.random(10.0f, 60.0f), 0.0f));
            }
        }
    }

    @Override
    public void onRender3D(class_4587 stack) {
        RenderSystem.disableDepthTest();
        if (HitParticles.mc.field_1724 != null && HitParticles.mc.field_1687 != null) {
            for (Particle particle : this.particles) {
                particle.render(stack);
            }
        }
        RenderSystem.enableDepthTest();
    }

    public static enum Mode {
        Orbiz,
        Stars,
        Hearts,
        Bloom,
        Text;

    }

    public static enum Physics {
        Fall,
        Fly;

    }

    public static enum ColorMode {
        Custom,
        Sync;

    }

    public class Particle {
        float x;
        float y;
        float z;
        float px;
        float py;
        float pz;
        float motionX;
        float motionY;
        float motionZ;
        float rotationAngle;
        float rotationSpeed;
        float health;
        long time;
        Color color;

        public Particle(float x, float y, float z, Color color, float rotationAngle, float rotationSpeed, float health) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.px = x;
            this.py = y;
            this.pz = z;
            this.motionX = MathUtility.random(-((float)HitParticles.this.speed.getValue().intValue()) / 50.0f, (float)HitParticles.this.speed.getValue().intValue() / 50.0f);
            this.motionY = MathUtility.random(-((float)HitParticles.this.speed.getValue().intValue()) / 50.0f, (float)HitParticles.this.speed.getValue().intValue() / 50.0f);
            this.motionZ = MathUtility.random(-((float)HitParticles.this.speed.getValue().intValue()) / 50.0f, (float)HitParticles.this.speed.getValue().intValue() / 50.0f);
            this.time = System.currentTimeMillis();
            this.color = color;
            this.rotationAngle = rotationAngle;
            this.rotationSpeed = rotationSpeed;
            this.health = health;
        }

        public long getTime() {
            return this.time;
        }

        public boolean update() {
            double sp = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            this.px = this.x;
            this.py = this.y;
            this.pz = this.z;
            this.x += this.motionX;
            this.y += this.motionY;
            this.z += this.motionZ;
            if (this.posBlock(this.x, this.y - HitParticles.this.starsScale.getValue().floatValue() / 10.0f, this.z)) {
                this.motionY = -this.motionY / 1.1f;
                this.motionX /= 1.1f;
                this.motionZ /= 1.1f;
            } else if (this.posBlock((double)this.x - sp, this.y, (double)this.z - sp) || this.posBlock((double)this.x + sp, this.y, (double)this.z + sp) || this.posBlock((double)this.x + sp, this.y, (double)this.z - sp) || this.posBlock((double)this.x - sp, this.y, (double)this.z + sp) || this.posBlock((double)this.x + sp, this.y, this.z) || this.posBlock((double)this.x - sp, this.y, this.z) || this.posBlock(this.x, this.y, (double)this.z + sp) || this.posBlock(this.x, this.y, (double)this.z - sp)) {
                this.motionX = -this.motionX;
                this.motionZ = -this.motionZ;
            }
            if (HitParticles.this.physics.getValue() == Physics.Fall) {
                this.motionY -= 0.035f;
            }
            this.motionX /= 1.005f;
            this.motionZ /= 1.005f;
            this.motionY /= 1.005f;
            return System.currentTimeMillis() - this.getTime() > (long)(HitParticles.this.lifeTime.getValue() * 1000);
        }

        public void render(class_4587 matrixStack) {
            float size = HitParticles.this.starsScale.getValue().floatValue();
            float scale = HitParticles.this.mode.is(Mode.Text) ? 0.025f * size : 0.07f;
            double posX = Render2DEngine.interpolate(this.px, this.x, Render3DEngine.getTickDelta()) - Module.mc.method_1561().field_4686.method_19326().method_10216();
            double posY = Render2DEngine.interpolate(this.py, this.y, Render3DEngine.getTickDelta()) + 0.1 - Module.mc.method_1561().field_4686.method_19326().method_10214();
            double posZ = Render2DEngine.interpolate(this.pz, this.z, Render3DEngine.getTickDelta()) - Module.mc.method_1561().field_4686.method_19326().method_10215();
            matrixStack.method_22903();
            matrixStack.method_22904(posX, posY, posZ);
            matrixStack.method_22905(scale, scale, scale);
            matrixStack.method_46416(size / 2.0f, size / 2.0f, size / 2.0f);
            matrixStack.method_22907(class_7833.field_40716.rotationDegrees(-Module.mc.field_1773.method_19418().method_19330()));
            matrixStack.method_22907(class_7833.field_40714.rotationDegrees(Module.mc.field_1773.method_19418().method_19329()));
            if (HitParticles.this.mode.is(Mode.Text)) {
                matrixStack.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
            } else {
                matrixStack.method_22907(class_7833.field_40718.rotationDegrees(this.rotationAngle += AnimationUtility.deltaTime() * this.rotationSpeed));
            }
            matrixStack.method_46416(-size / 2.0f, -size / 2.0f, -size / 2.0f);
            switch (HitParticles.this.mode.getValue().ordinal()) {
                case 0: {
                    Render2DEngine.drawOrbiz(matrixStack, 0.0f, 0.3, this.color);
                    Render2DEngine.drawOrbiz(matrixStack, -0.1f, 0.5, this.color);
                    Render2DEngine.drawOrbiz(matrixStack, -0.2f, 0.7, this.color);
                    break;
                }
                case 1: {
                    Render2DEngine.drawStar(matrixStack, this.color, size);
                    break;
                }
                case 2: {
                    Render2DEngine.drawHeart(matrixStack, this.color, size);
                    break;
                }
                case 3: {
                    Render2DEngine.drawBloom(matrixStack, this.color, size);
                    break;
                }
                case 4: {
                    FontRenderers.sf_medium.drawCenteredString(matrixStack, MathUtility.round2(this.health) + " ", 0.0, 0.0, (this.health > 0.0f ? HitParticles.this.colorH.getValue() : HitParticles.this.colorD.getValue()).getColorObject());
                }
            }
            matrixStack.method_22905(0.8f, 0.8f, 0.8f);
            matrixStack.method_22909();
        }

        private boolean posBlock(double x, double y, double z) {
            class_2248 b = Module.mc.field_1687.method_8320(class_2338.method_49637((double)x, (double)y, (double)z)).method_26204();
            return !(b instanceof class_2189) && b != class_2246.field_10382 && b != class_2246.field_10164;
        }
    }
}

