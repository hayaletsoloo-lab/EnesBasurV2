/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.Vec3d
 */
package thunder.hack.features.modules.render;

import java.awt.Color;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render3DEngine;

public class Tracers
extends Module {
    private final Setting<Float> height = new Setting<Float>("Height", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(2.0f));
    private final Setting<ColorSetting> color = new Setting<ColorSetting>("Color", new ColorSetting(new Color(-1812004864, true)));
    private final Setting<ColorSetting> friendColor = new Setting<ColorSetting>("Friends", new ColorSetting(new Color(-1827152291, true)));

    public Tracers() {
        super("Tracers", Module.Category.RENDER);
    }

    @Override
    public void onRender3D(class_4587 stack) {
        for (class_1657 playerEntity : Managers.ASYNC.getAsyncPlayers()) {
            if (playerEntity == Tracers.mc.field_1724) continue;
            Color color1 = this.color.getValue().getColorObject();
            if (Managers.FRIEND.isFriend(playerEntity)) {
                color1 = this.friendColor.getValue().getColorObject();
            }
            double x1 = Tracers.mc.field_1724.field_6014 + (Tracers.mc.field_1724.method_23317() - Tracers.mc.field_1724.field_6014) * (double)Render3DEngine.getTickDelta();
            double y1 = (double)Tracers.mc.field_1724.method_18381(Tracers.mc.field_1724.method_18376()) + Tracers.mc.field_1724.field_6036 + (Tracers.mc.field_1724.method_23318() - Tracers.mc.field_1724.field_6036) * (double)Render3DEngine.getTickDelta();
            double z1 = Tracers.mc.field_1724.field_5969 + (Tracers.mc.field_1724.method_23321() - Tracers.mc.field_1724.field_5969) * (double)Render3DEngine.getTickDelta();
            class_243 vec2 = new class_243(0.0, 0.0, 75.0).method_1037(-((float)Math.toRadians(Tracers.mc.field_1773.method_19418().method_19329()))).method_1024(-((float)Math.toRadians(Tracers.mc.field_1773.method_19418().method_19330()))).method_1031(x1, y1, z1);
            double x = playerEntity.field_6014 + (playerEntity.method_23317() - playerEntity.field_6014) * (double)Render3DEngine.getTickDelta();
            double y = playerEntity.field_6036 + (playerEntity.method_23318() - playerEntity.field_6036) * (double)Render3DEngine.getTickDelta();
            double z = playerEntity.field_5969 + (playerEntity.method_23321() - playerEntity.field_5969) * (double)Render3DEngine.getTickDelta();
            Render3DEngine.drawLineDebug(vec2, new class_243(x, y + (double)this.height.getValue().floatValue(), z), color1);
        }
    }
}

