/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.RenderLayer
 *  net.minecraft.client.render.VertexConsumer
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.entity.model.EntityModelLayers
 *  net.minecraft.client.render.entity.model.RabbitEntityModel
 *  net.minecraft.client.render.entity.model.VexEntityModel
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.EntityType
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.mob.VexEntity
 *  net.minecraft.entity.passive.RabbitEntity
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.World
 */
package thunder.hack.features.modules.render;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1463;
import net.minecraft.class_1634;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5602;
import net.minecraft.class_596;
import net.minecraft.class_617;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class CustomModels
extends Module {
    public final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Rabbit);
    public final Setting<Float> scale = new Setting<Float>("Scale", Float.valueOf(1.5f), Float.valueOf(0.1f), Float.valueOf(5.0f));
    public class_596<class_1463> rabbitModel;
    public class_617 devilModel;
    public class_1463 dummyRabbit;
    public class_1634 dummyDevil;
    private static final class_2960 RABBIT_TEXTURE = class_2960.method_60654((String)"textures/entity/rabbit/white.png");
    private static final class_2960 DEVIL_TEXTURE = class_2960.method_60654((String)"textures/entity/illager/vex.png");
    private static final class_2960 BLACK_RABBIT_TEXTURE = class_2960.method_60654((String)"textures/entity/rabbit/black.png");

    public CustomModels() {
        super("CustomModels", Module.Category.RENDER);
    }

    @Override
    public void onEnable() {
        if (this.rabbitModel == null) {
            this.rabbitModel = new class_596(mc.method_31974().method_32072(class_5602.field_27590));
            this.devilModel = new class_617(mc.method_31974().method_32072(class_5602.field_27674));
        }
    }

    public boolean onRenderModel(class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, class_1309 entity, float tickDelta) {
        if (!this.isEnabled() || entity != CustomModels.mc.field_1724) {
            return false;
        }
        if (this.rabbitModel == null || this.devilModel == null) {
            this.rabbitModel = new class_596(mc.method_31974().method_32072(class_5602.field_27590));
            this.devilModel = new class_617(mc.method_31974().method_32072(class_5602.field_27674));
        }
        if ((this.dummyRabbit == null || this.dummyDevil == null) && CustomModels.mc.field_1687 != null) {
            this.dummyRabbit = new class_1463(class_1299.field_6140, (class_1937)CustomModels.mc.field_1687);
            this.dummyDevil = new class_1634(class_1299.field_6059, (class_1937)CustomModels.mc.field_1687);
        }
        float h = class_3532.method_17821((float)tickDelta, (float)entity.field_6220, (float)entity.field_6283);
        float j = class_3532.method_17821((float)tickDelta, (float)entity.field_6259, (float)entity.field_6241);
        float headYaw = j - h;
        float headPitch = class_3532.method_16439((float)tickDelta, (float)entity.field_6004, (float)entity.method_36455());
        float s = this.scale.getValue().floatValue();
        matrices.method_22903();
        matrices.method_22905(s, s, s);
        if (this.mode.getValue() == Mode.Rabbit || this.mode.getValue() == Mode.BlackRabbit) {
            class_2960 tex = this.mode.getValue() == Mode.Rabbit ? RABBIT_TEXTURE : BLACK_RABBIT_TEXTURE;
            class_4588 buffer = vertexConsumers.getBuffer(class_1921.method_23578((class_2960)tex));
            if (this.dummyRabbit != null) {
                this.rabbitModel.method_17117(this.dummyRabbit, entity.field_42108.method_48572(tickDelta), entity.field_42108.method_48570(tickDelta), (float)entity.field_6012 + tickDelta, headYaw, headPitch);
            }
            this.rabbitModel.method_2828(matrices, buffer, light, overlay, -1);
        } else if (this.mode.getValue() == Mode.Devil) {
            class_4588 buffer = vertexConsumers.getBuffer(class_1921.method_23580((class_2960)DEVIL_TEXTURE));
            if (this.dummyDevil != null) {
                this.devilModel.method_17127(this.dummyDevil, entity.field_42108.method_48572(tickDelta), entity.field_42108.method_48570(tickDelta), (float)entity.field_6012 + tickDelta, headYaw, headPitch);
            }
            this.devilModel.method_2828(matrices, buffer, light, overlay, -65536);
        }
        matrices.method_22909();
        return true;
    }

    public static enum Mode {
        Rabbit,
        Devil,
        BlackRabbit;

    }
}

