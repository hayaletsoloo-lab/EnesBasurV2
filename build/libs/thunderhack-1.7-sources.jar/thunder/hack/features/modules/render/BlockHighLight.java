/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.Box
 */
package thunder.hack.features.modules.render;

import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public class BlockHighLight
extends Module {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Outline);
    private final Setting<ColorSetting> color = new Setting<ColorSetting>("Color", new ColorSetting(-1));
    private final Setting<Float> lineWidth = new Setting<Float>("LineWidth", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(5.0f));

    public BlockHighLight() {
        super("BlockHighLight", Module.Category.RENDER);
    }

    @Override
    public void onRender3D(class_4587 stack) {
        if (BlockHighLight.mc.field_1765 == null) {
            return;
        }
        if (BlockHighLight.mc.field_1765.method_17783() != class_239.class_240.field_1332) {
            return;
        }
        class_239 ItemStackParticleEffect = BlockHighLight.mc.field_1765;
        if (!(ItemStackParticleEffect instanceof class_3965)) {
            return;
        }
        class_3965 bhr = (class_3965)ItemStackParticleEffect;
        switch (this.mode.getValue().ordinal()) {
            case 0: {
                Render3DEngine.drawBoxOutline(new class_238(bhr.method_17777()), Render2DEngine.injectAlpha(this.color.getValue().getColorObject(), 255), this.lineWidth.getValue().floatValue());
                Render3DEngine.drawFilledBox(stack, new class_238(bhr.method_17777()), this.color.getValue().getColorObject());
                break;
            }
            case 1: {
                Render3DEngine.drawSideOutline(new class_238(bhr.method_17777()), Render2DEngine.injectAlpha(this.color.getValue().getColorObject(), 255), this.lineWidth.getValue().floatValue(), bhr.method_17780());
                Render3DEngine.drawFilledSide(stack, new class_238(bhr.method_17777()), this.color.getValue().getColorObject(), bhr.method_17780());
                break;
            }
            case 2: {
                Render3DEngine.drawFilledBox(stack, new class_238(bhr.method_17777()), this.color.getValue().getColorObject());
                break;
            }
            case 3: {
                Render3DEngine.drawFilledSide(stack, new class_238(bhr.method_17777()), this.color.getValue().getColorObject(), bhr.method_17780());
                break;
            }
            case 4: {
                Render3DEngine.drawBoxOutline(new class_238(bhr.method_17777()), Render2DEngine.injectAlpha(this.color.getValue().getColorObject(), 255), this.lineWidth.getValue().floatValue());
                break;
            }
            case 5: {
                Render3DEngine.drawSideOutline(new class_238(bhr.method_17777()), Render2DEngine.injectAlpha(this.color.getValue().getColorObject(), 255), this.lineWidth.getValue().floatValue(), bhr.method_17780());
            }
        }
    }

    private static enum Mode {
        Both,
        BothSide,
        Fill,
        FilledSide,
        Outline,
        OutlinedSide;

    }
}

