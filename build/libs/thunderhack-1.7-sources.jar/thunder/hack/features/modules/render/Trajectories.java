/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.projectile.ArrowEntity
 *  net.minecraft.item.BowItem
 *  net.minecraft.item.CrossbowItem
 *  net.minecraft.item.EggItem
 *  net.minecraft.item.EnderPearlItem
 *  net.minecraft.item.ExperienceBottleItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.LingeringPotionItem
 *  net.minecraft.item.SnowballItem
 *  net.minecraft.item.SplashPotionItem
 *  net.minecraft.item.TridentItem
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.util.Hand
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext$FluidHandling
 *  net.minecraft.world.RaycastContext$ShapeType
 */
package thunder.hack.features.modules.render;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1667;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1803;
import net.minecraft.class_1823;
import net.minecraft.class_1828;
import net.minecraft.class_1835;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public class Trajectories
extends Module {
    private final Setting<Mode> mode = new Setting<Mode>("ColorMode", Mode.Sync);
    private final Setting<ColorSetting> color = new Setting<ColorSetting>("Color", new ColorSetting(575714484), v -> this.mode.getValue() == Mode.Custom);
    private final Setting<Mode> lmode = new Setting<Mode>("LandedColorMode", Mode.Sync);
    private final Setting<ColorSetting> lcolor = new Setting<ColorSetting>("LandedColor", new ColorSetting(575714484), v -> this.lmode.getValue() == Mode.Custom);

    public Trajectories() {
        super("Trajectories", Module.Category.RENDER);
    }

    private boolean isThrowable(class_1792 item) {
        return item instanceof class_1776 || item instanceof class_1835 || item instanceof class_1779 || item instanceof class_1823 || item instanceof class_1771 || item instanceof class_1828 || item instanceof class_1803;
    }

    private float getDistance(class_1792 item) {
        return item instanceof class_1753 ? 1.0f : 0.4f;
    }

    private float getThrowVelocity(class_1792 item) {
        if (item instanceof class_1828 || item instanceof class_1803) {
            return 0.5f;
        }
        if (item instanceof class_1779) {
            return 0.59f;
        }
        if (item instanceof class_1835) {
            return 2.0f;
        }
        return 1.5f;
    }

    private int getThrowPitch(class_1792 item) {
        if (item instanceof class_1828 || item instanceof class_1803 || item instanceof class_1779) {
            return 20;
        }
        return 0;
    }

    @Override
    public void onRender3D(class_4587 stack) {
        class_1268 hand;
        if (Trajectories.mc.field_1690.field_1842) {
            return;
        }
        if (Trajectories.mc.field_1724 == null || Trajectories.mc.field_1687 == null || !Trajectories.mc.field_1690.method_31044().method_31034()) {
            return;
        }
        class_1799 mainHand = Trajectories.mc.field_1724.method_6047();
        class_1799 offHand = Trajectories.mc.field_1724.method_6079();
        if (mainHand.method_7909() instanceof class_1753 || mainHand.method_7909() instanceof class_1764 || this.isThrowable(mainHand.method_7909())) {
            hand = class_1268.field_5808;
        } else if (offHand.method_7909() instanceof class_1753 || offHand.method_7909() instanceof class_1764 || this.isThrowable(offHand.method_7909())) {
            hand = class_1268.field_5810;
        } else {
            return;
        }
        boolean prev_bob = (Boolean)Trajectories.mc.field_1690.method_42448().method_41753();
        Trajectories.mc.field_1690.method_42448().method_41748(false);
        if (offHand.method_7909() instanceof class_1764 && class_1890.method_8225((class_6880)((class_6880)Trajectories.mc.field_1687.method_30349().method_30530(class_1893.field_9108.method_58273()).method_40264(class_1893.field_9108).get()), (class_1799)offHand) != 0 || mainHand.method_7909() instanceof class_1764 && class_1890.method_8225((class_6880)((class_6880)Trajectories.mc.field_1687.method_30349().method_30530(class_1893.field_9108.method_58273()).method_40264(class_1893.field_9108).get()), (class_1799)mainHand) != 0) {
            this.calcTrajectory(hand == class_1268.field_5810 ? offHand.method_7909() : mainHand.method_7909(), Trajectories.mc.field_1724.method_36454() - 10.0f);
            this.calcTrajectory(hand == class_1268.field_5810 ? offHand.method_7909() : mainHand.method_7909(), Trajectories.mc.field_1724.method_36454());
            this.calcTrajectory(hand == class_1268.field_5810 ? offHand.method_7909() : mainHand.method_7909(), Trajectories.mc.field_1724.method_36454() + 10.0f);
        } else {
            this.calcTrajectory(hand == class_1268.field_5810 ? offHand.method_7909() : mainHand.method_7909(), Trajectories.mc.field_1724.method_36454());
        }
        Trajectories.mc.field_1690.method_42448().method_41748(prev_bob);
    }

    private void calcTrajectory(class_1792 item, float yaw) {
        double x = Render2DEngine.interpolate(Trajectories.mc.field_1724.field_6014, Trajectories.mc.field_1724.method_23317(), Render3DEngine.getTickDelta());
        double y = Render2DEngine.interpolate(Trajectories.mc.field_1724.field_6036, Trajectories.mc.field_1724.method_23318(), Render3DEngine.getTickDelta());
        double z = Render2DEngine.interpolate(Trajectories.mc.field_1724.field_5969, Trajectories.mc.field_1724.method_23321(), Render3DEngine.getTickDelta());
        y = y + (double)Trajectories.mc.field_1724.method_18381(Trajectories.mc.field_1724.method_18376()) - 0.1000000014901161;
        if (item == Trajectories.mc.field_1724.method_6047().method_7909()) {
            x -= (double)(class_3532.method_15362((float)(yaw / 180.0f * (float)Math.PI)) * 0.16f);
            z -= (double)(class_3532.method_15374((float)(yaw / 180.0f * (float)Math.PI)) * 0.16f);
        } else {
            x += (double)(class_3532.method_15362((float)(yaw / 180.0f * (float)Math.PI)) * 0.16f);
            z += (double)(class_3532.method_15374((float)(yaw / 180.0f * (float)Math.PI)) * 0.16f);
        }
        float maxDist = this.getDistance(item);
        double motionX = -class_3532.method_15374((float)(yaw / 180.0f * (float)Math.PI)) * class_3532.method_15362((float)(Trajectories.mc.field_1724.method_36455() / 180.0f * (float)Math.PI)) * maxDist;
        double motionY = -class_3532.method_15374((float)((Trajectories.mc.field_1724.method_36455() - (float)this.getThrowPitch(item)) / 180.0f * 3.141593f)) * maxDist;
        double motionZ = class_3532.method_15362((float)(yaw / 180.0f * (float)Math.PI)) * class_3532.method_15362((float)(Trajectories.mc.field_1724.method_36455() / 180.0f * (float)Math.PI)) * maxDist;
        float power = (float)Trajectories.mc.field_1724.method_6048() / 20.0f;
        power = (power * power + power * 2.0f) / 3.0f;
        if (power > 1.0f || power == 0.0f) {
            power = 1.0f;
        }
        float distance = class_3532.method_15355((float)((float)(motionX * motionX + motionY * motionY + motionZ * motionZ)));
        motionX /= (double)distance;
        motionY /= (double)distance;
        motionZ /= (double)distance;
        float pow = (item instanceof class_1753 ? power * 2.0f : (item instanceof class_1764 ? 2.2f : 1.0f)) * this.getThrowVelocity(item);
        motionX *= (double)pow;
        motionY *= (double)pow;
        motionZ *= (double)pow;
        if (!Trajectories.mc.field_1724.method_24828()) {
            motionY += Trajectories.mc.field_1724.method_18798().method_10214();
        }
        for (int i = 0; i < 300; ++i) {
            class_3965 bhr;
            class_243 lastPos = new class_243(x, y, z);
            if (Trajectories.mc.field_1687.method_8320(new class_2338((int)(x += motionX), (int)(y += motionY), (int)(z += motionZ))).method_26204() == class_2246.field_10382) {
                motionX *= 0.8;
                motionY *= 0.8;
                motionZ *= 0.8;
            } else {
                motionX *= 0.99;
                motionY *= 0.99;
                motionZ *= 0.99;
            }
            motionY = item instanceof class_1753 ? (motionY = motionY - (double)0.05f) : (Trajectories.mc.field_1724.method_6047().method_7909() instanceof class_1764 ? (motionY = motionY - (double)0.05f) : (motionY = motionY - (double)0.03f));
            class_243 pos = new class_243(x, y, z);
            for (class_1297 ent : Trajectories.mc.field_1687.method_18112()) {
                if (ent instanceof class_1667 || ent.equals(Trajectories.mc.field_1724) || !ent.method_5829().method_994(new class_238(x - 0.3, y - 0.3, z - 0.3, x + 0.3, y + 0.3, z + 0.3))) continue;
                Render3DEngine.OUTLINE_QUEUE.add(new Render3DEngine.OutlineAction(ent.method_5829(), this.lmode.getValue() == Mode.Sync ? HudEditor.getColor(i * 10) : this.lcolor.getValue().getColorObject(), 2.0f));
                Render3DEngine.FILLED_QUEUE.add(new Render3DEngine.FillAction(ent.method_5829(), this.lmode.getValue() == Mode.Sync ? Render2DEngine.injectAlpha(HudEditor.getColor(i * 10), 100) : this.lcolor.getValue().getColorObject()));
                break;
            }
            if ((bhr = Trajectories.mc.field_1687.method_17742(new class_3959(lastPos, pos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)Trajectories.mc.field_1724))) != null && bhr.method_17783() == class_239.class_240.field_1332) {
                Render3DEngine.OUTLINE_SIDE_QUEUE.add(new Render3DEngine.OutlineSideAction(new class_238(bhr.method_17777()), this.lmode.getValue() == Mode.Sync ? HudEditor.getColor(i * 10) : this.lcolor.getValue().getColorObject(), 2.0f, bhr.method_17780()));
                Render3DEngine.FILLED_SIDE_QUEUE.add(new Render3DEngine.FillSideAction(new class_238(bhr.method_17777()), this.lmode.getValue() == Mode.Sync ? Render2DEngine.injectAlpha(HudEditor.getColor(i * 10), 100) : this.lcolor.getValue().getColorObject(), bhr.method_17780()));
                break;
            }
            if (y <= -65.0) break;
            if (motionX == 0.0 && motionY == 0.0 && motionZ == 0.0) continue;
            Render3DEngine.drawLine(lastPos, pos, this.mode.getValue() == Mode.Sync ? HudEditor.getColor(i) : this.color.getValue().getColorObject());
        }
    }

    private static enum Mode {
        Custom,
        Sync;

    }
}

