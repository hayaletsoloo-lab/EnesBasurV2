/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.render.OverlayTexture
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.render.model.json.ModelTransformationMode
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.world.World
 */
package thunder.hack.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class TotemAnimation
extends Module {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.FadeOut);
    private final Setting<Integer> speed = new Setting<Integer>("Speed", 40, 1, 100);
    private class_1799 floatingItem = null;
    private int floatingItemTimeLeft;

    public TotemAnimation() {
        super("TotemAnimation", Module.Category.RENDER);
    }

    public void showFloatingItem(class_1799 floatingItem) {
        this.floatingItem = floatingItem;
        this.floatingItemTimeLeft = this.getTime();
    }

    @Override
    public void onUpdate() {
        if (this.floatingItemTimeLeft > 0) {
            --this.floatingItemTimeLeft;
            if (this.floatingItemTimeLeft == 0) {
                this.floatingItem = null;
            }
        }
    }

    public void renderFloatingItem(float tickDelta) {
        if (this.floatingItem != null && this.floatingItemTimeLeft > 0 && !this.mode.is(Mode.Off)) {
            int scaledWidth = mc.method_22683().method_4486();
            int scaledHeight = mc.method_22683().method_4502();
            int elapsedTime = this.getTime() - this.floatingItemTimeLeft;
            float animationProgress = ((float)elapsedTime + tickDelta) / (float)this.getTime();
            float progressSquared = animationProgress * animationProgress;
            float progressCubed = animationProgress * progressSquared;
            float oscillationFactor = 10.25f * progressCubed * progressSquared - 24.95f * progressSquared * progressSquared + 25.5f * progressCubed - 13.8f * progressSquared + 4.0f * animationProgress;
            float oscillationRadians = oscillationFactor * (float)Math.PI;
            RenderSystem.enableDepthTest();
            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            class_4587 matrixStack = new class_4587();
            matrixStack.method_22903();
            float adjustedProgress = (float)elapsedTime + tickDelta;
            float scale = 50.0f + 175.0f * class_3532.method_15374((float)oscillationRadians);
            switch (this.mode.getValue().ordinal()) {
                case 0: {
                    float x2 = (float)(Math.sin(adjustedProgress * 112.0f / 180.0f) * 100.0);
                    float y2 = (float)(Math.cos(adjustedProgress * 112.0f / 180.0f) * 50.0);
                    matrixStack.method_46416((float)(scaledWidth / 2) + x2, (float)(scaledHeight / 2) + y2, -50.0f);
                    matrixStack.method_22905(scale, -scale, scale);
                    break;
                }
                case 1: {
                    matrixStack.method_46416((float)(scaledWidth / 2), (float)(scaledHeight / 2), -50.0f);
                    matrixStack.method_22905(scale, -scale, scale);
                    break;
                }
                case 2: {
                    matrixStack.method_46416((float)(scaledWidth / 2), (float)(scaledHeight / 2), -50.0f);
                    matrixStack.method_22907(class_7833.field_40714.rotationDegrees(adjustedProgress * 2.0f));
                    matrixStack.method_22907(class_7833.field_40718.rotationDegrees(adjustedProgress * 2.0f));
                    matrixStack.method_22905(200.0f - adjustedProgress * 1.5f, -200.0f + adjustedProgress * 1.5f, 200.0f - adjustedProgress * 1.5f);
                    break;
                }
                case 3: {
                    matrixStack.method_46416((float)(scaledWidth / 2), (float)(scaledHeight / 2), -50.0f);
                    matrixStack.method_22907(class_7833.field_40714.rotationDegrees(adjustedProgress * 3.0f));
                    matrixStack.method_22905(200.0f - adjustedProgress * 1.5f, -200.0f + adjustedProgress * 1.5f, 200.0f - adjustedProgress * 1.5f);
                    break;
                }
                case 4: {
                    float downFactor = (float)(Math.pow(adjustedProgress, 3.0) * (double)0.2f);
                    matrixStack.method_46416((float)(scaledWidth / 2), (float)(scaledHeight / 2) + downFactor, -50.0f);
                    matrixStack.method_22907(class_7833.field_40718.rotationDegrees(adjustedProgress * 5.0f));
                    matrixStack.method_22905(200.0f - adjustedProgress * 1.5f, -200.0f + adjustedProgress * 1.5f, 200.0f - adjustedProgress * 1.5f);
                    break;
                }
                case 5: {
                    float downFactor = (float)(Math.pow(adjustedProgress, 3.0) * (double)0.2f) - 20.0f;
                    matrixStack.method_46416((float)(scaledWidth / 2), (float)(scaledHeight / 2) - downFactor, -50.0f);
                    matrixStack.method_22907(class_7833.field_40716.rotationDegrees(adjustedProgress * (float)this.floatingItemTimeLeft * 2.0f));
                    matrixStack.method_22905(200.0f - adjustedProgress * 1.5f, -200.0f + adjustedProgress * 1.5f, 200.0f - adjustedProgress * 1.5f);
                    break;
                }
                case 6: {
                    float rightFactor = (float)(Math.pow(adjustedProgress, 2.0) * 4.5);
                    matrixStack.method_46416((float)(scaledWidth / 2) + rightFactor, (float)(scaledHeight / 2), -50.0f);
                    matrixStack.method_22907(class_7833.field_40718.rotationDegrees(adjustedProgress * 40.0f));
                    matrixStack.method_22905(200.0f - adjustedProgress * 1.5f, -200.0f + adjustedProgress * 1.5f, 200.0f - adjustedProgress * 1.5f);
                }
            }
            class_4597.class_4598 immediate = mc.method_22940().method_23000();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)(1.0f - animationProgress));
            mc.method_1480().method_23178(this.floatingItem, class_811.field_4319, 0xF000F0, class_4608.field_21444, matrixStack, (class_4597)immediate, (class_1937)TotemAnimation.mc.field_1687, 0);
            matrixStack.method_22909();
            immediate.method_22993();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            RenderSystem.disableBlend();
            RenderSystem.enableCull();
            RenderSystem.disableDepthTest();
        }
    }

    private int getTime() {
        int invertedSpeed = 101 - this.speed.getValue();
        if (this.mode.is(Mode.FadeOut)) {
            return invertedSpeed / 4;
        }
        if (this.mode.is(Mode.Insert)) {
            return invertedSpeed / 2;
        }
        return invertedSpeed;
    }

    private static enum Mode {
        FadeOut,
        Size,
        Otkisuli,
        Insert,
        Fall,
        Rocket,
        Roll,
        Off;

    }
}

