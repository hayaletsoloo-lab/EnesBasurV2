/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.DrawContext
 */
package thunder.hack.features.modules.render;

import java.awt.Color;
import net.minecraft.class_332;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;

public class DamageTint
extends Module {
    public DamageTint() {
        super("DamageTint", Module.Category.RENDER);
    }

    @Override
    public void onRender2D(class_332 context) {
        float factor = 1.0f - MathUtility.clamp(DamageTint.mc.field_1724.method_6032(), 0.0f, 12.0f) / 12.0f;
        Color red = new Color(0xFF0000, true);
        if (factor < 1.0f) {
            Render2DEngine.draw2DGradientRect(context.method_51448(), 0.0f, 0.0f, mc.method_22683().method_4486(), mc.method_22683().method_4502(), Render2DEngine.injectAlpha(red, (int)(factor * 170.0f)), red, Render2DEngine.injectAlpha(red, (int)(factor * 170.0f)), red);
        }
    }
}

