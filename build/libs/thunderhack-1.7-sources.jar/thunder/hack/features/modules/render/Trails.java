/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.block.Block
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.Camera
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.projectile.ArrowEntity
 *  net.minecraft.entity.projectile.thrown.EnderPearlEntity
 *  net.minecraft.entity.projectile.thrown.ExperienceBottleEntity
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext$FluidHandling
 *  net.minecraft.world.RaycastContext$ShapeType
 *  org.joml.Matrix4f
 */
package thunder.hack.features.modules.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1683;
import net.minecraft.class_1684;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3959;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.joml.Matrix4f;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.render.HitParticles;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.interfaces.IEntity;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;

public class Trails
extends Module {
    private final Setting<Boolean> xp = new Setting<Boolean>("Xp", false);
    private final Setting<Particles> pearls = new Setting<Particles>("Pearls", Particles.Particles);
    private final Setting<Particles> arrows = new Setting<Particles>("Arrows", Particles.Particles);
    private final Setting<Players> players = new Setting<Players>("Players", Players.Particles);
    private final Setting<Boolean> onlySelf = new Setting<Boolean>("OnlySelf", false, v -> this.players.getValue() != Players.None);
    private final Setting<ColorSetting> color = new Setting<ColorSetting>("Color", new ColorSetting(-2013200640));
    private final Setting<Float> down = new Setting<Float>("Down", Float.valueOf(0.5f), Float.valueOf(0.0f), Float.valueOf(2.0f));
    private final Setting<Float> width = new Setting<Float>("Height", Float.valueOf(1.3f), Float.valueOf(0.1f), Float.valueOf(2.0f));
    private final Setting<Integer> speed = new Setting<Integer>("Speed", 2, 1, 20, v -> this.players.is(Players.Particles) || this.arrows.is(Particles.Particles) || this.pearls.is(Particles.Particles));
    private final Setting<HitParticles.Mode> mode = new Setting<HitParticles.Mode>("Mode", HitParticles.Mode.Stars);
    private final Setting<HitParticles.Physics> physics = new Setting<HitParticles.Physics>("Physics", HitParticles.Physics.Fall, v -> this.players.is(Players.Particles) || this.arrows.is(Particles.Particles) || this.pearls.is(Particles.Particles));
    private final Setting<Integer> starsScale = new Setting<Integer>("Scale", 3, 1, 10, v -> this.players.is(Players.Particles) || this.arrows.is(Particles.Particles) || this.pearls.is(Particles.Particles));
    private final Setting<Integer> amount = new Setting<Integer>("Amount", 2, 1, 5, v -> this.players.is(Players.Particles) || this.arrows.is(Particles.Particles) || this.pearls.is(Particles.Particles));
    private final Setting<Integer> lifeTime = new Setting<Integer>("LifeTime", 2, 1, 10, v -> this.players.is(Players.Particles) || this.arrows.is(Particles.Particles) || this.pearls.is(Particles.Particles));
    private final Setting<Mode> lmode = new Setting<Mode>("ColorMode", Mode.Sync);
    private final Setting<ColorSetting> lcolor = new Setting<ColorSetting>("Color2", new ColorSetting(575714484), v -> this.lmode.getValue() == Mode.Custom);
    private List<Particle> particles = new ArrayList<Particle>();

    public Trails() {
        super("Trails", Module.Category.RENDER);
    }

    @Override
    public void onRender3D(class_4587 stack) {
        for (class_1297 en : Managers.ASYNC.getAsyncEntities()) {
            if (en instanceof class_1684 && this.pearls.is(Particles.Trail)) {
                this.calcTrajectory(en);
            }
            if (en instanceof class_1667 && this.arrows.is(Particles.Trail)) {
                this.calcTrajectory(en);
            }
            if (!(en instanceof class_1683) || !this.xp.getValue().booleanValue()) continue;
            this.calcTrajectory(en);
        }
        if (this.players.getValue() == Players.Trail) {
            for (class_1657 entity : Trails.mc.field_1687.method_18456()) {
                if (entity != Trails.mc.field_1724 && this.onlySelf.getValue().booleanValue()) continue;
                float alpha = (float)this.color.getValue().getAlpha() / 255.0f;
                if (((IEntity)entity).getTrails().isEmpty()) continue;
                stack.method_22903();
                RenderSystem.disableCull();
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.enableDepthTest();
                RenderSystem.depthFunc((int)515);
                RenderSystem.setShader(class_757::method_34540);
                class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (int i = 0; i < ((IEntity)entity).getTrails().size(); ++i) {
                    Trail ctx = ((IEntity)entity).getTrails().get(i);
                    class_243 pos = ctx.interpolate(Render3DEngine.getTickDelta());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + this.down.getValue().floatValue(), (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(((IEntity)entity).getTrails().get(i).color(), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + this.width.getValue().floatValue() + this.down.getValue().floatValue(), (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(((IEntity)entity).getTrails().get(i).color(), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                Render3DEngine.endRender();
                RenderSystem.enableCull();
                RenderSystem.disableDepthTest();
                stack.method_22909();
            }
        } else if (this.players.getValue() == Players.Tail) {
            for (class_1657 entity : Trails.mc.field_1687.method_18456()) {
                if (entity != Trails.mc.field_1724 && this.onlySelf.getValue().booleanValue()) continue;
                float alpha = this.color.getValue().getAlpha();
                class_4184 camera = Trails.mc.field_1773.method_19418();
                stack.method_22903();
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.firefly);
                RenderSystem.enableBlend();
                RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
                RenderSystem.enableDepthTest();
                RenderSystem.depthMask((boolean)false);
                RenderSystem.setShader(class_757::method_34543);
                class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
                int size = ((IEntity)entity).getTrails().size();
                if (!((IEntity)entity).getTrails().isEmpty()) {
                    for (int i = 0; i < size; ++i) {
                        Trail ctx = ((IEntity)entity).getTrails().get(i);
                        class_4587 matrices = new class_4587();
                        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                        matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
                        class_243 pos = ctx.interpolate(Render3DEngine.getTickDelta());
                        matrices.method_22904(pos.field_1352, pos.field_1351 + (double)0.9f, pos.field_1350);
                        matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
                        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                        Matrix4f matrix = matrices.method_23760().method_23761();
                        Color col = ctx.color();
                        float sc = 0.6f;
                        float colorFactor = (float)i / (float)size;
                        col = Render2DEngine.interpolateColorC(col, Color.WHITE, (float)Math.pow(1.0f - colorFactor, 2.0));
                        float animPow = (float)ctx.animation(Render3DEngine.getTickDelta());
                        int animatedAlpha = (int)(alpha * animPow);
                        bufferBuilder.method_22918(matrix, -sc, sc, 0.0f).method_22913(0.0f, 1.0f).method_39415(Render2DEngine.injectAlpha(col, animatedAlpha).getRGB());
                        bufferBuilder.method_22918(matrix, sc, sc, 0.0f).method_22913(1.0f, 1.0f).method_39415(Render2DEngine.injectAlpha(col, animatedAlpha).getRGB());
                        bufferBuilder.method_22918(matrix, sc, -sc, 0.0f).method_22913(1.0f, 0.0f).method_39415(Render2DEngine.injectAlpha(col, animatedAlpha).getRGB());
                        bufferBuilder.method_22918(matrix, -sc, -sc, 0.0f).method_22913(0.0f, 0.0f).method_39415(Render2DEngine.injectAlpha(col, animatedAlpha).getRGB());
                    }
                }
                Render2DEngine.endBuilding(bufferBuilder);
                RenderSystem.depthMask((boolean)true);
                RenderSystem.disableDepthTest();
                RenderSystem.disableBlend();
                stack.method_22909();
            }
        } else if (this.players.getValue() == Players.Cute) {
            for (class_1657 entity : Trails.mc.field_1687.method_18456()) {
                class_243 pos;
                Trail ctx;
                int i;
                if (entity != Trails.mc.field_1724 && this.onlySelf.getValue().booleanValue()) continue;
                float alpha = (float)this.color.getValue().getAlpha() / 255.0f;
                if (((IEntity)entity).getTrails().isEmpty()) continue;
                stack.method_22903();
                RenderSystem.disableCull();
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.enableDepthTest();
                RenderSystem.depthFunc((int)515);
                float step = (float)(Trails.mc.field_1724.method_5829().method_17940() / 5.0);
                RenderSystem.setShader(class_757::method_34540);
                class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i < ((IEntity)entity).getTrails().size(); ++i) {
                    ctx = ((IEntity)entity).getTrails().get(i);
                    pos = ctx.interpolate(Render3DEngine.getTickDelta());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(69, 221, 255), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(69, 221, 255), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                RenderSystem.setShader(class_757::method_34540);
                bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i < ((IEntity)entity).getTrails().size(); ++i) {
                    ctx = ((IEntity)entity).getTrails().get(i);
                    pos = ctx.interpolate(Render3DEngine.getTickDelta());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(248, 139, 160), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step * 2.0f, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(248, 139, 160), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                RenderSystem.setShader(class_757::method_34540);
                bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i < ((IEntity)entity).getTrails().size(); ++i) {
                    ctx = ((IEntity)entity).getTrails().get(i);
                    pos = ctx.interpolate(Render3DEngine.getTickDelta());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step * 2.0f, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(255, 255, 255), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step * 3.0f, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(255, 255, 255), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                RenderSystem.setShader(class_757::method_34540);
                bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i < ((IEntity)entity).getTrails().size(); ++i) {
                    ctx = ((IEntity)entity).getTrails().get(i);
                    pos = ctx.interpolate(Render3DEngine.getTickDelta());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step * 3.0f, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(248, 139, 160), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step * 4.0f, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(248, 139, 160), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                RenderSystem.setShader(class_757::method_34540);
                bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i < ((IEntity)entity).getTrails().size(); ++i) {
                    ctx = ((IEntity)entity).getTrails().get(i);
                    pos = ctx.interpolate(Render3DEngine.getTickDelta());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step * 4.0f, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(69, 221, 255), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)pos.field_1352, (float)pos.field_1351 + step * 5.0f, (float)pos.field_1350).method_39415(Render2DEngine.injectAlpha(new Color(69, 221, 255), (int)((double)alpha * ctx.animation(Render3DEngine.getTickDelta()) * 255.0)).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                Render3DEngine.endRender();
                RenderSystem.enableCull();
                RenderSystem.disableDepthTest();
                stack.method_22909();
            }
        }
        if (!this.particles.isEmpty()) {
            RenderSystem.enableBlend();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask((boolean)false);
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
            switch (this.mode.getValue()) {
                case Stars: {
                    RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.star);
                    break;
                }
                case Bloom: {
                    RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.firefly);
                    break;
                }
                case Hearts: {
                    RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.heart);
                    break;
                }
                default: {
                    return;
                }
            }
            RenderSystem.setShader(class_757::method_34543);
            class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
            if (Trails.mc.field_1724 != null && Trails.mc.field_1687 != null) {
                this.particles.forEach(p -> p.render(stack, bufferBuilder));
            }
            Render2DEngine.endBuilding(bufferBuilder);
            RenderSystem.disableBlend();
            RenderSystem.depthMask((boolean)true);
            RenderSystem.disableDepthTest();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }

    @Override
    public void onUpdate() {
        Color c = this.lmode.getValue() == Mode.Sync ? HudEditor.getColor(Trails.mc.field_1724.field_6012 % 360) : this.lcolor.getValue().getColorObject();
        for (class_1657 player : Trails.mc.field_1687.method_18456()) {
            if (player.method_19538().method_10215() != player.field_5969 || player.method_19538().method_10216() != player.field_6014 && !this.onlySelf.getValue().booleanValue()) {
                ((IEntity)player).getTrails().add(new Trail(new class_243(player.field_6014, player.field_6036, player.field_5969), player.method_19538(), c));
                if (this.players.is(Players.Particles)) {
                    for (int i = 0; i < this.amount.getValue(); ++i) {
                        this.particles.add(new Particle(player.method_23317(), MathUtility.random((float)(player.method_23318() + (double)player.method_17682()), (float)player.method_23318()), player.method_23321(), c));
                    }
                }
            }
            ((IEntity)player).getTrails().removeIf(Trail::update);
        }
        for (class_1297 en : Managers.ASYNC.getAsyncEntities()) {
            if (en instanceof class_1667 && ((class_1667)en).field_6036 != en.method_23318() && this.arrows.is(Particles.Particles)) {
                for (int i = 0; i < 5; ++i) {
                    this.particles.add(new Particle(en.method_23317(), en.method_23318(), en.method_23321(), HudEditor.getColor(Trails.mc.field_1724.field_6012)));
                }
            }
            if (!(en instanceof class_1684) || !this.pearls.is(Particles.Particles)) continue;
            for (int i = 0; i < 5; ++i) {
                this.particles.add(new Particle(en.method_23317(), en.method_23318(), en.method_23321(), HudEditor.getColor(Trails.mc.field_1724.field_6012)));
            }
        }
        if (Managers.PLAYER.currentPlayerSpeed != 0.0f) {
            ((IEntity)Trails.mc.field_1724).getTrails().add(new Trail(new class_243(Trails.mc.field_1724.field_6014, Trails.mc.field_1724.field_6036, Trails.mc.field_1724.field_5969), Trails.mc.field_1724.method_19538(), c));
            if (this.players.is(Players.Particles)) {
                for (int i = 0; i < this.amount.getValue(); ++i) {
                    this.particles.add(new Particle(Trails.mc.field_1724.method_23317(), MathUtility.random((float)(Trails.mc.field_1724.method_23318() + (double)Trails.mc.field_1724.method_17682()), (float)Trails.mc.field_1724.method_23318()), Trails.mc.field_1724.method_23321(), c));
                }
            }
        }
        this.particles.removeIf(particle -> (float)(System.currentTimeMillis() - particle.time) > 1000.0f * (float)this.lifeTime.getValue().intValue());
    }

    private void calcTrajectory(class_1297 e) {
        double motionX = e.method_18798().field_1352;
        double motionY = e.method_18798().field_1351;
        double motionZ = e.method_18798().field_1350;
        double x = e.method_23317();
        double y = e.method_23318();
        double z = e.method_23321();
        class_243 lastPos = new class_243(x, y, z);
        for (int i = 0; i < 300; ++i) {
            lastPos = new class_243(x, y, z);
            if (Trails.mc.field_1687.method_8320(new class_2338((int)(x += motionX), (int)(y += motionY), (int)(z += motionZ))).method_26204() == class_2246.field_10382) {
                motionX *= 0.8;
                motionY *= 0.8;
                motionZ *= 0.8;
            } else {
                motionX *= 0.99;
                motionY *= 0.99;
                motionZ *= 0.99;
            }
            motionY = e instanceof class_1667 ? (motionY = motionY - (double)0.05f) : (motionY = motionY - (double)0.03f);
            class_243 pos = new class_243(x, y, z);
            if (Trails.mc.field_1687.method_17742(new class_3959(lastPos, pos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)Trails.mc.field_1724)) != null && (Trails.mc.field_1687.method_17742(new class_3959(lastPos, pos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)Trails.mc.field_1724)).method_17783() == class_239.class_240.field_1331 || Trails.mc.field_1687.method_17742(new class_3959(lastPos, pos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)Trails.mc.field_1724)).method_17783() == class_239.class_240.field_1332) || y <= -65.0) break;
            if (e.method_18798().field_1352 == 0.0 && e.method_18798().field_1351 == 0.0 && e.method_18798().field_1350 == 0.0) continue;
            int alpha = (int)MathUtility.clamp(255.0f * ((float)i / 8.0f), 0.0f, 255.0f);
            Render3DEngine.drawLine(lastPos, pos, this.lmode.getValue() == Mode.Sync ? Render2DEngine.injectAlpha(HudEditor.getColor(i * 5), alpha) : Render2DEngine.injectAlpha(this.lcolor.getValue().getColorObject(), alpha));
        }
    }

    private static enum Particles {
        Trail,
        Particles,
        None;

    }

    private static enum Players {
        Trail,
        Particles,
        Cute,
        Tail,
        None;

    }

    private static enum Mode {
        Custom,
        Sync;

    }

    public static class Trail {
        private final class_243 from;
        private final class_243 to;
        private final Color color;
        private int ticks;
        private int prevTicks;

        public Trail(class_243 from, class_243 to, Color color) {
            this.from = from;
            this.to = to;
            this.ticks = 10;
            this.color = color;
        }

        public class_243 interpolate(float pt) {
            double x = this.from.field_1352 + (this.to.field_1352 - this.from.field_1352) * (double)pt - Module.mc.method_1561().field_4686.method_19326().method_10216();
            double y = this.from.field_1351 + (this.to.field_1351 - this.from.field_1351) * (double)pt - Module.mc.method_1561().field_4686.method_19326().method_10214();
            double z = this.from.field_1350 + (this.to.field_1350 - this.from.field_1350) * (double)pt - Module.mc.method_1561().field_4686.method_19326().method_10215();
            return new class_243(x, y, z);
        }

        public double animation(float pt) {
            return (double)((float)this.prevTicks + (float)(this.ticks - this.prevTicks) * pt) / 10.0;
        }

        public boolean update() {
            this.prevTicks = this.ticks;
            return this.ticks-- <= 0;
        }

        public Color color() {
            return this.color;
        }
    }

    public class Particle {
        double x;
        double y;
        double z;
        double motionX;
        double motionY;
        double motionZ;
        long time;
        Color color;

        public Particle(double x, double y, double z, Color color) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.motionX = MathUtility.random(-((float)Trails.this.speed.getValue().intValue()) / 200.0f, (float)Trails.this.speed.getValue().intValue() / 200.0f);
            this.motionY = MathUtility.random(-((float)Trails.this.speed.getValue().intValue()) / 200.0f, (float)Trails.this.speed.getValue().intValue() / 200.0f);
            this.motionZ = MathUtility.random(-((float)Trails.this.speed.getValue().intValue()) / 200.0f, (float)Trails.this.speed.getValue().intValue() / 200.0f);
            this.time = System.currentTimeMillis();
            this.color = color;
        }

        public void update() {
            double sp = (float)Trails.this.starsScale.getValue().intValue() / 10.0f;
            this.x += this.motionX;
            this.y += this.motionY;
            this.z += this.motionZ;
            if (this.posBlock(this.x, this.y - (double)((float)Trails.this.starsScale.getValue().intValue() / 10.0f), this.z)) {
                this.motionY = -this.motionY / 1.1;
            } else if (this.posBlock(this.x, this.y, this.z) || this.posBlock(this.x - sp, this.y, this.z - sp) || this.posBlock(this.x + sp, this.y, this.z + sp) || this.posBlock(this.x + sp, this.y, this.z - sp) || this.posBlock(this.x - sp, this.y, this.z + sp) || this.posBlock(this.x + sp, this.y, this.z) || this.posBlock(this.x - sp, this.y, this.z) || this.posBlock(this.x, this.y, this.z - sp) || this.posBlock(this.x, this.y, this.z + sp)) {
                this.motionX = -this.motionX;
                this.motionZ = -this.motionZ;
            }
            if (Trails.this.physics.getValue() == HitParticles.Physics.Fall) {
                this.motionY -= (double)5.0E-4f;
            }
            this.motionX /= 1.005;
            this.motionZ /= 1.005;
            this.motionY /= 1.005;
        }

        public void render(class_4587 matrixStack, class_287 bufferBuilder) {
            this.update();
            float scale = (float)Trails.this.starsScale.getValue().intValue() / 10.0f;
            double posX = this.x - Module.mc.method_1561().field_4686.method_19326().method_10216();
            double posY = this.y - Module.mc.method_1561().field_4686.method_19326().method_10214();
            double posZ = this.z - Module.mc.method_1561().field_4686.method_19326().method_10215();
            class_4184 camera = Module.mc.field_1773.method_19418();
            class_4587 matrices = new class_4587();
            matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
            matrices.method_22904(posX, posY, posZ);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
            Matrix4f matrix = matrices.method_23760().method_23761();
            float colorAnim = (float)(System.currentTimeMillis() - this.time) / (1000.0f * (float)Trails.this.lifeTime.getValue().intValue());
            Color c = Trails.this.lmode.getValue() == Mode.Sync ? HudEditor.getColor((int)(360.0f * colorAnim)) : Trails.this.lcolor.getValue().getColorObject();
            bufferBuilder.method_22918(matrix, -scale / 2.0f, scale, 0.0f).method_22913(0.0f, 1.0f).method_39415(Render2DEngine.applyOpacity(c, 1.0f - colorAnim).getRGB());
            bufferBuilder.method_22918(matrix, scale, scale, 0.0f).method_22913(1.0f, 1.0f).method_39415(Render2DEngine.applyOpacity(c, 1.0f - colorAnim).getRGB());
            bufferBuilder.method_22918(matrix, scale, -scale / 2.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(Render2DEngine.applyOpacity(c, 1.0f - colorAnim).getRGB());
            bufferBuilder.method_22918(matrix, -scale / 2.0f, -scale / 2.0f, 0.0f).method_22913(0.0f, 0.0f).method_39415(Render2DEngine.applyOpacity(c, 1.0f - colorAnim).getRGB());
        }

        private boolean posBlock(double x, double y, double z) {
            class_2248 b = Module.mc.field_1687.method_8320(class_2338.method_49637((double)x, (double)y, (double)z)).method_26204();
            return b != class_2246.field_10124 && b != class_2246.field_10382 && b != class_2246.field_10164;
        }
    }
}

