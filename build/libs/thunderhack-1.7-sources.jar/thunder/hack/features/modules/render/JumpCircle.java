/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec3d
 *  org.joml.Matrix4f
 */
package thunder.hack.features.modules.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.joml.Matrix4f;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.setting.Setting;
import thunder.hack.utility.ThunderUtility;
import thunder.hack.utility.Timer;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

public class JumpCircle
extends Module {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Default);
    private final Setting<Boolean> easeOut = new Setting<Boolean>("EaseOut", true);
    private final Setting<Float> rotateSpeed = new Setting<Float>("RotateSpeed", Float.valueOf(2.0f), Float.valueOf(0.5f), Float.valueOf(5.0f));
    private final Setting<Float> circleScale = new Setting<Float>("CircleScale", Float.valueOf(1.0f), Float.valueOf(0.5f), Float.valueOf(5.0f));
    private final Setting<Boolean> onlySelf = new Setting<Boolean>("OnlySelf", false);
    private final List<Circle> circles = new ArrayList<Circle>();
    private final List<class_1657> cache = new CopyOnWriteArrayList<class_1657>();
    private class_2960 custom;

    public JumpCircle() {
        super("JumpCircle", Module.Category.RENDER);
    }

    @Override
    public void onEnable() {
        try {
            this.custom = ThunderUtility.getCustomImg("circle");
        }
        catch (Exception e) {
            this.sendMessage(e.getMessage());
        }
    }

    @Override
    public void onUpdate() {
        if (this.mode.is(Mode.Custom) && this.custom == null) {
            try {
                this.custom = ThunderUtility.getCustomImg("circle");
            }
            catch (Exception e) {
                this.sendMessage(".minecraft -> ThunderHackRecode -> misc -> images -> circle.png");
            }
        }
        for (class_1657 pl2 : JumpCircle.mc.field_1687.method_18456()) {
            if (this.cache.contains(pl2) || !pl2.method_24828() || JumpCircle.mc.field_1724 != pl2 && this.onlySelf.getValue().booleanValue()) continue;
            this.cache.add(pl2);
        }
        this.cache.forEach(pl -> {
            if (pl != null && !pl.method_24828()) {
                this.circles.add(new Circle(new class_243(pl.method_23317(), (double)((float)((int)Math.floor(pl.method_23318())) + 0.001f), pl.method_23321()), new Timer()));
                this.cache.remove(pl);
            }
        });
        this.circles.removeIf(c -> c.timer.passedMs(this.easeOut.getValue() != false ? 5000L : 6000L));
    }

    @Override
    public void onRender3D(class_4587 stack) {
        Collections.reverse(this.circles);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        switch (this.mode.getValue().ordinal()) {
            case 1: {
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.bubble);
                break;
            }
            case 0: {
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.default_circle);
                break;
            }
            case 2: {
                RenderSystem.setShaderTexture((int)0, (class_2960)Objects.requireNonNullElse(this.custom, TextureStorage.default_circle));
            }
        }
        RenderSystem.setShader(class_757::method_34543);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        for (Circle c : this.circles) {
            float colorAnim = (float)c.timer.getPassedTimeMs() / 6000.0f;
            float sizeAnim = this.circleScale.getValue().floatValue() - (float)Math.pow(1.0f - (float)c.timer.getPassedTimeMs() * (this.easeOut.getValue() != false ? 2.0f : 1.0f) / 5000.0f, 4.0);
            stack.method_22903();
            stack.method_22904(c.pos().field_1352 - JumpCircle.mc.method_1561().field_4686.method_19326().method_10216(), c.pos().field_1351 - JumpCircle.mc.method_1561().field_4686.method_19326().method_10214(), c.pos().field_1350 - JumpCircle.mc.method_1561().field_4686.method_19326().method_10215());
            stack.method_22907(class_7833.field_40714.rotationDegrees(90.0f));
            stack.method_22907(class_7833.field_40718.rotationDegrees(sizeAnim * this.rotateSpeed.getValue().floatValue() * 1000.0f));
            float scale = sizeAnim * 2.0f;
            Matrix4f matrix = stack.method_23760().method_23761();
            buffer.method_22918(matrix, -sizeAnim, -sizeAnim + scale, 0.0f).method_22913(0.0f, 1.0f).method_39415(Render2DEngine.applyOpacity(HudEditor.getColor(270), 1.0f - colorAnim).getRGB());
            buffer.method_22918(matrix, -sizeAnim + scale, -sizeAnim + scale, 0.0f).method_22913(1.0f, 1.0f).method_39415(Render2DEngine.applyOpacity(HudEditor.getColor(0), 1.0f - colorAnim).getRGB());
            buffer.method_22918(matrix, -sizeAnim + scale, -sizeAnim, 0.0f).method_22913(1.0f, 0.0f).method_39415(Render2DEngine.applyOpacity(HudEditor.getColor(180), 1.0f - colorAnim).getRGB());
            buffer.method_22918(matrix, -sizeAnim, -sizeAnim, 0.0f).method_22913(0.0f, 0.0f).method_39415(Render2DEngine.applyOpacity(HudEditor.getColor(90), 1.0f - colorAnim).getRGB());
            stack.method_22909();
        }
        Render2DEngine.endBuilding(buffer);
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.enableDepthTest();
        Collections.reverse(this.circles);
    }

    public static enum Mode {
        Default,
        Portal,
        Custom;

    }

    public record Circle(class_243 pos, Timer timer) {
    }
}

