/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.block.Block
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.Camera
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.AreaEffectCloudEntity
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.SpawnGroup
 *  net.minecraft.entity.TntEntity
 *  net.minecraft.entity.decoration.EndCrystalEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.projectile.thrown.EnderPearlEntity
 *  net.minecraft.item.Items
 *  net.minecraft.particle.EntityEffectParticleEffect
 *  net.minecraft.particle.ParticleEffect
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec2f
 *  net.minecraft.util.math.Vec3d
 *  org.jetbrains.annotations.NotNull
 *  org.joml.Matrix4f
 *  org.joml.Vector4d
 */
package thunder.hack.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_1295;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1684;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9381;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector4d;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.injection.accesors.IAreaEffectCloudEntity;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.setting.impl.SettingGroup;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.animation.AnimationUtility;

public class ESP
extends Module {
    private final Setting<Boolean> lingeringPotions = new Setting<Boolean>("LingeringPotions", false);
    private final Setting<Boolean> tntFuse = new Setting<Boolean>("TNTFuse", false);
    private final Setting<Float> tntrange = new Setting<Float>("TNTRange", Float.valueOf(8.0f), Float.valueOf(0.0f), Float.valueOf(8.0f));
    private final Setting<ColorSetting> tntFuseText = new Setting<ColorSetting>("TNTFuseText", new ColorSetting(new Color(-1)), v -> this.tntFuse.getValue());
    private final Setting<Boolean> tntRadius = new Setting<Boolean>("TNTRadius", false);
    private final Setting<ColorSetting> tntRadiusColor = new Setting<ColorSetting>("TNTSphereColor", new ColorSetting(new Color(-1)), v -> this.tntRadius.getValue());
    private final Setting<Boolean> beaconRadius = new Setting<Boolean>("BeaconRadius", false);
    private final Setting<Boolean> keepY = new Setting<Boolean>("KeepY", false, v -> this.beaconRadius.getValue());
    private final Setting<ColorSetting> sphereColor = new Setting<ColorSetting>("SphereColor", new ColorSetting(new Color(-1)), v -> this.beaconRadius.getValue());
    private final Setting<ColorSetting> beakonColor = new Setting<ColorSetting>("BeakonColor", new ColorSetting(new Color(-1)), v -> this.beaconRadius.getValue());
    private final Setting<Boolean> burrow = new Setting<Boolean>("Burrow", false);
    private final Setting<ColorSetting> burrowTextColor = new Setting<ColorSetting>("BurrowTextColor", new ColorSetting(new Color(-1)), v -> this.burrow.getValue());
    private final Setting<ColorSetting> burrowColor = new Setting<ColorSetting>("BurrowColor", new ColorSetting(new Color(-1)), v -> this.burrow.getValue());
    private final Setting<Boolean> pearls = new Setting<Boolean>("Pearls", false);
    private final Setting<Boolean> dizorentRadius = new Setting<Boolean>("DizorentRadius", true);
    private final Setting<ColorSetting> dizorentColor = new Setting<ColorSetting>("DizorentColor", new ColorSetting(new Color(-1291783732, true)), v -> this.dizorentRadius.getValue());
    private final Setting<SettingGroup> boxEsp = new Setting<SettingGroup>("Box", new SettingGroup(false, 0));
    private final Setting<Boolean> players = new Setting<Boolean>("Players", true).addToGroup(this.boxEsp);
    private final Setting<Boolean> friends = new Setting<Boolean>("Friends", true).addToGroup(this.boxEsp);
    private final Setting<Boolean> crystals = new Setting<Boolean>("Crystals", true).addToGroup(this.boxEsp);
    private final Setting<Boolean> creatures = new Setting<Boolean>("Creatures", false).addToGroup(this.boxEsp);
    private final Setting<Boolean> monsters = new Setting<Boolean>("Monsters", false).addToGroup(this.boxEsp);
    private final Setting<Boolean> ambients = new Setting<Boolean>("Ambients", false).addToGroup(this.boxEsp);
    private final Setting<Boolean> others = new Setting<Boolean>("Others", false).addToGroup(this.boxEsp);
    private final Setting<Boolean> outline = new Setting<Boolean>("Outline", true).addToGroup(this.boxEsp);
    private final Setting<Colors> colorMode = new Setting<Colors>("ColorMode", Colors.SyncColor).addToGroup(this.boxEsp);
    private final Setting<Boolean> renderHealth = new Setting<Boolean>("renderHealth", true).addToGroup(this.boxEsp);
    private final Setting<SettingGroup> boxColors = new Setting<SettingGroup>("BoxColors", new SettingGroup(false, 0));
    private final Setting<ColorSetting> playersC = new Setting<ColorSetting>("PlayersC", new ColorSetting(new Color(16749056))).addToGroup(this.boxColors);
    private final Setting<ColorSetting> friendsC = new Setting<ColorSetting>("FriendsC", new ColorSetting(new Color(0x30FF00))).addToGroup(this.boxColors);
    private final Setting<ColorSetting> crystalsC = new Setting<ColorSetting>("CrystalsC", new ColorSetting(new Color(48127))).addToGroup(this.boxColors);
    private final Setting<ColorSetting> creaturesC = new Setting<ColorSetting>("CreaturesC", new ColorSetting(new Color(10527910))).addToGroup(this.boxColors);
    private final Setting<ColorSetting> monstersC = new Setting<ColorSetting>("MonstersC", new ColorSetting(new Color(0xFF0000))).addToGroup(this.boxColors);
    private final Setting<ColorSetting> ambientsC = new Setting<ColorSetting>("AmbientsC", new ColorSetting(new Color(8061183))).addToGroup(this.boxColors);
    private final Setting<ColorSetting> othersC = new Setting<ColorSetting>("OthersC", new ColorSetting(new Color(16711778))).addToGroup(this.boxColors);
    public final Setting<ColorSetting> healthB = new Setting<ColorSetting>("healthB", new ColorSetting(new Color(0xFF1100))).addToGroup(this.boxColors);
    public final Setting<ColorSetting> healthU = new Setting<ColorSetting>("healthU", new ColorSetting(new Color(0x2FFF00))).addToGroup(this.boxColors);
    private float dizorentAnimation = 0.0f;

    public ESP() {
        super("ESP", Module.Category.RENDER);
    }

    @Override
    public void onRender3D(class_4587 stack) {
        double x;
        double y;
        if (ESP.mc.field_1690.field_1842) {
            return;
        }
        if (this.lingeringPotions.getValue().booleanValue()) {
            for (class_1297 ent : ESP.mc.field_1687.method_18112()) {
                double u;
                double v;
                int i;
                if (!(ent instanceof class_1295)) continue;
                class_1295 aece = (class_1295)ent;
                double x2 = aece.method_23317() - ESP.mc.method_1561().field_4686.method_19326().method_10216();
                y = aece.method_23318() - ESP.mc.method_1561().field_4686.method_19326().method_10214();
                double z = aece.method_23321() - ESP.mc.method_1561().field_4686.method_19326().method_10215();
                float middle = aece.method_5599();
                stack.method_22903();
                stack.method_22904(x2, y, z);
                Render3DEngine.setupRender();
                RenderSystem.disableDepthTest();
                RenderSystem.setShader(class_757::method_34540);
                class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i <= 360; i += 6) {
                    v = Math.sin(Math.toRadians(i));
                    u = Math.cos(Math.toRadians(i));
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)u * middle, 0.0f, (float)v * middle).method_39415(Render2DEngine.injectAlpha(new Color(this.getAreaCloudColor(aece)), 100).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), 0.0f, 0.0f, 0.0f).method_39415(Render2DEngine.injectAlpha(new Color(this.getAreaCloudColor(aece)), 0).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                RenderSystem.setShader(class_757::method_34540);
                bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i <= 360; i += 6) {
                    v = Math.sin(Math.toRadians(i));
                    u = Math.cos(Math.toRadians(i));
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)u * middle, 0.0f, (float)v * middle).method_39415(Render2DEngine.injectAlpha(new Color(this.getAreaCloudColor(aece)), 255).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)u * (middle - 0.04f), 0.0f, (float)v * (middle - 0.04f)).method_39415(Render2DEngine.injectAlpha(new Color(this.getAreaCloudColor(aece)), 255).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                Render3DEngine.endRender();
                RenderSystem.enableDepthTest();
                stack.method_22904(-x2, -y, -z);
                stack.method_22909();
                RenderSystem.disableDepthTest();
                class_4587 matrices = new class_4587();
                class_4184 camera = ESP.mc.field_1773.method_19418();
                matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
                matrices.method_22904(x2, y, z);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                matrices.method_46416(0.0f, 0.0f, 0.0f);
                matrices.method_22905(-0.05f, -0.05f, 0.0f);
                FontRenderers.modules.drawCenteredString(matrices, String.format("%.1f", Float.valueOf(aece.method_5599() * 10.0f - 5.0f)), 0.0, -10.0, -1);
                RenderSystem.disableBlend();
                RenderSystem.enableDepthTest();
            }
        }
        if (this.dizorentRadius.getValue().booleanValue()) {
            this.dizorentAnimation = AnimationUtility.fast(this.dizorentAnimation, ESP.mc.field_1724.method_6047().method_7909() == class_1802.field_8449 ? 10.0f : 0.0f, 15.0f);
            if (ESP.mc.field_1724.method_6047().method_7909() == class_1802.field_8449) {
                double u;
                int i;
                x = Render2DEngine.interpolate(ESP.mc.field_1724.field_6014, ESP.mc.field_1724.method_23317(), Render3DEngine.getTickDelta()) - ESP.mc.method_1561().field_4686.method_19326().method_10216();
                double y2 = Render2DEngine.interpolate(ESP.mc.field_1724.field_6036, ESP.mc.field_1724.method_23318(), Render3DEngine.getTickDelta()) - ESP.mc.method_1561().field_4686.method_19326().method_10214();
                double z = Render2DEngine.interpolate(ESP.mc.field_1724.field_5969, ESP.mc.field_1724.method_23321(), Render3DEngine.getTickDelta()) - ESP.mc.method_1561().field_4686.method_19326().method_10215();
                stack.method_22903();
                stack.method_22904(x, y2, z);
                Render3DEngine.setupRender();
                RenderSystem.disableDepthTest();
                RenderSystem.setShader(class_757::method_34540);
                class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i <= 360; i += 6) {
                    double d = Math.sin(Math.toRadians(i));
                    u = Math.cos(Math.toRadians(i));
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)u * this.dizorentAnimation, 0.0f, (float)d * this.dizorentAnimation).method_39415(Render2DEngine.injectAlpha(new Color(this.dizorentColor.getValue().getColor()), 100).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), 0.0f, 0.0f, 0.0f).method_39415(Render2DEngine.injectAlpha(new Color(this.dizorentColor.getValue().getColor()), 0).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                RenderSystem.setShader(class_757::method_34540);
                bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
                for (i = 0; i <= 360; i += 6) {
                    double d = Math.sin(Math.toRadians(i));
                    u = Math.cos(Math.toRadians(i));
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)u * this.dizorentAnimation, 0.0f, (float)d * this.dizorentAnimation).method_39415(Render2DEngine.injectAlpha(new Color(this.dizorentColor.getValue().getColor()), 255).getRGB());
                    bufferBuilder.method_22918(stack.method_23760().method_23761(), (float)u * (this.dizorentAnimation - 0.04f), 0.0f, (float)d * (this.dizorentAnimation - 0.04f)).method_39415(Render2DEngine.injectAlpha(new Color(this.dizorentColor.getValue().getColor()), 255).getRGB());
                }
                Render2DEngine.endBuilding(bufferBuilder);
                Render3DEngine.endRender();
                RenderSystem.enableDepthTest();
                stack.method_22904(-x, -y2, -z);
                stack.method_22909();
                for (class_1657 playerEntity : Managers.ASYNC.getAsyncPlayers()) {
                    if (ESP.mc.field_1724.method_5707(playerEntity.method_19538()) > 100.0 || playerEntity == ESP.mc.field_1724) continue;
                    Render3DEngine.drawTargetEsp(stack, (class_1297)playerEntity);
                }
            }
        }
        if (this.beaconRadius.getValue().booleanValue()) {
            // empty if block
        }
        if (this.burrow.getValue().booleanValue()) {
            for (class_1657 pl : ESP.mc.field_1687.method_18456()) {
                class_2338 blockPos = class_2338.method_49638((class_2374)pl.method_19538().method_1031(0.0, (double)0.15f, 0.0));
                class_2248 block = ESP.mc.field_1687.method_8320(blockPos).method_26204();
                double x3 = (double)blockPos.method_10263() - ESP.mc.method_1561().field_4686.method_19326().method_10216();
                double y3 = (double)blockPos.method_10264() - ESP.mc.method_1561().field_4686.method_19326().method_10214();
                double d = (double)blockPos.method_10260() - ESP.mc.method_1561().field_4686.method_19326().method_10215();
                if (block != class_2246.field_10540 && block != class_2246.field_22423 && block != class_2246.field_10535 && block != class_2246.field_10432 && block != class_2246.field_10481 && block != class_2246.field_10177) continue;
                Render3DEngine.drawBoxOutline(new class_238(blockPos), this.burrowColor.getValue().getColorObject(), 2.0f);
                RenderSystem.disableDepthTest();
                class_4587 matrices = new class_4587();
                class_4184 camera = ESP.mc.field_1773.method_19418();
                matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
                matrices.method_22904(x3 + 0.5, y3 + 0.5, d + 0.5);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                matrices.method_46416(0.0f, 0.0f, 0.0f);
                matrices.method_22905(-0.025f, -0.025f, 0.0f);
                FontRenderers.modules.drawCenteredString(matrices, "BURROW", 0.0, -5.0, this.burrowTextColor.getValue().getColor());
                RenderSystem.disableBlend();
                RenderSystem.enableDepthTest();
            }
        }
        if (this.tntFuse.getValue().booleanValue() || this.tntRadius.getValue().booleanValue()) {
            for (class_1297 ent : ESP.mc.field_1687.method_18112()) {
                if (!(ent instanceof class_1541)) continue;
                class_1541 tnt = (class_1541)ent;
                x = tnt.field_6014 + (tnt.method_19538().method_10216() - tnt.field_6014) * (double)Render3DEngine.getTickDelta() - ESP.mc.method_1561().field_4686.method_19326().method_10216();
                y = tnt.field_6036 + (tnt.method_19538().method_10214() - tnt.field_6036) * (double)Render3DEngine.getTickDelta() - ESP.mc.method_1561().field_4686.method_19326().method_10214();
                double z = tnt.field_5969 + (tnt.method_19538().method_10215() - tnt.field_5969) * (double)Render3DEngine.getTickDelta() - ESP.mc.method_1561().field_4686.method_19326().method_10215();
                if (this.tntFuse.getValue().booleanValue()) {
                    RenderSystem.disableDepthTest();
                    class_4587 matrices = new class_4587();
                    class_4184 camera = ESP.mc.field_1773.method_19418();
                    matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                    matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
                    matrices.method_22904(x, y + 0.5, z);
                    matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
                    matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                    RenderSystem.enableBlend();
                    RenderSystem.defaultBlendFunc();
                    matrices.method_46416(0.0f, 0.0f, 0.0f);
                    matrices.method_22905(-0.025f, -0.025f, 0.0f);
                    FontRenderers.modules.drawCenteredString(matrices, String.format("%.1f", Float.valueOf((float)tnt.method_6969() / 20.0f)) + "s", 0.0, -5.0, this.tntFuseText.getValue().getColor());
                    RenderSystem.disableBlend();
                    RenderSystem.enableDepthTest();
                }
                if (!this.tntRadius.getValue().booleanValue()) continue;
                stack.method_22903();
                stack.method_22904(x, y, z);
                Render3DEngine.drawSphere(stack, this.tntrange.getValue().floatValue(), 20, 20, this.tntRadiusColor.getValue().getColor());
                stack.method_22904(-x, -y, -z);
                stack.method_22909();
            }
        }
    }

    @Override
    public void onRender2D(class_332 context) {
        if (ESP.mc.field_1690.field_1842) {
            return;
        }
        if (this.pearls.getValue().booleanValue()) {
            for (class_1297 ent : ESP.mc.field_1687.method_18112()) {
                if (!(ent instanceof class_1684)) continue;
                class_1684 pearl = (class_1684)ent;
                float xOffset = (float)mc.method_22683().method_4486() / 2.0f;
                float yOffset = (float)mc.method_22683().method_4502() / 2.0f;
                float xPos = (float)(pearl.field_6014 + (pearl.method_19538().method_10216() - pearl.field_6014) * (double)Render3DEngine.getTickDelta());
                float zPos = (float)(pearl.field_5969 + (pearl.method_19538().method_10215() - pearl.field_5969) * (double)Render3DEngine.getTickDelta());
                float yaw = ESP.getRotations(new class_241(xPos, zPos)) - ESP.mc.field_1724.method_36454();
                context.method_51448().method_46416(xOffset, yOffset, 0.0f);
                context.method_51448().method_22907(class_7833.field_40718.rotationDegrees(yaw));
                context.method_51448().method_46416(-xOffset, -yOffset, 0.0f);
                Render2DEngine.drawTracerPointer(context.method_51448(), xOffset, yOffset - 50.0f, 12.5f, 0.5f, 3.63f, true, true, HudEditor.getColor(1).getRGB());
                context.method_51448().method_46416(xOffset, yOffset, 0.0f);
                context.method_51448().method_22907(class_7833.field_40718.rotationDegrees(-yaw));
                context.method_51448().method_46416(-xOffset, -yOffset, 0.0f);
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                FontRenderers.modules.drawCenteredString(context.method_51448(), String.format("%.1f", Float.valueOf(ESP.mc.field_1724.method_5739((class_1297)pearl))) + "m", (double)((float)(Math.sin(Math.toRadians(yaw)) * 50.0) + xOffset), (double)((float)((double)yOffset - Math.cos(Math.toRadians(yaw)) * 50.0) - 20.0f), -1);
            }
        }
        Matrix4f matrix = context.method_51448().method_23760().method_23761();
        Render2DEngine.setupRender();
        RenderSystem.setShader(class_757::method_34540);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        for (class_1297 ent : ESP.mc.field_1687.method_18112()) {
            if (!this.shouldRender(ent)) continue;
            this.drawBox(bufferBuilder, ent, matrix);
        }
        Render2DEngine.endBuilding(bufferBuilder);
        Render2DEngine.endRender();
    }

    public boolean shouldRender(class_1297 entity) {
        if (entity == null) {
            return false;
        }
        if (ESP.mc.field_1724 == null) {
            return false;
        }
        if (entity instanceof class_1657) {
            if (entity == ESP.mc.field_1724) {
                return false;
            }
            if (Managers.FRIEND.isFriend((class_1657)entity)) {
                return this.friends.getValue();
            }
            return this.players.getValue();
        }
        if (entity instanceof class_1511) {
            return this.crystals.getValue();
        }
        return switch (entity.method_5864().method_5891()) {
            case class_1311.field_6294, class_1311.field_6300 -> this.creatures.getValue();
            case class_1311.field_6302 -> this.monsters.getValue();
            case class_1311.field_6303, class_1311.field_24460 -> this.ambients.getValue();
            default -> this.others.getValue();
        };
    }

    public Color getEntityColor(class_1297 entity) {
        if (entity == null) {
            return new Color(-1);
        }
        if (entity instanceof class_1657) {
            if (Managers.FRIEND.isFriend((class_1657)entity)) {
                return this.friendsC.getValue().getColorObject();
            }
            return this.playersC.getValue().getColorObject();
        }
        if (entity instanceof class_1511) {
            return this.crystalsC.getValue().getColorObject();
        }
        return switch (entity.method_5864().method_5891()) {
            case class_1311.field_6294, class_1311.field_6300 -> this.creaturesC.getValue().getColorObject();
            case class_1311.field_6302 -> this.monstersC.getValue().getColorObject();
            case class_1311.field_6303, class_1311.field_24460 -> this.ambientsC.getValue().getColorObject();
            default -> this.othersC.getValue().getColorObject();
        };
    }

    public void drawBox(class_287 bufferBuilder, @NotNull class_1297 ent, Matrix4f matrix) {
        class_243[] vectors = ESP.getVectors(ent);
        Color col = this.getEntityColor(ent);
        Vector4d position = null;
        for (class_243 vector : vectors) {
            vector = Render3DEngine.worldSpaceToScreenSpace(new class_243(vector.field_1352, vector.field_1351, vector.field_1350));
            if (!(vector.field_1350 > 0.0) || !(vector.field_1350 < 1.0)) continue;
            if (position == null) {
                position = new Vector4d(vector.field_1352, vector.field_1351, vector.field_1350, 0.0);
            }
            position.x = Math.min(vector.field_1352, position.x);
            position.y = Math.min(vector.field_1351, position.y);
            position.z = Math.max(vector.field_1352, position.z);
            position.w = Math.max(vector.field_1351, position.w);
        }
        if (position != null) {
            class_1309 lent;
            double posX = position.x;
            double posY = position.y;
            double endPosX = position.z;
            double endPosY = position.w;
            if (this.outline.getValue().booleanValue()) {
                Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 1.0), (float)posY, (float)(posX + 0.5), (float)(endPosY + 0.5), Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK);
                Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 1.0), (float)(posY - 0.5), (float)(endPosX + 0.5), (float)(posY + 0.5 + 0.5), Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK);
                Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(endPosX - 0.5 - 0.5), (float)posY, (float)(endPosX + 0.5), (float)(endPosY + 0.5), Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK);
                Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 1.0), (float)(endPosY - 0.5 - 0.5), (float)(endPosX + 0.5), (float)(endPosY + 0.5), Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK);
            }
            switch (this.colorMode.getValue().ordinal()) {
                case 1: {
                    Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 0.5), (float)posY, (float)(posX + 0.5 - 0.5), (float)endPosY, col, col, col, col);
                    Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)posX, (float)(endPosY - 0.5), (float)endPosX, (float)endPosY, col, col, col, col);
                    Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 0.5), (float)posY, (float)endPosX, (float)(posY + 0.5), col, col, col, col);
                    Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(endPosX - 0.5), (float)posY, (float)endPosX, (float)endPosY, col, col, col, col);
                    break;
                }
                case 0: {
                    Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 0.5), (float)posY, (float)(posX + 0.5 - 0.5), (float)endPosY, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(0), HudEditor.getColor(270));
                    Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)posX, (float)(endPosY - 0.5), (float)endPosX, (float)endPosY, HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(180), HudEditor.getColor(0));
                    Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 0.5), (float)posY, (float)endPosX, (float)(posY + 0.5), HudEditor.getColor(180), HudEditor.getColor(90), HudEditor.getColor(90), HudEditor.getColor(180));
                    Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(endPosX - 0.5), (float)posY, (float)endPosX, (float)endPosY, HudEditor.getColor(90), HudEditor.getColor(270), HudEditor.getColor(270), HudEditor.getColor(90));
                }
            }
            if (ent instanceof class_1309 && (lent = (class_1309)ent).method_6032() != 0.0f && this.renderHealth.getValue().booleanValue()) {
                Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 5.0), (float)posY, (float)posX - 3.0f, (float)endPosY, Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK);
                switch (this.colorMode.getValue().ordinal()) {
                    case 1: {
                        Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 5.0), (float)(endPosY + (posY - endPosY) * (double)lent.method_6032() / (double)lent.method_6063()), (float)posX - 3.0f, (float)endPosY, this.healthB.getValue().getColorObject(), this.healthB.getValue().getColorObject(), this.healthU.getValue().getColorObject(), this.healthU.getValue().getColorObject());
                        break;
                    }
                    case 0: {
                        Render2DEngine.setRectPoints(bufferBuilder, matrix, (float)(posX - 5.0), (float)(endPosY + (posY - endPosY) * (double)lent.method_6032() / (double)lent.method_6063()), (float)posX - 3.0f, (float)endPosY, HudEditor.getColor(90), HudEditor.getColor(90), HudEditor.getColor(270), HudEditor.getColor(270));
                    }
                }
            }
        }
    }

    @NotNull
    private static class_243[] getVectors(@NotNull class_1297 ent) {
        double x = ent.field_6014 + (ent.method_23317() - ent.field_6014) * (double)Render3DEngine.getTickDelta();
        double y = ent.field_6036 + (ent.method_23318() - ent.field_6036) * (double)Render3DEngine.getTickDelta();
        double z = ent.field_5969 + (ent.method_23321() - ent.field_5969) * (double)Render3DEngine.getTickDelta();
        class_238 axisAlignedBB2 = ent.method_5829();
        class_238 axisAlignedBB = new class_238(axisAlignedBB2.field_1323 - ent.method_23317() + x - 0.05, axisAlignedBB2.field_1322 - ent.method_23318() + y, axisAlignedBB2.field_1321 - ent.method_23321() + z - 0.05, axisAlignedBB2.field_1320 - ent.method_23317() + x + 0.05, axisAlignedBB2.field_1325 - ent.method_23318() + y + 0.15, axisAlignedBB2.field_1324 - ent.method_23321() + z + 0.05);
        return new class_243[]{new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1322, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1325, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1322, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1325, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1322, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1325, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1322, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1325, axisAlignedBB.field_1324)};
    }

    private int getAreaCloudColor(class_1295 ent) {
        class_2394 particleEffect = ent.method_5600();
        if (particleEffect instanceof class_9381) {
            class_9381 effect = (class_9381)particleEffect;
            return ((IAreaEffectCloudEntity)ent).getPotionContentsComponent().method_8064();
        }
        return -1;
    }

    public static float getRotations(class_241 vec) {
        if (ESP.mc.field_1724 == null) {
            return 0.0f;
        }
        double x = (double)vec.field_1343 - ESP.mc.field_1724.method_19538().field_1352;
        double z = (double)vec.field_1342 - ESP.mc.field_1724.method_19538().field_1350;
        return (float)(-(Math.atan2(x, z) * 57.29577951308232));
    }

    public static enum Colors {
        SyncColor,
        Custom;

    }
}

