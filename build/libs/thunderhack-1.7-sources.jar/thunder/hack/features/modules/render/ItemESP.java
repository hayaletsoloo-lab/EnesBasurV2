/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.text.Style
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Vec3d
 *  org.jetbrains.annotations.NotNull
 *  org.joml.Matrix4f
 *  org.joml.Vector4d
 */
package thunder.hack.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector4d;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public class ItemESP
extends Module {
    private final Setting<Boolean> shadow = new Setting<Boolean>("Shadow", true);
    private final Setting<ColorSetting> scolor = new Setting<ColorSetting>("ShadowColor", new ColorSetting(new Color(0).getRGB()));
    private final Setting<ColorSetting> tcolor = new Setting<ColorSetting>("TextColor", new ColorSetting(new Color(-1).getRGB()));
    private final Setting<ESPMode> espMode = new Setting<ESPMode>("Mode", ESPMode.Rect);
    private final Setting<Float> radius = new Setting<Float>("Radius", Float.valueOf(1.0f), Float.valueOf(0.1f), Float.valueOf(5.0f), v -> this.espMode.getValue() == ESPMode.Circle);
    private final Setting<Boolean> useHudColor = new Setting<Boolean>("UseHudColor", true, v -> this.espMode.getValue() == ESPMode.Circle);
    private final Setting<Integer> cOffset = new Setting<Integer>("ColorOffset", 2, 1, 50, v -> this.espMode.getValue() == ESPMode.Circle && this.useHudColor.getValue() != false);
    private final Setting<ColorSetting> circleColor = new Setting<ColorSetting>("CircleColor", new ColorSetting(new Color(-1).getRGB()), v -> this.espMode.getValue() == ESPMode.Circle && this.useHudColor.getValue() == false);
    private final Setting<Integer> cPoints = new Setting<Integer>("CirclePoints", 12, 3, 32, v -> this.espMode.getValue() == ESPMode.Circle);

    public ItemESP() {
        super("ItemESP", Module.Category.RENDER);
    }

    @Override
    public void onRender2D(class_332 context) {
        if (ItemESP.mc.field_1687 == null) {
            return;
        }
        Matrix4f matrix = context.method_51448().method_23760().method_23761();
        class_287 bufferBuilder = null;
        if (this.espMode.getValue() == ESPMode.Rect) {
            Render2DEngine.setupRender();
            RenderSystem.setShader(class_757::method_34540);
            bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        }
        for (class_1297 ent : ItemESP.mc.field_1687.method_18112()) {
            if (!(ent instanceof class_1542)) continue;
            class_1542 itemEntity = (class_1542)ent;
            class_243[] vectors = ItemESP.getPoints((class_1297)itemEntity);
            Vector4d position = null;
            for (class_243 vector : vectors) {
                vector = Render3DEngine.worldSpaceToScreenSpace(new class_243(vector.field_1352, vector.field_1351, vector.field_1350));
                if (!(vector.field_1350 > 0.0) || !(vector.field_1350 < 1.0)) continue;
                if (position == null) {
                    position = new Vector4d(vector.field_1352, vector.field_1351, vector.field_1350, 0.0);
                }
                position.x = Math.min(vector.field_1352, position.x);
                position.y = Math.min(vector.field_1351, position.y);
                position.z = Math.max(vector.field_1352, position.z);
                position.w = Math.max(vector.field_1351, position.w);
            }
            if (position == null) continue;
            float posX = (float)position.x;
            float posY = (float)position.y;
            float endPosX = (float)position.z;
            float endPosY = (float)position.w;
            float diff = (endPosX - posX) / 2.0f;
            class_1799 stack = itemEntity.method_6983();
            Object name = this.getLegacyName(stack.method_7964());
            if (stack.method_7947() > 1) {
                name = (String)name + " \u00a77x" + stack.method_7947();
            }
            name = ((String)name).replace('&', '\u00a7');
            float textWidth = FontRenderers.sf_bold_mini.getStringWidth((String)name);
            float tagX = posX + diff - textWidth / 2.0f;
            if (this.shadow.getValue().booleanValue()) {
                Render2DEngine.drawBlurredShadow(context.method_51448(), tagX - 2.0f, posY - 13.0f, textWidth + 4.0f, 11.0f, 14, this.scolor.getValue().getColorObject());
            }
            Render2DEngine.drawRect(context.method_51448(), tagX - 2.0f, posY - 12.0f, textWidth + 4.0f, 10.0f, new Color(0, 0, 0, 160));
            FontRenderers.sf_bold_mini.drawString(context.method_51448(), (String)name, (double)tagX, (double)(posY - 10.0f), this.tcolor.getValue().getColor());
            if (bufferBuilder == null) continue;
            this.drawRect(bufferBuilder, matrix, posX, posY, endPosX, endPosY);
        }
        if (bufferBuilder != null) {
            Render2DEngine.endBuilding(bufferBuilder);
            Render2DEngine.endRender();
        }
    }

    private String getLegacyName(class_2561 text) {
        StringBuilder sb = new StringBuilder();
        text.method_27658((style, string) -> {
            class_124 formatting = null;
            if (style.method_10973() != null) {
                String colorName = style.method_10973().method_27721();
                for (class_124 f : class_124.values()) {
                    if (!f.method_537().equalsIgnoreCase(colorName)) continue;
                    formatting = f;
                    break;
                }
                if (formatting == null) {
                    int rgb = style.method_10973().method_27716();
                    formatting = this.getNearestFormatting(rgb);
                }
            }
            if (formatting != null) {
                sb.append(formatting);
            }
            if (style.method_10984()) {
                sb.append(class_124.field_1067);
            }
            if (style.method_10966()) {
                sb.append(class_124.field_1056);
            }
            if (style.method_10965()) {
                sb.append(class_124.field_1073);
            }
            if (style.method_10986()) {
                sb.append(class_124.field_1055);
            }
            if (style.method_10987()) {
                sb.append(class_124.field_1051);
            }
            sb.append(string);
            return Optional.empty();
        }, class_2583.field_24360);
        return sb.toString();
    }

    private class_124 getNearestFormatting(int rgb) {
        class_124 nearest = class_124.field_1068;
        double minDistance = Double.MAX_VALUE;
        int r = rgb >> 16 & 0xFF;
        int g = rgb >> 8 & 0xFF;
        int b = rgb & 0xFF;
        for (class_124 f : class_124.values()) {
            Integer fRgb;
            if (!f.method_543() || (fRgb = f.method_532()) == null) continue;
            int fr = fRgb >> 16 & 0xFF;
            int fg = fRgb >> 8 & 0xFF;
            int fb = fRgb & 0xFF;
            double dist = Math.sqrt(Math.pow(r - fr, 2.0) + Math.pow(g - fg, 2.0) + Math.pow(b - fb, 2.0));
            if (!(dist < minDistance)) continue;
            minDistance = dist;
            nearest = f;
        }
        return nearest;
    }

    @Override
    public void onRender3D(class_4587 stack) {
        if (this.espMode.getValue() == ESPMode.Circle) {
            for (class_1297 ent : ItemESP.mc.field_1687.method_18112()) {
                if (!(ent instanceof class_1542)) continue;
                Render3DEngine.drawCircle3D(stack, ent, this.radius.getValue().floatValue(), this.circleColor.getValue().getColor(), this.cPoints.getValue(), this.useHudColor.getValue(), this.cOffset.getValue());
            }
        }
    }

    private void drawRect(class_287 bufferBuilder, Matrix4f stack, float posX, float posY, float endPosX, float endPosY) {
        Color black = Color.BLACK;
        Render2DEngine.setRectPoints(bufferBuilder, stack, posX - 1.0f, posY, posX + 0.5f, endPosY + 0.5f, black, black, black, black);
        Render2DEngine.setRectPoints(bufferBuilder, stack, posX - 1.0f, posY - 0.5f, endPosX + 0.5f, posY + 1.0f, black, black, black, black);
        Render2DEngine.setRectPoints(bufferBuilder, stack, endPosX - 1.0f, posY, endPosX + 0.5f, endPosY + 0.5f, black, black, black, black);
        Render2DEngine.setRectPoints(bufferBuilder, stack, posX - 1.0f, endPosY - 1.0f, endPosX + 0.5f, endPosY + 0.5f, black, black, black, black);
        Render2DEngine.setRectPoints(bufferBuilder, stack, posX - 0.5f, posY, posX, endPosY, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(0), HudEditor.getColor(270));
        Render2DEngine.setRectPoints(bufferBuilder, stack, posX, endPosY - 0.5f, endPosX, endPosY, HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(180), HudEditor.getColor(0));
        Render2DEngine.setRectPoints(bufferBuilder, stack, posX - 0.5f, posY, endPosX, posY + 0.5f, HudEditor.getColor(180), HudEditor.getColor(90), HudEditor.getColor(90), HudEditor.getColor(180));
        Render2DEngine.setRectPoints(bufferBuilder, stack, endPosX - 0.5f, posY, endPosX, endPosY, HudEditor.getColor(90), HudEditor.getColor(270), HudEditor.getColor(270), HudEditor.getColor(90));
    }

    @NotNull
    private static class_243[] getPoints(class_1297 ent) {
        class_238 axisAlignedBB = ItemESP.getBox(ent);
        class_243[] vectors = new class_243[]{new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1322, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1325, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1322, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1325, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1322, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1325, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1322, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1325, axisAlignedBB.field_1324)};
        return vectors;
    }

    @NotNull
    private static class_238 getBox(class_1297 ent) {
        double x = ent.field_6014 + (ent.method_23317() - ent.field_6014) * (double)Render3DEngine.getTickDelta();
        double y = ent.field_6036 + (ent.method_23318() - ent.field_6036) * (double)Render3DEngine.getTickDelta();
        double z = ent.field_5969 + (ent.method_23321() - ent.field_5969) * (double)Render3DEngine.getTickDelta();
        class_238 axisAlignedBB2 = ent.method_5829();
        class_238 axisAlignedBB = new class_238(axisAlignedBB2.field_1323 - ent.method_23317() + x - 0.05, axisAlignedBB2.field_1322 - ent.method_23318() + y, axisAlignedBB2.field_1321 - ent.method_23321() + z - 0.05, axisAlignedBB2.field_1320 - ent.method_23317() + x + 0.05, axisAlignedBB2.field_1325 - ent.method_23318() + y + 0.15, axisAlignedBB2.field_1324 - ent.method_23321() + z + 0.05);
        return axisAlignedBB;
    }

    private static enum ESPMode {
        Rect,
        Circle,
        None;

    }
}

