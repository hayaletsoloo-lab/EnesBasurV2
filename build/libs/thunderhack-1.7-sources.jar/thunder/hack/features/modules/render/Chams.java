/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.model.ModelPart
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.OverlayTexture
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexConsumer
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.render.entity.EndCrystalEntityRenderer
 *  net.minecraft.client.render.entity.LivingEntityRenderer
 *  net.minecraft.client.render.entity.model.EntityModel
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityPose
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.decoration.EndCrystalEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec3d
 *  org.joml.Quaternionf
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package thunder.hack.features.modules.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_742;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_892;
import net.minecraft.class_922;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventHeldItemRenderer;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

public class Chams
extends Module {
    public final Setting<Boolean> handItems = new Setting<Boolean>("HandItems", false);
    private final Setting<ColorSetting> handItemsColor = new Setting<ColorSetting>("HandItemsColor", new ColorSetting(new Color(-1827152291, true)), v -> this.handItems.getValue());
    public final Setting<Boolean> crystals = new Setting<Boolean>("Crystals", false);
    private final Setting<ColorSetting> crystalColor = new Setting<ColorSetting>("CrystalColor", new ColorSetting(new Color(-1825711896, true)), v -> this.crystals.getValue());
    private final Setting<Boolean> staticCrystal = new Setting<Boolean>("StaticCrystal", true, v -> this.crystals.getValue());
    private final Setting<CMode> crystalMode = new Setting<CMode>("CrystalMode", CMode.One, v -> this.crystals.getValue());
    public final Setting<Boolean> players = new Setting<Boolean>("Players", false);
    private final Setting<ColorSetting> playerColor = new Setting<ColorSetting>("PlayerColor", new ColorSetting(new Color(-1825711896, true)), v -> this.players.getValue());
    private final Setting<ColorSetting> friendColor = new Setting<ColorSetting>("FriendColor", new ColorSetting(new Color(-1825707984, true)), v -> this.players.getValue());
    private final Setting<Boolean> playerTexture = new Setting<Boolean>("PlayerTexture", true, v -> this.players.getValue());
    private final Setting<Boolean> simple = new Setting<Boolean>("Simple", false, v -> this.players.getValue());
    private final Setting<Boolean> alternativeBlending = new Setting<Boolean>("AlternativeBlending", true);
    private final class_2960 crystalTexture = class_2960.method_60654((String)"textures/entity/end_crystal/end_crystal.png");
    private static final float SINE_45_DEGREES = (float)Math.sin(0.7853981633974483);

    public Chams() {
        super("Chams", Module.Category.RENDER);
    }

    public void renderCrystal(class_1511 endCrystalEntity, float f, float g, class_4587 matrixStack, int i, class_630 core, class_630 frame) {
        class_287 buffer;
        RenderSystem.enableBlend();
        if (this.alternativeBlending.getValue().booleanValue()) {
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        } else {
            RenderSystem.defaultBlendFunc();
        }
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        if (this.crystalMode.getValue() != CMode.One) {
            if (this.crystalMode.getValue() == CMode.Three) {
                RenderSystem.setShaderTexture((int)0, (class_2960)(Object)this.crystalTexture);
            } else {
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.crystalTexture2);
            }
            RenderSystem.setShader(class_757::method_34542);
            buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        } else {
            RenderSystem.setShader(class_757::method_34539);
            buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        }
        matrixStack.method_22903();
        float h = this.staticCrystal.getValue() != false ? -1.4f : class_892.method_23155((class_1511)endCrystalEntity, (float)g);
        float j = ((float)endCrystalEntity.field_7034 + g) * 3.0f;
        matrixStack.method_22903();
        RenderSystem.setShaderColor((float)this.crystalColor.getValue().getGlRed(), (float)this.crystalColor.getValue().getGlGreen(), (float)this.crystalColor.getValue().getGlBlue(), (float)this.crystalColor.getValue().getGlAlpha());
        matrixStack.method_22905(2.0f, 2.0f, 2.0f);
        matrixStack.method_46416(0.0f, -0.5f, 0.0f);
        int k = class_4608.field_21444;
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(j));
        matrixStack.method_46416(0.0f, 1.5f + h / 2.0f, 0.0f);
        matrixStack.method_22907(new Quaternionf().setAngleAxis(1.0471976f, SINE_45_DEGREES, 0.0f, SINE_45_DEGREES));
        frame.method_22698(matrixStack, (class_4588)buffer, i, k);
        matrixStack.method_22905(0.875f, 0.875f, 0.875f);
        matrixStack.method_22907(new Quaternionf().setAngleAxis(1.0471976f, SINE_45_DEGREES, 0.0f, SINE_45_DEGREES));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(j));
        frame.method_22698(matrixStack, (class_4588)buffer, i, k);
        matrixStack.method_22905(0.875f, 0.875f, 0.875f);
        matrixStack.method_22907(new Quaternionf().setAngleAxis(1.0471976f, SINE_45_DEGREES, 0.0f, SINE_45_DEGREES));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(j));
        core.method_22698(matrixStack, (class_4588)buffer, i, k);
        matrixStack.method_22909();
        matrixStack.method_22909();
        Render2DEngine.endBuilding(buffer);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
    }

    public void renderPlayer(class_1657 pe, float f, float g, class_4587 matrixStack, int i, class_583 model, CallbackInfo ci, Runnable post) {
        float n;
        class_2350 direction;
        float l;
        class_1297 entity;
        class_287 buffer;
        RenderSystem.enableBlend();
        if (this.alternativeBlending.getValue().booleanValue()) {
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        } else {
            RenderSystem.defaultBlendFunc();
        }
        RenderSystem.enableCull();
        RenderSystem.disableDepthTest();
        if (!this.simple.getValue().booleanValue()) {
            RenderSystem.setShaderTexture((int)0, (class_2960)((class_742)pe).method_52814().comp_1626());
            RenderSystem.setShader(class_757::method_34542);
            buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        } else {
            RenderSystem.setShader(class_757::method_34539);
            buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        }
        matrixStack.method_22903();
        if (Managers.FRIEND.isFriend(pe)) {
            RenderSystem.setShaderColor((float)this.friendColor.getValue().getGlRed(), (float)this.friendColor.getValue().getGlGreen(), (float)this.friendColor.getValue().getGlBlue(), (float)this.friendColor.getValue().getGlAlpha());
        } else {
            RenderSystem.setShaderColor((float)this.playerColor.getValue().getGlRed(), (float)this.playerColor.getValue().getGlGreen(), (float)this.playerColor.getValue().getGlBlue(), (float)this.playerColor.getValue().getGlAlpha());
        }
        model.field_3447 = pe.method_6055(g);
        model.field_3449 = pe.method_5765();
        model.field_3448 = false;
        float h = class_3532.method_17821((float)g, (float)pe.field_6220, (float)pe.field_6283);
        float j = class_3532.method_17821((float)g, (float)pe.field_6259, (float)pe.field_6241);
        float k = j - h;
        if (pe.method_5765() && (entity = pe.method_5854()) instanceof class_1309) {
            class_1309 livingEntity2 = (class_1309)entity;
            h = class_3532.method_17821((float)g, (float)livingEntity2.field_6220, (float)livingEntity2.field_6283);
            k = j - h;
            l = class_3532.method_15393((float)k);
            if (l < -85.0f) {
                l = -85.0f;
            }
            if (l >= 85.0f) {
                l = 85.0f;
            }
            h = j - l;
            if (l * l > 2500.0f) {
                h += l * 0.2f;
            }
            k = j - h;
        }
        float m = class_3532.method_16439((float)g, (float)pe.field_6004, (float)pe.method_36455());
        if (class_922.method_38563((class_1309)pe)) {
            m *= -1.0f;
            k *= -1.0f;
        }
        if (pe.method_41328(class_4050.field_18078) && (direction = pe.method_18401()) != null) {
            n = pe.method_18381(class_4050.field_18076) - 0.1f;
            matrixStack.method_46416((float)(-direction.method_10148()) * n, 0.0f, (float)(-direction.method_10165()) * n);
        }
        l = (float)pe.field_6012 + g;
        this.setupTransforms1(pe, matrixStack, l, h, g);
        matrixStack.method_22905(-1.0f, -1.0f, 1.0f);
        matrixStack.method_22905(0.9375f, 0.9375f, 0.9375f);
        matrixStack.method_46416(0.0f, -1.501f, 0.0f);
        n = 0.0f;
        float o = 0.0f;
        if (!pe.method_5765() && pe.method_5805()) {
            n = pe.field_42108.method_48570(g);
            o = pe.field_42108.method_48572(g);
            if (pe.method_6109()) {
                o *= 3.0f;
            }
            if (n > 1.0f) {
                n = 1.0f;
            }
        }
        model.method_2816((class_1297)pe, o, n, g);
        model.method_2819((class_1297)pe, o, n, l, k, m);
        int p = class_922.method_23622((class_1309)pe, (float)0.0f);
        model.method_60879(matrixStack, (class_4588)buffer, i, p);
        Render2DEngine.endBuilding(buffer);
        RenderSystem.disableBlend();
        RenderSystem.disableCull();
        matrixStack.method_22909();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.enableDepthTest();
        if (!this.playerTexture.getValue().booleanValue()) {
            ci.cancel();
            post.run();
        }
    }

    public void setupTransforms1(class_1657 abstractClientPlayerEntity, class_4587 matrixStack, float f, float g, float h) {
        float j = abstractClientPlayerEntity.method_6024(h);
        float k = abstractClientPlayerEntity.method_5695(h);
        if (abstractClientPlayerEntity.method_6128()) {
            this.setupTransforms(abstractClientPlayerEntity, matrixStack, f, g, h);
            float l = (float)abstractClientPlayerEntity.method_6003() + h;
            float m = class_3532.method_15363((float)(l * l / 100.0f), (float)0.0f, (float)1.0f);
            if (!abstractClientPlayerEntity.method_6123()) {
                matrixStack.method_22907(class_7833.field_40714.rotationDegrees(m * (-90.0f - k)));
            }
            class_243 vec3d = abstractClientPlayerEntity.method_5828(h);
            class_243 vec3d2 = abstractClientPlayerEntity.method_18798();
            double d = vec3d2.method_37268();
            double e = vec3d.method_37268();
            if (d > 0.0 && e > 0.0) {
                double n = (vec3d2.field_1352 * vec3d.field_1352 + vec3d2.field_1350 * vec3d.field_1350) / Math.sqrt(d * e);
                double o = vec3d2.field_1352 * vec3d.field_1350 - vec3d2.field_1350 * vec3d.field_1352;
                matrixStack.method_22907(class_7833.field_40716.rotation((float)(Math.signum(o) * Math.acos(n))));
            }
        } else if (j > 0.0f) {
            this.setupTransforms(abstractClientPlayerEntity, matrixStack, f, g, h);
            float l = abstractClientPlayerEntity.method_5799() ? -90.0f - k : -90.0f;
            float m = class_3532.method_16439((float)j, (float)0.0f, (float)l);
            matrixStack.method_22907(class_7833.field_40714.rotationDegrees(m));
            if (abstractClientPlayerEntity.method_20232()) {
                matrixStack.method_46416(0.0f, -1.0f, 0.3f);
            }
        } else {
            this.setupTransforms(abstractClientPlayerEntity, matrixStack, f, g, h);
        }
    }

    private void setupTransforms(class_1657 entity, class_4587 matrices, float animationProgress, float bodyYaw, float tickDelta) {
        if (!entity.method_41328(class_4050.field_18078)) {
            matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0f - bodyYaw));
        }
        if (entity.field_6213 > 0) {
            float f2 = ((float)entity.field_6213 + tickDelta - 1.0f) / 20.0f * 1.6f;
            f2 = class_3532.method_15355((float)f2);
            if (f2 > 1.0f) {
                f2 = 1.0f;
            }
            matrices.method_22907(class_7833.field_40718.rotationDegrees(f2 * 90.0f));
        } else if (entity.method_6123()) {
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-90.0f - entity.method_36455()));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(((float)entity.field_6012 + tickDelta) * -75.0f));
        } else if (entity.method_41328(class_4050.field_18078)) {
            class_2350 direction = entity.method_18401();
            float g = direction != null ? Chams.getYaw(direction) : bodyYaw;
            matrices.method_22907(class_7833.field_40716.rotationDegrees(g));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(90.0f));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(270.0f));
        }
    }

    private static float getYaw(class_2350 direction) {
        return switch (direction) {
            case class_2350.field_11043 -> 270.0f;
            case class_2350.field_11035 -> 90.0f;
            case class_2350.field_11034 -> 180.0f;
            default -> 0.0f;
        };
    }

    @EventHandler
    public void onRenderHands(EventHeldItemRenderer e) {
        if (this.handItems.getValue().booleanValue()) {
            RenderSystem.setShaderColor((float)((float)this.handItemsColor.getValue().getRed() / 255.0f), (float)((float)this.handItemsColor.getValue().getGreen() / 255.0f), (float)((float)this.handItemsColor.getValue().getBlue() / 255.0f), (float)((float)this.handItemsColor.getValue().getAlpha() / 255.0f));
        }
    }

    private static enum CMode {
        One,
        Two,
        Three;

    }
}

