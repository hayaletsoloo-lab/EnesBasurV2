/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec3d
 */
package thunder.hack.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventAttack;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IClientPlayerEntity;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.render.Render2DEngine;

public class HitBubbles
extends Module {
    public final Setting<Integer> lifeTime = new Setting<Integer>("LifeTime", 30, 1, 150);
    private final ArrayList<HitBubble> bubbles = new ArrayList();

    public HitBubbles() {
        super("HitBubbles", Module.Category.RENDER);
    }

    @EventHandler
    public void onHit(EventAttack e) {
        class_243 point = Managers.PLAYER.getRtxPoint(((IClientPlayerEntity)HitBubbles.mc.field_1724).getLastYaw(), ((IClientPlayerEntity)HitBubbles.mc.field_1724).getLastPitch(), ModuleManager.aura.attackRange.getValue().floatValue());
        if (point != null && !e.isPre()) {
            this.bubbles.add(new HitBubble((float)point.field_1352, (float)point.field_1351, (float)point.field_1350, -((IClientPlayerEntity)HitBubbles.mc.field_1724).getLastYaw(), ((IClientPlayerEntity)HitBubbles.mc.field_1724).getLastPitch(), new Timer()));
        }
    }

    @Override
    public void onRender3D(class_4587 matrixStack) {
        RenderSystem.disableDepthTest();
        ArrayList<HitBubble> bubblesCopy = new ArrayList<HitBubble>(this.bubbles);
        bubblesCopy.forEach(b -> {
            matrixStack.method_22903();
            matrixStack.method_22904((double)b.x - HitBubbles.mc.method_1561().field_4686.method_19326().method_10216(), (double)b.y - HitBubbles.mc.method_1561().field_4686.method_19326().method_10214(), (double)b.z - HitBubbles.mc.method_1561().field_4686.method_19326().method_10215());
            matrixStack.method_22907(class_7833.field_40716.rotationDegrees(b.yaw));
            matrixStack.method_22907(class_7833.field_40714.rotationDegrees(b.pitch));
            Render2DEngine.drawBubble(matrixStack, (float)(-b.life.getPassedTimeMs()) / 4.0f, (float)b.life.getPassedTimeMs() / 1500.0f);
            matrixStack.method_22909();
        });
        RenderSystem.enableDepthTest();
        this.bubbles.removeIf(b -> b.life.passedMs(this.lifeTime.getValue() * 50));
    }

    public record HitBubble(float x, float y, float z, float yaw, float pitch, Timer life) {
    }
}

