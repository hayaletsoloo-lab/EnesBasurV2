/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.render.OverlayTexture
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.model.json.ModelTransformationMode
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.item.CrossbowItem
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.c2s.play.HandSwingC2SPacket
 *  net.minecraft.util.Arm
 *  net.minecraft.util.Hand
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RotationAxis
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.render;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2879;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.jetbrains.annotations.NotNull;
import thunder.hack.ThunderHack;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventHeldItemRenderer;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.injection.accesors.IHeldItemRenderer;
import thunder.hack.setting.Setting;

public class Animations
extends Module {
    private final Setting<Boolean> onlyaura = new Setting<Boolean>("OnlyAura", false);
    public Setting<Boolean> oldAnimationsM = new Setting<Boolean>("DisableSwapMain", true);
    public Setting<Boolean> oldAnimationsOff = new Setting<Boolean>("DisableSwapOff", true);
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Default);
    public static Setting<Boolean> slowAnimation = new Setting<Boolean>("SlowAnimation", true);
    public static Setting<Integer> slowAnimationVal = new Setting<Integer>("SlowValue", 12, 1, 50);
    public boolean flip;

    public Animations() {
        super("Animations", Module.Category.RENDER);
    }

    public boolean shouldAnimate() {
        return this.isEnabled() && (this.onlyaura.getValue() == false || ModuleManager.aura.isEnabled() && Aura.target != null) && this.mode.getValue() != Mode.Normal;
    }

    public boolean shouldChangeAnimationDuration() {
        return this.isEnabled() && (this.onlyaura.getValue() == false || ModuleManager.aura.isEnabled() && Aura.target != null);
    }

    @Override
    public void onUpdate() {
        if (Animations.fullNullCheck()) {
            return;
        }
        if (this.oldAnimationsM.getValue().booleanValue() && ((IHeldItemRenderer)mc.method_1561().method_43336()).getEquippedProgressMainHand() <= 1.0f) {
            ((IHeldItemRenderer)mc.method_1561().method_43336()).setEquippedProgressMainHand(1.0f);
            ((IHeldItemRenderer)mc.method_1561().method_43336()).setItemStackMainHand(Animations.mc.field_1724.method_6047());
        }
        if (this.oldAnimationsOff.getValue().booleanValue() && ((IHeldItemRenderer)mc.method_1561().method_43336()).getEquippedProgressOffHand() <= 1.0f) {
            ((IHeldItemRenderer)mc.method_1561().method_43336()).setEquippedProgressOffHand(1.0f);
            ((IHeldItemRenderer)mc.method_1561().method_43336()).setItemStackOffHand(Animations.mc.field_1724.method_6079());
        }
    }

    @EventHandler
    public void onPacketSend(PacketEvent.Send e) {
        if (e.getPacket() instanceof class_2879) {
            this.flip = !this.flip;
        }
    }

    private void renderSwordAnimation(class_4587 matrices, float f, float swingProgress, float equipProgress, class_1306 arm) {
        if (arm == class_1306.field_6182 && (this.mode.getValue() == Mode.Eleven || this.mode.getValue() == Mode.Ten || this.mode.getValue() == Mode.Nine || this.mode.getValue() == Mode.Three || this.mode.getValue() == Mode.Thirteen || this.mode.getValue() == Mode.Fourteen)) {
            this.applyEquipOffset(matrices, arm, equipProgress);
            matrices.method_46416(-ModuleManager.viewModel.positionMainX.getValue().floatValue(), ModuleManager.viewModel.positionMainY.getValue().floatValue(), ModuleManager.viewModel.positionMainZ.getValue().floatValue());
            this.applySwingOffset(matrices, arm, swingProgress);
            matrices.method_46416(ModuleManager.viewModel.positionMainX.getValue().floatValue(), -ModuleManager.viewModel.positionMainY.getValue().floatValue(), -ModuleManager.viewModel.positionMainZ.getValue().floatValue());
            return;
        }
        switch (this.mode.getValue().ordinal()) {
            case 1: {
                this.applyEquipOffset(matrices, arm, equipProgress);
                this.translateToViewModelOff(matrices);
                this.applySwingOffset(matrices, arm, swingProgress);
                this.translateBacklOff(matrices);
                break;
            }
            case 2: {
                float n = -0.4f * class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                this.applyEquipOffset(matrices, arm, n);
                int i = arm == class_1306.field_6183 ? 1 : -1;
                this.translateToViewModel(matrices);
                float f1 = class_3532.method_15374((float)(swingProgress * swingProgress * (float)Math.PI));
                matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * (45.0f + f1 * -20.0f)));
                float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * g * -20.0f));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(g * 0.0f));
                matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * -45.0f));
                this.translateBack(matrices);
                break;
            }
            case 3: {
                this.applyEquipOffset(matrices, arm, 0.2f * class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * ((float)Math.PI * 2))));
                break;
            }
            case 4: {
                float n = -0.4f * class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                this.applyEquipOffset(matrices, arm, n);
                int i = arm == class_1306.field_6183 ? 1 : -1;
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * (45.0f + f * -20.0f)));
                matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * g * -70.0f));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-70.0f));
                matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * -45.0f));
                this.translateBack(matrices);
                break;
            }
            case 5: {
                this.applyEquipOffset(matrices, arm, 0.0f);
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(swingProgress > 0.0f ? -class_3532.method_15374((float)(swingProgress * 13.0f)) * 37.0f : 0.0f));
                this.translateBack(matrices);
                break;
            }
            case 6: {
                this.applyEquipOffset(matrices, arm, 0.0f);
                int i = arm == class_1306.field_6183 ? 1 : -1;
                float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * g * -20.0f));
                this.translateBack(matrices);
                break;
            }
            case 7: {
                this.applyEquipOffset(matrices, arm, equipProgress);
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(swingProgress * (this.flip ? 360.0f : -360.0f)));
                this.translateBack(matrices);
                break;
            }
            case 9: {
                this.applyEquipOffset(matrices, arm, equipProgress);
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(swingProgress * -360.0f));
                this.translateBack(matrices);
                break;
            }
            case 8: {
                this.applyEquipOffset(matrices, arm, equipProgress);
                float a = -class_3532.method_15374((float)(swingProgress * 3.0f)) / 2.0f + 1.0f;
                matrices.method_22905(a, a, a);
                break;
            }
            case 10: {
                float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                this.applyEquipOffset(matrices, arm, 0.0f);
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(50.0f));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-30.0f * (1.0f - g) - 30.0f));
                matrices.method_22907(class_7833.field_40718.rotationDegrees(110.0f));
                this.translateBack(matrices);
                break;
            }
            case 11: {
                float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                matrices.method_46416(0.0f, 0.0f, 0.0f);
                this.applyEquipOffset(matrices, arm, 0.0f);
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(50.0f));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-60.0f * g - 50.0f));
                matrices.method_22907(class_7833.field_40718.rotationDegrees(110.0f));
                this.translateBack(matrices);
                break;
            }
            case 12: {
                float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                this.applyEquipOffset(matrices, arm, 0.0f);
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(50.0f));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-60.0f));
                matrices.method_22907(class_7833.field_40718.rotationDegrees(110.0f + 20.0f * g));
                this.translateBack(matrices);
                break;
            }
            case 13: {
                float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                this.applyEquipOffset(matrices, arm, 0.0f);
                matrices.method_46416(0.0f, 0.0f, -g / 4.0f);
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-120.0f));
                this.translateBack(matrices);
                break;
            }
            case 14: {
                float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                this.applyEquipOffset(matrices, arm, 0.0f);
                this.translateToViewModel(matrices);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-class_3532.method_15374((float)(swingProgress * 3.0f)) * 60.0f));
                matrices.method_22907(class_7833.field_40718.rotationDegrees(-60.0f * g));
                this.translateBack(matrices);
                break;
            }
            case 15: {
                if (swingProgress > 0.0f) {
                    float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                    matrices.method_46416(0.56f, equipProgress * -0.2f - 0.5f, -0.7f);
                    this.translateToViewModel(matrices);
                    matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0f));
                    matrices.method_22907(class_7833.field_40714.rotationDegrees(g * -85.0f));
                    if (ModuleManager.viewModel.isEnabled()) {
                        matrices.method_46416(-0.1f * ModuleManager.viewModel.scaleMain.getValue().floatValue(), 0.28f * ModuleManager.viewModel.scaleMain.getValue().floatValue(), 0.2f * ModuleManager.viewModel.scaleMain.getValue().floatValue());
                    } else {
                        matrices.method_46416(-0.1f, 0.28f, 0.2f);
                    }
                    matrices.method_22907(class_7833.field_40714.rotationDegrees(-85.0f));
                    this.translateBack(matrices);
                    break;
                }
                float n = -0.4f * class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                float m = 0.2f * class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * ((float)Math.PI * 2)));
                float f1 = -0.2f * class_3532.method_15374((float)(swingProgress * (float)Math.PI));
                matrices.method_46416(n, m, f1);
                this.applyEquipOffset(matrices, arm, equipProgress);
                this.applySwingOffset(matrices, arm, swingProgress);
            }
        }
    }

    public void renderFirstPersonItemCustom(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light) {
        if (!player.method_31550()) {
            boolean bl = hand == class_1268.field_5808;
            class_1306 arm = bl ? player.method_6068() : player.method_6068().method_5928();
            matrices.method_22903();
            float f = 0.0f;
            if (item.method_31574(class_1802.field_8399)) {
                boolean bl2 = class_1764.method_7781((class_1799)item);
                boolean bl3 = arm == class_1306.field_6183;
                int i = bl3 ? 1 : -1;
                int n = i;
                float g = 0.0f;
                if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
                    this.applyEquipOffset(matrices, arm, equipProgress);
                    matrices.method_46416((float)i * -0.4785682f, -0.094387f, 0.05731531f);
                    matrices.method_22907(class_7833.field_40714.rotationDegrees(-11.935f));
                    matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * 65.3f));
                    matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * -9.785f));
                    f = (float)item.method_7935((class_1309)Animations.mc.field_1724) - ((float)Animations.mc.field_1724.method_6014() - tickDelta + 1.0f);
                    g = f / (float)class_1764.method_7775((class_1799)item, (class_1309)Animations.mc.field_1724);
                    if (g > 1.0f) {
                        g = 1.0f;
                    }
                    if (g > 0.1f) {
                        float h = class_3532.method_15374((float)((f - 0.1f) * 1.3f));
                        float j = g - 0.1f;
                        float k = h * j;
                        matrices.method_46416(k * 0.0f, k * 0.004f, k * 0.0f);
                    }
                    matrices.method_46416(g * 0.0f, g * 0.0f, g * 0.04f);
                    matrices.method_22905(1.0f, 1.0f, 1.0f + g * 0.2f);
                    matrices.method_22907(class_7833.field_40715.rotationDegrees((float)i * 45.0f));
                } else {
                    f = -0.4f * class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
                    g = 0.2f * class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * ((float)Math.PI * 2)));
                    float h = -0.2f * class_3532.method_15374((float)(swingProgress * (float)Math.PI));
                    matrices.method_46416((float)i * f, g, h);
                    this.applyEquipOffset(matrices, arm, equipProgress);
                    this.applySwingOffset(matrices, arm, swingProgress);
                    if (bl2 && swingProgress < 0.001f && bl) {
                        matrices.method_46416((float)i * -0.641864f, 0.0f, 0.0f);
                        matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * 10.0f));
                    }
                }
                EventHeldItemRenderer event = new EventHeldItemRenderer(hand, item, equipProgress, matrices);
                ThunderHack.EVENT_BUS.post(event);
                this.renderItem((class_1309)player, item, bl3 ? class_811.field_4322 : class_811.field_4321, !bl3, matrices, vertexConsumers, light);
            } else {
                boolean bl2 = arm == class_1306.field_6183;
                float m = 0.0f;
                int l = 0;
                if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
                    l = bl2 ? 1 : -1;
                    switch (item.method_7976()) {
                        case field_8952: 
                        case field_8949: {
                            this.applyEquipOffset(matrices, arm, equipProgress);
                            break;
                        }
                        case field_8950: 
                        case field_8946: {
                            this.applyEatOrDrinkTransformationCustom(matrices, tickDelta, arm, item);
                            this.applyEquipOffset(matrices, arm, equipProgress);
                            break;
                        }
                        case field_8953: {
                            this.applyEquipOffset(matrices, arm, equipProgress);
                            matrices.method_46416((float)l * -0.2785682f, 0.18344387f, 0.15731531f);
                            matrices.method_22907(class_7833.field_40714.rotationDegrees(-13.935f));
                            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)l * 35.3f));
                            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)l * -9.785f));
                            m = (float)item.method_7935((class_1309)Animations.mc.field_1724) - ((float)Animations.mc.field_1724.method_6014() - tickDelta + 1.0f);
                            f = m / 20.0f;
                            f = (f * f + f * 2.0f) / 3.0f;
                            if (f > 1.0f) {
                                f = 1.0f;
                            }
                            if (f > 0.1f) {
                                float g = class_3532.method_15374((float)((m - 0.1f) * 1.3f));
                                float h = f - 0.1f;
                                float j = g * h;
                                matrices.method_46416(j * 0.0f, j * 0.004f, j * 0.0f);
                            }
                            matrices.method_46416(f * 0.0f, f * 0.0f, f * 0.04f);
                            matrices.method_22905(1.0f, 1.0f, 1.0f + f * 0.2f);
                            matrices.method_22907(class_7833.field_40715.rotationDegrees((float)l * 45.0f));
                            break;
                        }
                        case field_8951: {
                            this.applyEquipOffset(matrices, arm, equipProgress);
                            matrices.method_46416((float)l * -0.5f, 0.7f, 0.1f);
                            matrices.method_22907(class_7833.field_40714.rotationDegrees(-55.0f));
                            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)l * 35.3f));
                            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)l * -9.785f));
                            m = (float)item.method_7935((class_1309)Animations.mc.field_1724) - ((float)Animations.mc.field_1724.method_6014() - tickDelta + 1.0f);
                            f = m / 10.0f;
                            if (f > 1.0f) {
                                f = 1.0f;
                            }
                            if (f > 0.1f) {
                                float g = class_3532.method_15374((float)((m - 0.1f) * 1.3f));
                                float h = f - 0.1f;
                                float j = g * h;
                                matrices.method_46416(j * 0.0f, j * 0.004f, j * 0.0f);
                            }
                            matrices.method_46416(0.0f, 0.0f, f * 0.2f);
                            matrices.method_22905(1.0f, 1.0f, 1.0f + f * 0.2f);
                            matrices.method_22907(class_7833.field_40715.rotationDegrees((float)l * 45.0f));
                            break;
                        }
                        case field_42717: {
                            this.applyBrushTransformation(matrices, tickDelta, arm, item, equipProgress);
                        }
                    }
                } else if (player.method_6123()) {
                    this.applyEquipOffset(matrices, arm, equipProgress);
                    l = bl2 ? 1 : -1;
                    matrices.method_46416((float)l * -0.4f, 0.8f, 0.3f);
                    matrices.method_22907(class_7833.field_40716.rotationDegrees((float)l * 65.0f));
                    matrices.method_22907(class_7833.field_40718.rotationDegrees((float)l * -85.0f));
                } else {
                    this.renderSwordAnimation(matrices, f, swingProgress, equipProgress, arm);
                }
                EventHeldItemRenderer event = new EventHeldItemRenderer(hand, item, equipProgress, matrices);
                ThunderHack.EVENT_BUS.post(event);
                this.renderItem((class_1309)player, item, bl2 ? class_811.field_4322 : class_811.field_4321, !bl2, matrices, vertexConsumers, light);
            }
            matrices.method_22909();
        }
    }

    private void applyBrushTransformation(class_4587 matrices, float tickDelta, class_1306 arm, @NotNull class_1799 stack, float equipProgress) {
        this.applyEquipOffset(matrices, arm, equipProgress);
        float f = (float)Animations.mc.field_1724.method_6014() - tickDelta + 1.0f;
        float g = 1.0f - f / (float)stack.method_7935((class_1309)Animations.mc.field_1724);
        float m = -15.0f + 75.0f * class_3532.method_15362((float)(g * 45.0f * (float)Math.PI));
        if (arm != class_1306.field_6183) {
            matrices.method_22904(0.1, 0.83, 0.35);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0f));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-90.0f));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(m));
            matrices.method_22904(-0.3, 0.22, 0.35);
        } else {
            matrices.method_22904(-0.25, 0.22, 0.35);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0f));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(90.0f));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(0.0f));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(m));
        }
    }

    private void applyEquipOffset(@NotNull class_4587 matrices, class_1306 arm, float equipProgress) {
        int i = arm == class_1306.field_6183 ? 1 : -1;
        matrices.method_46416((float)i * 0.56f, -0.52f + equipProgress * -0.6f, -0.72f);
    }

    private void applySwingOffset(@NotNull class_4587 matrices, class_1306 arm, float swingProgress) {
        int i = arm == class_1306.field_6183 ? 1 : -1;
        float f = class_3532.method_15374((float)(swingProgress * swingProgress * (float)Math.PI));
        matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * (45.0f + f * -20.0f)));
        float g = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
        matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * g * -20.0f));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(g * -80.0f));
        matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * -45.0f));
    }

    public void renderItem(class_1309 entity, class_1799 stack, class_811 renderMode, boolean leftHanded, class_4587 matrices, class_4597 vertexConsumers, int light) {
        if (stack.method_7960()) {
            return;
        }
        mc.method_1480().method_23177(entity, stack, renderMode, leftHanded, matrices, vertexConsumers, entity.method_37908(), light, class_4608.field_21444, entity.method_5628() + renderMode.ordinal());
    }

    private void applyEatOrDrinkTransformationCustom(class_4587 matrices, float tickDelta, class_1306 arm, @NotNull class_1799 stack) {
        float h;
        float f = (float)Animations.mc.field_1724.method_6014() - tickDelta + 1.0f;
        float g = f / (float)stack.method_7935((class_1309)Animations.mc.field_1724);
        if (g < 0.8f) {
            h = class_3532.method_15379((float)(class_3532.method_15362((float)(f / 4.0f * (float)Math.PI)) * 0.005f));
            matrices.method_46416(0.0f, h, 0.0f);
        }
        h = 1.0f - (float)Math.pow(g, 27.0);
        int i = arm == class_1306.field_6183 ? 1 : -1;
        matrices.method_46416(h * 0.6f * (float)i * ModuleManager.viewModel.eatX.getValue().floatValue(), h * -0.5f * ModuleManager.viewModel.eatY.getValue().floatValue(), h * 0.0f);
        matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * h * 90.0f));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(h * 10.0f));
        matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * h * 30.0f));
    }

    private void translateToViewModel(class_4587 matrices) {
        if (ModuleManager.viewModel.isEnabled()) {
            matrices.method_46416(ModuleManager.viewModel.positionMainX.getValue().floatValue(), ModuleManager.viewModel.positionMainY.getValue().floatValue(), ModuleManager.viewModel.positionMainZ.getValue().floatValue());
        }
    }

    private void translateToViewModelOff(class_4587 matrices) {
        if (ModuleManager.viewModel.isEnabled()) {
            matrices.method_46416(-ModuleManager.viewModel.positionMainX.getValue().floatValue(), ModuleManager.viewModel.positionMainY.getValue().floatValue(), ModuleManager.viewModel.positionMainZ.getValue().floatValue());
        }
    }

    private void translateBack(class_4587 matrices) {
        if (ModuleManager.viewModel.isEnabled()) {
            matrices.method_46416(-ModuleManager.viewModel.positionMainX.getValue().floatValue(), -ModuleManager.viewModel.positionMainY.getValue().floatValue(), -ModuleManager.viewModel.positionMainZ.getValue().floatValue());
        }
    }

    private void translateBacklOff(class_4587 matrices) {
        if (ModuleManager.viewModel.isEnabled()) {
            matrices.method_46416(ModuleManager.viewModel.positionMainX.getValue().floatValue(), -ModuleManager.viewModel.positionMainY.getValue().floatValue(), -ModuleManager.viewModel.positionMainZ.getValue().floatValue());
        }
    }

    private static enum Mode {
        Normal,
        Default,
        One,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Eleven,
        Twelve,
        Thirteen,
        Fourteen;

    }
}

