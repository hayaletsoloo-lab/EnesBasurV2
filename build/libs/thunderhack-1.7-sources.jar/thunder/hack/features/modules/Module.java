/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.logging.LogUtils
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.network.PendingUpdateManager
 *  net.minecraft.client.network.SequencedPacketCreator
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package thunder.hack.features.modules;

import com.mojang.logging.LogUtils;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_7202;
import net.minecraft.class_7204;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.CommandManager;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.client.UnHook;
import thunder.hack.features.modules.client.Windows;
import thunder.hack.gui.notification.Notification;
import thunder.hack.injection.accesors.IClientWorldMixin;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.Bind;

public abstract class Module {
    private final Setting<Bind> bind = new Setting<Bind>("Keybind", new Bind(-1, false, false));
    private final Setting<Boolean> drawn = new Setting<Boolean>("Drawn", true);
    private final Setting<Boolean> enabled = new Setting<Boolean>("Enabled", false);
    private final String description;
    private final Category category;
    private final String displayName;
    private final List<String> ignoreSoundList = Arrays.asList("ClickGui", "ThunderGui", "HudEditor");
    public static final class_310 mc = class_310.method_1551();

    public Module(@NotNull String name, @NotNull Category category) {
        this.displayName = name;
        this.description = "descriptions." + category.getName().toLowerCase() + "." + name.toLowerCase();
        this.category = category;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onLogin() {
    }

    public void onLogout() {
    }

    public void onUpdate() {
    }

    public void onRender2D(class_332 event) {
    }

    public void onRender3D(class_4587 event) {
    }

    public void onUnload() {
    }

    public boolean isToggleable() {
        return true;
    }

    protected void sendPacket(class_2596<?> packet) {
        if (mc.method_1562() == null) {
            return;
        }
        mc.method_1562().method_52787(packet);
    }

    protected void sendPacketSilent(class_2596<?> packet) {
        if (mc.method_1562() == null) {
            return;
        }
        ThunderHack.core.silentPackets.add(packet);
        mc.method_1562().method_52787(packet);
    }

    protected void sendSequencedPacket(class_7204 packetCreator) {
        if (mc.method_1562() == null || Module.mc.field_1687 == null) {
            return;
        }
        try (class_7202 pendingUpdateManager = ((IClientWorldMixin)Module.mc.field_1687).getPendingUpdateManager().method_41937();){
            int i = pendingUpdateManager.method_41942();
            mc.method_1562().method_52787(packetCreator.predict(i));
        }
    }

    public String getDisplayInfo() {
        return null;
    }

    public boolean isOn() {
        return this.enabled.getValue();
    }

    public boolean isOff() {
        return this.enabled.getValue() == false;
    }

    public void setEnabled(boolean enabled) {
        this.enabled.setValue(enabled);
    }

    public void onThread() {
    }

    public void enable() {
        if (!(this instanceof UnHook)) {
            this.enabled.setValue(true);
        }
        if (!Module.fullNullCheck() || this instanceof UnHook || this instanceof Windows) {
            this.onEnable();
        }
        if (this.isOn()) {
            ThunderHack.EVENT_BUS.subscribe((Object)this);
        }
        if (Module.fullNullCheck()) {
            return;
        }
        LogUtils.getLogger().info("[ThunderHack] enabled " + this.getName());
        Managers.MODULE.sortModules();
        if (!this.ignoreSoundList.contains(this.getDisplayName())) {
            Managers.NOTIFICATION.publicity(this.getDisplayName(), ClientSettings.isRu() ? "\u041c\u043e\u0434\u0443\u043b\u044c \u0432\u043a\u043b\u044e\u0447\u0435\u043d!" : "Was Enabled!", 2, Notification.Type.ENABLED);
            Managers.SOUND.playEnable();
        }
    }

    public void disable(String reason) {
        this.sendMessage(reason);
        this.disable();
    }

    public void disable() {
        try {
            ThunderHack.EVENT_BUS.unsubscribe((Object)this);
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.enabled.setValue(false);
        Managers.MODULE.sortModules();
        if (Module.fullNullCheck()) {
            return;
        }
        this.onDisable();
        ThunderHack.LOGGER.info("[ThunderHack] disabled {}", (Object)this.getName());
        if (!this.ignoreSoundList.contains(this.getDisplayName())) {
            Managers.NOTIFICATION.publicity(this.getDisplayName(), ClientSettings.isRu() ? "\u041c\u043e\u0434\u0443\u043b\u044c \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d!" : "Was Disabled!", 2, Notification.Type.DISABLED);
            Managers.SOUND.playDisable();
        }
    }

    public void toggle() {
        if (this.enabled.getValue().booleanValue()) {
            this.disable();
        } else {
            this.enable();
        }
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public String getDescription() {
        return this.description;
    }

    public boolean isDrawn() {
        return this.drawn.getValue();
    }

    public void setDrawn(boolean d) {
        this.drawn.setValue(d);
    }

    public Category getCategory() {
        return this.category;
    }

    public Bind getBind() {
        return this.bind.getValue();
    }

    public void setBind(int key, boolean mouse, boolean hold) {
        this.setBind(new Bind(key, mouse, hold));
    }

    public void setBind(Bind b) {
        this.bind.setValue(b);
    }

    public boolean listening() {
        return this.isOn();
    }

    public String getFullArrayString() {
        return this.getDisplayName() + String.valueOf(class_124.field_1080) + (String)(this.getDisplayInfo() != null ? " [" + String.valueOf(class_124.field_1068) + this.getDisplayInfo() + String.valueOf(class_124.field_1080) + "]" : "");
    }

    public static boolean fullNullCheck() {
        return Module.mc.field_1724 == null || Module.mc.field_1687 == null || ModuleManager.unHook.isEnabled();
    }

    public String getName() {
        return this.getDisplayName();
    }

    public List<Setting<?>> getSettings() {
        ArrayList<Setting<?>> settingList = new ArrayList<>();
        for (Class<?> currentSuperclass = this.getClass(); currentSuperclass != null; currentSuperclass = currentSuperclass.getSuperclass()) {
            for (Field field : currentSuperclass.getDeclaredFields()) {
                if (!Setting.class.isAssignableFrom(field.getType())) continue;
                try {
                    field.setAccessible(true);
                    settingList.add((Setting)field.get(this));
                }
                catch (IllegalAccessException error) {
                    ThunderHack.LOGGER.warn(error.getMessage());
                }
            }
        }
        settingList.forEach(s -> s.setModule(this));
        return settingList;
    }

    public boolean isEnabled() {
        return this.isOn();
    }

    public boolean isDisabled() {
        return !this.isEnabled();
    }

    public static void clickSlot(int id) {
        if (id == -1 || Module.mc.field_1761 == null || Module.mc.field_1724 == null) {
            return;
        }
        Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, id, 0, class_1713.field_7790, (class_1657)Module.mc.field_1724);
    }

    public static void clickSlot(int id, class_1713 type) {
        if (id == -1 || Module.mc.field_1761 == null || Module.mc.field_1724 == null) {
            return;
        }
        Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, id, 0, type, (class_1657)Module.mc.field_1724);
    }

    public static void clickSlot(int id, int button, class_1713 type) {
        if (id == -1 || Module.mc.field_1761 == null || Module.mc.field_1724 == null) {
            return;
        }
        Module.mc.field_1761.method_2906(Module.mc.field_1724.field_7512.field_7763, id, button, type, (class_1657)Module.mc.field_1724);
    }

    public void sendMessage(String message) {
        if (Module.fullNullCheck() || !ClientSettings.clientMessages.getValue().booleanValue() || ModuleManager.unHook.isEnabled()) {
            return;
        }
        if (mc.method_18854()) {
            Module.mc.field_1724.method_43496(class_2561.method_30163((String)(CommandManager.getClientMessage() + " " + String.valueOf(class_124.field_1080) + "[" + String.valueOf(class_124.field_1064) + this.getDisplayName() + String.valueOf(class_124.field_1080) + "] " + message)));
        } else {
            mc.method_40000(() -> Module.mc.field_1724.method_43496(class_2561.method_30163((String)(CommandManager.getClientMessage() + " " + String.valueOf(class_124.field_1080) + "[" + String.valueOf(class_124.field_1064) + this.getDisplayName() + String.valueOf(class_124.field_1080) + "] " + message))));
        }
    }

    public void sendChatMessage(String message) {
        if (Module.fullNullCheck()) {
            return;
        }
        mc.method_1562().method_45729(message);
    }

    public void sendChatCommand(String command) {
        if (Module.fullNullCheck()) {
            return;
        }
        mc.method_1562().method_45730(command);
    }

    public void debug(String message) {
        if (Module.fullNullCheck() || !ClientSettings.debug.getValue().booleanValue()) {
            return;
        }
        if (mc.method_18854()) {
            Module.mc.field_1724.method_43496(class_2561.method_30163((String)(CommandManager.getClientMessage() + " " + String.valueOf(class_124.field_1080) + "[" + String.valueOf(class_124.field_1064) + this.getDisplayName() + String.valueOf(class_124.field_1080) + "] [\ud83d\udd27] " + message)));
        } else {
            mc.method_40000(() -> Module.mc.field_1724.method_43496(class_2561.method_30163((String)(CommandManager.getClientMessage() + " " + String.valueOf(class_124.field_1080) + "[" + String.valueOf(class_124.field_1064) + this.getDisplayName() + String.valueOf(class_124.field_1080) + "] [\ud83d\udd27] " + message))));
        }
    }

    public boolean isKeyPressed(int button) {
        if (button == -1 || ModuleManager.unHook.isEnabled()) {
            return false;
        }
        if (Managers.MODULE.activeMouseKeys.contains(button)) {
            Managers.MODULE.activeMouseKeys.clear();
            return true;
        }
        if (button < 10) {
            return false;
        }
        return class_3675.method_15987((long)mc.method_22683().method_4490(), (int)button);
    }

    public boolean isKeyPressed(Setting<Bind> bind) {
        if (bind.getValue().getKey() == -1 || ModuleManager.unHook.isEnabled()) {
            return false;
        }
        return this.isKeyPressed(bind.getValue().getKey());
    }

    @Nullable
    public Setting<?> getSettingByName(String name) {
        for (Setting<?> setting : this.getSettings()) {
            if (!setting.getName().equalsIgnoreCase(name)) continue;
            return setting;
        }
        return null;
    }

    public static class Category {
        private final String name;
        private static final Map<String, Category> CATEGORIES = new LinkedHashMap<String, Category>();
        public static final Category COMBAT = new Category("Combat");
        public static final Category MISC = new Category("Misc");
        public static final Category RENDER = new Category("Render");
        public static final Category MOVEMENT = new Category("Movement");
        public static final Category PLAYER = new Category("Player");
        public static final Category CLIENT = new Category("Client");
        public static final Category HUD = new Category("HUD");

        private Category(String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }

        public static Category getCategory(String name) {
            return CATEGORIES.computeIfAbsent(name, Category::new);
        }

        public static Collection<Category> values() {
            return CATEGORIES.values();
        }

        public static boolean isCustomCategory(Category category) {
            Set<String> predefinedCategoryNames = Set.of("Combat", "Misc", "Render", "Movement", "Player", "Client", "HUD");
            return !predefinedCategoryNames.contains(category.getName());
        }

        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            Category category = (Category)o;
            return Objects.equals(this.name, category.name);
        }

        public int hashCode() {
            return Objects.hash(this.name);
        }

        static {
            CATEGORIES.put("Combat", COMBAT);
            CATEGORIES.put("Misc", MISC);
            CATEGORIES.put("Render", RENDER);
            CATEGORIES.put("Movement", MOVEMENT);
            CATEGORIES.put("Player", PLAYER);
            CATEGORIES.put("Client", CLIENT);
            CATEGORIES.put("HUD", HUD);
        }
    }
}

