/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  org.jetbrains.annotations.Nullable
 */
package thunder.hack.features.modules.combat;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.jetbrains.annotations.Nullable;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.player.CombatManager;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.base.TrapModule;
import thunder.hack.setting.Setting;

public final class AutoTrap
extends TrapModule {
    private final Setting<CombatManager.TargetBy> targetBy = new Setting<CombatManager.TargetBy>("Target By", CombatManager.TargetBy.Distance);
    private final Setting<Boolean> targetMovingPlayers = new Setting<Boolean>("MovingPlayers", false);

    public AutoTrap() {
        super("AutoTrap", Module.Category.COMBAT);
    }

    @Override
    protected boolean needNewTarget() {
        return this.target == null || this.target.method_5739((class_1297)AutoTrap.mc.field_1724) > ((Float)(Object)this.range.getValue()).floatValue() || this.target.method_6032() + this.target.method_6067() <= 0.0f || this.target.method_29504();
    }

    @Override
    @Nullable
    protected class_1657 getTarget() {
        return Managers.COMBAT.getTarget(((Float)(Object)this.range.getValue()).floatValue(), this.targetBy.getValue(), p -> p.method_18798().method_1027() < 0.08 || this.targetMovingPlayers.getValue() != false);
    }
}

