/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.network.PendingUpdateManager
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.HandSwingC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.util.Hand
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 */
package thunder.hack.features.modules.combat;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2886;
import net.minecraft.class_4587;
import net.minecraft.class_7202;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.player.ElytraHelper;
import thunder.hack.injection.accesors.IClientWorldMixin;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render3DEngine;

public class ElytraTarget
extends Module {
    public final Setting<Boolean> drawBox = new Setting<Boolean>("Draw Box", true);
    public final Setting<ColorSetting> boxColor = new Setting<ColorSetting>("Box Color", new ColorSetting(new Color(0, 0, 255, 120).getRGB()));
    public final Setting<Float> distanceInFront = new Setting<Float>("DistanceInFront", Float.valueOf(2.5f), Float.valueOf(0.0f), Float.valueOf(20.0f));
    public final Setting<Float> distance = new Setting<Float>("Distance", Float.valueOf(100.0f), Float.valueOf(10.0f), Float.valueOf(400.0f));
    public final Setting<Boolean> autoFirework = new Setting<Boolean>("Auto Firework", true);
    public final Setting<Integer> fireworkDelay = new Setting<Integer>("Firework Delay", 1000, 200, 5000, v -> this.autoFirework.getValue());
    public static class_1657 target = null;
    public static class_243 predictedPos = null;
    private class_1937 lastWorld;
    private long lastFireworkTime = 0L;

    public ElytraTarget() {
        super("ElytraTarget", Module.Category.COMBAT);
    }

    @EventHandler
    public void onTick(EventTick event) {
        if (ElytraTarget.mc.field_1724 == null || ElytraTarget.mc.field_1687 == null) {
            target = null;
            predictedPos = null;
            return;
        }
        if (ElytraTarget.mc.field_1687 != this.lastWorld) {
            target = null;
            this.lastWorld = ElytraTarget.mc.field_1687;
        }
        if ((target = this.findTarget()) != null) {
            predictedPos = this.getFrontPosition((class_1297)target, this.distanceInFront.getValue().floatValue());
            this.useFireworkIfNeeded();
        } else {
            predictedPos = null;
        }
    }

    private class_1657 findTarget() {
        class_1657 bestTarget = null;
        float closestDistance = this.distance.getValue().floatValue();
        for (class_1657 player : ElytraTarget.mc.field_1687.method_18456()) {
            float d;
            boolean isFlying;
            if (player == ElytraTarget.mc.field_1724 || !player.method_5805() || player.method_31481() || player.method_6032() <= 0.0f || Managers.FRIEND.isFriend(player) || !(isFlying = player.method_6128() || player.method_31548().method_7372(2).method_31574(class_1802.field_8833) && !player.method_24828()) || !((d = ElytraTarget.mc.field_1724.method_5739((class_1297)player)) < closestDistance)) continue;
            bestTarget = player;
            closestDistance = d;
        }
        return bestTarget;
    }

    private boolean skipEntity(class_1297 entity) {
        if (!(entity instanceof class_1657)) {
            return true;
        }
        class_1657 player = (class_1657)entity;
        return player.method_31481() || !player.method_5805() || player.method_6032() <= 0.0f || !player.method_6128() || Managers.FRIEND.isFriend(player) || ElytraTarget.mc.field_1724.method_5739((class_1297)player) > this.distance.getValue().floatValue();
    }

    @Override
    public void onRender3D(class_4587 stack) {
        if (target != null && predictedPos != null && this.drawBox.getValue().booleanValue()) {
            class_238 targetBox = target.method_5829();
            double w = (targetBox.field_1320 - targetBox.field_1323) / 2.0;
            double h = targetBox.field_1325 - targetBox.field_1322;
            class_238 box = new class_238(ElytraTarget.predictedPos.field_1352 - w, ElytraTarget.predictedPos.field_1351, ElytraTarget.predictedPos.field_1350 - w, ElytraTarget.predictedPos.field_1352 + w, ElytraTarget.predictedPos.field_1351 + h, ElytraTarget.predictedPos.field_1350 + w);
            Color color = this.boxColor.getValue().getColorObject();
            Render3DEngine.drawFilledBox(stack, box, color);
            Render3DEngine.drawBoxOutline(box, color, 2.0f);
        }
    }

    private class_243 getFrontPosition(class_1297 target, double distanceInFront) {
        class_243 targetPos = target.method_19538();
        class_243 lookVec = target.method_5720();
        class_243 horizontalLookVec = new class_243(lookVec.field_1352, 0.0, lookVec.field_1350).method_1029();
        class_243 frontPos = targetPos.method_1019(horizontalLookVec.method_1021(distanceInFront));
        return new class_243(frontPos.field_1352, targetPos.field_1351 + 1.2, frontPos.field_1350);
    }

    private void useFireworkIfNeeded() {
        if (ElytraTarget.mc.field_1724 == null || ElytraTarget.mc.field_1687 == null || !this.autoFirework.getValue().booleanValue()) {
            return;
        }
        if (!ElytraTarget.mc.field_1724.method_6128()) {
            return;
        }
        if (System.currentTimeMillis() - this.lastFireworkTime < (long)this.fireworkDelay.getValue().intValue()) {
            return;
        }
        int fireworkSlot = -1;
        for (int i = 0; i < 9; ++i) {
            if (ElytraTarget.mc.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_8639) continue;
            fireworkSlot = i;
            break;
        }
        if (fireworkSlot == -1) {
            return;
        }
        String fireworkMode = ElytraHelper.getInstance().getFireWorkMode();
        boolean shouldSwing = ElytraHelper.getInstance().isSwingEnabled();
        int oldSlot = ElytraTarget.mc.field_1724.method_31548().field_7545;
        if (fireworkMode.equalsIgnoreCase("Legit")) {
            ElytraTarget.mc.field_1724.method_31548().field_7545 = fireworkSlot;
            ElytraTarget.mc.field_1761.method_2919((class_1657)ElytraTarget.mc.field_1724, class_1268.field_5808);
            if (shouldSwing) {
                ElytraTarget.mc.field_1724.method_6104(class_1268.field_5808);
            }
        } else if (fireworkMode.equalsIgnoreCase("Silent")) {
            ElytraTarget.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(fireworkSlot));
            try (class_7202 pendingUpdateManager = ((IClientWorldMixin)ElytraTarget.mc.field_1687).getPendingUpdateManager().method_41937();){
                int sequence = pendingUpdateManager.method_41942();
                ElytraTarget.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, sequence, ElytraTarget.mc.field_1724.method_36454(), ElytraTarget.mc.field_1724.method_36455()));
            }
            if (shouldSwing) {
                ElytraTarget.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
            }
            ElytraTarget.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(oldSlot));
        }
        this.lastFireworkTime = System.currentTimeMillis();
    }
}

