/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.network.OtherClientPlayerEntity
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.attribute.EntityAttributes
 *  net.minecraft.entity.decoration.ArmorStandEntity
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.mob.HostileEntity
 *  net.minecraft.entity.mob.MobEntity
 *  net.minecraft.entity.mob.SlimeEntity
 *  net.minecraft.entity.passive.AnimalEntity
 *  net.minecraft.entity.passive.CatEntity
 *  net.minecraft.entity.passive.VillagerEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.projectile.FireballEntity
 *  net.minecraft.entity.projectile.ProjectileEntity
 *  net.minecraft.entity.projectile.ShulkerBulletEntity
 *  net.minecraft.item.AxeItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.item.SwordItem
 *  net.minecraft.item.TridentItem
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$Full
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.Hand
 *  net.minecraft.util.UseAction
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.combat;

import java.util.Comparator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1451;
import net.minecraft.class_1531;
import net.minecraft.class_1588;
import net.minecraft.class_1621;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1674;
import net.minecraft.class_1676;
import net.minecraft.class_1678;
import net.minecraft.class_1713;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_2708;
import net.minecraft.class_2815;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5134;
import net.minecraft.class_745;
import org.jetbrains.annotations.NotNull;
import thunder.hack.ThunderHack;
import thunder.hack.core.Core;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.core.manager.player.PlayerManager;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.combat.AntiBot;
import thunder.hack.features.modules.combat.Criticals;
import thunder.hack.features.modules.combat.ElytraTarget;
import thunder.hack.gui.notification.Notification;
import thunder.hack.injection.accesors.ILivingEntity;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.setting.impl.SettingGroup;
import thunder.hack.utility.BaritoneUtility;
import thunder.hack.utility.Timer;
import thunder.hack.utility.interfaces.IOtherClientPlayerEntity;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.PlayerUtility;
import thunder.hack.utility.player.SearchInvResult;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.animation.CaptureMark;

public class Aura
extends Module {
    public final Setting<Float> attackRange = new Setting<Float>("Range", Float.valueOf(3.1f), Float.valueOf(1.0f), Float.valueOf(6.0f));
    public final Setting<Float> wallRange = new Setting<Float>("ThroughWallsRange", Float.valueOf(3.1f), Float.valueOf(0.0f), Float.valueOf(6.0f));
    public final Setting<Boolean> elytra = new Setting<Boolean>("ElytraOverride", false);
    public final Setting<Float> elytraAttackRange = new Setting<Float>("ElytraRange", Float.valueOf(30.0f), Float.valueOf(1.0f), Float.valueOf(100.0f), v -> this.elytra.getValue());
    public final Setting<Float> elytraWallRange = new Setting<Float>("ElytraThroughWallsRange", Float.valueOf(30.0f), Float.valueOf(0.0f), Float.valueOf(100.0f), v -> this.elytra.getValue());
    public final Setting<WallsBypass> wallsBypass = new Setting<WallsBypass>("WallsBypass", WallsBypass.Off, v -> this.getWallRange() > 0.0f);
    public final Setting<Integer> fov = new Setting<Integer>("FOV", 180, 1, 180);
    public final Setting<Mode> rotationMode = new Setting<Mode>("RotationMode", Mode.Track);
    public final Setting<Integer> interactTicks = new Setting<Integer>("InteractTicks", 3, 1, 10, v -> this.rotationMode.getValue() == Mode.Interact);
    public final Setting<Switch> switchMode = new Setting<Switch>("AutoWeapon", Switch.None);
    public final Setting<Boolean> onlyWeapon = new Setting<Boolean>("OnlyWeapon", false, v -> this.switchMode.getValue() != Switch.Silent);
    public final Setting<BooleanSettingGroup> smartCrit = new Setting<BooleanSettingGroup>("SmartCrit", new BooleanSettingGroup(true));
    public final Setting<Boolean> onlySpace = new Setting<Boolean>("OnlyCrit", false).addToGroup(this.smartCrit);
    public final Setting<Boolean> autoJump = new Setting<Boolean>("AutoJump", false).addToGroup(this.smartCrit);
    public final Setting<Boolean> shieldBreaker = new Setting<Boolean>("ShieldBreaker", true);
    public final Setting<Boolean> pauseWhileEating = new Setting<Boolean>("PauseWhileEating", false);
    public final Setting<Boolean> tpsSync = new Setting<Boolean>("TPSSync", false);
    public final Setting<Boolean> clientLook = new Setting<Boolean>("ClientLook", false);
    public final Setting<Boolean> pauseBaritone = new Setting<Boolean>("PauseBaritone", false);
    public final Setting<BooleanSettingGroup> oldDelay = new Setting<BooleanSettingGroup>("OldDelay", new BooleanSettingGroup(false));
    public final Setting<Integer> minCPS = new Setting<Integer>("MinCPS", 7, 1, 20).addToGroup(this.oldDelay);
    public final Setting<Integer> maxCPS = new Setting<Integer>("MaxCPS", 12, 1, 20).addToGroup(this.oldDelay);
    public final Setting<ESP> esp = new Setting<ESP>("ESP", ESP.ThunderHack);
    public final Setting<SettingGroup> espGroup = new Setting<SettingGroup>("ESPSettings", new SettingGroup(false, 0), v -> this.esp.is(ESP.ThunderHackV2));
    public final Setting<Integer> espLength = new Setting<Integer>("ESPLength", 14, 1, 40, v -> this.esp.is(ESP.ThunderHackV2)).addToGroup(this.espGroup);
    public final Setting<Integer> espFactor = new Setting<Integer>("ESPFactor", 8, 1, 20, v -> this.esp.is(ESP.ThunderHackV2)).addToGroup(this.espGroup);
    public final Setting<Float> espShaking = new Setting<Float>("ESPShaking", Float.valueOf(1.8f), Float.valueOf(1.5f), Float.valueOf(10.0f), v -> this.esp.is(ESP.ThunderHackV2)).addToGroup(this.espGroup);
    public final Setting<Float> espAmplitude = new Setting<Float>("ESPAmplitude", Float.valueOf(3.0f), Float.valueOf(0.1f), Float.valueOf(8.0f), v -> this.esp.is(ESP.ThunderHackV2)).addToGroup(this.espGroup);
    public final Setting<Sort> sort = new Setting<Sort>("Sort", Sort.LowestDistance);
    public final Setting<Boolean> lockTarget = new Setting<Boolean>("LockTarget", true);
    public final Setting<Boolean> elytraTarget = new Setting<Boolean>("ElytraTarget", true);
    public final Setting<SettingGroup> advanced = new Setting<SettingGroup>("Advanced", new SettingGroup(false, 0));
    public final Setting<Float> aimRange = new Setting<Float>("AimRange", Float.valueOf(3.1f), Float.valueOf(0.0f), Float.valueOf(6.0f)).addToGroup(this.advanced);
    public final Setting<Boolean> randomHitDelay = new Setting<Boolean>("RandomHitDelay", false).addToGroup(this.advanced);
    public final Setting<Boolean> pauseInInventory = new Setting<Boolean>("PauseInInventory", true).addToGroup(this.advanced);
    public final Setting<Boolean> dropSprint = new Setting<Boolean>("DropSprint", true).addToGroup(this.advanced);
    public final Setting<Boolean> returnSprint = new Setting<Boolean>("ReturnSprint", true, v -> this.dropSprint.getValue()).addToGroup(this.advanced);
    public final Setting<RayTrace> rayTrace = new Setting<RayTrace>("RayTrace", RayTrace.OnlyTarget).addToGroup(this.advanced);
    public final Setting<Boolean> grimRayTrace = new Setting<Boolean>("GrimRayTrace", true).addToGroup(this.advanced);
    public final Setting<Boolean> unpressShield = new Setting<Boolean>("UnpressShield", true).addToGroup(this.advanced);
    public final Setting<Boolean> deathDisable = new Setting<Boolean>("DisableOnDeath", true).addToGroup(this.advanced);
    public final Setting<Boolean> tpDisable = new Setting<Boolean>("TPDisable", false).addToGroup(this.advanced);
    public final Setting<Boolean> pullDown = new Setting<Boolean>("FastFall", false).addToGroup(this.advanced);
    public final Setting<Boolean> onlyJumpBoost = new Setting<Boolean>("OnlyJumpBoost", false, v -> this.pullDown.getValue()).addToGroup(this.advanced);
    public final Setting<Float> pullValue = new Setting<Float>("PullValue", Float.valueOf(3.0f), Float.valueOf(0.0f), Float.valueOf(20.0f), v -> this.pullDown.getValue()).addToGroup(this.advanced);
    public final Setting<AttackHand> attackHand = new Setting<AttackHand>("AttackHand", AttackHand.MainHand).addToGroup(this.advanced);
    public final Setting<Resolver> resolver = new Setting<Resolver>("Resolver", Resolver.Advantage).addToGroup(this.advanced);
    public final Setting<Integer> backTicks = new Setting<Integer>("BackTicks", 4, 1, 20, v -> this.resolver.is(Resolver.BackTrack)).addToGroup(this.advanced);
    public final Setting<Boolean> resolverVisualisation = new Setting<Boolean>("ResolverVisualisation", false, v -> !this.resolver.is(Resolver.Off)).addToGroup(this.advanced);
    public final Setting<AccelerateOnHit> accelerateOnHit = new Setting<AccelerateOnHit>("AccelerateOnHit", AccelerateOnHit.Off).addToGroup(this.advanced);
    public final Setting<Integer> minYawStep = new Setting<Integer>("MinYawStep", 65, 1, 180).addToGroup(this.advanced);
    public final Setting<Integer> maxYawStep = new Setting<Integer>("MaxYawStep", 75, 1, 180).addToGroup(this.advanced);
    public final Setting<Float> aimedPitchStep = new Setting<Float>("AimedPitchStep", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(90.0f)).addToGroup(this.advanced);
    public final Setting<Float> maxPitchStep = new Setting<Float>("MaxPitchStep", Float.valueOf(8.0f), Float.valueOf(1.0f), Float.valueOf(90.0f)).addToGroup(this.advanced);
    public final Setting<Float> pitchAccelerate = new Setting<Float>("PitchAccelerate", Float.valueOf(1.65f), Float.valueOf(1.0f), Float.valueOf(10.0f)).addToGroup(this.advanced);
    public final Setting<Float> attackCooldown = new Setting<Float>("AttackCooldown", Float.valueOf(0.9f), Float.valueOf(0.5f), Float.valueOf(1.0f)).addToGroup(this.advanced);
    public final Setting<Float> attackBaseTime = new Setting<Float>("AttackBaseTime", Float.valueOf(0.5f), Float.valueOf(0.0f), Float.valueOf(2.0f)).addToGroup(this.advanced);
    public final Setting<Integer> attackTickLimit = new Setting<Integer>("AttackTickLimit", 11, 0, 20).addToGroup(this.advanced);
    public final Setting<Float> critFallDistance = new Setting<Float>("CritFallDistance", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(1.0f)).addToGroup(this.advanced);
    public final Setting<Boolean> predict = new Setting<Boolean>("Predict", false).addToGroup(this.advanced);
    public final Setting<Float> predictMultiplier = new Setting<Float>("PredictMultiplier", Float.valueOf(3.0f), Float.valueOf(0.0f), Float.valueOf(10.0f), v -> this.predict.getValue()).addToGroup(this.advanced);
    public final Setting<Boolean> visualTurn = new Setting<Boolean>("VisualTurn", false).addToGroup(this.advanced);
    public final Setting<SettingGroup> targets = new Setting<SettingGroup>("Targets", new SettingGroup(false, 0));
    public final Setting<Boolean> Players = new Setting<Boolean>("Players", true).addToGroup(this.targets);
    public final Setting<Boolean> Mobs = new Setting<Boolean>("Mobs", true).addToGroup(this.targets);
    public final Setting<Boolean> Animals = new Setting<Boolean>("Animals", true).addToGroup(this.targets);
    public final Setting<Boolean> Villagers = new Setting<Boolean>("Villagers", true).addToGroup(this.targets);
    public final Setting<Boolean> Slimes = new Setting<Boolean>("Slimes", true).addToGroup(this.targets);
    public final Setting<Boolean> hostiles = new Setting<Boolean>("Hostiles", true).addToGroup(this.targets);
    public final Setting<Boolean> onlyAngry = new Setting<Boolean>("OnlyAngryHostiles", true, v -> this.hostiles.getValue()).addToGroup(this.targets);
    public final Setting<Boolean> Projectiles = new Setting<Boolean>("Projectiles", true).addToGroup(this.targets);
    public final Setting<Boolean> ignoreInvisible = new Setting<Boolean>("IgnoreInvisibleEntities", false).addToGroup(this.targets);
    public final Setting<Boolean> ignoreNamed = new Setting<Boolean>("IgnoreNamed", false).addToGroup(this.targets);
    public final Setting<Boolean> ignoreTeam = new Setting<Boolean>("IgnoreTeam", false).addToGroup(this.targets);
    public final Setting<Boolean> ignoreCreative = new Setting<Boolean>("IgnoreCreative", true).addToGroup(this.targets);
    public final Setting<Boolean> ignoreNaked = new Setting<Boolean>("IgnoreNaked", false).addToGroup(this.targets);
    public final Setting<Boolean> ignoreShield = new Setting<Boolean>("AttackShieldingEntities", true).addToGroup(this.targets);
    public static class_1297 target;
    public float rotationYaw;
    public float rotationPitch;
    public float pitchAcceleration = 1.0f;
    private class_243 rotationPoint = class_243.field_1353;
    private class_243 rotationMotion = class_243.field_1353;
    private int hitTicks;
    private int trackticks;
    private boolean lookingAtHitbox;
    private final Timer delayTimer = new Timer();
    private final Timer pauseTimer = new Timer();
    private class_1937 lastWorld;
    public class_238 resolvedBox;
    static boolean wasTargeted;

    public Aura() {
        super("Aura", Module.Category.COMBAT);
    }

    private float getRange() {
        return (this.elytra.getValue() != false && Aura.mc.field_1724.method_6128() ? this.elytraAttackRange.getValue() : this.attackRange.getValue()).floatValue();
    }

    private float getWallRange() {
        return (this.elytra.getValue() != false && Aura.mc.field_1724 != null && Aura.mc.field_1724.method_6128() ? this.elytraWallRange.getValue() : this.wallRange.getValue()).floatValue();
    }

    public void auraLogic() {
        boolean readyForAttack;
        if (!this.haveWeapon()) {
            target = null;
            return;
        }
        this.handleKill();
        this.updateTarget();
        if (target == null) {
            return;
        }
        if (!Aura.mc.field_1690.field_1903.method_1434() && Aura.mc.field_1724.method_24828() && this.autoJump.getValue().booleanValue()) {
            Aura.mc.field_1724.method_6043();
        }
        if (this.grimRayTrace.getValue().booleanValue()) {
            readyForAttack = this.autoCrit() && (this.lookingAtHitbox || this.skipRayTraceCheck());
            this.calcRotations(this.autoCrit());
        } else {
            this.calcRotations(this.autoCrit());
            readyForAttack = this.autoCrit() && (this.lookingAtHitbox || this.skipRayTraceCheck());
            boolean bl = readyForAttack;
        }
        if (readyForAttack) {
            class_1657 pl;
            if (this.shieldBreaker(false)) {
                return;
            }
            boolean[] playerState = this.preAttack();
            class_1297 class_12972 = target;
            if (!(class_12972 instanceof class_1657) || !(pl = (class_1657)class_12972).method_6115() || pl.method_6079().method_7909() != class_1802.field_8255 || this.ignoreShield.getValue().booleanValue()) {
                this.attack();
            }
            this.postAttack(playerState[0], playerState[1]);
        }
    }

    private boolean haveWeapon() {
        class_1792 handItem = Aura.mc.field_1724.method_6047().method_7909();
        if (this.onlyWeapon.getValue().booleanValue()) {
            if (this.switchMode.getValue() == Switch.None) {
                return handItem instanceof class_1829 || handItem instanceof class_1743 || handItem instanceof class_1835;
            }
            return InventoryUtility.getSwordHotBar().found() || InventoryUtility.getAxeHotBar().found();
        }
        return true;
    }

    private boolean skipRayTraceCheck() {
        return this.rotationMode.getValue() == Mode.None || this.rayTrace.getValue() == RayTrace.OFF || this.rotationMode.is(Mode.Grim) || this.rotationMode.is(Mode.Interact) && (this.interactTicks.getValue() <= 1 || Aura.mc.field_1687.method_20812((class_1297)Aura.mc.field_1724, Aura.mc.field_1724.method_5829().method_1009(-0.25, 0.0, -0.25).method_989(0.0, 1.0, 0.0)).iterator().hasNext());
    }

    public void attack() {
        int prevSlot = this.switchMethod();
        Aura.mc.field_1761.method_2918((class_1657)Aura.mc.field_1724, target);
        this.swingHand();
        this.hitTicks = this.getHitTicks();
        if (prevSlot != -1) {
            if (this.switchMode.getValue() == Switch.Silent) {
                InventoryUtility.switchToSilent(prevSlot);
            } else {
                InventoryUtility.switchTo(prevSlot);
            }
            ModuleManager.itemSwapFix.forceSync();
        }
    }

    private boolean @NotNull [] preAttack() {
        boolean sprint;
        boolean blocking = Aura.mc.field_1724.method_6115() && Aura.mc.field_1724.method_6030().method_7909().method_7853(Aura.mc.field_1724.method_6030()) == class_1839.field_8949;
        boolean bl = blocking;
        if (blocking && this.unpressShield.getValue().booleanValue()) {
            this.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12974, class_2338.field_10980, class_2350.field_11033));
        }
        if ((sprint = Core.serverSprint) && this.dropSprint.getValue().booleanValue()) {
            this.disableSprint();
        }
        if (this.rotationMode.is(Mode.Grim)) {
            this.sendPacket((class_2596<?>)new class_2828.class_2830(Aura.mc.field_1724.method_23317(), Aura.mc.field_1724.method_23318(), Aura.mc.field_1724.method_23321(), this.rotationYaw, this.rotationPitch, Aura.mc.field_1724.method_24828()));
        }
        return new boolean[]{blocking, sprint};
    }

    public void postAttack(boolean block, boolean sprint) {
        if (sprint && this.returnSprint.getValue().booleanValue() && this.dropSprint.getValue().booleanValue()) {
            this.enableSprint();
        }
        if (block && this.unpressShield.getValue().booleanValue()) {
            this.sendSequencedPacket(id -> new class_2886(class_1268.field_5810, id, this.rotationYaw, this.rotationPitch));
        }
        if (this.rotationMode.is(Mode.Grim)) {
            this.sendPacket((class_2596<?>)new class_2828.class_2830(Aura.mc.field_1724.method_23317(), Aura.mc.field_1724.method_23318(), Aura.mc.field_1724.method_23321(), Aura.mc.field_1724.method_36454(), Aura.mc.field_1724.method_36455(), Aura.mc.field_1724.method_24828()));
        }
    }

    private void disableSprint() {
        Aura.mc.field_1724.method_5728(false);
        Aura.mc.field_1690.field_1867.method_23481(false);
        this.sendPacket((class_2596<?>)new class_2848((class_1297)Aura.mc.field_1724, class_2848.class_2849.field_12985));
    }

    private void enableSprint() {
        Aura.mc.field_1724.method_5728(true);
        Aura.mc.field_1690.field_1867.method_23481(true);
        this.sendPacket((class_2596<?>)new class_2848((class_1297)Aura.mc.field_1724, class_2848.class_2849.field_12981));
    }

    public void resolvePlayers() {
        if (this.resolver.not(Resolver.Off)) {
            for (class_1657 player : Aura.mc.field_1687.method_18456()) {
                if (!(player instanceof class_745)) continue;
                ((IOtherClientPlayerEntity)player).resolve(this.resolver.getValue());
            }
        }
    }

    public void restorePlayers() {
        if (this.resolver.not(Resolver.Off)) {
            for (class_1657 player : Aura.mc.field_1687.method_18456()) {
                if (!(player instanceof class_745)) continue;
                ((IOtherClientPlayerEntity)player).releaseResolver();
            }
        }
    }

    public void handleKill() {
        if (target instanceof class_1309 && (((class_1309)target).method_6032() <= 0.0f || ((class_1309)target).method_29504())) {
            Managers.NOTIFICATION.publicity("Aura", ClientSettings.isRu() ? "\u0426\u0435\u043b\u044c \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043d\u0435\u0439\u0442\u0440\u0430\u043b\u0438\u0437\u043e\u0432\u0430\u043d\u0430!" : "Target successfully neutralized!", 3, Notification.Type.SUCCESS);
        }
    }

    private int switchMethod() {
        int prevSlot = -1;
        SearchInvResult swordResult = InventoryUtility.getSwordHotBar();
        if (swordResult.found() && this.switchMode.getValue() != Switch.None) {
            if (this.switchMode.getValue() == Switch.Silent) {
                prevSlot = Aura.mc.field_1724.method_31548().field_7545;
                swordResult.switchToSilent();
            } else {
                swordResult.switchTo();
            }
        }
        return prevSlot;
    }

    private int getHitTicks() {
        return this.oldDelay.getValue().isEnabled() ? 1 + (int)(20.0f / MathUtility.random(this.minCPS.getValue().intValue(), this.maxCPS.getValue().intValue())) : (this.shouldRandomizeDelay() ? (int)MathUtility.random(11.0f, 13.0f) : this.attackTickLimit.getValue());
    }

    @EventHandler
    public void onUpdate(PlayerUpdateEvent e) {
        if (Aura.mc.field_1687 != this.lastWorld) {
            target = null;
            this.lastWorld = Aura.mc.field_1687;
        }
        if (!this.pauseTimer.passedMs(1000L)) {
            return;
        }
        if (Aura.mc.field_1724.method_6115() && this.pauseWhileEating.getValue().booleanValue()) {
            return;
        }
        if (this.pauseBaritone.getValue().booleanValue() && ThunderHack.baritone) {
            boolean isTargeted = target != null;
            boolean bl = isTargeted;
            if (isTargeted && !wasTargeted) {
                BaritoneUtility.executeInternal("pause");
                wasTargeted = true;
            } else if (!isTargeted && wasTargeted) {
                BaritoneUtility.executeInternal("resume");
                wasTargeted = false;
            }
        }
        this.resolvePlayers();
        this.auraLogic();
        this.restorePlayers();
        --this.hitTicks;
    }

    @EventHandler
    public void onSync(EventSync e) {
        if (!this.pauseTimer.passedMs(1000L)) {
            return;
        }
        if (Aura.mc.field_1724.method_6115() && this.pauseWhileEating.getValue().booleanValue()) {
            return;
        }
        if (!this.haveWeapon()) {
            return;
        }
        if (target != null && this.rotationMode.getValue() != Mode.None && this.rotationMode.getValue() != Mode.Grim) {
            Aura.mc.field_1724.method_36456(this.rotationYaw);
            Aura.mc.field_1724.method_36457(this.rotationPitch);
        } else {
            this.rotationYaw = Aura.mc.field_1724.method_36454();
            this.rotationPitch = Aura.mc.field_1724.method_36455();
        }
        if (this.oldDelay.getValue().isEnabled() && this.minCPS.getValue() > this.maxCPS.getValue()) {
            this.minCPS.setValue(this.maxCPS.getValue());
        }
        if (target != null && this.pullDown.getValue().booleanValue() && (Aura.mc.field_1724.method_6059(class_1294.field_5913) || !this.onlyJumpBoost.getValue().booleanValue())) {
            Aura.mc.field_1724.method_5762(0.0, (double)(-this.pullValue.getValue().floatValue() / 1000.0f), 0.0);
        }
    }

    @EventHandler
    public void onPacketSend(@NotNull PacketEvent.Send e) {
        class_2824 pie;
        Object t = e.getPacket();
        if (t instanceof class_2824 && Criticals.getInteractType(pie = (class_2824)t) != Criticals.InteractType.ATTACK && target != null) {
            e.cancel();
        }
    }

    @EventHandler
    public void onPacketReceive(@NotNull PacketEvent.Receive e) {
        class_2663 pac;
        class_2663 status;
        Object t = e.getPacket();
        if (t instanceof class_2663 && (status = (class_2663)t).method_11470() == 30 && status.method_11469((class_1937)Aura.mc.field_1687) != null && target != null && status.method_11469((class_1937)Aura.mc.field_1687) == target) {
            Managers.NOTIFICATION.publicity("Aura", ClientSettings.isRu() ? "\u0423\u0441\u043f\u0435\u0448\u043d\u043e \u0441\u043b\u043e\u043c\u0430\u043b\u0438 \u0449\u0438\u0442 \u0438\u0433\u0440\u043e\u043a\u0443 " + target.method_5477().getString() : "Succesfully destroyed " + target.method_5477().getString() + "'s shield", 2, Notification.Type.SUCCESS);
        }
        if (e.getPacket() instanceof class_2708 && this.tpDisable.getValue().booleanValue()) {
            this.disable(ClientSettings.isRu() ? "\u041e\u0442\u043a\u043b\u044e\u0447\u0430\u044e \u0438\u0437-\u0437\u0430 \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0430\u0446\u0438\u0438!" : "Disabling due to tp!");
        }
        if ((t = e.getPacket()) instanceof class_2663 && (pac = (class_2663)t).method_11470() == 3 && pac.method_11469((class_1937)Aura.mc.field_1687) == Aura.mc.field_1724 && this.deathDisable.getValue().booleanValue()) {
            this.disable(ClientSettings.isRu() ? "\u041e\u0442\u043a\u043b\u044e\u0447\u0430\u044e \u0438\u0437-\u0437\u0430 \u0441\u043c\u0435\u0440\u0442\u0438!" : "Disabling due to death!");
        }
    }

    @Override
    public void onEnable() {
        target = null;
        this.lookingAtHitbox = false;
        this.rotationPoint = class_243.field_1353;
        this.rotationMotion = class_243.field_1353;
        this.rotationYaw = Aura.mc.field_1724.method_36454();
        this.rotationPitch = Aura.mc.field_1724.method_36455();
        this.delayTimer.reset();
    }

    private boolean autoCrit() {
        float f2;
        boolean reasonForSkipCrit = !this.smartCrit.getValue().isEnabled() || Aura.mc.field_1724.method_31549().field_7479 || Aura.mc.field_1724.method_6128() || Aura.mc.field_1724.method_6059(class_1294.field_5919) || Aura.mc.field_1724.method_6059(class_1294.field_5906) || Managers.PLAYER.isInWeb();
        boolean bl = reasonForSkipCrit;
        if (this.hitTicks > 0) {
            return false;
        }
        if (this.pauseInInventory.getValue().booleanValue() && Managers.PLAYER.inInventory) {
            return false;
        }
        if (this.getAttackCooldown() < this.attackCooldown.getValue().floatValue() && !this.oldDelay.getValue().isEnabled()) {
            return false;
        }
        boolean mergeWithTargetStrafe = !ModuleManager.targetStrafe.isEnabled() || ModuleManager.targetStrafe.jump.getValue() == false;
        boolean mergeWithSpeed = !ModuleManager.speed.isEnabled() || Aura.mc.field_1724.method_24828();
        boolean bl2 = mergeWithSpeed;
        if (!Aura.mc.field_1690.field_1903.method_1434() && mergeWithTargetStrafe && mergeWithSpeed && !this.onlySpace.getValue().booleanValue() && !this.autoJump.getValue().booleanValue()) {
            return true;
        }
        if (Aura.mc.field_1724.method_5771()) {
            return true;
        }
        if (Aura.mc.field_1724.method_5869()) {
            return true;
        }
        if (!Aura.mc.field_1690.field_1903.method_1434() && this.isAboveWater()) {
            return true;
        }
        if (Aura.mc.field_1724.field_6017 > 1.0f && (double)Aura.mc.field_1724.field_6017 < 1.14) {
            return false;
        }
        if (reasonForSkipCrit) {
            return true;
        }
        if (Aura.mc.field_1724.method_24828()) {
            return false;
        }
        float f = Aura.mc.field_1724.field_6017;
        float f3 = f2 = this.shouldRandomizeFallDistance() ? MathUtility.random(0.15f, 0.7f) : this.critFallDistance.getValue().floatValue();
        return f > f2;
    }

    private boolean shieldBreaker(boolean instant) {
        int axeSlot = InventoryUtility.getAxe().slot();
        if (axeSlot == -1) {
            return false;
        }
        if (!this.shieldBreaker.getValue().booleanValue()) {
            return false;
        }
        if (!(target instanceof class_1657)) {
            return false;
        }
        if (!((class_1657)target).method_6115() && !instant) {
            return false;
        }
        if (((class_1657)target).method_6079().method_7909() != class_1802.field_8255 && ((class_1657)target).method_6047().method_7909() != class_1802.field_8255) {
            return false;
        }
        if (axeSlot >= 9) {
            Aura.mc.field_1761.method_2906(Aura.mc.field_1724.field_7512.field_7763, axeSlot, Aura.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)Aura.mc.field_1724);
            this.sendPacket((class_2596<?>)new class_2815(Aura.mc.field_1724.field_7512.field_7763));
            Aura.mc.field_1761.method_2918((class_1657)Aura.mc.field_1724, target);
            this.swingHand();
            Aura.mc.field_1761.method_2906(Aura.mc.field_1724.field_7512.field_7763, axeSlot, Aura.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)Aura.mc.field_1724);
            this.sendPacket((class_2596<?>)new class_2815(Aura.mc.field_1724.field_7512.field_7763));
            ModuleManager.itemSwapFix.forceSync();
        } else {
            this.sendPacket((class_2596<?>)new class_2868(axeSlot));
            Aura.mc.field_1761.method_2918((class_1657)Aura.mc.field_1724, target);
            this.swingHand();
            this.sendPacket((class_2596<?>)new class_2868(Aura.mc.field_1724.method_31548().field_7545));
            ModuleManager.itemSwapFix.forceSync();
        }
        this.hitTicks = 10;
        return true;
    }

    private void swingHand() {
        switch (this.attackHand.getValue().ordinal()) {
            case 1: {
                Aura.mc.field_1724.method_6104(class_1268.field_5810);
                break;
            }
            case 0: {
                Aura.mc.field_1724.method_6104(class_1268.field_5808);
            }
        }
    }

    public boolean isAboveWater() {
        class_243 pos = Aura.mc.field_1724.method_19538().method_1031(0.0, -0.4, 0.0);
        return Aura.mc.field_1724.method_5869() || Aura.mc.field_1687.method_8320(class_2338.method_49637((double)pos.field_1352, (double)pos.field_1351, (double)pos.field_1350)).method_26204() == class_2246.field_10382;
    }

    public float getAttackCooldownProgressPerTick() {
        return (float)(1.0 / Aura.mc.field_1724.method_45325(class_5134.field_23723) * (20.0 * (double)ThunderHack.TICK_TIMER * (double)(this.tpsSync.getValue() != false ? Managers.SERVER.getTPSFactor() : 1.0f)));
    }

    public float getAttackCooldown() {
        return class_3532.method_15363((float)(((float)((ILivingEntity)Aura.mc.field_1724).getLastAttackedTicks() + this.attackBaseTime.getValue().floatValue()) / this.getAttackCooldownProgressPerTick()), (float)0.0f, (float)1.0f);
    }

    private void updateTarget() {
        if (this.elytraTarget.getValue().booleanValue() && ElytraTarget.target != null) {
            if (this.lockTarget.getValue().booleanValue() && target != null && !this.skipEntity(target)) {
                return;
            }
            if (!this.skipEntity((class_1297)ElytraTarget.target)) {
                target = ElytraTarget.target;
                return;
            }
        }
        if (this.lockTarget.getValue().booleanValue() && target != null && !this.skipEntity(target) && this.sort.getValue() != Sort.FOV) {
            return;
        }
        class_1297 candidat = this.findTarget();
        if (target == null || !this.lockTarget.getValue().booleanValue() || this.sort.getValue() == Sort.FOV) {
            target = candidat;
        }
        if (candidat instanceof class_1676) {
            target = candidat;
        }
        if (target != null && this.skipEntity(target)) {
            target = null;
        }
    }

    private void calcRotations(boolean ready) {
        float f2;
        float pitchStep = 0.0f;
        float yawStep = 0.0f;
        if (ready) {
            this.trackticks = Aura.mc.field_1687.method_20812((class_1297)Aura.mc.field_1724, Aura.mc.field_1724.method_5829().method_1009(-0.25, 0.0, -0.25).method_989(0.0, 1.0, 0.0)).iterator().hasNext() ? 1 : this.interactTicks.getValue();
        } else if (this.trackticks > 0) {
            --this.trackticks;
        }
        if (target == null) {
            return;
        }
        class_243 targetVec = null;
        if (this.predict.getValue().booleanValue()) {
            double motionX = target.method_23317() - Aura.target.field_6014;
            double motionY = target.method_23318() - Aura.target.field_6036;
            double motionZ = target.method_23321() - Aura.target.field_5969;
            targetVec = new class_243(target.method_23317() + motionX * (double)this.predictMultiplier.getValue().floatValue(), target.method_23318() + motionY * (double)this.predictMultiplier.getValue().floatValue() + (double)(target.method_18381(target.method_18376()) / 2.0f), target.method_23321() + motionZ * (double)this.predictMultiplier.getValue().floatValue());
        } else {
            class_243 vec3d = targetVec = Aura.mc.field_1724.method_6128() ? target.method_33571() : this.getLegitLook(target);
        }
        if (targetVec == null) {
            return;
        }
        this.pitchAcceleration = Managers.PLAYER.checkRtx(this.rotationYaw, this.rotationPitch, this.getRange() + this.aimRange.getValue().floatValue(), this.getRange() + this.aimRange.getValue().floatValue(), this.rayTrace.getValue()) ? this.aimedPitchStep.getValue().floatValue() : (this.pitchAcceleration < this.maxPitchStep.getValue().floatValue() ? this.pitchAcceleration * this.pitchAccelerate.getValue().floatValue() : this.maxPitchStep.getValue().floatValue());
        float delta_yaw = class_3532.method_15393((float)((float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(targetVec.field_1350 - Aura.mc.field_1724.method_23321(), targetVec.field_1352 - Aura.mc.field_1724.method_23317())) - 90.0)) - this.rotationYaw)) + (float)(this.wallsBypass.is(WallsBypass.V2) && !ready && !Aura.mc.field_1724.method_6057(target) ? 20 : 0);
        float delta_pitch = (float)(-Math.toDegrees(Math.atan2(targetVec.field_1351 - (Aura.mc.field_1724.method_19538().field_1351 + (double)Aura.mc.field_1724.method_18381(Aura.mc.field_1724.method_18376())), Math.sqrt(Math.pow(targetVec.field_1352 - Aura.mc.field_1724.method_23317(), 2.0) + Math.pow(targetVec.field_1350 - Aura.mc.field_1724.method_23321(), 2.0))))) - this.rotationPitch;
        yawStep = this.rotationMode.getValue() != Mode.Track ? 360.0f : MathUtility.random(this.minYawStep.getValue().intValue(), this.maxYawStep.getValue().intValue());
        float f = yawStep;
        float f3 = this.rotationMode.getValue() != Mode.Track ? 180.0f : (f2 = (pitchStep = Managers.PLAYER.ticksElytraFlying > 5 ? 180.0f : this.pitchAcceleration + MathUtility.random(-1.0f, 1.0f)));
        if (ready) {
            switch (this.accelerateOnHit.getValue().ordinal()) {
                case 1: {
                    yawStep = 180.0f;
                    break;
                }
                case 2: {
                    pitchStep = 90.0f;
                    break;
                }
                case 3: {
                    yawStep = 180.0f;
                    pitchStep = 90.0f;
                }
            }
        }
        if (delta_yaw > 180.0f) {
            delta_yaw -= 180.0f;
        }
        float deltaYaw = class_3532.method_15363((float)class_3532.method_15379((float)delta_yaw), (float)(-yawStep), (float)yawStep);
        float deltaPitch = class_3532.method_15363((float)delta_pitch, (float)(-pitchStep), (float)pitchStep);
        float newYaw = this.rotationYaw + (delta_yaw > 0.0f ? deltaYaw : -deltaYaw);
        float newPitch = class_3532.method_15363((float)(this.rotationPitch + deltaPitch), (float)-90.0f, (float)90.0f);
        double gcdFix = Math.pow((Double)Aura.mc.field_1690.method_42495().method_41753() * 0.6 + 0.2, 3.0) * 1.2;
        if (this.trackticks > 0 || this.rotationMode.getValue() == Mode.Track) {
            this.rotationYaw = (float)((double)newYaw - (double)(newYaw - this.rotationYaw) % gcdFix);
            this.rotationPitch = (float)((double)newPitch - (double)(newPitch - this.rotationPitch) % gcdFix);
        } else {
            this.rotationYaw = Aura.mc.field_1724.method_36454();
            this.rotationPitch = Aura.mc.field_1724.method_36455();
        }
        if (!this.rotationMode.is(Mode.Grim)) {
            ModuleManager.rotations.fixRotation = this.rotationYaw;
        }
        this.lookingAtHitbox = Managers.PLAYER.checkRtx(this.rotationYaw, this.rotationPitch, this.getRange(), this.getWallRange(), this.rayTrace.getValue());
        if (this.visualTurn.getValue().booleanValue()) {
            Aura.mc.field_1724.field_6241 = this.rotationYaw;
            Aura.mc.field_1724.field_6283 = this.rotationYaw;
        }
    }

    @Override
    public void onRender3D(class_4587 stack) {
        if (!this.haveWeapon() || target == null) {
            return;
        }
        if ((this.resolver.is(Resolver.BackTrack) || this.resolverVisualisation.getValue().booleanValue()) && this.resolvedBox != null) {
            Render3DEngine.OUTLINE_QUEUE.add(new Render3DEngine.OutlineAction(this.resolvedBox, HudEditor.getColor(0), 1.0f));
        }
        switch (this.esp.getValue().ordinal()) {
            case 3: {
                Render3DEngine.drawOldTargetEsp(stack, target);
                break;
            }
            case 2: {
                CaptureMark.render(target);
                break;
            }
            case 4: {
                Render3DEngine.renderGhosts(this.espLength.getValue(), this.espFactor.getValue(), this.espShaking.getValue().floatValue(), this.espAmplitude.getValue().floatValue(), target);
                break;
            }
            case 1: {
                Render3DEngine.drawTargetEsp(stack, target);
            }
        }
        if (this.clientLook.getValue().booleanValue() && this.rotationMode.getValue() != Mode.None) {
            Aura.mc.field_1724.method_36456((float)Render2DEngine.interpolate(Aura.mc.field_1724.field_5982, this.rotationYaw, Render3DEngine.getTickDelta()));
            Aura.mc.field_1724.method_36457((float)Render2DEngine.interpolate(Aura.mc.field_1724.field_6004, this.rotationPitch, Render3DEngine.getTickDelta()));
        }
    }

    @Override
    public void onDisable() {
        target = null;
    }

    public float getSquaredRotateDistance() {
        float dst = this.getRange();
        dst += this.aimRange.getValue().floatValue();
        if (Aura.mc.field_1724.method_6128() || target instanceof class_1657 && ((class_1657)target).method_6128()) {
            dst += 45.0f;
        }
        if (ModuleManager.strafe.isEnabled()) {
            dst += 10.0f;
        }
        if (this.rotationMode.getValue() != Mode.Track || this.rayTrace.getValue() == RayTrace.OFF) {
            dst = this.getRange();
        }
        return dst * dst;
    }

    public class_243 getLegitLook(class_1297 target) {
        float minMotionXZ = 0.003f;
        float maxMotionXZ = 0.03f;
        float minMotionY = 0.001f;
        float maxMotionY = 0.03f;
        double lenghtX = target.method_5829().method_17939();
        double lenghtY = target.method_5829().method_17940();
        double lenghtZ = target.method_5829().method_17941();
        if (this.rotationMotion.equals(class_243.field_1353)) {
            this.rotationMotion = new class_243((double)MathUtility.random(-0.05f, 0.05f), (double)MathUtility.random(-0.05f, 0.05f), (double)MathUtility.random(-0.05f, 0.05f));
        }
        this.rotationPoint = this.rotationPoint.method_1019(this.rotationMotion);
        if (this.rotationPoint.field_1352 >= (lenghtX - 0.05) / 2.0) {
            this.rotationMotion = new class_243((double)(-MathUtility.random(minMotionXZ, maxMotionXZ)), this.rotationMotion.method_10214(), this.rotationMotion.method_10215());
        }
        if (this.rotationPoint.field_1351 >= lenghtY) {
            this.rotationMotion = new class_243(this.rotationMotion.method_10216(), (double)(-MathUtility.random(minMotionY, maxMotionY)), this.rotationMotion.method_10215());
        }
        if (this.rotationPoint.field_1350 >= (lenghtZ - 0.05) / 2.0) {
            this.rotationMotion = new class_243(this.rotationMotion.method_10216(), this.rotationMotion.method_10214(), (double)(-MathUtility.random(minMotionXZ, maxMotionXZ)));
        }
        if (this.rotationPoint.field_1352 <= -(lenghtX - 0.05) / 2.0) {
            this.rotationMotion = new class_243((double)MathUtility.random(minMotionXZ, 0.03f), this.rotationMotion.method_10214(), this.rotationMotion.method_10215());
        }
        if (this.rotationPoint.field_1351 <= 0.05) {
            this.rotationMotion = new class_243(this.rotationMotion.method_10216(), (double)MathUtility.random(minMotionY, maxMotionY), this.rotationMotion.method_10215());
        }
        if (this.rotationPoint.field_1350 <= -(lenghtZ - 0.05) / 2.0) {
            this.rotationMotion = new class_243(this.rotationMotion.method_10216(), this.rotationMotion.method_10214(), (double)MathUtility.random(minMotionXZ, maxMotionXZ));
        }
        this.rotationPoint.method_1031((double)MathUtility.random(-0.03f, 0.03f), 0.0, (double)MathUtility.random(-0.03f, 0.03f));
        if (!Aura.mc.field_1724.method_6057(target) && Objects.requireNonNull(this.wallsBypass.getValue()) == WallsBypass.V1) {
            return target.method_19538().method_1031(MathUtility.random(-0.15, 0.15), lenghtY, MathUtility.random(-0.15, 0.15));
        }
        if (!Managers.PLAYER.checkRtx(this.rotationYaw, this.rotationPitch, this.getRange(), this.getWallRange(), this.rayTrace.getValue())) {
            float[] rotation1 = PlayerManager.calcAngle(target.method_19538().method_1031(0.0, (double)(target.method_18381(target.method_18376()) / 2.0f), 0.0));
            if (PlayerUtility.squaredDistanceFromEyes(target.method_19538().method_1031(0.0, (double)(target.method_18381(target.method_18376()) / 2.0f), 0.0)) <= this.attackRange.getPow2Value() && Managers.PLAYER.checkRtx(rotation1[0], rotation1[1], this.getRange(), 0.0f, this.rayTrace.getValue())) {
                this.rotationPoint = new class_243((double)MathUtility.random(-0.1f, 0.1f), (double)(target.method_18381(target.method_18376()) / MathUtility.random(1.8f, 2.5f)), (double)MathUtility.random(-0.1f, 0.1f));
            } else {
                float halfBox = (float)(lenghtX / 2.0);
                for (float x1 = -halfBox; x1 <= halfBox; x1 += 0.05f) {
                    block1: for (float z1 = -halfBox; z1 <= halfBox; z1 += 0.05f) {
                        float y1 = 0.05f;
                        while ((double)y1 <= target.method_5829().method_17940()) {
                            float[] rotation;
                            class_243 v1 = new class_243(target.method_23317() + (double)x1, target.method_23318() + (double)y1, target.method_23321() + (double)z1);
                            if (!(PlayerUtility.squaredDistanceFromEyes(v1) > this.attackRange.getPow2Value()) && Managers.PLAYER.checkRtx((rotation = PlayerManager.calcAngle(v1))[0], rotation[1], this.getRange(), 0.0f, this.rayTrace.getValue())) {
                                this.rotationPoint = new class_243((double)x1, (double)y1, (double)z1);
                                continue block1;
                            }
                            y1 += 0.15f;
                        }
                    }
                }
            }
        }
        return target.method_19538().method_1019(this.rotationPoint);
    }

    public boolean isInRange(class_1297 target) {
        if (PlayerUtility.squaredDistanceFromEyes(target.method_19538().method_1031(0.0, (double)target.method_18381(target.method_18376()), 0.0)) > this.getSquaredRotateDistance() + 4.0f) {
            return false;
        }
        float halfBox = (float)(target.method_5829().method_17939() / 2.0);
        for (float x1 = -halfBox; x1 <= halfBox; x1 += 0.15f) {
            for (float z1 = -halfBox; z1 <= halfBox; z1 += 0.15f) {
                float y1 = 0.05f;
                while ((double)y1 <= target.method_5829().method_17940()) {
                    float[] rotation;
                    if (!(PlayerUtility.squaredDistanceFromEyes(new class_243(target.method_23317() + (double)x1, target.method_23318() + (double)y1, target.method_23321() + (double)z1)) > this.getSquaredRotateDistance()) && Managers.PLAYER.checkRtx((rotation = PlayerManager.calcAngle(new class_243(target.method_23317() + (double)x1, target.method_23318() + (double)y1, target.method_23321() + (double)z1)))[0], rotation[1], (float)Math.sqrt(this.getSquaredRotateDistance()), this.getWallRange(), this.rayTrace.getValue())) {
                        return true;
                    }
                    y1 += 0.25f;
                }
            }
        }
        return false;
    }

    public class_1297 findTarget() {
        CopyOnWriteArrayList<class_1309> first_stage = new CopyOnWriteArrayList<class_1309>();
        for (class_1297 ent : Aura.mc.field_1687.method_18112()) {
            if ((ent instanceof class_1678 || ent instanceof class_1674) && ent.method_5805() && this.isInRange(ent) && this.Projectiles.getValue().booleanValue()) {
                return ent;
            }
            if (this.skipEntity(ent) || !(ent instanceof class_1309)) continue;
            first_stage.add((class_1309)ent);
        }
        return switch (this.sort.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> first_stage.stream().min(Comparator.comparing(e -> Aura.mc.field_1724.method_5707(e.method_19538()))).orElse(null);
            case 1 -> first_stage.stream().max(Comparator.comparing(e -> Aura.mc.field_1724.method_5707(e.method_19538()))).orElse(null);
            case 6 -> first_stage.stream().min(Comparator.comparing(this::getFOVAngle)).orElse(null);
            case 2 -> first_stage.stream().min(Comparator.comparing(e -> Float.valueOf(e.method_6032() + e.method_6067()))).orElse(null);
            case 3 -> first_stage.stream().max(Comparator.comparing(e -> Float.valueOf(e.method_6032() + e.method_6067()))).orElse(null);
            case 4 -> first_stage.stream().min(Comparator.comparing(e -> {
                float v = 0.0f;
                for (class_1799 armor : e.method_5661()) {
                    if (armor == null || armor.method_7909().equals(class_1802.field_8162)) continue;
                    v += (float)(armor.method_7936() - armor.method_7919()) / (float)armor.method_7936();
                }
                return Float.valueOf(v);
            })).orElse(null);
            case 5 -> first_stage.stream().max(Comparator.comparing(e -> {
                float v = 0.0f;
                for (class_1799 armor : e.method_5661()) {
                    if (armor == null || armor.method_7909().equals(class_1802.field_8162)) continue;
                    v += (float)(armor.method_7936() - armor.method_7919()) / (float)armor.method_7936();
                }
                return Float.valueOf(v);
            })).orElse(null);
        };
    }

    private boolean skipEntity(class_1297 entity) {
        if (this.isBullet(entity)) {
            return false;
        }
        if (!(entity instanceof class_1309)) {
            return true;
        }
        class_1309 ent = (class_1309)entity;
        if (ent.method_29504() || !entity.method_5805() || entity.method_31481() || entity.method_37908() != Aura.mc.field_1687) {
            return true;
        }
        if (entity instanceof class_1531) {
            return true;
        }
        if (entity instanceof class_1451) {
            return true;
        }
        if (this.skipNotSelected(entity)) {
            return true;
        }
        if (!InteractionUtility.isVecInFOV(ent.method_19538(), this.fov.getValue())) {
            return true;
        }
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (ModuleManager.antiBot.isEnabled() && AntiBot.bots.contains(entity)) {
                return true;
            }
            if (player == Aura.mc.field_1724 || Managers.FRIEND.isFriend(player)) {
                return true;
            }
            if (player.method_7337() && this.ignoreCreative.getValue().booleanValue()) {
                return true;
            }
            if (player.method_6096() == 0 && this.ignoreNaked.getValue().booleanValue()) {
                return true;
            }
            if (player.method_5767() && this.ignoreInvisible.getValue().booleanValue()) {
                return true;
            }
            if (player.method_22861() == Aura.mc.field_1724.method_22861() && this.ignoreTeam.getValue().booleanValue() && Aura.mc.field_1724.method_22861() != 0xFFFFFF) {
                return true;
            }
        }
        return !this.isInRange(entity) || entity.method_16914() && this.ignoreNamed.getValue() != false;
    }

    private boolean isBullet(class_1297 entity) {
        return (entity instanceof class_1678 || entity instanceof class_1674) && entity.method_5805() && PlayerUtility.squaredDistanceFromEyes(entity.method_19538()) < this.getSquaredRotateDistance() && this.Projectiles.getValue() != false;
    }

    private boolean skipNotSelected(class_1297 entity) {
        if (entity instanceof class_1621 && !this.Slimes.getValue().booleanValue()) {
            return true;
        }
        if (entity instanceof class_1588) {
            class_1588 he = (class_1588)entity;
            if (!this.hostiles.getValue().booleanValue()) {
                return true;
            }
            if (this.onlyAngry.getValue().booleanValue()) {
                return !he.method_7076((class_1657)Aura.mc.field_1724);
            }
        }
        if (entity instanceof class_1657 && !this.Players.getValue().booleanValue()) {
            return true;
        }
        if (entity instanceof class_1646 && !this.Villagers.getValue().booleanValue()) {
            return true;
        }
        if (entity instanceof class_1308 && !this.Mobs.getValue().booleanValue()) {
            return true;
        }
        return entity instanceof class_1429 && this.Animals.getValue() == false;
    }

    private float getFOVAngle(@NotNull class_1309 e) {
        double difX = e.method_23317() - Aura.mc.field_1724.method_23317();
        double difZ = e.method_23321() - Aura.mc.field_1724.method_23321();
        float yaw = (float)class_3532.method_15338((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0));
        return Math.abs(yaw - class_3532.method_15393((float)Aura.mc.field_1724.method_36454()));
    }

    public void pause() {
        this.pauseTimer.reset();
    }

    private boolean shouldRandomizeDelay() {
        return this.randomHitDelay.getValue() != false && (Aura.mc.field_1724.method_24828() || Aura.mc.field_1724.field_6017 < 0.12f || Aura.mc.field_1724.method_5681() || Aura.mc.field_1724.method_6128());
    }

    private boolean shouldRandomizeFallDistance() {
        return this.randomHitDelay.getValue() != false && !this.shouldRandomizeDelay();
    }

    static {
        wasTargeted = false;
    }

    public static enum WallsBypass {
        Off,
        V1,
        V2;

    }

    public static enum Mode {
        Interact,
        Track,
        Grim,
        None;

    }

    public static enum Switch {
        Normal,
        None,
        Silent;

    }

    public static enum ESP {
        Off,
        ThunderHack,
        NurikZapen,
        CelkaPasta,
        ThunderHackV2;

    }

    public static enum Sort {
        LowestDistance,
        HighestDistance,
        LowestHealth,
        HighestHealth,
        LowestDurability,
        HighestDurability,
        FOV;

    }

    public static enum RayTrace {
        OFF,
        OnlyTarget,
        AllEntities;

    }

    public static enum AttackHand {
        MainHand,
        OffHand,
        None;

    }

    public static enum Resolver {
        Off,
        Advantage,
        Predictive,
        BackTrack;

    }

    public static enum AccelerateOnHit {
        Off,
        Yaw,
        Pitch,
        Both;

    }

    public static class Position {
        private double x;
        private double y;
        private double z;
        private int ticks;

        public Position(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public boolean shouldRemove() {
            return this.ticks++ > ModuleManager.aura.backTicks.getValue();
        }

        public double getX() {
            return this.x;
        }

        public double getY() {
            return this.y;
        }

        public double getZ() {
            return this.z;
        }
    }
}

