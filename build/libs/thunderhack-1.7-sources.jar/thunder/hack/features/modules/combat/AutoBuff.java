/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.PotionContentsComponent
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.SplashPotionItem
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.util.Hand
 */
package thunder.hack.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1828;
import net.minecraft.class_1844;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_6880;
import net.minecraft.class_9334;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventAfterRotate;
import thunder.hack.events.impl.EventPostSync;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.utility.Timer;

public final class AutoBuff
extends Module {
    private final Setting<Boolean> strength = new Setting<Boolean>("Strength", true);
    private final Setting<Boolean> speed = new Setting<Boolean>("Speed", true);
    private final Setting<Boolean> fire = new Setting<Boolean>("FireResistance", true);
    private final Setting<BooleanSettingGroup> heal = new Setting<BooleanSettingGroup>("InstantHealing", new BooleanSettingGroup(true));
    private final Setting<Integer> healthH = new Setting<Integer>("Health", 8, 0, 20).addToGroup(this.heal);
    private final Setting<BooleanSettingGroup> regen = new Setting<BooleanSettingGroup>("Regeneration", new BooleanSettingGroup(true));
    private final Setting<TriggerOn> triggerOn = new Setting<TriggerOn>("Trigger", TriggerOn.LackOfRegen).addToGroup(this.regen);
    private final Setting<Integer> healthR = new Setting<Integer>("HP", 8, 0, 20, v -> this.triggerOn.is(TriggerOn.Health)).addToGroup(this.regen);
    private final Setting<Boolean> onDaGround = new Setting<Boolean>("OnlyOnGround", true);
    private final Setting<Boolean> pauseAura = new Setting<Boolean>("PauseAura", false);
    public Timer timer = new Timer();
    private boolean spoofed = false;

    public AutoBuff() {
        super("AutoBuff", Module.Category.COMBAT);
    }

    public static int getPotionSlot(Potions potion) {
        for (int i = 0; i < 9; ++i) {
            if (!AutoBuff.isStackPotion(AutoBuff.mc.field_1724.method_31548().method_5438(i), potion)) continue;
            return i;
        }
        return -1;
    }

    public static boolean isPotionOnHotBar(Potions potions) {
        return AutoBuff.getPotionSlot(potions) != -1;
    }

    public static boolean isStackPotion(class_1799 stack, Potions potion) {
        if (stack == null) {
            return false;
        }
        if (stack.method_7909() instanceof class_1828) {
            class_1844 potionContentsComponent = (class_1844)stack.method_57825(class_9334.field_49651, class_1844.field_49274);
            class_6880 id = null;
            switch (potion.ordinal()) {
                case 0: {
                    id = class_1294.field_5910;
                    break;
                }
                case 1: {
                    id = class_1294.field_5904;
                    break;
                }
                case 2: {
                    id = class_1294.field_5918;
                    break;
                }
                case 3: {
                    id = class_1294.field_5915;
                    break;
                }
                case 4: {
                    id = class_1294.field_5924;
                }
            }
            for (class_1293 effect : potionContentsComponent.method_57397()) {
                if (effect.method_5579() != id) continue;
                return true;
            }
        }
        return false;
    }

    @EventHandler
    public void onPostRotationSet(EventAfterRotate event) {
        if (Aura.target != null && AutoBuff.mc.field_1724.method_7261(1.0f) > 0.5f) {
            return;
        }
        if (AutoBuff.mc.field_1724.field_6012 > 80 && this.shouldThrow()) {
            AutoBuff.mc.field_1724.method_36457(90.0f);
            this.spoofed = true;
        }
    }

    private boolean shouldThrow() {
        return !AutoBuff.mc.field_1724.method_6059(class_1294.field_5904) && AutoBuff.isPotionOnHotBar(Potions.SPEED) && this.speed.getValue() != false || !AutoBuff.mc.field_1724.method_6059(class_1294.field_5910) && AutoBuff.isPotionOnHotBar(Potions.STRENGTH) && this.strength.getValue() != false || !AutoBuff.mc.field_1724.method_6059(class_1294.field_5918) && AutoBuff.isPotionOnHotBar(Potions.FIRERES) && this.fire.getValue() != false || AutoBuff.mc.field_1724.method_6032() + AutoBuff.mc.field_1724.method_6067() < (float)this.healthH.getValue().intValue() && AutoBuff.isPotionOnHotBar(Potions.HEAL) && this.heal.getValue().isEnabled() || !AutoBuff.mc.field_1724.method_6059(class_1294.field_5924) && this.triggerOn.is(TriggerOn.LackOfRegen) && AutoBuff.isPotionOnHotBar(Potions.REGEN) && this.regen.getValue().isEnabled() || AutoBuff.mc.field_1724.method_6032() + AutoBuff.mc.field_1724.method_6067() < (float)this.healthR.getValue().intValue() && this.triggerOn.is(TriggerOn.Health) && AutoBuff.isPotionOnHotBar(Potions.REGEN) && this.regen.getValue().isEnabled();
    }

    @EventHandler
    public void onPostSync(EventPostSync e) {
        if (Aura.target != null && AutoBuff.mc.field_1724.method_7261(1.0f) > 0.5f) {
            return;
        }
        if (this.onDaGround.getValue().booleanValue() && !AutoBuff.mc.field_1724.method_24828()) {
            return;
        }
        if (AutoBuff.mc.field_1724.field_6012 > 80 && this.shouldThrow() && this.timer.passedMs(1000L) && this.spoofed) {
            if (!AutoBuff.mc.field_1724.method_6059(class_1294.field_5904) && AutoBuff.isPotionOnHotBar(Potions.SPEED) && this.speed.getValue().booleanValue()) {
                this.throwPotion(Potions.SPEED);
            }
            if (!AutoBuff.mc.field_1724.method_6059(class_1294.field_5910) && AutoBuff.isPotionOnHotBar(Potions.STRENGTH) && this.strength.getValue().booleanValue()) {
                this.throwPotion(Potions.STRENGTH);
            }
            if (!AutoBuff.mc.field_1724.method_6059(class_1294.field_5918) && AutoBuff.isPotionOnHotBar(Potions.FIRERES) && this.fire.getValue().booleanValue()) {
                this.throwPotion(Potions.FIRERES);
            }
            if (AutoBuff.mc.field_1724.method_6032() + AutoBuff.mc.field_1724.method_6067() < (float)this.healthH.getValue().intValue() && this.heal.getValue().isEnabled() && AutoBuff.isPotionOnHotBar(Potions.HEAL)) {
                this.throwPotion(Potions.HEAL);
            }
            if ((!AutoBuff.mc.field_1724.method_6059(class_1294.field_5924) && this.triggerOn.is(TriggerOn.LackOfRegen) || AutoBuff.mc.field_1724.method_6032() + AutoBuff.mc.field_1724.method_6067() < (float)this.healthR.getValue().intValue() && this.triggerOn.is(TriggerOn.Health)) && AutoBuff.isPotionOnHotBar(Potions.REGEN) && this.regen.getValue().isEnabled()) {
                this.throwPotion(Potions.REGEN);
            }
            this.sendPacket((class_2596<?>)new class_2868(AutoBuff.mc.field_1724.method_31548().field_7545));
            this.timer.reset();
            this.spoofed = false;
        }
    }

    public void throwPotion(Potions potion) {
        if (this.pauseAura.getValue().booleanValue()) {
            ModuleManager.aura.pause();
        }
        this.sendPacket((class_2596<?>)new class_2868(AutoBuff.getPotionSlot(potion)));
        this.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, AutoBuff.mc.field_1724.method_36454(), AutoBuff.mc.field_1724.method_36455()));
    }

    public static enum TriggerOn {
        LackOfRegen,
        Health;

    }

    public static enum Potions {
        STRENGTH,
        SPEED,
        FIRERES,
        HEAL,
        REGEN;

    }
}

