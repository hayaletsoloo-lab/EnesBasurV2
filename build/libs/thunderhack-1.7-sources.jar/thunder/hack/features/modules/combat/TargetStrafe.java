/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Blocks
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.BlockPos$Mutable
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Direction$Axis
 */
package thunder.hack.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2848;
import thunder.hack.core.Core;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventMove;
import thunder.hack.events.impl.EventSprint;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.injection.accesors.IClientPlayerEntity;
import thunder.hack.injection.accesors.ISPacketEntityVelocity;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.MovementUtility;

public class TargetStrafe
extends Module {
    public Setting<Boolean> jump = new Setting<Boolean>("Jump", true);
    public Setting<Float> distance = new Setting<Float>("Distance", Float.valueOf(1.3f), Float.valueOf(0.2f), Float.valueOf(7.0f));
    private final Setting<Boost> boost = new Setting<Boost>("Boost", Boost.None);
    public Setting<Float> setSpeed = new Setting<Float>("speed", Float.valueOf(1.3f), Float.valueOf(0.0f), Float.valueOf(2.0f), v -> this.boost.getValue() == Boost.Elytra);
    private final Setting<Float> velReduction = new Setting<Float>("Reduction", Float.valueOf(6.0f), Float.valueOf(0.1f), Float.valueOf(10.0f), v -> this.boost.getValue() == Boost.Damage);
    private final Setting<Float> maxVelocitySpeed = new Setting<Float>("MaxVelocity", Float.valueOf(0.8f), Float.valueOf(0.1f), Float.valueOf(2.0f), v -> this.boost.getValue() == Boost.Damage);
    public static double oldSpeed;
    public static double contextFriction;
    public static double fovval;
    public static boolean needSwap;
    public static boolean needSprintState;
    public static boolean skip;
    public static boolean switchDir;
    public static boolean disabled;
    public static int noSlowTicks;
    public static int jumpTicks;
    public static int waterTicks;
    static long disableTime;
    private static TargetStrafe instance;

    public TargetStrafe() {
        super("TargetStrafe", Module.Category.COMBAT);
        instance = this;
    }

    public static TargetStrafe getInstance() {
        return instance;
    }

    @Override
    public void onEnable() {
        oldSpeed = 0.0;
        fovval = (Double)TargetStrafe.mc.field_1690.method_42454().method_41753();
        TargetStrafe.mc.field_1690.method_42454().method_41748(0.0);
        skip = true;
    }

    public boolean canStrafe() {
        if (TargetStrafe.mc.field_1724.method_5715()) {
            return false;
        }
        if (TargetStrafe.mc.field_1724.method_5771()) {
            return false;
        }
        if (ModuleManager.speed.isEnabled()) {
            return false;
        }
        if (TargetStrafe.mc.field_1724.method_5869() || waterTicks > 0) {
            return false;
        }
        return !TargetStrafe.mc.field_1724.method_31549().field_7479;
    }

    public boolean needToSwitch(double x, double z) {
        if (TargetStrafe.mc.field_1724.field_5976 || (TargetStrafe.mc.field_1690.field_1913.method_1434() || TargetStrafe.mc.field_1690.field_1849.method_1434()) && jumpTicks <= 0) {
            jumpTicks = 10;
            return true;
        }
        for (int i = (int)(TargetStrafe.mc.field_1724.method_23318() + 4.0); i >= 0; --i) {
            class_2338 playerPos = new class_2338((int)Math.floor(x), (int)Math.floor(i), (int)Math.floor(z));
            if (TargetStrafe.mc.field_1687.method_8320(playerPos).method_26204().equals(class_2246.field_10164) || TargetStrafe.mc.field_1687.method_8320(playerPos).method_26204().equals(class_2246.field_10036)) {
                return true;
            }
            if (TargetStrafe.mc.field_1687.method_22347(playerPos)) continue;
            return false;
        }
        return false;
    }

    @Override
    public void onDisable() {
        TargetStrafe.mc.field_1690.method_42454().method_41748(fovval);
    }

    public double calculateSpeed(EventMove move) {
        float n8;
        float f;
        --jumpTicks;
        float speedAttributes = this.getAIMoveSpeed();
        float frictionFactor = TargetStrafe.mc.field_1687.method_8320((class_2338)new class_2338.class_2339().method_10102(TargetStrafe.mc.field_1724.method_23317(), this.getBoundingBox().method_1001(class_2350.class_2351.field_11052) - move.getY(), TargetStrafe.mc.field_1724.method_23321())).method_26204().method_9499() * 0.91f;
        float n6 = (float)(oldSpeed > 0.32 && TargetStrafe.mc.field_1724.method_6115() ? 0.88 : (double)0.91f);
        float f2 = f = TargetStrafe.mc.field_1724.method_6059(class_1294.field_5913) && TargetStrafe.mc.field_1724.method_6115() ? 0.88f : n6;
        if (TargetStrafe.mc.field_1724.method_24828()) {
            n6 = frictionFactor;
        }
        float n7 = (float)((double)0.1631f / Math.pow(n6, 3.0));
        if (TargetStrafe.mc.field_1724.method_24828()) {
            n8 = speedAttributes * n7;
            if (move.getY() > 0.0) {
                n8 += this.boost.getValue() == Boost.Elytra && InventoryUtility.getElytra() != -1 && disabled ? 0.65f : 0.2f;
            }
            disabled = false;
        } else {
            n8 = 0.0255f;
        }
        boolean noslow = false;
        double max2 = oldSpeed + (double)n8;
        double max = 0.0;
        if (TargetStrafe.mc.field_1724.method_6115() && move.getY() <= 0.0) {
            double d = 0.2873;
            double n10 = oldSpeed + (double)n8 * 0.25;
            double motionY2 = move.getY();
            if (motionY2 != 0.0 && Math.abs(motionY2) < 0.08) {
                n10 += 0.055;
            }
            max = Math.max(0.043, n10);
            if (max2 > d) {
                noslow = true;
                ++noSlowTicks;
            } else {
                noSlowTicks = Math.max(noSlowTicks - 1, 0);
            }
        } else {
            noSlowTicks = 0;
        }
        max2 = noSlowTicks > 3 ? max - 0.019 : Math.max(noslow ? 0.0 : 0.25, max2) - (TargetStrafe.mc.field_1724.field_6012 % 2 == 0 ? 0.001 : 0.002);
        contextFriction = n6;
        if (!TargetStrafe.mc.field_1724.method_24828()) {
            needSprintState = !((IClientPlayerEntity)TargetStrafe.mc.field_1724).getLastSprinting();
            needSwap = true;
        } else {
            needSprintState = false;
        }
        return max2;
    }

    public class_238 getBoundingBox() {
        return new class_238(TargetStrafe.mc.field_1724.method_23317() - 0.1, TargetStrafe.mc.field_1724.method_23318(), TargetStrafe.mc.field_1724.method_23321() - 0.1, TargetStrafe.mc.field_1724.method_23317() + 0.1, TargetStrafe.mc.field_1724.method_23318() + 1.0, TargetStrafe.mc.field_1724.method_23321() + 0.1);
    }

    public float getAIMoveSpeed() {
        boolean prevSprinting = TargetStrafe.mc.field_1724.method_5624();
        TargetStrafe.mc.field_1724.method_5728(false);
        float speed = TargetStrafe.mc.field_1724.method_6029() * 1.3f;
        TargetStrafe.mc.field_1724.method_5728(prevSprinting);
        return speed;
    }

    public static void disabler(int elytra) {
        if (elytra == -1) {
            return;
        }
        if (System.currentTimeMillis() - disableTime > 190L) {
            if (elytra != -2) {
                TargetStrafe.mc.field_1761.method_2906(0, elytra, 1, class_1713.field_7790, (class_1657)TargetStrafe.mc.field_1724);
                TargetStrafe.mc.field_1761.method_2906(0, 6, 1, class_1713.field_7790, (class_1657)TargetStrafe.mc.field_1724);
            }
            TargetStrafe.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)TargetStrafe.mc.field_1724, class_2848.class_2849.field_12982));
            TargetStrafe.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)TargetStrafe.mc.field_1724, class_2848.class_2849.field_12982));
            if (elytra != -2) {
                TargetStrafe.mc.field_1761.method_2906(0, 6, 1, class_1713.field_7790, (class_1657)TargetStrafe.mc.field_1724);
                TargetStrafe.mc.field_1761.method_2906(0, elytra, 1, class_1713.field_7790, (class_1657)TargetStrafe.mc.field_1724);
            }
            disableTime = System.currentTimeMillis();
        }
        disabled = true;
    }

    private double wrapDS(double x, double z) {
        double diffX = x - TargetStrafe.mc.field_1724.method_23317();
        double diffZ = z - TargetStrafe.mc.field_1724.method_23321();
        return Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0;
    }

    @EventHandler
    public void onMove(EventMove event) {
        int elytraSlot = InventoryUtility.getElytra();
        if (this.boost.getValue() == Boost.Elytra && elytraSlot != -1 && MovementUtility.isMoving() && !TargetStrafe.mc.field_1724.method_24828() && TargetStrafe.mc.field_1687.method_20812((class_1297)TargetStrafe.mc.field_1724, TargetStrafe.mc.field_1724.method_5829().method_989(0.0, event.getY(), 0.0)).iterator().hasNext() && disabled) {
            oldSpeed = this.setSpeed.getValue().floatValue();
        }
        if (this.canStrafe()) {
            if (Aura.target != null && ModuleManager.aura.isEnabled()) {
                double z;
                double speed = this.calculateSpeed(event);
                double wrap = Math.atan2(TargetStrafe.mc.field_1724.method_23321() - Aura.target.method_23321(), TargetStrafe.mc.field_1724.method_23317() - Aura.target.method_23317());
                double x = Aura.target.method_23317() + (double)this.distance.getValue().floatValue() * Math.cos(wrap += switchDir ? speed / Math.sqrt(TargetStrafe.mc.field_1724.method_5858(Aura.target)) : -(speed / Math.sqrt(TargetStrafe.mc.field_1724.method_5858(Aura.target))));
                if (this.needToSwitch(x, z = Aura.target.method_23321() + (double)this.distance.getValue().floatValue() * Math.sin(wrap))) {
                    switchDir = !switchDir;
                    x = Aura.target.method_23317() + (double)this.distance.getValue().floatValue() * Math.cos(wrap += 2.0 * (switchDir ? speed / Math.sqrt(TargetStrafe.mc.field_1724.method_5858(Aura.target)) : -(speed / Math.sqrt(TargetStrafe.mc.field_1724.method_5858(Aura.target)))));
                    z = Aura.target.method_23321() + (double)this.distance.getValue().floatValue() * Math.sin(wrap);
                }
                event.setX(speed * -Math.sin(Math.toRadians(this.wrapDS(x, z))));
                event.setZ(speed * Math.cos(Math.toRadians(this.wrapDS(x, z))));
                event.cancel();
            }
        } else {
            oldSpeed = 0.0;
        }
    }

    @EventHandler
    public void updateValues(EventSync e) {
        oldSpeed = Math.hypot(TargetStrafe.mc.field_1724.method_23317() - TargetStrafe.mc.field_1724.field_6014, TargetStrafe.mc.field_1724.method_23321() - TargetStrafe.mc.field_1724.field_5969) * contextFriction;
        if (TargetStrafe.mc.field_1724.method_24828() && this.jump.getValue().booleanValue() && Aura.target != null) {
            TargetStrafe.mc.field_1724.method_6043();
        }
        waterTicks = TargetStrafe.mc.field_1724.method_5869() ? 10 : (waterTicks = waterTicks - 1);
    }

    @EventHandler
    public void onUpdate(PlayerUpdateEvent event) {
        if (this.boost.getValue() == Boost.Elytra && InventoryUtility.getElytra() != -1 && !TargetStrafe.mc.field_1724.method_24828() && TargetStrafe.mc.field_1724.field_6017 > 0.0f && !disabled) {
            TargetStrafe.disabler(InventoryUtility.getElytra());
        }
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        class_2743 velocity;
        if (e.getPacket() instanceof class_2708) {
            oldSpeed = 0.0;
        }
        if (e.getPacket() instanceof class_2743 && (velocity = (class_2743)e.getPacket()).method_11818() == TargetStrafe.mc.field_1724.method_5628() && this.boost.getValue() == Boost.Damage) {
            if (TargetStrafe.mc.field_1724.method_24828()) {
                return;
            }
            double vX = velocity.method_11815();
            double vZ = velocity.method_11819();
            if (vX < 0.0) {
                vX *= -1.0;
            }
            if (vZ < 0.0) {
                vZ *= -1.0;
            }
            oldSpeed = (vX + vZ) / (double)(this.velReduction.getValue().floatValue() * 1000.0f);
            oldSpeed = Math.min(oldSpeed, (double)this.maxVelocitySpeed.getValue().floatValue());
            ((ISPacketEntityVelocity)velocity).setMotionX(0);
            ((ISPacketEntityVelocity)velocity).setMotionY(0);
            ((ISPacketEntityVelocity)velocity).setMotionZ(0);
        }
    }

    @EventHandler
    public void actionEvent(EventSprint eventAction) {
        if (this.canStrafe() && Core.serverSprint != needSprintState) {
            eventAction.setSprintState(!Core.serverSprint);
        }
        if (needSwap) {
            eventAction.setSprintState(!((IClientPlayerEntity)TargetStrafe.mc.field_1724).getLastSprinting());
            needSwap = false;
        }
    }

    private static enum Boost {
        None,
        Elytra,
        Damage;

    }
}

