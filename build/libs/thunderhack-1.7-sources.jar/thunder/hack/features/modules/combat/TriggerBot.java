/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Blocks
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.Hand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Position
 */
package thunder.hack.features.modules.combat;

import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;

public final class TriggerBot
extends Module {
    public final Setting<Float> attackRange = new Setting<Float>("Range", Float.valueOf(3.0f), Float.valueOf(1.0f), Float.valueOf(7.0f));
    public final Setting<BooleanSettingGroup> smartCrit = new Setting<BooleanSettingGroup>("SmartCrit", new BooleanSettingGroup(true));
    public final Setting<Boolean> onlySpace = new Setting<Boolean>("OnlyCrit", false).addToGroup(this.smartCrit);
    public final Setting<Boolean> autoJump = new Setting<Boolean>("AutoJump", false).addToGroup(this.smartCrit);
    public final Setting<Boolean> ignoreWalls = new Setting<Boolean>("IgnoreWalls", false);
    public final Setting<Boolean> pauseEating = new Setting<Boolean>("PauseWhileEating", false);
    public final Setting<Integer> minDelay = new Setting<Integer>("RandomDelayMin", 2, 0, 20);
    public final Setting<Integer> maxDelay = new Setting<Integer>("RandomDelayMax", 13, 0, 20);
    private int delay;
    private final Random random = new Random();

    public TriggerBot() {
        super("TriggerBot", Module.Category.COMBAT);
    }

    @EventHandler
    public void onAttack(PlayerUpdateEvent e) {
        if (TriggerBot.mc.field_1724.method_6115() && this.pauseEating.getValue().booleanValue()) {
            return;
        }
        if (!TriggerBot.mc.field_1690.field_1903.method_1434() && TriggerBot.mc.field_1724.method_24828() && this.autoJump.getValue().booleanValue()) {
            TriggerBot.mc.field_1724.method_6043();
        }
        if (!this.autoCrit() && this.delay > 0) {
            --this.delay;
            return;
        }
        class_1297 ent = Managers.PLAYER.getRtxTarget(TriggerBot.mc.field_1724.method_36454(), TriggerBot.mc.field_1724.method_36455(), this.attackRange.getValue().floatValue(), this.ignoreWalls.getValue());
        if (ent != null && !Managers.FRIEND.isFriend(ent.method_5477().getString())) {
            TriggerBot.mc.field_1761.method_2918((class_1657)TriggerBot.mc.field_1724, ent);
            TriggerBot.mc.field_1724.method_6104(class_1268.field_5808);
            this.delay = this.random.nextInt(this.minDelay.getValue(), this.maxDelay.getValue() + 1);
        }
    }

    private boolean autoCrit() {
        float f2;
        boolean reasonForSkipCrit = !this.smartCrit.getValue().isEnabled() || TriggerBot.mc.field_1724.method_31549().field_7479 || TriggerBot.mc.field_1724.method_6128() || TriggerBot.mc.field_1724.method_6059(class_1294.field_5919) || TriggerBot.mc.field_1724.method_21754() || TriggerBot.mc.field_1687.method_8320(class_2338.method_49638((class_2374)TriggerBot.mc.field_1724.method_19538())).method_26204() == class_2246.field_10343;
        boolean bl = reasonForSkipCrit;
        if (TriggerBot.mc.field_1724.field_6017 > 1.0f && (double)TriggerBot.mc.field_1724.field_6017 < 1.14) {
            return false;
        }
        float f = ModuleManager.aura.getAttackCooldown();
        float f3 = f2 = TriggerBot.mc.field_1724.method_24828() ? 1.0f : 0.9f;
        if (f < f2) {
            return false;
        }
        boolean mergeWithTargetStrafe = !ModuleManager.targetStrafe.isEnabled() || ModuleManager.targetStrafe.jump.getValue() == false;
        boolean mergeWithSpeed = !ModuleManager.speed.isEnabled() || TriggerBot.mc.field_1724.method_24828();
        boolean bl2 = mergeWithSpeed;
        if (!TriggerBot.mc.field_1690.field_1903.method_1434() && mergeWithTargetStrafe && mergeWithSpeed && !this.onlySpace.getValue().booleanValue() && !this.autoJump.getValue().booleanValue()) {
            return true;
        }
        if (TriggerBot.mc.field_1724.method_5771()) {
            return true;
        }
        if (!TriggerBot.mc.field_1690.field_1903.method_1434() && ModuleManager.aura.isAboveWater()) {
            return true;
        }
        if (!reasonForSkipCrit) {
            return !TriggerBot.mc.field_1724.method_24828() && TriggerBot.mc.field_1724.field_6017 > 0.0f;
        }
        return true;
    }
}

