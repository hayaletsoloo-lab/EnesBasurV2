/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.gui.screen.ingame.GenericContainerScreen
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityType
 *  net.minecraft.entity.TntEntity
 *  net.minecraft.entity.decoration.EndCrystalEntity
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.mob.CreeperEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.vehicle.TntMinecartEntity
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.item.ShieldItem
 *  net.minecraft.item.SwordItem
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket
 *  net.minecraft.network.packet.c2s.play.PickFromInventoryC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket
 *  net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.Hand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.Vec3d
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_1548;
import net.minecraft.class_1657;
import net.minecraft.class_1701;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_1829;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2604;
import net.minecraft.class_2626;
import net.minecraft.class_2815;
import net.minecraft.class_2838;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_476;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IMinecraftClient;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.Bind;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.setting.impl.SettingGroup;
import thunder.hack.utility.Timer;
import thunder.hack.utility.math.PredictUtility;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.SearchInvResult;
import thunder.hack.utility.world.ExplosionUtility;

public final class AutoTotem
extends Module {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Matrix);
    private final Setting<OffHand> offhand = new Setting<OffHand>("Item", OffHand.Totem);
    private final Setting<BooleanSettingGroup> bindSwap = new Setting<BooleanSettingGroup>("BindSwap", new BooleanSettingGroup(false), v -> this.offhand.is(OffHand.Totem));
    private final Setting<Bind> swapButton = new Setting<Bind>("SwapButton", new Bind(280, false, false)).addToGroup(this.bindSwap);
    private final Setting<Swap> swapMode = new Setting<Swap>("Swap", Swap.GappleShield).addToGroup(this.bindSwap);
    private final Setting<Boolean> ncpStrict = new Setting<Boolean>("NCPStrict", false);
    private final Setting<Float> healthF = new Setting<Float>("HP", Float.valueOf(16.0f), Float.valueOf(0.0f), Float.valueOf(36.0f));
    private final Setting<Float> healthS = new Setting<Float>("ShieldGappleHp", Float.valueOf(16.0f), Float.valueOf(0.0f), Float.valueOf(20.0f), v -> this.offhand.getValue() == OffHand.Shield);
    private final Setting<Boolean> calcAbsorption = new Setting<Boolean>("CalcAbsorption", true);
    private final Setting<Boolean> stopMotion = new Setting<Boolean>("StopMotion", false);
    private final Setting<Boolean> resetAttackCooldown = new Setting<Boolean>("ResetAttackCooldown", false);
    private final Setting<SettingGroup> safety = new Setting<SettingGroup>("Safety", new SettingGroup(false, 0));
    private final Setting<Boolean> hotbarFallBack = new Setting<Boolean>("HotbarFallback", false).addToGroup(this.safety);
    private final Setting<Boolean> fallBackCalc = new Setting<Boolean>("FallBackCalc", true, v -> this.hotbarFallBack.getValue()).addToGroup(this.safety);
    private final Setting<Boolean> onElytra = new Setting<Boolean>("OnElytra", true).addToGroup(this.safety);
    private final Setting<Boolean> onFall = new Setting<Boolean>("OnFall", true).addToGroup(this.safety);
    private final Setting<Boolean> onCrystal = new Setting<Boolean>("OnCrystal", true).addToGroup(this.safety);
    private final Setting<Boolean> onObsidianPlace = new Setting<Boolean>("OnObsidianPlace", false).addToGroup(this.safety);
    private final Setting<Boolean> onCrystalInHand = new Setting<Boolean>("OnCrystalInHand", false).addToGroup(this.safety);
    private final Setting<Boolean> onMinecartTnt = new Setting<Boolean>("OnMinecartTNT", true).addToGroup(this.safety);
    private final Setting<Boolean> onCreeper = new Setting<Boolean>("OnCreeper", true).addToGroup(this.safety);
    private final Setting<Boolean> onAnchor = new Setting<Boolean>("OnAnchor", true).addToGroup(this.safety);
    private final Setting<Boolean> onTnt = new Setting<Boolean>("OnTNT", true).addToGroup(this.safety);
    public final Setting<RCGap> rcGap = new Setting<RCGap>("RightClickGapple", RCGap.Off);
    private final Setting<Boolean> crappleSpoof = new Setting<Boolean>("CrappleSpoof", true, v -> this.offhand.getValue() == OffHand.GApple);
    private int delay;
    private Timer bindDelay = new Timer();
    private class_1792 prevItem;

    public AutoTotem() {
        super("AutoTotem", Module.Category.COMBAT);
    }

    @EventHandler
    public void onSync(EventSync e) {
        this.swapTo(this.getItemSlot());
        if (this.rcGap.not(RCGap.Off) && AutoTotem.mc.field_1724.method_6047().method_7909() instanceof class_1829 && AutoTotem.mc.field_1690.field_1904.method_1434() && !AutoTotem.mc.field_1724.method_6115()) {
            ((IMinecraftClient)mc).idoItemUse();
        }
        --this.delay;
    }

    @EventHandler
    public void onPacketReceive(@NotNull PacketEvent.Receive e) {
        class_2626 blockUpdate;
        class_2604 spawn;
        Object t = e.getPacket();
        if (t instanceof class_2604 && (spawn = (class_2604)t).method_11169() == class_1299.field_6110 && this.getPlayerPos().method_1028(spawn.method_11175(), spawn.method_11174(), spawn.method_11176()) < 36.0) {
            if (this.hotbarFallBack.getValue().booleanValue()) {
                class_243 VanillaChestLootTableGenerator;
                if (this.fallBackCalc.getValue().booleanValue() && ExplosionUtility.getExplosionDamageWPredict(VanillaChestLootTableGenerator = new class_243(spawn.method_11175(), spawn.method_11174(), spawn.method_11176()), (class_1657)AutoTotem.mc.field_1724, PredictUtility.createBox(this.getPlayerPos(), (class_1297)AutoTotem.mc.field_1724), false) < this.getTriggerHealth() + 4.0f) {
                    return;
                }
                this.runInstant();
            }
            if (this.onCrystal.getValue().booleanValue()) {
                class_243 WallPlayerSkullBlock = new class_243(spawn.method_11175(), spawn.method_11174(), spawn.method_11176());
                if ((double)(this.getTriggerHealth() - ExplosionUtility.getExplosionDamageWPredict(WallPlayerSkullBlock, (class_1657)AutoTotem.mc.field_1724, PredictUtility.createBox(this.getPlayerPos(), (class_1297)AutoTotem.mc.field_1724), false)) < 0.5) {
                    int slot = -1;
                    for (int i = 9; i < 45; ++i) {
                        if (!AutoTotem.mc.field_1724.method_31548().method_5438(i >= 36 ? i - 36 : i).method_7909().equals(class_1802.field_8288)) continue;
                        slot = i >= 36 ? i - 36 : i;
                        break;
                    }
                    this.swapTo(slot);
                    this.debug("spawn switch");
                }
            }
        }
        if ((t = e.getPacket()) instanceof class_2626 && (blockUpdate = (class_2626)t).method_11308().method_26204() == class_2246.field_10540 && this.onObsidianPlace.getValue().booleanValue() && this.getPlayerPos().method_1025(blockUpdate.method_11309().method_46558()) < 36.0 && this.delay <= 0) {
            this.runInstant();
        }
    }

    private float getTriggerHealth() {
        return AutoTotem.mc.field_1724.method_6032() + (this.calcAbsorption.getValue() != false ? AutoTotem.mc.field_1724.method_6067() : 0.0f);
    }

    private void runInstant() {
        SearchInvResult hotbarResult = InventoryUtility.findItemInHotBar(class_1802.field_8288);
        SearchInvResult invResult = InventoryUtility.findItemInInventory(class_1802.field_8288);
        if (hotbarResult.found()) {
            hotbarResult.switchTo();
            this.delay = 20;
        } else if (invResult.found()) {
            int slot = invResult.slot() >= 36 ? invResult.slot() - 36 : invResult.slot();
            int n = slot;
            if (!this.hotbarFallBack.getValue().booleanValue()) {
                this.swapTo(slot);
            } else {
                AutoTotem.mc.field_1761.method_2916(slot);
            }
            this.delay = 20;
        }
    }

    public void swapTo(int slot) {
        block14: {
            block16: {
                int prevCurrentItem;
                block15: {
                    if (slot == -1 || this.delay > 0) break block14;
                    if (AutoTotem.mc.field_1755 instanceof class_476) {
                        return;
                    }
                    if (this.stopMotion.getValue().booleanValue()) {
                        AutoTotem.mc.field_1724.method_18800(0.0, AutoTotem.mc.field_1724.method_18798().method_10214(), 0.0);
                    }
                    int nearestSlot = AutoTotem.findNearestCurrentItem();
                    prevCurrentItem = AutoTotem.mc.field_1724.method_31548().field_7545;
                    if (slot < 9) break block15;
                    switch (this.mode.getValue().ordinal()) {
                        case 0: {
                            if (this.ncpStrict.getValue().booleanValue()) {
                                this.sendPacket((class_2596<?>)new class_2848((class_1297)AutoTotem.mc.field_1724, class_2848.class_2849.field_12985));
                            }
                            AutoTotem.clickSlot(slot);
                            AutoTotem.clickSlot(45);
                            AutoTotem.clickSlot(slot);
                            this.sendPacket((class_2596<?>)new class_2815(AutoTotem.mc.field_1724.field_7512.field_7763));
                            break;
                        }
                        case 1: {
                            if (this.ncpStrict.getValue().booleanValue()) {
                                this.sendPacket((class_2596<?>)new class_2848((class_1297)AutoTotem.mc.field_1724, class_2848.class_2849.field_12985));
                            }
                            AutoTotem.clickSlot(slot, nearestSlot, class_1713.field_7791);
                            AutoTotem.clickSlot(45, nearestSlot, class_1713.field_7791);
                            AutoTotem.clickSlot(slot, nearestSlot, class_1713.field_7791);
                            this.sendPacket((class_2596<?>)new class_2815(AutoTotem.mc.field_1724.field_7512.field_7763));
                            break;
                        }
                        case 2: {
                            if (this.ncpStrict.getValue().booleanValue()) {
                                this.sendPacket((class_2596<?>)new class_2848((class_1297)AutoTotem.mc.field_1724, class_2848.class_2849.field_12985));
                            }
                            AutoTotem.mc.field_1761.method_2906(AutoTotem.mc.field_1724.field_7512.field_7763, slot, nearestSlot, class_1713.field_7791, (class_1657)AutoTotem.mc.field_1724);
                            this.debug(slot + " " + nearestSlot);
                            this.sendPacket((class_2596<?>)new class_2868(nearestSlot));
                            AutoTotem.mc.field_1724.method_31548().field_7545 = nearestSlot;
                            class_1799 itemstack = AutoTotem.mc.field_1724.method_6079();
                            AutoTotem.mc.field_1724.method_6122(class_1268.field_5810, AutoTotem.mc.field_1724.method_6047());
                            AutoTotem.mc.field_1724.method_6122(class_1268.field_5808, itemstack);
                            this.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
                            this.sendPacket((class_2596<?>)new class_2868(prevCurrentItem));
                            AutoTotem.mc.field_1724.method_31548().field_7545 = prevCurrentItem;
                            AutoTotem.mc.field_1761.method_2906(AutoTotem.mc.field_1724.field_7512.field_7763, slot, nearestSlot, class_1713.field_7791, (class_1657)AutoTotem.mc.field_1724);
                            this.sendPacket((class_2596<?>)new class_2815(AutoTotem.mc.field_1724.field_7512.field_7763));
                            if (this.resetAttackCooldown.getValue().booleanValue()) {
                                AutoTotem.mc.field_1724.method_7350();
                                break;
                            }
                            break block16;
                        }
                        case 3: {
                            this.debug(slot + " pick");
                            this.sendPacket((class_2596<?>)new class_2838(slot));
                            this.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
                            int prevSlot = AutoTotem.mc.field_1724.method_31548().field_7545;
                            Managers.ASYNC.run(() -> {
                                AutoTotem.mc.field_1724.method_31548().field_7545 = prevSlot;
                            }, 300L);
                            break;
                        }
                        case 4: {
                            this.debug(slot + " swap");
                            AutoTotem.mc.field_1761.method_2906(AutoTotem.mc.field_1724.field_7512.field_7763, slot, 40, class_1713.field_7791, (class_1657)AutoTotem.mc.field_1724);
                            this.sendPacket((class_2596<?>)new class_2815(AutoTotem.mc.field_1724.field_7512.field_7763));
                        }
                    }
                    break block16;
                }
                this.sendPacket((class_2596<?>)new class_2868(slot));
                AutoTotem.mc.field_1724.method_31548().field_7545 = slot;
                this.debug(slot + " select");
                this.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
                this.sendPacket((class_2596<?>)new class_2868(prevCurrentItem));
                AutoTotem.mc.field_1724.method_31548().field_7545 = prevCurrentItem;
                if (this.resetAttackCooldown.getValue().booleanValue()) {
                    AutoTotem.mc.field_1724.method_7350();
                }
            }
            this.delay = (int)(2.0f + (float)Managers.SERVER.getPing() / 25.0f);
        }
    }

    public static int findNearestCurrentItem() {
        int i = AutoTotem.mc.field_1724.method_31548().field_7545;
        if (i == 8) {
            return 7;
        }
        if (i == 0) {
            return 1;
        }
        return i - 1;
    }

    /*
     * WARNING - void declaration
     */
    public int getItemSlot() {
        if (AutoTotem.mc.field_1724 == null || AutoTotem.mc.field_1687 == null) {
            return -1;
        }
        SearchInvResult gapple = InventoryUtility.findItemInInventory(class_1802.field_8367);
        SearchInvResult crapple = InventoryUtility.findItemInInventory(class_1802.field_8463);
        SearchInvResult shield = InventoryUtility.findItemInInventory(class_1802.field_8255);
        class_1792 offHandItem = AutoTotem.mc.field_1724.method_6079().method_7909();
        int itemSlot = -1;
        class_1792 item = null;
        switch (this.offhand.getValue().ordinal()) {
            case 0: {
                if (offHandItem != class_1802.field_8288 && !AutoTotem.mc.field_1724.method_6079().method_7960()) {
                    this.prevItem = offHandItem;
                }
                item = this.prevItem;
                if (!this.bindSwap.getValue().isEnabled() || !this.isKeyPressed(this.swapButton) || !this.bindDelay.every(250L)) break;
                switch (this.swapMode.getValue().ordinal()) {
                    case 1: {
                        if (AutoTotem.mc.field_1724.method_6079().method_7960() || offHandItem == class_1802.field_8255) {
                            item = class_1802.field_8575;
                            break;
                        }
                        item = class_1802.field_8255;
                        break;
                    }
                    case 2: {
                        if (AutoTotem.mc.field_1724.method_6079().method_7960() || offHandItem == class_1802.field_8463) {
                            item = class_1802.field_8575;
                            break;
                        }
                        item = class_1802.field_8463;
                        break;
                    }
                    case 0: {
                        if (AutoTotem.mc.field_1724.method_6079().method_7960() || offHandItem == class_1802.field_8255) {
                            item = class_1802.field_8463;
                            break;
                        }
                        item = class_1802.field_8255;
                        break;
                    }
                    case 3: {
                        item = AutoTotem.mc.field_1724.method_6079().method_7960() || offHandItem == class_1802.field_8288 ? class_1802.field_8575 : class_1802.field_8288;
                    }
                }
                this.prevItem = item;
                break;
            }
            case 1: {
                item = class_1802.field_8301;
                break;
            }
            case 2: {
                if (this.crappleSpoof.getValue().booleanValue()) {
                    if (AutoTotem.mc.field_1724.method_6059(class_1294.field_5898) && AutoTotem.mc.field_1724.method_6112(class_1294.field_5898).method_5578() > 2) {
                        if (crapple.found() || offHandItem == class_1802.field_8463) {
                            item = class_1802.field_8463;
                            break;
                        }
                        if (!gapple.found() && offHandItem != class_1802.field_8367) break;
                        item = class_1802.field_8367;
                        break;
                    }
                    if (gapple.found() || offHandItem == class_1802.field_8367) {
                        item = class_1802.field_8367;
                        break;
                    }
                    if (!crapple.found() && offHandItem != class_1802.field_8463) break;
                    item = class_1802.field_8463;
                    break;
                }
                if (crapple.found() || offHandItem == class_1802.field_8463) {
                    item = class_1802.field_8463;
                    break;
                }
                if (!gapple.found() && offHandItem != class_1802.field_8367) break;
                item = class_1802.field_8367;
                break;
            }
            case 3: {
                if (shield.found() || offHandItem == class_1802.field_8255) {
                    if (this.getTriggerHealth() <= this.healthS.getValue().floatValue()) {
                        if (crapple.found() || offHandItem == class_1802.field_8463) {
                            item = class_1802.field_8463;
                            break;
                        }
                        if (!gapple.found() && offHandItem != class_1802.field_8367) break;
                        item = class_1802.field_8367;
                        break;
                    }
                    if (!AutoTotem.mc.field_1724.method_7357().method_7904(class_1802.field_8255)) {
                        item = class_1802.field_8255;
                        break;
                    }
                    if (crapple.found() || offHandItem == class_1802.field_8463) {
                        item = class_1802.field_8463;
                        break;
                    }
                    if (!gapple.found() && offHandItem != class_1802.field_8367) break;
                    item = class_1802.field_8367;
                    break;
                }
                if (!crapple.found() && offHandItem != class_1802.field_8463) break;
                item = class_1802.field_8463;
            }
        }
        if (this.getTriggerHealth() <= this.healthF.getValue().floatValue() && (InventoryUtility.findItemInInventory(class_1802.field_8288).found() || offHandItem == class_1802.field_8288)) {
            item = class_1802.field_8288;
        }
        if (!this.rcGap.is(RCGap.Off) && AutoTotem.mc.field_1724.method_6047().method_7909() instanceof class_1829 && AutoTotem.mc.field_1690.field_1904.method_1434() && !(offHandItem instanceof class_1819) && (this.rcGap.is(RCGap.Always) || this.rcGap.is(RCGap.OnlySafe) && this.getTriggerHealth() > this.healthF.getValue().floatValue())) {
            if (crapple.found() || offHandItem == class_1802.field_8463) {
                item = class_1802.field_8463;
            }
            if (gapple.found() || offHandItem == class_1802.field_8367) {
                item = class_1802.field_8367;
            }
        }
        if (this.onFall.getValue().booleanValue() && (double)(this.getTriggerHealth() - ((AutoTotem.mc.field_1724.field_6017 - 3.0f) / 2.0f + 3.5f)) < 0.5) {
            item = class_1802.field_8288;
        }
        if (this.onElytra.getValue().booleanValue() && AutoTotem.mc.field_1724.method_6128()) {
            item = class_1802.field_8288;
        }
        if (this.onCrystalInHand.getValue().booleanValue()) {
            for (class_1657 playerEntity : Managers.ASYNC.getAsyncPlayers()) {
                if (Managers.FRIEND.isFriend(playerEntity) || playerEntity == AutoTotem.mc.field_1724 || !(this.getPlayerPos().method_1025(playerEntity.method_19538()) < 36.0) || playerEntity.method_6047().method_7909() != class_1802.field_8281 && playerEntity.method_6047().method_7909() != class_1802.field_8301 && playerEntity.method_6079().method_7909() != class_1802.field_8281 && playerEntity.method_6079().method_7909() != class_1802.field_8301) continue;
                item = class_1802.field_8288;
            }
        }
        for (class_1297 entity : AutoTotem.mc.field_1687.method_18112()) {
            if (entity == null || !entity.method_5805() || this.getPlayerPos().method_1025(entity.method_19538()) > 36.0) continue;
            if (this.onCrystal.getValue().booleanValue() && entity instanceof class_1511 && (double)(this.getTriggerHealth() - ExplosionUtility.getExplosionDamageWPredict(entity.method_19538(), (class_1657)AutoTotem.mc.field_1724, PredictUtility.createBox(this.getPlayerPos(), (class_1297)AutoTotem.mc.field_1724), false)) < 0.5) {
                item = class_1802.field_8288;
                break;
            }
            if (this.onTnt.getValue().booleanValue() && entity instanceof class_1541) {
                item = class_1802.field_8288;
                break;
            }
            if (this.onMinecartTnt.getValue().booleanValue() && entity instanceof class_1701) {
                item = class_1802.field_8288;
                break;
            }
            if (!this.onCreeper.getValue().booleanValue() || !(entity instanceof class_1548)) continue;
            item = class_1802.field_8288;
            break;
        }
        if (this.onAnchor.getValue().booleanValue()) {
            for (int x = -6; x <= 6; ++x) {
                int var8_14 = -6;
                while (var8_14 <= 6) {
                    for (int z = -6; z <= 6; ++z) {
                        class_2338 bp = new class_2338(x, (int)var8_14, z);
                        if (AutoTotem.mc.field_1687.method_8320(bp).method_26204() != class_2246.field_23152) continue;
                        item = class_1802.field_8288;
                        break;
                    }
                    ++var8_14;
                }
            }
        }
        for (int i = 9; i < 45; ++i) {
            if (AutoTotem.mc.field_1724.method_6079().method_7909() == item) {
                return -1;
            }
            if (!AutoTotem.mc.field_1724.method_31548().method_5438(i >= 36 ? i - 36 : i).method_7909().equals(item)) continue;
            itemSlot = i >= 36 ? i - 36 : i;
            break;
        }
        if (item == AutoTotem.mc.field_1724.method_6047().method_7909() && AutoTotem.mc.field_1690.field_1904.method_1434()) {
            return -1;
        }
        return itemSlot;
    }

    private class_243 getPlayerPos() {
        return AutoTotem.mc.field_1724.method_19538();
    }

    private static enum Mode {
        Default,
        Alternative,
        Matrix,
        MatrixPick,
        NewVersion;

    }

    private static enum OffHand {
        Totem,
        Crystal,
        GApple,
        Shield;

    }

    private static enum Swap {
        GappleShield,
        BallShield,
        GappleBall,
        BallTotem;

    }

    public static enum RCGap {
        Off,
        Always,
        OnlySafe;

    }
}

