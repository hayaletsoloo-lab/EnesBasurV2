/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.Unpooled
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.decoration.EndCrystalEntity
 *  net.minecraft.network.PacketByteBuf
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$Full
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$PositionAndOnGround
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.modules.combat;

import io.netty.buffer.Unpooled;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import org.jetbrains.annotations.NotNull;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IClientPlayerEntity;
import thunder.hack.injection.accesors.IPlayerInteractEntityC2SPacket;
import thunder.hack.setting.Setting;

public final class Criticals
extends Module {
    public final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.UpdatedNCP);
    public static boolean cancelCrit;

    public Criticals() {
        super("Criticals", Module.Category.COMBAT);
    }

    @EventHandler
    public void onPacketSend(@NotNull PacketEvent.Send event) {
        if (event.getPacket() instanceof class_2824 && Criticals.getInteractType((class_2824)event.getPacket()) == InteractType.ATTACK) {
            class_1297 ent = Criticals.getEntity((class_2824)event.getPacket());
            if (ent == null || ent instanceof class_1511 || cancelCrit) {
                return;
            }
            this.doCrit();
        }
    }

    public void doCrit() {
        if (this.isDisabled() || Criticals.mc.field_1724 == null || Criticals.mc.field_1687 == null) {
            return;
        }
        if ((Criticals.mc.field_1724.method_24828() || Criticals.mc.field_1724.method_31549().field_7479 || this.mode.is(Mode.Grim)) && !Criticals.mc.field_1724.method_5771() && !Criticals.mc.field_1724.method_5869()) {
            switch (this.mode.getValue().ordinal()) {
                case 2: {
                    this.critPacket(1.058293536E-5, false);
                    this.critPacket(9.16580235E-6, false);
                    this.critPacket(1.0371854E-7, false);
                    break;
                }
                case 0: {
                    this.critPacket(0.0625, false);
                    this.critPacket(0.0, false);
                    break;
                }
                case 3: {
                    this.critPacket(2.71875E-7, false);
                    this.critPacket(0.0, false);
                    break;
                }
                case 1: {
                    this.critPacket(0.062600301692775, false);
                    this.critPacket(0.07260029960661, false);
                    this.critPacket(0.0, false);
                    this.critPacket(0.0, false);
                    break;
                }
                case 4: {
                    if (Criticals.mc.field_1724.method_24828()) break;
                    this.critPacket(-1.0E-6, true);
                }
            }
        }
    }

    private void critPacket(double yDelta, boolean full) {
        if (!full) {
            this.sendPacket((class_2596<?>)new class_2828.class_2829(Criticals.mc.field_1724.method_23317(), Criticals.mc.field_1724.method_23318() + yDelta, Criticals.mc.field_1724.method_23321(), false));
        } else {
            this.sendPacket((class_2596<?>)new class_2828.class_2830(Criticals.mc.field_1724.method_23317(), Criticals.mc.field_1724.method_23318() + yDelta, Criticals.mc.field_1724.method_23321(), ((IClientPlayerEntity)Criticals.mc.field_1724).getLastYaw(), ((IClientPlayerEntity)Criticals.mc.field_1724).getLastPitch(), false));
        }
    }

    public static class_1297 getEntity(@NotNull class_2824 packet) {
        class_2540 packetBuf = new class_2540(Unpooled.buffer());
        ((IPlayerInteractEntityC2SPacket)packet).write(packetBuf);
        return Criticals.mc.field_1687.method_8469(packetBuf.method_10816());
    }

    public static InteractType getInteractType(@NotNull class_2824 packet) {
        class_2540 packetBuf = new class_2540(Unpooled.buffer());
        ((IPlayerInteractEntityC2SPacket)packet).write(packetBuf);
        packetBuf.method_10816();
        return (InteractType)packetBuf.method_10818(InteractType.class);
    }

    public static enum Mode {
        Ncp,
        Strict,
        OldNCP,
        UpdatedNCP,
        Grim;

    }

    public static enum InteractType {
        INTERACT,
        ATTACK,
        INTERACT_AT;

    }
}

