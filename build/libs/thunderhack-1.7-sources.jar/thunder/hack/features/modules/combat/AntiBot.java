/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.network.OtherClientPlayerEntity
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.Entity$RemovalReason
 *  net.minecraft.entity.player.PlayerEntity
 */
package thunder.hack.features.modules.combat;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_745;
import thunder.hack.events.impl.EventSync;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.features.modules.misc.FakePlayer;
import thunder.hack.features.modules.render.NameTags;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;

public final class AntiBot
extends Module {
    public static ArrayList<class_1657> bots = new ArrayList();
    public Setting<Boolean> remove = new Setting<Boolean>("Remove", false);
    public Setting<Boolean> onlyAura = new Setting<Boolean>("OnlyAura", true);
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.UUIDCheck);
    public Setting<Integer> checkticks = new Setting<Integer>("checkTicks", 3, 0, 10, v -> this.mode.getValue() == Mode.MotionCheck);
    private final Timer clearTimer = new Timer();
    private int ticks = 0;

    public AntiBot() {
        super("AntiBot", Module.Category.COMBAT);
    }

    @EventHandler
    public void onSync(EventSync e) {
        if (!this.onlyAura.getValue().booleanValue()) {
            AntiBot.mc.field_1687.method_18456().forEach(this::markAsBot);
        } else {
            class_1297 class_12972 = Aura.target;
            if (class_12972 instanceof class_1657) {
                class_1657 ent = (class_1657)class_12972;
                this.markAsBot(ent);
            }
        }
        if (this.remove.getValue().booleanValue()) {
            bots.forEach(b -> {
                try {
                    AntiBot.mc.field_1687.method_2945(b.method_5628(), class_1297.class_5529.field_26998);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            });
        }
        if (this.clearTimer.passedMs(10000L)) {
            bots.clear();
            this.ticks = 0;
            this.clearTimer.reset();
        }
    }

    private void markAsBot(class_1657 ent) {
        if (bots.contains(ent)) {
            return;
        }
        switch (this.mode.getValue().ordinal()) {
            case 0: {
                if (ent.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + ent.method_5477().getString()).getBytes(StandardCharsets.UTF_8))) || !(ent instanceof class_745) || FakePlayer.fakePlayer != null && ent.method_5628() == FakePlayer.fakePlayer.method_5628() || ent.method_5477().getString().contains("-")) break;
                this.addBot(ent);
                break;
            }
            case 1: {
                double diffX = ent.method_23317() - ent.field_6014;
                double diffZ = ent.method_23321() - ent.field_5969;
                if (!(diffX * diffX + diffZ * diffZ > 0.5)) break;
                if (this.ticks >= this.checkticks.getValue()) {
                    this.addBot(ent);
                }
                ++this.ticks;
                break;
            }
            case 2: {
                if (NameTags.getEntityPing(ent) > 0) break;
                this.addBot(ent);
            }
        }
    }

    private void addBot(class_1657 entity) {
        this.sendMessage(entity.method_5477().getString() + " is a bot!");
        bots.add(entity);
    }

    @Override
    public String getDisplayInfo() {
        return String.valueOf(bots.size());
    }

    public static enum Mode {
        UUIDCheck,
        MotionCheck,
        ZeroPing;

    }
}

