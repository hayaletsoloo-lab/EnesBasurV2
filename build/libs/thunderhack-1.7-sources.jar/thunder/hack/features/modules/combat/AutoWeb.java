/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Block
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.BlockItem
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.Position
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext$FluidHandling
 *  net.minecraft.world.RaycastContext$ShapeType
 */
package thunder.hack.features.modules.combat;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.setting.impl.SettingGroup;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public final class AutoWeb
extends Module {
    private final Setting<Integer> range = new Setting<Integer>("Range", 5, 1, 7);
    private final Setting<Integer> placeWallRange = new Setting<Integer>("WallRange", 5, 1, 7);
    private final Setting<PlaceTiming> placeTiming = new Setting<PlaceTiming>("PlaceTiming", PlaceTiming.Default);
    private final Setting<Integer> blocksPerTick = new Setting<Integer>("Block/Tick", 8, 1, 12, v -> this.placeTiming.getValue() == PlaceTiming.Default);
    private final Setting<Integer> placeDelay = new Setting<Integer>("Delay/Place", 3, 0, 10);
    private final Setting<InteractionUtility.Interact> interact = new Setting<InteractionUtility.Interact>("Interact", InteractionUtility.Interact.Strict);
    private final Setting<InteractionUtility.PlaceMode> placeMode = new Setting<InteractionUtility.PlaceMode>("PlaceMode", InteractionUtility.PlaceMode.Normal);
    private final Setting<InteractionUtility.Rotate> rotate = new Setting<InteractionUtility.Rotate>("Rotate", InteractionUtility.Rotate.None);
    private final Setting<SettingGroup> selection = new Setting<SettingGroup>("Selection", new SettingGroup(false, 0));
    private final Setting<Boolean> head = new Setting<Boolean>("Head", true).addToGroup(this.selection);
    private final Setting<Boolean> leggs = new Setting<Boolean>("Leggs", true).addToGroup(this.selection);
    private final Setting<Boolean> surround = new Setting<Boolean>("Surround", true).addToGroup(this.selection);
    private final Setting<Boolean> upperSurround = new Setting<Boolean>("UpperSurround", false).addToGroup(this.selection);
    private final Setting<SettingGroup> renderCategory = new Setting<SettingGroup>("Render", new SettingGroup(false, 0));
    private final Setting<RenderMode> renderMode = new Setting<RenderMode>("Render Mode", RenderMode.Fade).addToGroup(this.renderCategory);
    private final Setting<ColorSetting> renderFillColor = new Setting<ColorSetting>("Render Fill Color", new ColorSetting(HudEditor.getColor(0))).addToGroup(this.renderCategory);
    private final Setting<ColorSetting> renderLineColor = new Setting<ColorSetting>("Render Line Color", new ColorSetting(HudEditor.getColor(0))).addToGroup(this.renderCategory);
    private final Setting<Integer> renderLineWidth = new Setting<Integer>("Render Line Width", 2, 1, 5).addToGroup(this.renderCategory);
    private final Setting<Integer> effectDurationMs = new Setting<Integer>("Effect Duration (MS)", 500, 0, 10000).addToGroup(this.renderCategory);
    private final ArrayList<class_2338> sequentialBlocks = new ArrayList();
    public static Timer inactivityTimer = new Timer();
    private final Map<class_2338, Long> renderPoses = new ConcurrentHashMap<class_2338, Long>();
    private int delay = 0;

    public AutoWeb() {
        super("AutoWeb", Module.Category.COMBAT);
    }

    @Override
    public void onRender3D(class_4587 stack) {
        this.renderPoses.forEach((pos, time) -> {
            if (System.currentTimeMillis() - time > (long)this.effectDurationMs.getValue().intValue()) {
                this.renderPoses.remove(pos);
            } else {
                switch (this.renderMode.getValue().ordinal()) {
                    case 0: {
                        Render3DEngine.drawFilledBox(stack, new class_238(pos), Render2DEngine.injectAlpha(this.renderFillColor.getValue().getColorObject(), (int)(100.0f * (1.0f - (float)(System.currentTimeMillis() - time) / 500.0f))));
                        Render3DEngine.drawBoxOutline(new class_238(pos), Render2DEngine.injectAlpha(this.renderLineColor.getValue().getColorObject(), (int)(100.0f * (1.0f - (float)(System.currentTimeMillis() - time) / 500.0f))), this.renderLineWidth.getValue().intValue());
                        break;
                    }
                    case 1: {
                        float scale = 1.0f - (float)(System.currentTimeMillis() - time) / 500.0f;
                        class_238 box = new class_238((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260(), (double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260());
                        Render3DEngine.drawFilledBox(stack, box.method_1002((double)scale, (double)scale, (double)scale).method_989(0.5 + (double)scale * 0.5, 0.5 + (double)scale * 0.5, 0.5 + (double)scale * 0.5), Render2DEngine.injectAlpha(this.renderFillColor.getValue().getColorObject(), (int)(100.0f * (1.0f - (float)(System.currentTimeMillis() - time) / 500.0f))));
                        Render3DEngine.drawBoxOutline(box.method_1002((double)scale, (double)scale, (double)scale).method_989(0.5 + (double)scale * 0.5, 0.5 + (double)scale * 0.5, 0.5 + (double)scale * 0.5), this.renderLineColor.getValue().getColorObject(), this.renderLineWidth.getValue().intValue());
                    }
                }
            }
        });
    }

    @Override
    public void onEnable() {
        this.sequentialBlocks.clear();
        this.renderPoses.clear();
    }

    @EventHandler
    public void onTick(EventTick e) {
        class_2338 targetBlock1 = this.getSequentialPos();
        if (targetBlock1 == null) {
            return;
        }
        if (this.delay > 0) {
            --this.delay;
            return;
        }
        InventoryUtility.saveSlot();
        if (this.placeTiming.getValue() == PlaceTiming.Default) {
            class_2338 targetBlock;
            for (int placed = 0; placed < this.blocksPerTick.getValue() && (targetBlock = this.getSequentialPos()) != null && InteractionUtility.placeBlock(targetBlock, this.rotate.getValue(), this.interact.getValue(), this.placeMode.getValue(), this.getSlot(), false, true); ++placed) {
                this.renderPoses.put(targetBlock, System.currentTimeMillis());
                this.delay = this.placeDelay.getValue();
                inactivityTimer.reset();
            }
        } else if (this.placeTiming.getValue() == PlaceTiming.Vanilla) {
            class_2338 targetBlock = this.getSequentialPos();
            if (targetBlock == null) {
                return;
            }
            if (InteractionUtility.placeBlock(targetBlock, this.rotate.getValue(), this.interact.getValue(), this.placeMode.getValue(), this.getSlot(), false, true)) {
                this.sequentialBlocks.add(targetBlock);
                this.renderPoses.put(targetBlock, System.currentTimeMillis());
                this.delay = this.placeDelay.getValue();
                inactivityTimer.reset();
            }
        }
        InventoryUtility.returnSlot();
    }

    private class_2338 getSequentialPos() {
        class_1657 target = Managers.COMBAT.getNearestTarget(this.range.getValue().intValue());
        if (target != null) {
            class_2338 targetBp = class_2338.method_49638((class_2374)target.method_19538());
            ArrayList<class_2338> positions = new ArrayList<class_2338>();
            if (this.leggs.getValue().booleanValue()) {
                positions.add(targetBp);
            }
            if (this.head.getValue().booleanValue()) {
                positions.add(targetBp.method_10084());
            }
            if (this.surround.getValue().booleanValue()) {
                positions.add(targetBp.method_10078());
                positions.add(targetBp.method_10067());
                positions.add(targetBp.method_10072());
                positions.add(targetBp.method_10095());
            }
            if (this.upperSurround.getValue().booleanValue()) {
                positions.add(targetBp.method_10078().method_10084());
                positions.add(targetBp.method_10067().method_10084());
                positions.add(targetBp.method_10072().method_10084());
                positions.add(targetBp.method_10095().method_10084());
            }
            for (class_2338 bp : positions) {
                class_3965 wallCheck = AutoWeb.mc.field_1687.method_17742(new class_3959(InteractionUtility.getEyesPos((class_1297)AutoWeb.mc.field_1724), bp.method_46558().method_43206(class_2350.field_11036, 0.5), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)AutoWeb.mc.field_1724));
                if (wallCheck != null && wallCheck.method_17783() == class_239.class_240.field_1332 && wallCheck.method_17777() != bp && InteractionUtility.squaredDistanceFromEyes(bp.method_46558()) > this.placeWallRange.getPow2Value() || !InteractionUtility.canPlaceBlock(bp, this.interact.getValue(), true) || !AutoWeb.mc.field_1687.method_8320(bp).method_45474()) continue;
                return bp;
            }
        }
        return null;
    }

    private int getSlot() {
        class_2248 blockFromMainhandItem;
        ArrayList<class_2248> canUseBlocks = new ArrayList<class_2248>();
        canUseBlocks.add(class_2246.field_10343);
        int slot = -1;
        class_1799 mainhandStack = AutoWeb.mc.field_1724.method_6047();
        if (mainhandStack != class_1799.field_8037 && mainhandStack.method_7909() instanceof class_1747 && canUseBlocks.contains(blockFromMainhandItem = ((class_1747)mainhandStack.method_7909()).method_7711())) {
            slot = AutoWeb.mc.field_1724.method_31548().field_7545;
        }
        if (slot == -1) {
            for (int i = 0; i < 9; ++i) {
                class_2248 blockFromItem;
                class_1799 stack = AutoWeb.mc.field_1724.method_31548().method_5438(i);
                if (stack == class_1799.field_8037 || !(stack.method_7909() instanceof class_1747) || !canUseBlocks.contains(blockFromItem = ((class_1747)stack.method_7909()).method_7711())) continue;
                slot = i;
                break;
            }
        }
        return slot;
    }

    private static enum PlaceTiming {
        Default,
        Vanilla;

    }

    private static enum RenderMode {
        Fade,
        Decrease;

    }
}

