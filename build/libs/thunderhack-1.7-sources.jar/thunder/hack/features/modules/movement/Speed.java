/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Blocks
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.decoration.ArmorStandEntity
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.vehicle.BoatEntity
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$Full
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.Hand
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.shape.VoxelShape
 *  net.minecraft.util.shape.VoxelShapes
 */
package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2815;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventMove;
import thunder.hack.events.impl.EventPlayerTravel;
import thunder.hack.events.impl.EventPostTick;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.EventTick;
import thunder.hack.events.impl.PostPlayerUpdateEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.movement.Strafe;
import thunder.hack.injection.accesors.IInteractionManager;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.interfaces.IEntity;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.MovementUtility;
import thunder.hack.utility.player.SearchInvResult;

public class Speed
extends Module {
    public final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.NCP);
    public Setting<Boolean> useTimer = new Setting<Boolean>("Use Timer", false);
    public Setting<Boolean> pauseInLiquids = new Setting<Boolean>("PauseInLiquids", false);
    public Setting<Boolean> pauseWhileSneaking = new Setting<Boolean>("PauseWhileSneaking", false);
    public final Setting<Integer> hurttime = new Setting<Integer>("HurtTime", 0, 0, 10, v -> this.mode.is(Mode.MatrixDamage));
    public final Setting<Float> boostFactor = new Setting<Float>("BoostFactor", Float.valueOf(2.0f), Float.valueOf(0.0f), Float.valueOf(10.0f), v -> this.mode.is(Mode.MatrixDamage) || this.mode.is(Mode.Vanilla));
    public final Setting<Boolean> allowOffGround = new Setting<Boolean>("AllowOffGround", true, v -> this.mode.is(Mode.MatrixDamage));
    public final Setting<Integer> shiftTicks = new Setting<Integer>("ShiftTicks", 0, 0, 10, v -> this.mode.is(Mode.MatrixDamage));
    public final Setting<Integer> fireWorkSlot = new Setting<Integer>("FireSlot", 1, 1, 9, v -> this.mode.getValue() == Mode.FireWork);
    public final Setting<Integer> delay = new Setting<Integer>("Delay", 8, 1, 20, v -> this.mode.getValue() == Mode.FireWork);
    public final Setting<Boolean> strict = new Setting<Boolean>("Strict", false, v -> this.mode.is(Mode.GrimIce));
    public final Setting<Float> matrixJBSpeed = new Setting<Float>("TimerSpeed", Float.valueOf(1.088f), Float.valueOf(1.0f), Float.valueOf(2.0f), v -> this.mode.is(Mode.MatrixJB));
    public final Setting<Boolean> armorStands = new Setting<Boolean>("ArmorStands", false, v -> this.mode.is(Mode.GrimCombo) || this.mode.is(Mode.GrimEntity2));
    public double baseSpeed;
    private int stage;
    private int ticks;
    private int prevSlot;
    private float prevForward = 0.0f;
    private Timer elytraDelay = new Timer();
    private Timer startDelay = new Timer();

    public Speed() {
        super("Speed", Module.Category.MOVEMENT);
    }

    @Override
    public void onDisable() {
        ThunderHack.TICK_TIMER = 1.0f;
    }

    @Override
    public void onEnable() {
        this.stage = 1;
        this.ticks = 0;
        this.baseSpeed = 0.2873;
        this.startDelay.reset();
        this.prevSlot = -1;
    }

    @EventHandler
    public void onSync(EventSync e) {
        if (Speed.mc.field_1724.method_52535() && this.pauseInLiquids.getValue().booleanValue() || Speed.mc.field_1724.method_5715() && this.pauseWhileSneaking.getValue().booleanValue()) {
            return;
        }
        if (this.mode.getValue() == Mode.MatrixJB) {
            boolean closeToGround = false;
            for (class_265 a : Speed.mc.field_1687.method_20812((class_1297)Speed.mc.field_1724, Speed.mc.field_1724.method_5829().method_1009(0.5, 0.0, 0.5).method_989(0.0, -1.0, 0.0))) {
                if (a == class_259.method_1073()) continue;
                closeToGround = true;
                break;
            }
            if (MovementUtility.isMoving() && closeToGround && Speed.mc.field_1724.field_6017 <= 0.0f) {
                ThunderHack.TICK_TIMER = 1.0f;
                Speed.mc.field_1724.method_24830(true);
                Speed.mc.field_1724.method_6043();
            } else if (Speed.mc.field_1724.field_6017 > 0.0f && this.useTimer.getValue().booleanValue()) {
                ThunderHack.TICK_TIMER = this.matrixJBSpeed.getValue().floatValue();
                Speed.mc.field_1724.method_5762(0.0, (double)-0.003f, 0.0);
            }
        }
    }

    @EventHandler
    public void modifyVelocity(EventPlayerTravel e) {
        if (this.mode.getValue() == Mode.GrimEntity && !e.isPre() && ThunderHack.core.getSetBackTime() > 1000L) {
            for (class_1657 playerEntity : Managers.ASYNC.getAsyncPlayers()) {
                if (playerEntity == Speed.mc.field_1724 || !(Speed.mc.field_1724.method_5858((class_1297)playerEntity) <= 2.25)) continue;
                float p = Speed.mc.field_1687.method_8320(((IEntity)Speed.mc.field_1724).thunderHack_Recode$getVelocityBP()).method_26204().method_9499();
                float f = Speed.mc.field_1724.method_24828() ? p * 0.91f : 0.91f;
                float f2 = Speed.mc.field_1724.method_24828() ? p : 0.99f;
                Speed.mc.field_1724.method_18800(Speed.mc.field_1724.method_18798().method_10216() / (double)f * (double)f2, Speed.mc.field_1724.method_18798().method_10214(), Speed.mc.field_1724.method_18798().method_10215() / (double)f * (double)f2);
                break;
            }
        }
        if ((this.mode.is(Mode.GrimEntity2) || this.mode.is(Mode.GrimCombo)) && !e.isPre() && ThunderHack.core.getSetBackTime() > 1000L && MovementUtility.isMoving()) {
            int collisions = 0;
            for (class_1297 ent : Speed.mc.field_1687.method_18112()) {
                if (ent == Speed.mc.field_1724 || ent instanceof class_1531 && !this.armorStands.getValue().booleanValue() || !(ent instanceof class_1309) && !(ent instanceof class_1690) || !Speed.mc.field_1724.method_5829().method_1014(1.0).method_994(ent.method_5829())) continue;
                ++collisions;
            }
            double[] dArray = MovementUtility.forward(0.08 * (double)collisions);
            Speed.mc.field_1724.method_5762(dArray[0], 0.0, dArray[1]);
        }
    }

    @EventHandler
    public void onTick(EventTick e) {
        if ((this.mode.is(Mode.GrimIce) || this.mode.is(Mode.GrimCombo)) && Speed.mc.field_1724.method_24828()) {
            class_2338 pos = ((IEntity)Speed.mc.field_1724).thunderHack_Recode$getVelocityBP();
            SearchInvResult result = InventoryUtility.findBlockInHotBar(class_2246.field_10295, class_2246.field_10225, class_2246.field_10384);
            if (Speed.mc.field_1687.method_22347(pos) || !result.found() || !Speed.mc.field_1690.field_1903.method_1434()) {
                return;
            }
            this.prevSlot = Speed.mc.field_1724.method_31548().field_7545;
            result.switchTo();
            this.sendPacket((class_2596<?>)new class_2828.class_2830(Speed.mc.field_1724.method_23317(), Speed.mc.field_1724.method_23318(), Speed.mc.field_1724.method_23321(), Speed.mc.field_1724.method_36454(), 90.0f, Speed.mc.field_1724.method_24828()));
            if (this.strict.getValue().booleanValue()) {
                this.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12968, pos, class_2350.field_11036));
                this.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, pos, class_2350.field_11036));
            }
            this.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, pos, class_2350.field_11036));
            this.sendSequencedPacket(id -> new class_2885(class_1268.field_5808, new class_3965(pos.method_10074().method_46558().method_1031(0.0, 0.5, 0.0), class_2350.field_11036, pos.method_10074(), false), id));
            Speed.mc.field_1687.method_8501(pos, class_2246.field_10295.method_9564());
        }
    }

    @EventHandler
    public void onPostTick(EventPostTick e) {
        if ((this.mode.is(Mode.GrimIce) || this.mode.is(Mode.GrimCombo)) && this.prevSlot != -1) {
            Speed.mc.field_1724.method_31548().field_7545 = this.prevSlot;
            ((IInteractionManager)Speed.mc.field_1761).syncSlot();
            this.prevSlot = -1;
        }
    }

    @Override
    public void onUpdate() {
        if (Speed.mc.field_1724.method_52535() && this.pauseInLiquids.getValue().booleanValue() || Speed.mc.field_1724.method_5715() && this.pauseWhileSneaking.getValue().booleanValue()) {
            return;
        }
        if (this.mode.getValue() == Mode.FireWork) {
            int fireInInv;
            --this.ticks;
            int ellySlot = InventoryUtility.getElytra();
            int fireSlot = InventoryUtility.findItemInHotBar(class_1802.field_8639).slot();
            boolean inOffHand = Speed.mc.field_1724.method_6079().method_7909() == class_1802.field_8639;
            boolean bl = inOffHand;
            if (fireSlot == -1 && (fireInInv = InventoryUtility.findItemInInventory(class_1802.field_8639).slot()) != -1) {
                Speed.mc.field_1761.method_2906(Speed.mc.field_1724.field_7512.field_7763, fireInInv, this.fireWorkSlot.getValue() - 1, class_1713.field_7791, (class_1657)Speed.mc.field_1724);
            }
            if (ellySlot != -1 && (fireSlot != -1 || inOffHand) && !Speed.mc.field_1724.method_24828() && Speed.mc.field_1724.field_6017 > 0.0f && this.ticks <= 0) {
                if (ellySlot != -2) {
                    Speed.mc.field_1761.method_2906(0, ellySlot, 1, class_1713.field_7790, (class_1657)Speed.mc.field_1724);
                    Speed.mc.field_1761.method_2906(0, 6, 1, class_1713.field_7790, (class_1657)Speed.mc.field_1724);
                }
                Speed.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)Speed.mc.field_1724, class_2848.class_2849.field_12982));
                int prevSlot = Speed.mc.field_1724.method_31548().field_7545;
                if (prevSlot != fireSlot && !inOffHand) {
                    this.sendPacket((class_2596<?>)new class_2868(fireSlot));
                }
                Speed.mc.field_1761.method_2919((class_1657)Speed.mc.field_1724, inOffHand ? class_1268.field_5810 : class_1268.field_5808);
                if (prevSlot != fireSlot && !inOffHand) {
                    this.sendPacket((class_2596<?>)new class_2868(prevSlot));
                }
                if (ellySlot != -2) {
                    Speed.mc.field_1761.method_2906(0, 6, 1, class_1713.field_7790, (class_1657)Speed.mc.field_1724);
                    Speed.mc.field_1761.method_2906(0, ellySlot, 1, class_1713.field_7790, (class_1657)Speed.mc.field_1724);
                }
                Speed.mc.field_1724.field_3944.method_52787((class_2596)new class_2815(Speed.mc.field_1724.field_7512.field_7763));
                this.ticks = this.delay.getValue();
            }
        }
        if (this.mode.getValue() == Mode.ElytraLowHop) {
            if (Speed.mc.field_1724.method_24828()) {
                Speed.mc.field_1724.method_6043();
                return;
            }
            if (Speed.mc.field_1687.method_20812((class_1297)Speed.mc.field_1724, Speed.mc.field_1724.method_5829().method_1009(-0.29, 0.0, -0.29).method_989(0.0, -3.0, 0.0)).iterator().hasNext() && this.elytraDelay.passedMs(150L) && this.startDelay.passedMs(500L)) {
                int elytra = InventoryUtility.getElytra();
                if (elytra == -1) {
                    this.disable(ClientSettings.isRu() ? "\u0414\u043b\u044f \u044d\u0442\u043e\u0433\u043e \u0440\u0435\u0436\u0438\u043c\u0430 \u043d\u0443\u0436\u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u0430!" : "You need elytra for this mode!");
                } else {
                    Strafe.disabler(elytra);
                }
                Speed.mc.field_1724.method_18800(Speed.mc.field_1724.method_18798().method_10216(), 0.0, Speed.mc.field_1724.method_18798().method_10215());
                if (MovementUtility.isMoving()) {
                    MovementUtility.setMotion(0.85);
                }
                this.elytraDelay.reset();
            }
        }
    }

    @EventHandler
    public void onPostPlayerUpdate(PostPlayerUpdateEvent event) {
        if (this.mode.getValue() == Mode.MatrixDamage && MovementUtility.isMoving() && Speed.mc.field_1724.field_6235 > this.hurttime.getValue()) {
            if (Speed.mc.field_1724.method_24828()) {
                MovementUtility.setMotion(0.387f * this.boostFactor.getValue().floatValue());
            } else if (Speed.mc.field_1724.method_5799()) {
                MovementUtility.setMotion(0.346f * this.boostFactor.getValue().floatValue());
            } else if (!Speed.mc.field_1724.method_24828() && this.allowOffGround.getValue().booleanValue()) {
                MovementUtility.setMotion(0.448f * this.boostFactor.getValue().floatValue());
            }
            if (this.shiftTicks.getValue() > 0) {
                event.cancel();
                event.setIterations(this.shiftTicks.getValue());
            }
        }
    }

    @EventHandler
    public void onMove(EventMove event) {
        if (Speed.mc.field_1724.method_52535() && this.pauseInLiquids.getValue().booleanValue() || Speed.mc.field_1724.method_5715() && this.pauseWhileSneaking.getValue().booleanValue()) {
            return;
        }
        if (this.mode.getValue() != Mode.NCP && this.mode.getValue() != Mode.StrictStrafe) {
            return;
        }
        if (Speed.mc.field_1724.method_31549().field_7479) {
            return;
        }
        if (Speed.mc.field_1724.method_6128()) {
            return;
        }
        if (Speed.mc.field_1724.method_7344().method_7586() <= 6) {
            return;
        }
        if (event.isCancelled()) {
            return;
        }
        event.cancel();
        if (MovementUtility.isMoving()) {
            double amplifier;
            ThunderHack.TICK_TIMER = this.useTimer.getValue() != false ? 1.088f : 1.0f;
            float currentSpeed = this.mode.getValue() == Mode.NCP && Speed.mc.field_1724.field_3913.field_3905 <= 0.0f && this.prevForward > 0.0f ? Managers.PLAYER.currentPlayerSpeed * 0.66f : Managers.PLAYER.currentPlayerSpeed;
            boolean canJump = !Speed.mc.field_1724.field_5976;
            boolean bl = canJump;
            if (this.stage == 1 && Speed.mc.field_1724.method_24828() && canJump) {
                Speed.mc.field_1724.method_18800(Speed.mc.field_1724.method_18798().field_1352, MovementUtility.getJumpSpeed(), Speed.mc.field_1724.method_18798().field_1350);
                event.setY(MovementUtility.getJumpSpeed());
                this.baseSpeed *= 2.149;
                this.stage = 2;
            } else if (this.stage == 2) {
                this.baseSpeed = (double)currentSpeed - 0.66 * ((double)currentSpeed - MovementUtility.getBaseMoveSpeed());
                this.stage = 3;
            } else {
                if (Speed.mc.field_1687.method_20812((class_1297)Speed.mc.field_1724, Speed.mc.field_1724.method_5829().method_989(0.0, Speed.mc.field_1724.method_18798().method_10214(), 0.0)).iterator().hasNext() || Speed.mc.field_1724.field_5992) {
                    this.stage = 1;
                }
                this.baseSpeed = (double)currentSpeed - (double)currentSpeed / 159.0;
            }
            this.baseSpeed = Math.max(this.baseSpeed, MovementUtility.getBaseMoveSpeed());
            double ncpSpeed = this.mode.getValue() == Mode.StrictStrafe || Speed.mc.field_1724.field_3913.field_3905 < 1.0f ? 0.465 : 0.576;
            double ncpBypassSpeed = this.mode.getValue() == Mode.StrictStrafe || Speed.mc.field_1724.field_3913.field_3905 < 1.0f ? 0.44 : 0.57;
            double d = ncpBypassSpeed;
            if (Speed.mc.field_1724.method_6059(class_1294.field_5904)) {
                amplifier = Speed.mc.field_1724.method_6112(class_1294.field_5904).method_5578();
                ncpSpeed *= 1.0 + 0.2 * (amplifier + 1.0);
                ncpBypassSpeed *= 1.0 + 0.2 * (amplifier + 1.0);
            }
            if (Speed.mc.field_1724.method_6059(class_1294.field_5909)) {
                amplifier = Speed.mc.field_1724.method_6112(class_1294.field_5909).method_5578();
                ncpSpeed /= 1.0 + 0.2 * (amplifier + 1.0);
                ncpBypassSpeed /= 1.0 + 0.2 * (amplifier + 1.0);
            }
            this.baseSpeed = Math.min(this.baseSpeed, this.ticks > 25 ? ncpSpeed : ncpBypassSpeed);
            if (this.ticks++ > 50) {
                this.ticks = 0;
            }
            MovementUtility.modifyEventSpeed(event, this.baseSpeed);
            this.prevForward = Speed.mc.field_1724.field_3913.field_3905;
        } else {
            ThunderHack.TICK_TIMER = 1.0f;
            event.setX(0.0);
            event.setZ(0.0);
        }
    }

    public static enum Mode {
        StrictStrafe,
        MatrixJB,
        NCP,
        ElytraLowHop,
        MatrixDamage,
        GrimEntity,
        GrimEntity2,
        FireWork,
        Vanilla,
        GrimIce,
        GrimCombo;

    }
}

