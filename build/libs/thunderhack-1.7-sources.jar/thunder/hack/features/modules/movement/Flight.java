/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$Full
 *  net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket
 *  net.minecraft.util.Formatting
 */
package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.MovementUtility;

public class Flight
extends Module {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Vanilla);
    private final Setting<Float> hSpeed = new Setting<Float>("Horizontal", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(10.0f), v -> !this.mode.is(Mode.StormBreak));
    private final Setting<Float> vSpeed = new Setting<Float>("Vertical", Float.valueOf(0.78f), Float.valueOf(0.0f), Float.valueOf(5.0f), v -> !this.mode.is(Mode.StormBreak));
    private final Setting<Float> boostValue = new Setting<Float>("Boost", Float.valueOf(1.0f), Float.valueOf(0.1f), Float.valueOf(1.0f), v -> this.mode.is(Mode.StormBreak));
    private final Setting<Boolean> autoToggle = new Setting<Boolean>("AutoToggle", false, v -> this.mode.is(Mode.MatrixJump));
    private final Setting<Integer> boostTicks = new Setting<Integer>("Ticks", 8, 0, 40, v -> this.mode.is(Mode.Damage));
    private final Setting<Boolean> antiKick = new Setting<Boolean>("AntiKick", false, v -> this.mode.is(Mode.Creative) || this.mode.is(Mode.Vanilla));
    private double prevX;
    private double prevY;
    private double prevZ;
    private double velocityMotion;
    public boolean onPosLook = false;
    private int flyTicks = 0;

    public Flight() {
        super("Flight", Module.Category.MOVEMENT);
    }

    @EventHandler
    public void onEventSync(EventSync event) {
        switch (this.mode.getValue().ordinal()) {
            case 0: {
                if (MovementUtility.isMoving()) {
                    double[] dir = MovementUtility.forward(this.hSpeed.getValue().floatValue());
                    Flight.mc.field_1724.method_18800(dir[0], 0.0, dir[1]);
                } else {
                    Flight.mc.field_1724.method_18800(0.0, 0.0, 0.0);
                }
                if (Flight.mc.field_1690.field_1903.method_1434()) {
                    Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, (double)this.vSpeed.getValue().floatValue(), 0.0));
                }
                if (!Flight.mc.field_1690.field_1832.method_1434()) break;
                Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, (double)(-this.vSpeed.getValue().floatValue()), 0.0));
                break;
            }
            case 2: {
                if (!MovementUtility.isMoving() || !Flight.mc.field_1687.method_20812((class_1297)Flight.mc.field_1724, Flight.mc.field_1724.method_5829().method_1009(0.5, 0.0, 0.5).method_989(0.0, -1.0, 0.0)).iterator().hasNext()) break;
                Flight.mc.field_1724.method_24830(true);
                Flight.mc.field_1724.method_6043();
                break;
            }
            case 3: {
                if (Flight.mc.field_1724.method_24828()) {
                    Flight.mc.field_1724.method_6043();
                    this.flyTicks = 5;
                    break;
                }
                if (this.flyTicks <= 0) break;
                if (MovementUtility.isMoving()) {
                    double[] dir = MovementUtility.forward(this.hSpeed.getValue().floatValue());
                    Flight.mc.field_1724.method_18800(dir[0], -0.04, dir[1]);
                } else {
                    Flight.mc.field_1724.method_18800(0.0, -0.04, 0.0);
                }
                --this.flyTicks;
                break;
            }
            case 4: {
                if (Flight.mc.field_1724.field_6012 % 60 != 0) break;
                this.sendMessage(String.valueOf(class_124.field_1061) + (ClientSettings.isRu() ? "\u0412 \u044d\u0442\u043e\u043c \u0440\u0435\u0436\u0438\u043c\u0435 \u043d\u0443\u0436\u043d\u043e \u043b\u043e\u043c\u0430\u0442\u044c \u0431\u043b\u043e\u043a\u0438!" : "In this mode you need to break blocks!"));
            }
        }
        if (this.antiKick.getValue().booleanValue() && (this.mode.is(Mode.Creative) || this.mode.is(Mode.Vanilla))) {
            Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, -0.08, 0.0));
        }
    }

    @Override
    public void onUpdate() {
        if (this.mode.is(Mode.Damage) && this.flyTicks-- > this.boostTicks.getValue()) {
            Flight.mc.field_1724.method_18800(Flight.mc.field_1724.method_18798().field_1352, this.velocityMotion, Flight.mc.field_1724.method_18798().method_10215());
        }
        if (this.mode.is(Mode.MatrixJump)) {
            if (Flight.mc.field_1724.field_6017 == 0.0f) {
                return;
            }
            Flight.mc.field_1724.method_31549().field_7479 = false;
            Flight.mc.field_1724.method_18800(0.0, 0.0, 0.0);
            if (Flight.mc.field_1690.field_1903.method_1434()) {
                Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, (double)this.vSpeed.getValue().floatValue(), 0.0));
            }
            if (Flight.mc.field_1690.field_1832.method_1434()) {
                Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, (double)(-this.vSpeed.getValue().floatValue()), 0.0));
            }
            double[] dir = MovementUtility.forward(this.hSpeed.getValue().floatValue());
            Flight.mc.field_1724.method_18800(dir[0], Flight.mc.field_1724.method_18798().method_10214(), dir[1]);
        }
        if (this.mode.is(Mode.Creative)) {
            Flight.mc.field_1724.method_31549().field_7479 = true;
            Flight.mc.field_1724.method_31549().method_7248(this.hSpeed.getValue().floatValue() / 10.0f);
        }
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        Object t;
        if (this.mode.is(Mode.MatrixJump)) {
            if (Flight.fullNullCheck()) {
                return;
            }
            if (e.getPacket() instanceof class_2708) {
                this.onPosLook = true;
                this.prevX = Flight.mc.field_1724.method_18798().method_10216();
                this.prevY = Flight.mc.field_1724.method_18798().method_10214();
                this.prevZ = Flight.mc.field_1724.method_18798().method_10215();
            }
        }
        if (this.mode.is(Mode.Damage) && (t = e.getPacket()) instanceof class_2743) {
            class_2743 v = (class_2743)t;
            if (v.method_11816() / 8000.0 > 0.2) {
                this.velocityMotion = v.method_11816() / 8000.0;
                this.flyTicks = this.boostTicks.getValue();
            }
        }
    }

    @EventHandler
    public void onPacketSend(PacketEvent.Send e) {
        class_2846 pac;
        Object t;
        if (this.mode.is(Mode.MatrixJump) && e.getPacket() instanceof class_2828.class_2830 && this.onPosLook) {
            Flight.mc.field_1724.method_18800(this.prevX, this.prevY, this.prevZ);
            this.onPosLook = false;
            if (this.autoToggle.getValue().booleanValue()) {
                this.disable();
            }
        }
        if (this.mode.is(Mode.StormBreak) && (t = e.getPacket()) instanceof class_2846 && ((pac = (class_2846)t).method_12363() == class_2846.class_2847.field_12973 || pac.method_12363() == class_2846.class_2847.field_12968 && Flight.mc.field_1687.method_8320(pac.method_12362()).method_45474())) {
            double[] dir = MovementUtility.forward(2.0f * this.boostValue.getValue().floatValue());
            Flight.mc.field_1724.method_18800(dir[0], (double)(3.0f * this.boostValue.getValue().floatValue()), dir[1]);
        }
    }

    @Override
    public void onDisable() {
        Flight.mc.field_1724.method_31549().field_7479 = false;
        Flight.mc.field_1724.method_31549().method_7248(0.05f);
    }

    private static enum Mode {
        Vanilla,
        MatrixJump,
        AirJump,
        MatrixGlide,
        StormBreak,
        Damage,
        Creative;

    }
}

