/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.entity.projectile.FishingBobberEntity
 *  net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket
 *  net.minecraft.world.World
 */
package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1536;
import net.minecraft.class_1937;
import net.minecraft.class_2663;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class NoPush
extends Module {
    public Setting<Boolean> blocks = new Setting<Boolean>("Blocks", true);
    public Setting<Boolean> players = new Setting<Boolean>("Players", true);
    public Setting<Boolean> water = new Setting<Boolean>("Liquids", true);
    public Setting<Boolean> fishingHook = new Setting<Boolean>("FishingHook", true);

    public NoPush() {
        super("NoPush", Module.Category.MOVEMENT);
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        class_2663 pac;
        Object object = e.getPacket();
        if (object instanceof class_2663 && (pac = (class_2663)object).method_11470() == 31 && (object = pac.method_11469((class_1937)NoPush.mc.field_1687)) instanceof class_1536) {
            class_1536 hook = (class_1536)object;
            if (this.fishingHook.getValue().booleanValue() && hook.method_26957() == NoPush.mc.field_1724) {
                e.cancel();
            }
        }
    }
}

