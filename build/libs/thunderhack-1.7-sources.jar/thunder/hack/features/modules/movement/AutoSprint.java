/*
 * Decompiled with CFR 0.152.
 */
package thunder.hack.features.modules.movement;

import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.setting.Setting;

public class AutoSprint
extends Module {
    public static final Setting<Boolean> sprint = new Setting<Boolean>("KeepSprint", true);
    public static final Setting<Float> motion = new Setting<Float>("Motion", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(1.0f), v -> sprint.getValue());
    private final Setting<Boolean> stopWhileUsing = new Setting<Boolean>("StopWhileUsing", false);
    private final Setting<Boolean> pauseWhileAura = new Setting<Boolean>("PauseWhileAura", false);

    public AutoSprint() {
        super("AutoSprint", Module.Category.MOVEMENT);
    }

    @Override
    public void onUpdate() {
        AutoSprint.mc.field_1724.method_5728(!(AutoSprint.mc.field_1724.method_7344().method_7586() <= 6 || AutoSprint.mc.field_1724.field_5976 || !(AutoSprint.mc.field_1724.field_3913.field_3905 > 0.0f) || AutoSprint.mc.field_1724.method_5715() || AutoSprint.mc.field_1724.method_6115() && this.stopWhileUsing.getValue() != false || ModuleManager.aura.isEnabled() && Aura.target != null && this.pauseWhileAura.getValue() != false));
    }
}

