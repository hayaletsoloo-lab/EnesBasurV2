/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket
 *  net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
 *  net.minecraft.util.Hand
 *  net.minecraft.util.math.Direction
 */
package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2350;
import net.minecraft.class_2596;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_9334;
import thunder.hack.events.impl.EventKeyboardInput;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.SettingGroup;

public class NoSlow
extends Module {
    public final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.NCP);
    private final Setting<Boolean> mainHand = new Setting<Boolean>("MainHand", true);
    private final Setting<SettingGroup> selection = new Setting<SettingGroup>("Selection", new SettingGroup(false, 0));
    private final Setting<Boolean> food = new Setting<Boolean>("Food", true).addToGroup(this.selection);
    private final Setting<Boolean> projectiles = new Setting<Boolean>("Projectiles", true).addToGroup(this.selection);
    private final Setting<Boolean> shield = new Setting<Boolean>("Shield", true).addToGroup(this.selection);
    public final Setting<Boolean> soulSand = new Setting<Boolean>("SoulSand", true).addToGroup(this.selection);
    public final Setting<Boolean> honey = new Setting<Boolean>("Honey", true).addToGroup(this.selection);
    public final Setting<Boolean> slime = new Setting<Boolean>("Slime", true).addToGroup(this.selection);
    public final Setting<Boolean> ice = new Setting<Boolean>("Ice", true).addToGroup(this.selection);
    public final Setting<Boolean> sweetBerryBush = new Setting<Boolean>("SweetBerryBush", true).addToGroup(this.selection);
    public final Setting<Boolean> sneak = new Setting<Boolean>("Sneak", false).addToGroup(this.selection);
    public final Setting<Boolean> crawl = new Setting<Boolean>("Crawl", false).addToGroup(this.selection);
    private boolean returnSneak;

    public NoSlow() {
        super("NoSlow", Module.Category.MOVEMENT);
    }

    @Override
    public void onUpdate() {
        if (this.returnSneak) {
            NoSlow.mc.field_1690.field_1832.method_23481(false);
            NoSlow.mc.field_1724.method_5728(true);
            this.returnSneak = false;
        }
        if (NoSlow.mc.field_1724.method_6115() && !NoSlow.mc.field_1724.method_3144() && !NoSlow.mc.field_1724.method_6128()) {
            switch (this.mode.getValue().ordinal()) {
                case 1: {
                    this.sendPacket((class_2596<?>)new class_2868(NoSlow.mc.field_1724.method_31548().field_7545));
                    break;
                }
                case 4: {
                    if (!NoSlow.mc.field_1724.method_24828() || !NoSlow.mc.field_1690.field_1903.method_1434()) break;
                    NoSlow.mc.field_1690.field_1832.method_23481(true);
                    this.returnSneak = true;
                    break;
                }
                case 3: {
                    if (NoSlow.mc.field_1724.method_6058() == class_1268.field_5810) {
                        this.sendPacket((class_2596<?>)new class_2868(NoSlow.mc.field_1724.method_31548().field_7545 % 8 + 1));
                        this.sendPacket((class_2596<?>)new class_2868(NoSlow.mc.field_1724.method_31548().field_7545 % 7 + 2));
                        this.sendPacket((class_2596<?>)new class_2868(NoSlow.mc.field_1724.method_31548().field_7545));
                        break;
                    }
                    if (!this.mainHand.getValue().booleanValue()) break;
                    this.sendSequencedPacket(id -> new class_2886(class_1268.field_5810, id, NoSlow.mc.field_1724.method_36454(), NoSlow.mc.field_1724.method_36455()));
                    break;
                }
                case 2: {
                    if (NoSlow.mc.field_1724.method_24828() && !NoSlow.mc.field_1690.field_1903.method_1434()) {
                        NoSlow.mc.field_1724.method_18800(NoSlow.mc.field_1724.method_18798().field_1352 * 0.3, NoSlow.mc.field_1724.method_18798().field_1351, NoSlow.mc.field_1724.method_18798().field_1350 * 0.3);
                        break;
                    }
                    if (!(NoSlow.mc.field_1724.field_6017 > 0.2f)) break;
                    NoSlow.mc.field_1724.method_18800(NoSlow.mc.field_1724.method_18798().field_1352 * (double)0.95f, NoSlow.mc.field_1724.method_18798().field_1351, NoSlow.mc.field_1724.method_18798().field_1350 * (double)0.95f);
                    break;
                }
                case 5: {
                    if (NoSlow.mc.field_1724.method_6058() == class_1268.field_5810) {
                        this.sendPacket((class_2596<?>)new class_2868(NoSlow.mc.field_1724.method_31548().field_7545 % 8 + 1));
                        this.sendPacket((class_2596<?>)new class_2868(NoSlow.mc.field_1724.method_31548().field_7545 % 7 + 2));
                        this.sendPacket((class_2596<?>)new class_2868(NoSlow.mc.field_1724.method_31548().field_7545));
                        break;
                    }
                    if (!this.mainHand.getValue().booleanValue() || NoSlow.mc.field_1724.method_6048() > 3 && NoSlow.mc.field_1724.field_6012 % 2 != 0) break;
                    this.sendSequencedPacket(id -> new class_2886(class_1268.field_5810, id, NoSlow.mc.field_1724.method_36454(), NoSlow.mc.field_1724.method_36455()));
                    break;
                }
                case 6: {
                    if (!NoSlow.mc.field_1724.method_24828()) break;
                    if (NoSlow.mc.field_1724.field_6012 % 2 == 0) {
                        NoSlow.mc.field_1724.method_18800(NoSlow.mc.field_1724.method_18798().field_1352 * 0.5, NoSlow.mc.field_1724.method_18798().field_1351, NoSlow.mc.field_1724.method_18798().field_1350 * 0.5);
                        break;
                    }
                    NoSlow.mc.field_1724.method_18800(NoSlow.mc.field_1724.method_18798().field_1352 * (double)0.95f, NoSlow.mc.field_1724.method_18798().field_1351, NoSlow.mc.field_1724.method_18798().field_1350 * (double)0.95f);
                    break;
                }
                case 7: {
                    if (NoSlow.mc.field_1724.method_6048() > 3) break;
                    this.sendSequencedPacket(id -> new class_2846(class_2846.class_2847.field_12971, NoSlow.mc.field_1724.method_24515().method_10084(), class_2350.field_11043, id));
                }
            }
        }
    }

    @EventHandler
    public void onKeyboardInput(EventKeyboardInput e) {
        if (this.mode.getValue() == Mode.Matrix3 && NoSlow.mc.field_1724.method_6115() && !NoSlow.mc.field_1724.method_6128()) {
            NoSlow.mc.field_1724.field_3913.field_3905 *= 5.0f;
            NoSlow.mc.field_1724.field_3913.field_3907 *= 5.0f;
            float mult = 1.0f;
            if (NoSlow.mc.field_1724.method_24828()) {
                if (NoSlow.mc.field_1724.field_3913.field_3905 != 0.0f && NoSlow.mc.field_1724.field_3913.field_3907 != 0.0f) {
                    NoSlow.mc.field_1724.field_3913.field_3905 *= 0.35f;
                    NoSlow.mc.field_1724.field_3913.field_3907 *= 0.35f;
                } else {
                    NoSlow.mc.field_1724.field_3913.field_3905 *= 0.5f;
                    NoSlow.mc.field_1724.field_3913.field_3907 *= 0.5f;
                }
            } else {
                mult = NoSlow.mc.field_1724.field_3913.field_3905 != 0.0f && NoSlow.mc.field_1724.field_3913.field_3907 != 0.0f ? 0.47f : 0.67f;
            }
            NoSlow.mc.field_1724.field_3913.field_3905 *= mult;
            NoSlow.mc.field_1724.field_3913.field_3907 *= mult;
        }
    }

    public boolean canNoSlow() {
        if (this.mode.getValue() == Mode.Matrix3) {
            return false;
        }
        if (!this.food.getValue().booleanValue() && NoSlow.mc.field_1724.method_6030().method_57353().method_57832(class_9334.field_50075)) {
            return false;
        }
        if (!this.shield.getValue().booleanValue() && NoSlow.mc.field_1724.method_6030().method_7909() == class_1802.field_8255) {
            return false;
        }
        if (!(this.projectiles.getValue().booleanValue() || NoSlow.mc.field_1724.method_6030().method_7909() != class_1802.field_8399 && NoSlow.mc.field_1724.method_6030().method_7909() != class_1802.field_8102 && NoSlow.mc.field_1724.method_6030().method_7909() != class_1802.field_8547)) {
            return false;
        }
        if (this.mode.getValue() == Mode.MusteryGrief && NoSlow.mc.field_1724.method_24828() && !NoSlow.mc.field_1690.field_1903.method_1434()) {
            return false;
        }
        if (!this.mainHand.getValue().booleanValue() && NoSlow.mc.field_1724.method_6058() == class_1268.field_5808) {
            return false;
        }
        return !NoSlow.mc.field_1724.method_6079().method_57353().method_57832(class_9334.field_50075) && NoSlow.mc.field_1724.method_6079().method_7909() != class_1802.field_8255 || this.mode.getValue() != Mode.GrimNew && this.mode.getValue() != Mode.Grim || NoSlow.mc.field_1724.method_6058() != class_1268.field_5808;
    }

    public static enum Mode {
        NCP,
        StrictNCP,
        Matrix,
        Grim,
        MusteryGrief,
        GrimNew,
        Matrix2,
        LFCraft,
        Matrix3;

    }
}

