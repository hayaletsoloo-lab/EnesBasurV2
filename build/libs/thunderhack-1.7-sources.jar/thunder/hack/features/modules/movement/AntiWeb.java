/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.block.Blocks
 *  net.minecraft.block.CobwebBlock
 */
package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2560;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventCollision;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.MovementUtility;

public class AntiWeb
extends Module {
    public static final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Solid);
    public static final Setting<Boolean> grim = new Setting<Boolean>("Grim", false, v -> mode.is(Mode.Ignore));
    public static final Setting<Float> timer = new Setting<Float>("Timer", Float.valueOf(20.0f), Float.valueOf(1.0f), Float.valueOf(50.0f), v -> mode.getValue() == Mode.Timer);
    public Setting<Float> speed = new Setting<Float>("Speed", Float.valueOf(0.3f), Float.valueOf(0.0f), Float.valueOf(10.0f), v -> mode.getValue() == Mode.Fly);
    private boolean timerEnabled = false;

    public AntiWeb() {
        super("AntiWeb", Module.Category.MOVEMENT);
    }

    @EventHandler
    public void onPlayerUpdate(PlayerUpdateEvent e) {
        if (Managers.PLAYER.isInWeb()) {
            if (mode.getValue() == Mode.Timer) {
                if (AntiWeb.mc.field_1724.method_24828()) {
                    ThunderHack.TICK_TIMER = 1.0f;
                } else {
                    ThunderHack.TICK_TIMER = timer.getValue().floatValue();
                    this.timerEnabled = true;
                }
            }
            if (mode.getValue() == Mode.Fly) {
                double[] dir = MovementUtility.forward(this.speed.getValue().floatValue());
                AntiWeb.mc.field_1724.method_18800(dir[0], 0.0, dir[1]);
                if (AntiWeb.mc.field_1690.field_1903.method_1434()) {
                    AntiWeb.mc.field_1724.method_18799(AntiWeb.mc.field_1724.method_18798().method_1031(0.0, (double)this.speed.getValue().floatValue(), 0.0));
                }
                if (AntiWeb.mc.field_1690.field_1832.method_1434()) {
                    AntiWeb.mc.field_1724.method_18799(AntiWeb.mc.field_1724.method_18798().method_1031(0.0, (double)(-this.speed.getValue().floatValue()), 0.0));
                }
            }
        } else if (this.timerEnabled) {
            this.timerEnabled = false;
            ThunderHack.TICK_TIMER = 1.0f;
        }
    }

    @EventHandler
    public void onCollide(EventCollision e) {
        if (e.getState().method_26204() instanceof class_2560 && mode.getValue() == Mode.Solid) {
            e.setState(class_2246.field_10566.method_9564());
        }
    }

    public static enum Mode {
        Timer,
        Solid,
        Ignore,
        Fly;

    }
}

