/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.client.option.KeyBinding
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$PositionAndOnGround
 *  net.minecraft.screen.slot.SlotActionType
 */
package thunder.hack.features.modules.movement;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicBoolean;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1713;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import thunder.hack.events.impl.EventClickSlot;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.MovementUtility;

public class GuiMove
extends Module {
    private final Setting<Bypass> clickBypass = new Setting<Bypass>("Bypass", Bypass.None);
    private final Setting<Boolean> rotateOnArrows = new Setting<Boolean>("RotateOnArrows", true);
    private final Setting<Boolean> sneak = new Setting<Boolean>("sneak", false);
    private final Queue<class_2813> storedClicks = new LinkedList<class_2813>();
    private AtomicBoolean pause = new AtomicBoolean();

    public GuiMove() {
        super("GuiMove", Module.Category.MOVEMENT);
    }

    @Override
    public void onUpdate() {
        if (GuiMove.mc.field_1755 != null && !(GuiMove.mc.field_1755 instanceof class_408)) {
            for (class_304 k : new class_304[]{GuiMove.mc.field_1690.field_1894, GuiMove.mc.field_1690.field_1881, GuiMove.mc.field_1690.field_1913, GuiMove.mc.field_1690.field_1849, GuiMove.mc.field_1690.field_1903, GuiMove.mc.field_1690.field_1867}) {
                k.method_23481(this.isKeyPressed(class_3675.method_15981((String)k.method_1428()).method_1444()));
            }
            float deltaX = 0.0f;
            float deltaY = 0.0f;
            if (this.rotateOnArrows.getValue().booleanValue()) {
                if (this.isKeyPressed(264)) {
                    deltaY += 30.0f;
                }
                if (this.isKeyPressed(265)) {
                    deltaY -= 30.0f;
                }
                if (this.isKeyPressed(262)) {
                    deltaX += 30.0f;
                }
                if (this.isKeyPressed(263)) {
                    deltaX -= 30.0f;
                }
                if (deltaX != 0.0f || deltaY != 0.0f) {
                    GuiMove.mc.field_1724.method_5872((double)deltaX, (double)deltaY);
                }
            }
            if (this.sneak.getValue().booleanValue()) {
                GuiMove.mc.field_1690.field_1832.method_23481(this.isKeyPressed(class_3675.method_15981((String)GuiMove.mc.field_1690.field_1832.method_1428()).method_1444()));
            }
        }
    }

    @EventHandler
    public void onClickSlot(EventClickSlot e) {
        if (this.clickBypass.is(Bypass.DisableClicks) && (MovementUtility.isMoving() || GuiMove.mc.field_1690.field_1903.method_1434())) {
            e.cancel();
        }
    }

    @EventHandler
    public void onPacketSend(PacketEvent.Send e) {
        if (!MovementUtility.isMoving() || !GuiMove.mc.field_1690.field_1903.method_1434() || this.pause.get()) {
            return;
        }
        Object t = e.getPacket();
        if (t instanceof class_2813) {
            class_2813 click = (class_2813)t;
            switch (this.clickBypass.getValue().ordinal()) {
                case 3: {
                    if (click.method_12195() == class_1713.field_7790 || click.method_12195() == class_1713.field_7793) break;
                    this.sendPacket((class_2596<?>)new class_2815(0));
                    break;
                }
                case 2: {
                    if (!GuiMove.mc.field_1724.method_24828() || GuiMove.mc.field_1687.method_20812((class_1297)GuiMove.mc.field_1724, GuiMove.mc.field_1724.method_5829().method_989(0.0, 0.0656, 0.0)).iterator().hasNext()) break;
                    if (GuiMove.mc.field_1724.method_5624()) {
                        this.sendPacket((class_2596<?>)new class_2848((class_1297)GuiMove.mc.field_1724, class_2848.class_2849.field_12985));
                    }
                    this.sendPacket((class_2596<?>)new class_2828.class_2829(GuiMove.mc.field_1724.method_23317(), GuiMove.mc.field_1724.method_23318() + 0.0656, GuiMove.mc.field_1724.method_23321(), false));
                    break;
                }
                case 6: {
                    if (!GuiMove.mc.field_1724.method_24828() || GuiMove.mc.field_1687.method_20812((class_1297)GuiMove.mc.field_1724, GuiMove.mc.field_1724.method_5829().method_989(0.0, 2.71875E-7, 0.0)).iterator().hasNext()) break;
                    if (GuiMove.mc.field_1724.method_5624()) {
                        this.sendPacket((class_2596<?>)new class_2848((class_1297)GuiMove.mc.field_1724, class_2848.class_2849.field_12985));
                    }
                    this.sendPacket((class_2596<?>)new class_2828.class_2829(GuiMove.mc.field_1724.method_23317(), GuiMove.mc.field_1724.method_23318() + 2.71875E-7, GuiMove.mc.field_1724.method_23321(), false));
                    break;
                }
                case 4: {
                    this.sendPacket((class_2596<?>)new class_2848((class_1297)GuiMove.mc.field_1724, class_2848.class_2849.field_12985));
                    GuiMove.mc.field_1690.field_1894.method_23481(false);
                    GuiMove.mc.field_1724.field_3913.field_3905 = 0.0f;
                    GuiMove.mc.field_1724.field_3913.field_3910 = false;
                    break;
                }
                case 5: {
                    this.storedClicks.add(click);
                    e.cancel();
                }
            }
        }
        if (e.getPacket() instanceof class_2815 && this.clickBypass.is(Bypass.Delay)) {
            this.pause.set(true);
            while (!this.storedClicks.isEmpty()) {
                this.sendPacket((class_2596)(Object)this.storedClicks.poll());
            }
            this.pause.set(false);
        }
    }

    @EventHandler
    public void onPacketSendPost(PacketEvent.SendPost e) {
        if (e.getPacket() instanceof class_2813 && GuiMove.mc.field_1724.method_5624() && this.clickBypass.is(Bypass.StrictNCP)) {
            this.sendPacket((class_2596<?>)new class_2848((class_1297)GuiMove.mc.field_1724, class_2848.class_2849.field_12981));
        }
    }

    private static enum Bypass {
        DisableClicks,
        None,
        StrictNCP,
        GrimSwap,
        MatrixNcp,
        Delay,
        StrictNCP2;

    }
}

