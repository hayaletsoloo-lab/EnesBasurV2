/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$Full
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$PositionAndOnGround
 *  net.minecraft.network.packet.s2c.common.CommonPingS2CPacket
 *  net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket
 *  net.minecraft.network.packet.s2c.play.ExplosionS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.Position
 */
package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_6373;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.injection.accesors.IClientPlayerEntity;
import thunder.hack.injection.accesors.IExplosionS2CPacket;
import thunder.hack.injection.accesors.ISPacketEntityVelocity;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.MovementUtility;

public class Velocity
extends Module {
    public Setting<Boolean> onlyAura = new Setting<Boolean>("OnlyDuringAura", false);
    public Setting<Boolean> pauseInWater = new Setting<Boolean>("PauseInLiquids", false);
    public Setting<Boolean> explosions = new Setting<Boolean>("Explosions", true);
    public Setting<Boolean> cc = new Setting<Boolean>("PauseOnFlag", false);
    public Setting<Boolean> fire = new Setting<Boolean>("PauseOnFire", false);
    private final Setting<modeEn> mode = new Setting<modeEn>("Mode", modeEn.Matrix);
    public Setting<Float> vertical = new Setting<Float>("Vertical", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(100.0f), v -> this.mode.getValue() == modeEn.Custom);
    private final Setting<jumpModeEn> jumpMode = new Setting<jumpModeEn>("JumpMode", jumpModeEn.Jump, v -> this.mode.getValue() == modeEn.Jump);
    public Setting<Float> horizontal = new Setting<Float>("Horizontal", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(100.0f), v -> this.mode.getValue() == modeEn.Custom || this.mode.getValue() == modeEn.Jump);
    public Setting<Float> motion = new Setting<Float>("Motion", Float.valueOf(0.42f), Float.valueOf(0.4f), Float.valueOf(0.5f), v -> this.mode.getValue() == modeEn.Jump);
    public Setting<Boolean> fail = new Setting<Boolean>("SmartFail", true, v -> this.mode.getValue() == modeEn.Jump);
    public Setting<Float> failRate = new Setting<Float>("FailRate", Float.valueOf(0.3f), Float.valueOf(0.0f), Float.valueOf(1.0f), v -> this.mode.getValue() == modeEn.Jump && this.fail.getValue() != false);
    public Setting<Float> jumpRate = new Setting<Float>("FailJumpRate", Float.valueOf(0.25f), Float.valueOf(0.0f), Float.valueOf(1.0f), v -> this.mode.getValue() == modeEn.Jump && this.fail.getValue() != false);
    private boolean doJump;
    private boolean failJump;
    private boolean skip;
    private boolean flag;
    private int grimTicks;
    private int ccCooldown;

    public Velocity() {
        super("Velocity", Module.Category.MOVEMENT);
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        class_2743 pac;
        if (Velocity.fullNullCheck()) {
            return;
        }
        if (Velocity.mc.field_1724 != null && (Velocity.mc.field_1724.method_5799() || Velocity.mc.field_1724.method_5869() || Velocity.mc.field_1724.method_5771()) && this.pauseInWater.getValue().booleanValue()) {
            return;
        }
        if (Velocity.mc.field_1724 != null && Velocity.mc.field_1724.method_5809() && this.fire.getValue().booleanValue() && Velocity.mc.field_1724.field_6235 > 0) {
            return;
        }
        if (this.ccCooldown > 0) {
            --this.ccCooldown;
            return;
        }
        Object t = e.getPacket();
        if (t instanceof class_2743 && (pac = (class_2743)t).method_11818() == Velocity.mc.field_1724.method_5628() && (!this.onlyAura.getValue().booleanValue() || ModuleManager.aura.isEnabled())) {
            switch (this.mode.getValue().ordinal()) {
                case 0: {
                    if (!this.flag) {
                        e.cancel();
                        this.flag = true;
                        break;
                    }
                    this.flag = false;
                    ((ISPacketEntityVelocity)pac).setMotionX((int)(pac.method_11815() * -0.1));
                    ((ISPacketEntityVelocity)pac).setMotionZ((int)(pac.method_11819() * -0.1));
                    break;
                }
                case 4: {
                    double vX = Math.abs(pac.method_11815());
                    double vZ = Math.abs(pac.method_11819());
                    double[] motion = MovementUtility.forward(vX + vZ);
                    ((ISPacketEntityVelocity)pac).setMotionX((int)motion[0]);
                    ((ISPacketEntityVelocity)pac).setMotionY(0);
                    ((ISPacketEntityVelocity)pac).setMotionZ((int)motion[1]);
                    break;
                }
                case 3: {
                    ((ISPacketEntityVelocity)pac).setMotionX((int)((float)pac.method_11815() * this.horizontal.getValue().floatValue() / 100.0f));
                    ((ISPacketEntityVelocity)pac).setMotionY((int)((float)pac.method_11816() * this.vertical.getValue().floatValue() / 100.0f));
                    ((ISPacketEntityVelocity)pac).setMotionZ((int)((float)pac.method_11819() * this.horizontal.getValue().floatValue() / 100.0f));
                    break;
                }
                case 2: {
                    e.cancel();
                    this.sendPacket((class_2596<?>)new class_2828.class_2829(Velocity.mc.field_1724.method_23317(), -999.0, Velocity.mc.field_1724.method_23321(), true));
                    break;
                }
                case 1: {
                    e.cancel();
                    break;
                }
                case 6: {
                    ((ISPacketEntityVelocity)pac).setMotionX((int)((float)pac.method_11815() * this.horizontal.getValue().floatValue() / 100.0f));
                    ((ISPacketEntityVelocity)pac).setMotionZ((int)((float)pac.method_11819() * this.horizontal.getValue().floatValue() / 100.0f));
                    break;
                }
                case 5: {
                    e.cancel();
                    this.grimTicks = 6;
                    break;
                }
                case 7: {
                    e.cancel();
                    this.flag = true;
                }
            }
        }
        if ((t = e.getPacket()) instanceof class_2664) {
            class_2664 explosion = (class_2664)t;
            if (this.explosions.getValue().booleanValue()) {
                switch (this.mode.getValue().ordinal()) {
                    case 1: {
                        ((IExplosionS2CPacket)explosion).setMotionX(0.0f);
                        ((IExplosionS2CPacket)explosion).setMotionY(0.0f);
                        ((IExplosionS2CPacket)explosion).setMotionZ(0.0f);
                        break;
                    }
                    case 3: {
                        ((IExplosionS2CPacket)explosion).setMotionX(((IExplosionS2CPacket)explosion).getMotionX() * this.horizontal.getValue().floatValue() / 100.0f);
                        ((IExplosionS2CPacket)explosion).setMotionZ(((IExplosionS2CPacket)explosion).getMotionZ() * this.horizontal.getValue().floatValue() / 100.0f);
                        ((IExplosionS2CPacket)explosion).setMotionY(((IExplosionS2CPacket)explosion).getMotionY() * this.vertical.getValue().floatValue() / 100.0f);
                        break;
                    }
                    case 7: {
                        ((IExplosionS2CPacket)explosion).setMotionX(0.0f);
                        ((IExplosionS2CPacket)explosion).setMotionY(0.0f);
                        ((IExplosionS2CPacket)explosion).setMotionZ(0.0f);
                        this.flag = true;
                    }
                }
            }
        }
        if (this.mode.getValue() == modeEn.OldGrim && e.getPacket() instanceof class_6373 && this.grimTicks > 0) {
            e.cancel();
            --this.grimTicks;
        }
        if (e.getPacket() instanceof class_2708 && (this.cc.getValue().booleanValue() || this.mode.getValue() == modeEn.GrimNew)) {
            this.ccCooldown = 5;
        }
    }

    @Override
    public void onUpdate() {
        if (Velocity.mc.field_1724 != null && (Velocity.mc.field_1724.method_5799() || Velocity.mc.field_1724.method_5869()) && this.pauseInWater.getValue().booleanValue()) {
            return;
        }
        switch (this.mode.getValue().ordinal()) {
            case 0: {
                if (Velocity.mc.field_1724.field_6235 <= 0 || Velocity.mc.field_1724.method_24828()) break;
                double var3 = Velocity.mc.field_1724.method_36454() * ((float)Math.PI / 180);
                double var5 = Math.sqrt(Velocity.mc.field_1724.method_18798().field_1352 * Velocity.mc.field_1724.method_18798().field_1352 + Velocity.mc.field_1724.method_18798().field_1350 * Velocity.mc.field_1724.method_18798().field_1350);
                Velocity.mc.field_1724.method_18800(-Math.sin(var3) * var5, Velocity.mc.field_1724.method_18798().field_1351, Math.cos(var3) * var5);
                Velocity.mc.field_1724.method_5728(Velocity.mc.field_1724.field_6012 % 2 != 0);
                break;
            }
            case 6: {
                if (!this.failJump && Velocity.mc.field_1724.field_6235 <= 6 || !Velocity.mc.field_1724.method_24828()) break;
                if (this.failJump) {
                    this.failJump = false;
                }
                if (!this.doJump) {
                    this.skip = true;
                }
                if (Math.random() <= (double)this.failRate.getValue().floatValue() && this.fail.getValue().booleanValue()) {
                    if (Math.random() <= (double)this.jumpRate.getValue().floatValue()) {
                        this.doJump = true;
                        this.failJump = true;
                    } else {
                        this.doJump = false;
                        this.failJump = false;
                    }
                } else {
                    this.doJump = true;
                    this.failJump = false;
                }
                if (this.skip) {
                    this.skip = false;
                    return;
                }
                switch (this.jumpMode.getValue().ordinal()) {
                    case 1: {
                        Velocity.mc.field_1724.method_6043();
                        break;
                    }
                    case 0: {
                        Velocity.mc.field_1724.method_18800(Velocity.mc.field_1724.method_18798().method_10216(), (double)this.motion.getValue().floatValue(), Velocity.mc.field_1724.method_18798().method_10215());
                        break;
                    }
                    case 2: {
                        Velocity.mc.field_1724.method_6043();
                        Velocity.mc.field_1724.method_18800(Velocity.mc.field_1724.method_18798().method_10216(), (double)this.motion.getValue().floatValue(), Velocity.mc.field_1724.method_18798().method_10215());
                    }
                }
                break;
            }
            case 7: {
                if (!this.flag) break;
                if (this.ccCooldown <= 0) {
                    this.sendPacket((class_2596<?>)new class_2828.class_2830(Velocity.mc.field_1724.method_23317(), Velocity.mc.field_1724.method_23318(), Velocity.mc.field_1724.method_23321(), ((IClientPlayerEntity)Velocity.mc.field_1724).getLastYaw(), ((IClientPlayerEntity)Velocity.mc.field_1724).getLastPitch(), Velocity.mc.field_1724.method_24828()));
                    this.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, class_2338.method_49638((class_2374)Velocity.mc.field_1724.method_19538()), class_2350.field_11033));
                }
                this.flag = false;
            }
        }
        if (this.grimTicks > 0) {
            --this.grimTicks;
        }
    }

    private boolean isValidMotion(double motion, double min, double max) {
        return Math.abs(motion) > min && Math.abs(motion) < max;
    }

    @Override
    public void onEnable() {
        this.grimTicks = 0;
    }

    public static enum modeEn {
        Matrix,
        Cancel,
        Sunrise,
        Custom,
        Redirect,
        OldGrim,
        Jump,
        GrimNew;

    }

    public static enum jumpModeEn {
        Motion,
        Jump,
        Both;

    }
}

