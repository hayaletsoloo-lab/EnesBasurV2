/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.util.math.RotationAxis
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_332;
import net.minecraft.class_7833;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventEatFood;
import thunder.hack.features.hud.HudElement;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public class GapplesHud
extends HudElement {
    private float angle;
    private float prevAngle;
    private final Setting<Boolean> crapple = new Setting<Boolean>("Crapple", true);

    public GapplesHud() {
        super("GapplesHud", 0, 0);
    }

    @Override
    public void onRender2D(class_332 context) {
        class_1792 targetItem = this.crapple.getValue() != false ? class_1802.field_8463 : class_1802.field_8367;
        class_1792 class_17922 = targetItem;
        if (this.getItemCount(targetItem) == 0) {
            return;
        }
        float xPos = ModuleManager.crosshair.getAnimatedPosX();
        float yPos = ModuleManager.crosshair.getAnimatedPosY();
        float factor = this.angle > 0.0f ? this.angle / 15.0f : 0.0f;
        float factor2 = 1.0f - (float)GapplesHud.mc.field_1724.method_6048() / 40.0f;
        if (GapplesHud.mc.field_1724.method_6030().method_7909() != targetItem) {
            factor2 = 1.0f;
        }
        factor2 = MathUtility.clamp(factor2, 0.01f, 1.0f);
        context.method_51448().method_22903();
        context.method_51448().method_46416(xPos, yPos, 0.0f);
        context.method_51448().method_22907(class_7833.field_40717.rotation((float)Math.toRadians(-Render2DEngine.interpolateFloat(this.prevAngle, this.angle, Render3DEngine.getTickDelta()))));
        context.method_51448().method_46416(-xPos, -yPos, 0.0f);
        RenderSystem.setShaderColor((float)0.3f, (float)0.3f, (float)0.3f, (float)1.0f);
        context.method_51448().method_46416(xPos + 20.0f, yPos - 9.0f, 0.0f);
        context.method_51427(targetItem.method_7854(), 0, 0);
        context.method_51448().method_46416(-(xPos + 20.0f), -(yPos - 9.0f), 0.0f);
        RenderSystem.setShaderColor((float)1.0f, (float)(1.0f - factor), (float)(1.0f - factor), (float)1.0f);
        context.method_51448().method_46416(xPos + 28.0f, yPos - 1.0f, 0.0f);
        context.method_51448().method_22905(factor2, factor2, 1.0f);
        context.method_51427(targetItem.method_7854(), -8, -8);
        context.method_51448().method_22905(factor2 != 0.0f ? 1.0f / factor2 : 1.0f, factor2 != 0.0f ? 1.0f / factor2 : 1.0f, 1.0f);
        context.method_51448().method_46416(-(xPos + 28.0f), -(yPos - 1.0f), 0.0f);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        if (factor > 0.0f) {
            Render2DEngine.drawBlurredShadow(context.method_51448(), xPos + 22.0f, yPos - 6.0f, 11.0f, 11.0f, 8, Render2DEngine.injectAlpha(new Color(16717056), (int)(255.0f * factor)));
        }
        FontRenderers.sf_bold_mini.drawCenteredString(context.method_51448(), "" + this.getItemCount(targetItem), (double)(xPos + 28.5f), (double)(yPos + 8.0f), -1);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        context.method_51448().method_22909();
    }

    @EventHandler
    public void onEatFood(EventEatFood e) {
        if (e.getFood().method_7909() == class_1802.field_8463 || e.getFood().method_7909() == class_1802.field_8367) {
            this.angle = 15.0f;
        }
    }

    @Override
    public void onUpdate() {
        this.prevAngle = this.angle;
        if (this.angle > 0.0f) {
            this.angle -= 1.0f;
        }
    }

    public int getItemCount(class_1792 item) {
        if (GapplesHud.mc.field_1724 == null) {
            return 0;
        }
        int n = 0;
        int n2 = 44;
        for (int i = 0; i <= n2; ++i) {
            class_1799 itemStack = GapplesHud.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7909() != item) continue;
            n += itemStack.method_7947();
        }
        return n;
    }
}

