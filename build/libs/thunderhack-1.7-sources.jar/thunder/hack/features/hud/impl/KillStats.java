/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 *  net.minecraft.world.World
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2663;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

public class KillStats
extends HudElement {
    int death = 0;
    int killstreak = 0;
    int kills = 0;

    public KillStats() {
        super("KillStats", 100, 35);
    }

    @Override
    public void onDisable() {
        this.death = 0;
        this.kills = 0;
        this.killstreak = 0;
    }

    @EventHandler
    private void death(PacketEvent.Receive event) {
        class_2663 pac;
        Object t = event.getPacket();
        if (t instanceof class_2663 && (pac = (class_2663)t).method_11470() == 3) {
            if (!(pac.method_11469((class_1937)KillStats.mc.field_1687) instanceof class_1657)) {
                return;
            }
            if (pac.method_11469((class_1937)KillStats.mc.field_1687) == KillStats.mc.field_1724) {
                ++this.death;
                this.killstreak = 0;
            } else if (Aura.target == pac.method_11469((class_1937)KillStats.mc.field_1687)) {
                ++this.killstreak;
                ++this.kills;
            }
        }
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        String streak = "KillStreak: " + String.valueOf(class_124.field_1068) + this.killstreak;
        String kd = " KD: " + String.valueOf(class_124.field_1068) + MathUtility.round((float)this.kills / (float)(this.death > 0 ? this.death : 1));
        float pX = this.getPosX() > (float)mc.method_22683().method_4486() / 2.0f ? this.getPosX() - FontRenderers.getModulesRenderer().getStringWidth(streak) - FontRenderers.getModulesRenderer().getStringWidth(kd) : this.getPosX();
        float f = pX;
        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawRoundedBlur(context.method_51448(), pX, this.getPosY(), FontRenderers.getModulesRenderer().getStringWidth(streak) + FontRenderers.getModulesRenderer().getStringWidth(kd) + 21.0f, 13.0f, 3.0f, HudEditor.blurColor.getValue().getColorObject());
            Render2DEngine.drawRect(context.method_51448(), pX + 14.0f, this.getPosY() + 2.0f, 0.5f, 8.0f, new Color(0x44FFFFFF, true));
            Render2DEngine.setupRender();
            RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.swordIcon);
            Render2DEngine.renderGradientTexture(context.method_51448(), pX + 2.0f, this.getPosY() + 1.0f, 10.0, 10.0, 0.0f, 0.0f, 16.0, 16.0, 16.0, 16.0, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
            Render2DEngine.endRender();
        }
        FontRenderers.getModulesRenderer().drawString(context.method_51448(), streak, (double)(pX + 18.0f), (double)(this.getPosY() + 5.0f), HudEditor.getColor(1).getRGB());
        FontRenderers.getModulesRenderer().drawString(context.method_51448(), kd, (double)(pX + 18.0f + FontRenderers.getModulesRenderer().getStringWidth(streak)), (double)(this.getPosY() + 5.0f), HudEditor.getColor(1).getRGB());
        this.setBounds(pX, this.getPosY(), FontRenderers.getModulesRenderer().getStringWidth(streak) + FontRenderers.getModulesRenderer().getStringWidth(kd) + 21.0f, 13.0f);
    }
}

