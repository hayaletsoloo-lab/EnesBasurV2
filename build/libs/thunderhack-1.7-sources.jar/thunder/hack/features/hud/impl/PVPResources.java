/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemConvertible
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 */
package thunder.hack.features.hud.impl;

import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_332;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.render.Render2DEngine;

public class PVPResources
extends HudElement {
    public PVPResources() {
        super("PVPResources", 50, 50);
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        Render2DEngine.drawHudBase(context.method_51448(), this.getPosX(), this.getPosY(), 50.0f, 50.0f, HudEditor.hudRound.getValue().floatValue());
        this.setBounds(this.getPosX(), this.getPosY(), 50.0f, 50.0f);
        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawRectDumbWay(context.method_51448(), this.getPosX(), this.getPosY() + 24.5f, this.getPosX() + 50.0f, this.getPosY() + 25.0f, new Color(0x54FFFFFF, true));
            Render2DEngine.drawRectDumbWay(context.method_51448(), this.getPosX() + 24.5f, this.getPosY() - 1.0f, this.getPosX() + 25.0f, this.getPosY() + 49.0f, new Color(0x54FFFFFF, true));
        } else {
            Render2DEngine.horizontalGradient(context.method_51448(), this.getPosX() + 2.0f, this.getPosY() + 24.5f, this.getPosX() + 26.0f, this.getPosY() + 25.0f, Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0), HudEditor.textColor.getValue().getColorObject());
            Render2DEngine.horizontalGradient(context.method_51448(), this.getPosX() + 26.0f, this.getPosY() + 24.5f, this.getPosX() + 48.0f, this.getPosY() + 25.0f, HudEditor.textColor.getValue().getColorObject(), Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0));
            Render2DEngine.verticalGradient(context.method_51448(), this.getPosX() + 25.5f, this.getPosY() + 2.0f, this.getPosX() + 26.0f, this.getPosY() + 23.0f, Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0), HudEditor.textColor.getValue().getColorObject());
            Render2DEngine.verticalGradient(context.method_51448(), this.getPosX() + 25.5f, this.getPosY() + 23.0f, this.getPosX() + 26.0f, this.getPosY() + 48.0f, HudEditor.textColor.getValue().getColorObject(), Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0));
        }
        int totemCount = this.getItemCount(class_1802.field_8288);
        int xpCount = this.getItemCount(class_1802.field_8287);
        int crystalCount = this.getItemCount(class_1802.field_8301);
        int gappleCount = this.getItemCount(class_1802.field_8367);
        ArrayList<class_1799> list = new ArrayList<class_1799>();
        if (totemCount > 0) {
            list.add(new class_1799((class_1935)class_1802.field_8288, totemCount));
        }
        if (xpCount > 0) {
            list.add(new class_1799((class_1935)class_1802.field_8287, xpCount));
        }
        if (crystalCount > 0) {
            list.add(new class_1799((class_1935)class_1802.field_8301, crystalCount));
        }
        if (gappleCount > 0) {
            list.add(new class_1799((class_1935)class_1802.field_8367, gappleCount));
        }
        for (int i = 0; i < list.size(); ++i) {
            int offsetX = i % 2 * 25;
            int offsetY = i / 2 * 25;
            context.method_51427((class_1799)list.get(i), (int)(this.getPosX() + (float)offsetX + 4.0f), (int)(this.getPosY() + (float)offsetY + 4.0f));
            context.method_51448().method_22903();
            context.method_51448().method_46416(0.0f, 0.0f, 151.0f);
            Render2DEngine.drawBlurredShadow(context.method_51448(), this.getPosX() + (float)offsetX + 8.0f, this.getPosY() + (float)offsetY + 8.0f, 9.0f, 9.0f, 12, Color.BLACK);
            FontRenderers.sf_medium.drawCenteredString(context.method_51448(), String.valueOf(((class_1799)list.get(i)).method_7947()), (double)((int)(this.getPosX() + (float)offsetX + 12.0f)), (double)((int)(this.getPosY() + (float)offsetY + 11.0f)), HudEditor.textColor.getValue().getColor());
            context.method_51448().method_22909();
        }
    }

    public int getItemCount(class_1792 item) {
        if (PVPResources.mc.field_1724 == null) {
            return 0;
        }
        int n = 0;
        int n2 = 44;
        for (int i = 0; i <= n2; ++i) {
            class_1799 itemStack = PVPResources.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7909() != item) continue;
            n += itemStack.method_7947();
        }
        return n;
    }
}

