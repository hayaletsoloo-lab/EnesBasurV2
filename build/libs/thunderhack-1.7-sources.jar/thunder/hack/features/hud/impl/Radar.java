/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.Formatting
 */
package thunder.hack.features.hud.impl;

import java.awt.Color;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_332;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.render.NameTags;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public class Radar
extends HudElement {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Rect);
    private final Setting<ColorMode> colorMode = new Setting<ColorMode>("ColorMode", ColorMode.Sync);
    private final Setting<Integer> size = new Setting<Integer>("Size", 80, 20, 300);
    private final Setting<ColorSetting> color2 = new Setting<ColorSetting>("Color", new ColorSetting(-15724528));
    private final Setting<ColorSetting> color3 = new Setting<ColorSetting>("PlayerColor", new ColorSetting(-979657829));
    private final Setting<Component> c1 = new Setting<Component>("Component1", Component.Name, v -> this.mode.is(Mode.Text));
    private final Setting<Component> c2 = new Setting<Component>("Component2", Component.Hp, v -> this.mode.is(Mode.Text));
    private final Setting<Component> c3 = new Setting<Component>("Component3", Component.Ping, v -> this.mode.is(Mode.Text));
    private final Setting<Component> c4 = new Setting<Component>("Component4", Component.None, v -> this.mode.is(Mode.Text));
    private final Setting<Component> c5 = new Setting<Component>("Component5", Component.None, v -> this.mode.is(Mode.Text));
    private final Setting<class_124> c12 = new Setting<class_124>("Color1", class_124.field_1068, v -> this.mode.is(Mode.Text));
    private final Setting<class_124> c22 = new Setting<class_124>("Color2", class_124.field_1068, v -> this.mode.is(Mode.Text));
    private final Setting<class_124> c32 = new Setting<class_124>("Color3", class_124.field_1068, v -> this.mode.is(Mode.Text));
    private final Setting<class_124> c42 = new Setting<class_124>("Color4", class_124.field_1068, v -> this.mode.is(Mode.Text));

    public Radar() {
        super("Radar", 100, 100);
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        if (this.mode.getValue() == Mode.Rect) {
            Render2DEngine.drawHudBase(context.method_51448(), this.getPosX(), this.getPosY(), this.size.getValue().intValue(), this.size.getValue().intValue(), HudEditor.hudRound.getValue().floatValue());
            if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
                Render2DEngine.drawRectDumbWay(context.method_51448(), this.getPosX(), this.getPosY() + ((float)this.size.getValue().intValue() / 2.0f + 0.25f), this.getPosX() + (float)this.size.getValue().intValue(), this.getPosY() + (float)this.size.getValue().intValue() / 2.0f - 0.25f, new Color(0x54FFFFFF, true));
                Render2DEngine.drawRectDumbWay(context.method_51448(), this.getPosX() + ((float)this.size.getValue().intValue() / 2.0f - 0.25f), this.getPosY() - 0.5f, this.getPosX() + (float)this.size.getValue().intValue() / 2.0f + 0.25f, this.getPosY() + (float)this.size.getValue().intValue() - 1.0f, new Color(0x54FFFFFF, true));
            } else {
                Render2DEngine.draw2DGradientRect(context.method_51448(), (float)((double)this.getPosX() + ((double)((float)this.size.getValue().intValue() / 2.0f) - 0.5)), (float)((double)this.getPosY() + 3.5), (float)((double)this.getPosX() + ((double)((float)this.size.getValue().intValue() / 2.0f) + 0.2)), (float)((double)(this.getPosY() + (float)this.size.getValue().intValue()) - 3.5), this.color2.getValue().getColorObject(), this.color2.getValue().getColorObject(), this.color2.getValue().getColorObject(), this.color2.getValue().getColorObject());
                Render2DEngine.draw2DGradientRect(context.method_51448(), this.getPosX() + 3.5f, this.getPosY() + ((float)this.size.getValue().intValue() / 2.0f - 0.2f), this.getPosX() + (float)this.size.getValue().intValue() - 3.5f, this.getPosY() + ((float)this.size.getValue().intValue() / 2.0f + 0.5f), this.color2.getValue().getColorObject(), this.color2.getValue().getColorObject(), this.color2.getValue().getColorObject(), this.color2.getValue().getColorObject());
            }
            for (class_1657 playerEntity : Managers.ASYNC.getAsyncPlayers()) {
                if (playerEntity == Radar.mc.field_1724) continue;
                float f = (float)(playerEntity.field_6014 + (playerEntity.field_6014 - playerEntity.method_23317()) * (double)Render3DEngine.getTickDelta() - Radar.mc.field_1724.method_23317()) * 2.0f;
                float posZ = (float)(playerEntity.field_5969 + (playerEntity.field_5969 - playerEntity.method_23321()) * (double)Render3DEngine.getTickDelta() - Radar.mc.field_1724.method_23321()) * 2.0f;
                float cos = (float)Math.cos((double)Radar.mc.field_1724.method_5705(Render3DEngine.getTickDelta()) * 0.017453292);
                float sin = (float)Math.sin((double)Radar.mc.field_1724.method_5705(Render3DEngine.getTickDelta()) * 0.017453292);
                float rotY = -(posZ * cos - f * sin);
                float rotX = -(f * cos + posZ * sin);
                if (rotY > (float)this.size.getValue().intValue() / 2.0f - 6.0f) {
                    rotY = (float)this.size.getValue().intValue() / 2.0f - 6.0f;
                } else if (rotY < -((float)this.size.getValue().intValue() / 2.0f - 8.0f)) {
                    rotY = -((float)this.size.getValue().intValue() / 2.0f - 8.0f);
                }
                if (rotX > (float)this.size.getValue().intValue() / 2.0f - 5.0f) {
                    rotX = (float)this.size.getValue().intValue() / 2.0f - 5.0f;
                } else if (rotX < -((float)this.size.getValue().intValue() / 2.0f - 5.0f)) {
                    rotX = -((float)this.size.getValue().intValue() / 2.0f - 5.0f);
                }
                Render2DEngine.drawRound(context.method_51448(), this.getPosX() + (float)this.size.getValue().intValue() / 2.0f + rotX - 2.0f, this.getPosY() + (float)this.size.getValue().intValue() / 2.0f + rotY - 2.0f, 4.0f, 4.0f, 2.0f, this.color3.getValue().getColorObject());
            }
        }
        if (this.mode.getValue() == Mode.Text) {
            float offset_y = 0.0f;
            for (class_1657 playerEntity : Managers.ASYNC.getAsyncPlayers()) {
                if (playerEntity == Radar.mc.field_1724) continue;
                String str = String.format("%s %s %s %s %s", this.getText(this.c1, playerEntity), this.getText(this.c2, playerEntity), this.getText(this.c3, playerEntity), this.getText(this.c4, playerEntity), this.getText(this.c5, playerEntity));
                if (this.colorMode.getValue() == ColorMode.Sync) {
                    FontRenderers.sf_bold.drawString(context.method_51448(), str, (double)this.getPosX(), (double)(this.getPosY() + offset_y), HudEditor.getColor((int)(offset_y * 2.0f)).getRGB());
                } else {
                    FontRenderers.sf_bold.drawString(context.method_51448(), str, (double)this.getPosX(), (double)(this.getPosY() + offset_y), this.color2.getValue().getColor());
                }
                offset_y += FontRenderers.sf_bold.getFontHeight(str);
            }
        }
        this.setBounds(this.getPosX(), this.getPosY(), this.size.getValue().intValue(), this.size.getValue().intValue());
    }

    public String getText(Setting<Component> c, class_1657 player) {
        switch (c.getValue().ordinal()) {
            default: {
                return "";
            }
            case 1: {
                int health = (int)Math.ceil(player.method_6032() + player.method_6067());
                return ModuleManager.nameTags.getHealthColor(health) + health + String.valueOf(class_124.field_1070);
            }
            case 0: {
                return String.valueOf(this.c12.getValue()) + player.method_5477().getString() + String.valueOf(class_124.field_1070);
            }
            case 3: {
                return String.valueOf(this.c22.getValue()) + NameTags.getEntityPing(player) + "ms" + String.valueOf(class_124.field_1070);
            }
            case 2: {
                return String.valueOf(this.c32.getValue()) + (int)Math.ceil(Radar.mc.field_1724.method_5739((class_1297)player)) + "m" + String.valueOf(class_124.field_1070);
            }
            case 4: 
        }
        return String.valueOf(this.c42.getValue()) + Managers.COMBAT.getPops(player) + String.valueOf(class_124.field_1070);
    }

    private static enum Mode {
        Rect,
        Text;

    }

    public static enum ColorMode {
        Sync,
        Custom;

    }

    public static enum Component {
        Name,
        Hp,
        Distance,
        Ping,
        TotemPops,
        None;

    }
}

