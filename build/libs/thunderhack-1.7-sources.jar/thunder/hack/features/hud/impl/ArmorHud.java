/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.entity.EquipmentSlot
 *  net.minecraft.item.ArmorItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import thunder.hack.features.hud.HudElement;
import thunder.hack.setting.Setting;
import thunder.hack.utility.render.Render2DEngine;

public class ArmorHud
extends HudElement {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.V2);

    public ArmorHud() {
        super("ArmorHud", 60, 25);
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        float xItemOffset = this.getPosX();
        for (class_1799 itemStack : ArmorHud.mc.field_1724.method_31548().field_7548.reversed()) {
            if (itemStack.method_7960()) continue;
            if (this.mode.is(Mode.V1)) {
                context.method_51427(itemStack, (int)xItemOffset, (int)this.getPosY());
                context.method_51431(ArmorHud.mc.field_1772, itemStack, (int)xItemOffset, (int)this.getPosY());
            } else {
                class_1738 ai;
                RenderSystem.setShaderColor((float)0.4f, (float)0.4f, (float)0.4f, (float)0.35f);
                context.method_51427(itemStack, (int)xItemOffset, (int)this.getPosY());
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                class_1792 class_17922 = itemStack.method_7909();
                float offset = class_17922 instanceof class_1738 && (ai = (class_1738)class_17922).method_7685() == class_1304.field_6169 ? -4.0f : 0.0f;
                Render2DEngine.addWindow(context.method_51448(), (int)xItemOffset, this.getPosY() + offset + (15.0f - offset) * ((float)itemStack.method_7919() / (float)itemStack.method_7936()), xItemOffset + 15.0f, this.getPosY() + 15.0f, 1.0);
                context.method_51427(itemStack, (int)xItemOffset, (int)this.getPosY());
                Render2DEngine.popWindow();
            }
            xItemOffset += 20.0f;
        }
        this.setBounds(this.getPosX(), this.getPosY(), 60.0f, 25.0f);
    }

    private static enum Mode {
        V1,
        V2;

    }
}

