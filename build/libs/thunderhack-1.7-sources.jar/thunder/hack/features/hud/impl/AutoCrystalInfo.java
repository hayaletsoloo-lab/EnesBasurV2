/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.util.Formatting
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.Collections;
import net.minecraft.class_124;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_757;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.render.Render2DEngine;

public class AutoCrystalInfo
extends HudElement {
    private final ArrayDeque<Integer> speeds = new ArrayDeque(20);
    private int max;
    private int min;
    private long time;

    public AutoCrystalInfo() {
        super("AutoCrystalInfo", 175, 80);
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        Render2DEngine.drawHudBase(context.method_51448(), this.getPosX(), this.getPosY(), this.getWidth(), this.getHeight(), HudEditor.hudRound.getValue().floatValue());
        Color c1 = HudEditor.getColor(0).darker().darker().darker();
        Color c2 = HudEditor.getColor(0);
        Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 2.0f, this.getPosY() + 14.0f, 96.0f, 64.0f, HudEditor.hudRound.getValue().floatValue(), 0.4f, c1, c1, c1, c1);
        FontRenderers.sf_bold.drawGradientString(context.method_51448(), "AutoCrystal Info", this.getPosX() + 2.0f, this.getPosY() + 4.0f, 10);
        RenderSystem.setShader(class_757::method_34540);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29345, class_290.field_1576);
        float offset = 0.0f;
        for (Integer n : this.speeds) {
            bufferBuilder.method_22912(this.getPosX() + 2.0f + offset, this.getPosY() + 80.0f - 55.0f * ((float)n.intValue() / (float)this.max), 0.0f).method_39415(c2.getRGB());
            offset += 4.8f;
        }
        Render2DEngine.endBuilding(bufferBuilder);
        class_287 bufferBuilder2 = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        offset = 0.0f;
        for (Integer speed : this.speeds) {
            bufferBuilder2.method_22912(this.getPosX() + 2.0f + offset, this.getPosY() + 80.0f - 55.0f * ((float)speed.intValue() / (float)this.max), 0.0f).method_39415(Render2DEngine.applyOpacity(c2.getRGB(), 0.3f));
            bufferBuilder2.method_22912(this.getPosX() + 2.0f + offset, this.getPosY() + 80.0f, 0.0f).method_39415(Render2DEngine.applyOpacity(c2.darker().darker().getRGB(), 0.0f));
            offset += 4.8f;
        }
        Render2DEngine.endBuilding(bufferBuilder2);
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "" + this.max, (double)(this.getPosX() + 100.0f), (double)(this.getPosY() + 16.0f), HudEditor.textColor.getValue().getRawColor());
        if (!this.speeds.isEmpty()) {
            FontRenderers.sf_bold_mini.drawString(context.method_51448(), String.valueOf(this.speeds.getLast()), (double)(this.getPosX() + 100.0f), (double)(this.getPosY() + 80.0f - 55.0f * ((float)this.speeds.getLast().intValue() / (float)this.max)), HudEditor.textColor.getValue().getRawColor());
        }
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "" + this.min, (double)(this.getPosX() + 100.0f), (double)(this.getPosY() + 72.0f), HudEditor.textColor.getValue().getRawColor());
        boolean bl = true;
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "Target: " + String.valueOf(class_124.field_1080) + "null", (double)(this.getPosX() + 113.0f), (double)(this.getPosY() + 16.0f), HudEditor.textColor.getValue().getRawColor());
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "Calc delay: 0ms", (double)(this.getPosX() + 113.0f), (double)(this.getPosY() + 24.0f), HudEditor.textColor.getValue().getRawColor());
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "Side: null", (double)(this.getPosX() + 113.0f), (double)(this.getPosY() + 32.0f), HudEditor.textColor.getValue().getRawColor());
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "Damage: 0", (double)(this.getPosX() + 113.0f), (double)(this.getPosY() + 40.0f), HudEditor.textColor.getValue().getRawColor());
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "Self: 0", (double)(this.getPosX() + 113.0f), (double)(this.getPosY() + 48.0f), HudEditor.textColor.getValue().getRawColor());
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "Overr. dmg: 0", (double)(this.getPosX() + 113.0f), (double)(this.getPosY() + 56.0f), HudEditor.textColor.getValue().getRawColor());
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "Efficiency: 0", (double)(this.getPosX() + 113.0f), (double)(this.getPosY() + 64.0f), HudEditor.textColor.getValue().getRawColor());
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), "Pause: null", (double)(this.getPosX() + 113.0f), (double)(this.getPosY() + 72.0f), HudEditor.textColor.getValue().getRawColor());
        Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 110.5f, this.getPosY() + 12.0f, 0.5f, 65.0f, new Color(0x44FFFFFF, true));
        this.setBounds(this.getPosX(), this.getPosY(), this.getWidth(), this.getHeight());
    }

    public class_124 getCalcColor(float val) {
        if (val > 20.0f) {
            return class_124.field_1061;
        }
        if (val > 10.0f) {
            return class_124.field_1054;
        }
        return class_124.field_1060;
    }

    public class_124 getEfficiencyColor(float val) {
        if (val > 6.0f) {
            return class_124.field_1060;
        }
        if (val < 1.0f) {
            return class_124.field_1061;
        }
        return class_124.field_1054;
    }

    public void onSpawn() {
        if (this.time != 0L) {
            if (this.speeds.size() > 20) {
                this.speeds.poll();
            }
            this.speeds.add((int)(1000.0f / (float)(System.currentTimeMillis() - this.time)));
            this.max = Collections.max(this.speeds);
            this.min = Collections.min(this.speeds);
        }
        this.time = System.currentTimeMillis();
    }
}

