/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.BufferRenderer
 *  net.minecraft.client.render.BuiltBuffer
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.render.Tessellator
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.RotationAxis
 *  org.joml.Matrix4f
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;
import thunder.hack.utility.render.animation.AnimationUtility;

public class Crosshair
extends Module {
    private final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Circle);
    private final Setting<Boolean> animated = new Setting<Boolean>("Animated", true, v -> this.mode.is(Mode.Default));
    private final Setting<Boolean> dot = new Setting<Boolean>("Dot", false, v -> this.mode.is(Mode.Default));
    private final Setting<Boolean> t = new Setting<Boolean>("T", false, v -> this.mode.is(Mode.Default));
    private final Setting<ColorMode> colorMode = new Setting<ColorMode>("ColorMode", ColorMode.Sync);
    public final Setting<ColorSetting> color = new Setting<ColorSetting>("Color", new ColorSetting(575714484));
    private final Setting<Boolean> dynamic = new Setting<Boolean>("Dynamic", true);
    private final Setting<Float> range = new Setting<Float>("Range", Float.valueOf(30.0f), Float.valueOf(0.1f), Float.valueOf(120.0f));
    private final Setting<Float> speed = new Setting<Float>("Speed", Float.valueOf(3.0f), Float.valueOf(0.1f), Float.valueOf(20.0f));
    private final Setting<Float> backSpeed = new Setting<Float>("BackSpeed", Float.valueOf(5.0f), Float.valueOf(0.1f), Float.valueOf(20.0f));
    private float xAnim;
    private float yAnim;
    private float prevPitch;
    private float prevProgress;

    public Crosshair() {
        super("Crosshair", Module.Category.HUD);
    }

    @Override
    public void onRender2D(class_332 context) {
        float progress;
        if (!Crosshair.mc.field_1690.method_31044().method_31034()) {
            return;
        }
        float midX = (float)mc.method_22683().method_4486() / 2.0f;
        float midY = (float)mc.method_22683().method_4502() / 2.0f;
        float yawDelta = Crosshair.mc.field_1724.field_6259 - Crosshair.mc.field_1724.method_5791();
        float pitchDelta = this.prevPitch - Crosshair.mc.field_1724.method_36455();
        float f = yawDelta > 0.0f ? AnimationUtility.fast(this.xAnim, midX - this.range.getValue().floatValue(), this.speed.getValue().floatValue()) : (this.xAnim = yawDelta < 0.0f ? AnimationUtility.fast(this.xAnim, midX + this.range.getValue().floatValue(), this.speed.getValue().floatValue()) : AnimationUtility.fast(this.xAnim, midX, this.backSpeed.getValue().floatValue()));
        this.yAnim = pitchDelta > 0.0f ? AnimationUtility.fast(this.yAnim, midY - this.range.getValue().floatValue(), this.speed.getValue().floatValue()) : (pitchDelta < 0.0f ? AnimationUtility.fast(this.yAnim, midY + this.range.getValue().floatValue(), this.speed.getValue().floatValue()) : AnimationUtility.fast(this.yAnim, midY, this.backSpeed.getValue().floatValue()));
        this.prevPitch = Crosshair.mc.field_1724.method_36455();
        if (!this.dynamic.getValue().booleanValue()) {
            this.xAnim = midX;
            this.yAnim = midY;
        }
        progress = (progress = 360.0f * Crosshair.mc.field_1724.method_7261(0.5f)) == 0.0f ? 360.0f : progress;
        switch (this.mode.getValue().ordinal()) {
            case 0: {
                Color c1 = this.colorMode.getValue() == ColorMode.Sync ? HudEditor.hcolor1.getValue().getColorObject() : this.color.getValue().getColorObject();
                Color c2 = this.colorMode.getValue() == ColorMode.Sync ? HudEditor.acolor.getValue().getColorObject() : this.color.getValue().getColorObject();
                Render2DEngine.drawArc(context.method_51448(), this.xAnim - 25.0f, this.yAnim - 25.0f, 50.0f, 50.0f, 0.05f, 0.12f, 0.0f, Render2DEngine.interpolateFloat(this.prevProgress, progress, Render3DEngine.getTickDelta()), c1, c2);
                this.prevProgress = progress;
                break;
            }
            case 1: {
                Color color = this.color.getValue().getColorObject();
                context.method_51448().method_22903();
                context.method_51448().method_46416(this.xAnim, this.yAnim, 0.0f);
                context.method_51448().method_22907(class_7833.field_40718.rotation((float)(System.currentTimeMillis() % 70000L) / 70000.0f * 360.0f));
                context.method_51448().method_46416(-this.xAnim, -this.yAnim, 0.0f);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 0.75f, this.yAnim - 5.0f, 1.5f, 10.0f, color);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 5.0f, this.yAnim - 0.75f, 10.0f, 1.5f, color);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim, this.yAnim - 5.0f, 5.0f, 1.5f, color);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 5.0f, this.yAnim + 4.0f, 5.25f, 1.5f, color);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 5.0f, this.yAnim - 5.0f, 1.5f, 4.25f, color);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim + 3.5f, this.yAnim, 1.5f, 5.5f, color);
                context.method_51448().method_22909();
                break;
            }
            case 2: {
                context.method_51448().method_22903();
                context.method_51448().method_46416(this.xAnim + 4.0f, this.yAnim + 4.0f, 0.0f);
                RenderSystem.enableBlend();
                RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
                RenderSystem.setShader(class_757::method_34543);
                class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.firefly);
                Color color1 = this.colorMode.getValue() == ColorMode.Sync ? HudEditor.getColor(1) : this.color.getValue().getColorObject();
                Matrix4f posMatrix = context.method_51448().method_23760().method_23761();
                bufferBuilder.method_22918(posMatrix, 0.0f, -8.0f, 0.0f).method_22913(0.0f, 1.0f).method_39415(color1.getRGB());
                bufferBuilder.method_22918(posMatrix, -8.0f, -8.0f, 0.0f).method_22913(1.0f, 1.0f).method_39415(color1.getRGB());
                bufferBuilder.method_22918(posMatrix, -8.0f, 0.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(color1.getRGB());
                bufferBuilder.method_22918(posMatrix, 0.0f, 0.0f, 0.0f).method_22913(0.0f, 0.0f).method_39415(color1.getRGB());
                class_286.method_43433((class_9801)bufferBuilder.method_60800());
                RenderSystem.defaultBlendFunc();
                RenderSystem.disableBlend();
                context.method_51448().method_22909();
                break;
            }
            case 3: {
                Color color = this.color.getValue().getColorObject();
                float offset = this.animated.getValue() != false ? -3.0f + Render2DEngine.interpolateFloat(this.prevProgress, progress, Render3DEngine.getTickDelta()) / 100.0f : 0.0f;
                this.prevProgress = progress;
                if (!this.t.getValue().booleanValue()) {
                    Render2DEngine.drawRect(context.method_51448(), this.xAnim - 1.0f, this.yAnim - 6.0f + offset, 2.0f, 4.0f, Color.BLACK);
                    Render2DEngine.drawRect(context.method_51448(), this.xAnim - 0.5f, this.yAnim - 5.5f + offset, 1.0f, 3.0f, color);
                }
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 1.0f, this.yAnim + 2.0f - offset, 2.0f, 4.0f, Color.BLACK);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 0.5f, this.yAnim + 2.5f - offset, 1.0f, 3.0f, color);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 6.0f + offset, this.yAnim - 1.0f, 4.0f, 2.0f, Color.BLACK);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 5.5f + offset, this.yAnim - 0.5f, 3.0f, 1.0f, color);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim + 2.0f - offset, this.yAnim - 1.0f, 4.0f, 2.0f, Color.BLACK);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim + 2.5f - offset, this.yAnim - 0.5f, 3.0f, 1.0f, color);
                if (!this.dot.getValue().booleanValue()) break;
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 1.0f, this.yAnim - 1.0f, 2.0f, 2.0f, Color.BLACK);
                Render2DEngine.drawRect(context.method_51448(), this.xAnim - 0.5f, this.yAnim - 0.5f, 1.0f, 1.0f, color);
            }
        }
    }

    public float getAnimatedPosX() {
        if (this.xAnim == 0.0f) {
            return (float)mc.method_22683().method_4486() / 2.0f;
        }
        return this.xAnim;
    }

    public float getAnimatedPosY() {
        if (this.yAnim == 0.0f) {
            return (float)mc.method_22683().method_4502() / 2.0f;
        }
        return this.yAnim;
    }

    private static enum Mode {
        Circle,
        WiseTree,
        Dot,
        Default;

    }

    private static enum ColorMode {
        Custom,
        Sync;

    }
}

