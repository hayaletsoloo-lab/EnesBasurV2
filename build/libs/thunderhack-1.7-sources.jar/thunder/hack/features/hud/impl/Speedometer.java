/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_124;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

public class Speedometer
extends HudElement {
    public float speed = 0.0f;
    private final Setting<Boolean> bps = new Setting<Boolean>("BPS", false);
    private final Setting<Boolean> average = new Setting<Boolean>("Average", false);

    public Speedometer() {
        super("Speedometer", 50, 10);
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        String str = "Speed " + String.valueOf(class_124.field_1068);
        str = this.bps.getValue() == false ? str + MathUtility.round(this.getSpeedKpH() * ThunderHack.TICK_TIMER) + " km/h" : str + MathUtility.round(this.getSpeedMpS() * ThunderHack.TICK_TIMER) + " b/s";
        float pX = this.getPosX() > (float)mc.method_22683().method_4486() / 2.0f ? this.getPosX() - FontRenderers.getModulesRenderer().getStringWidth(str) : this.getPosX();
        float f = pX;
        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawRoundedBlur(context.method_51448(), pX, this.getPosY(), FontRenderers.getModulesRenderer().getStringWidth(str) + 21.0f, 13.0f, 3.0f, HudEditor.blurColor.getValue().getColorObject());
            Render2DEngine.drawRect(context.method_51448(), pX + 14.0f, this.getPosY() + 2.0f, 0.5f, 8.0f, new Color(0x44FFFFFF, true));
            Render2DEngine.setupRender();
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
            RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.speedometerIcon);
            Render2DEngine.renderGradientTexture(context.method_51448(), pX + 2.0f, this.getPosY() + 1.0f, 10.0, 10.0, 0.0f, 0.0f, 512.0, 512.0, 512.0, 512.0, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
            Render2DEngine.endRender();
        }
        FontRenderers.getModulesRenderer().drawString(context.method_51448(), str, (double)(pX + 18.0f), (double)(this.getPosY() + 5.0f), HudEditor.getColor(1).getRGB());
        this.setBounds(pX, this.getPosY(), FontRenderers.getModulesRenderer().getStringWidth(str) + 21.0f, 13.0f);
    }

    public float getSpeedKpH() {
        return (this.average.getValue() != false ? Managers.PLAYER.averagePlayerSpeed : Managers.PLAYER.currentPlayerSpeed) * 72.0f;
    }

    public float getSpeedMpS() {
        return (this.average.getValue() != false ? Managers.PLAYER.averagePlayerSpeed : Managers.PLAYER.currentPlayerSpeed) * 20.0f;
    }
}

