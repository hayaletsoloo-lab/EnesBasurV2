/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.network.PlayerListEntry
 *  net.minecraft.scoreboard.Team
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 *  net.minecraft.world.GameMode
 */
package thunder.hack.features.hud.impl;

import com.mojang.authlib.GameProfile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_1934;
import net.minecraft.class_268;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_640;
import thunder.hack.features.cmd.impl.StaffCommand;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.animation.AnimationUtility;

public class StaffBoard
extends HudElement {
    private static final Pattern validUserPattern = Pattern.compile("^\\w{3,16}$");
    private List<String> players = new ArrayList<String>();
    private List<String> notSpec = new ArrayList<String>();
    private Map<String, class_2960> skinMap = new HashMap<String, class_2960>();
    private float vAnimation;
    private float hAnimation;

    public StaffBoard() {
        super("StaffBoard", 50, 50);
    }

    public static List<String> getOnlinePlayer() {
        return StaffBoard.mc.field_1724.field_3944.method_2880().stream().map(class_640::method_2966).map(GameProfile::getName).filter(profileName -> validUserPattern.matcher((CharSequence)profileName).matches()).collect(Collectors.toList());
    }

    public static List<String> getOnlinePlayerD() {
        ArrayList<String> S = new ArrayList<String>();
        for (class_640 player : StaffBoard.mc.field_1724.field_3944.method_2880()) {
            if (mc.method_1542() || player.method_2955() == null) break;
            String prefix = player.method_2955().method_1144().getString();
            if (!StaffBoard.check(class_124.method_539((String)prefix).toLowerCase()) && !StaffCommand.staffNames.toString().toLowerCase().contains(player.method_2966().getName().toLowerCase()) && !player.method_2966().getName().toLowerCase().contains("1danil_mansoru1") && !player.method_2966().getName().toLowerCase().contains("barslan_") && !player.method_2966().getName().toLowerCase().contains("timmings") && !player.method_2966().getName().toLowerCase().contains("timings") && !player.method_2966().getName().toLowerCase().contains("ruthless") && !player.method_2955().method_1144().getString().contains("YT") && (!player.method_2955().method_1144().getString().contains("Y") || !player.method_2955().method_1144().getString().contains("T"))) continue;
            String name = Arrays.asList(player.method_2955().method_1204().toArray()).toString().replace("[", "").replace("]", "");
            if (player.method_2958() == class_1934.field_9219) {
                S.add(player.method_2955().method_1144().getString() + name + ":gm3");
                continue;
            }
            S.add(player.method_2955().method_1144().getString() + name + ":active");
        }
        return S;
    }

    public List<String> getVanish() {
        ArrayList<String> list = new ArrayList<String>();
        for (class_268 s : StaffBoard.mc.field_1687.method_8428().method_1159()) {
            if (s.method_1144().getString().isEmpty() || mc.method_1542()) continue;
            String name = Arrays.asList(s.method_1204().toArray()).toString().replace("[", "").replace("]", "");
            if (StaffBoard.getOnlinePlayer().contains(name) || name.isEmpty() || (!StaffCommand.staffNames.toString().toLowerCase().contains(name.toLowerCase()) || !StaffBoard.check(s.method_1144().getString().toLowerCase())) && !StaffBoard.check(s.method_1144().getString().toLowerCase()) && !name.toLowerCase().contains("1danil_mansoru1") && !name.toLowerCase().contains("barslan_") && !name.toLowerCase().contains("timmings") && !name.toLowerCase().contains("timings") && !name.toLowerCase().contains("ruthless") && !s.method_1144().getString().contains("YT") && (!s.method_1144().getString().contains("Y") || !s.method_1144().getString().contains("T"))) continue;
            list.add(s.method_1144().getString() + name + ":vanish");
        }
        return list;
    }

    public static boolean check(String name) {
        if (mc.method_1558() != null && StaffBoard.mc.method_1558().field_3761.contains("mcfunny")) {
            return name.contains("helper") || name.contains("moder") || name.contains("\u043c\u043e\u0434\u0435\u0440") || name.contains("\u0445\u0435\u043b\u043f\u0435\u0440");
        }
        return name.contains("helper") || name.contains("moder") || name.contains("admin") || name.contains("owner") || name.contains("curator") || name.contains("\u043a\u0443\u0440\u0430\u0442\u043e\u0440") || name.contains("\u043c\u043e\u0434\u0435\u0440") || name.contains("\u0430\u0434\u043c\u0438\u043d") || name.contains("\u0445\u0435\u043b\u043f\u0435\u0440") || name.contains("\u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0430") || name.contains("\u0441\u043e\u0442\u0440\u0443\u0434\u043d\u0438\u043a") || name.contains("\u0437\u0430\u043c") || name.contains("\u0441\u0442\u0430\u0436\u0451\u0440");
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        ArrayList<String> all = new ArrayList<String>();
        all.addAll(this.players);
        all.addAll(this.notSpec);
        int y_offset1 = 0;
        float max_width = 50.0f;
        float pointerX = 0.0f;
        for (String player : all) {
            float timeWidth;
            if (y_offset1 == 0) {
                y_offset1 += 4;
            }
            y_offset1 += 9;
            float nameWidth = FontRenderers.sf_bold_mini.getStringWidth(player.split(":")[0]);
            float width = (nameWidth + (timeWidth = FontRenderers.sf_bold_mini.getStringWidth(player.split(":")[1].equalsIgnoreCase("vanish") ? String.valueOf(class_124.field_1061) + "V" : (player.split(":")[1].equalsIgnoreCase("gm3") ? String.valueOf(class_124.field_1061) + "V " + String.valueOf(class_124.field_1054) + "(GM3)" : String.valueOf(class_124.field_1060) + "Z")))) * 1.4f;
            if (width > max_width) {
                max_width = width;
            }
            if (!(timeWidth > pointerX)) continue;
            pointerX = timeWidth;
        }
        this.vAnimation = AnimationUtility.fast(this.vAnimation, 14 + y_offset1, 15.0f);
        this.hAnimation = AnimationUtility.fast(this.hAnimation, max_width, 15.0f);
        Render2DEngine.drawHudBase(context.method_51448(), this.getPosX(), this.getPosY(), this.hAnimation, this.vAnimation, HudEditor.hudRound.getValue().floatValue());
        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Glowing)) {
            FontRenderers.sf_bold.drawCenteredString(context.method_51448(), "Staff", (double)(this.getPosX() + this.hAnimation / 2.0f), (double)(this.getPosY() + 4.0f), HudEditor.textColor.getValue().getColorObject());
        } else {
            FontRenderers.sf_bold.drawGradientCenteredString(context.method_51448(), "Staff", this.getPosX() + this.hAnimation / 2.0f, this.getPosY() + 4.0f, 10);
        }
        if (y_offset1 > 0) {
            if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
                Render2DEngine.drawRectDumbWay(context.method_51448(), this.getPosX() + 4.0f, this.getPosY() + 13.0f, this.getPosX() + this.getWidth() - 8.0f, this.getPosY() + 14.0f, new Color(0x54FFFFFF, true));
            } else {
                Render2DEngine.horizontalGradient(context.method_51448(), this.getPosX() + 2.0f, this.getPosY() + 13.7f, this.getPosX() + 2.0f + this.hAnimation / 2.0f - 2.0f, this.getPosY() + 13.5f, Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0), HudEditor.textColor.getValue().getColorObject());
                Render2DEngine.horizontalGradient(context.method_51448(), this.getPosX() + 2.0f + this.hAnimation / 2.0f - 2.0f, this.getPosY() + 13.7f, this.getPosX() + 2.0f + this.hAnimation - 4.0f, this.getPosY() + 14.0f, HudEditor.textColor.getValue().getColorObject(), Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0));
            }
        }
        Render2DEngine.addWindow(context.method_51448(), this.getPosX(), this.getPosY(), this.getPosX() + this.hAnimation, this.getPosY() + this.vAnimation, 1.0);
        int y_offset = 0;
        for (String player : all) {
            float px = this.getPosX() + (max_width - pointerX - 10.0f);
            class_2960 tex = this.getTexture(player);
            if (tex != null) {
                context.method_25293(tex, (int)(this.getPosX() + 3.0f), (int)(this.getPosY() + 16.0f + (float)y_offset), 8, 8, 8.0f, 8.0f, 8, 8, 64, 64);
                context.method_25293(tex, (int)(this.getPosX() + 3.0f), (int)(this.getPosY() + 16.0f + (float)y_offset), 8, 8, 40.0f, 8.0f, 8, 8, 64, 64);
            }
            FontRenderers.sf_bold_mini.drawString(context.method_51448(), player.split(":")[0], (double)(this.getPosX() + 13.0f), (double)(this.getPosY() + 19.0f + (float)y_offset), HudEditor.textColor.getValue().getColor());
            FontRenderers.sf_bold_mini.drawCenteredString(context.method_51448(), player.split(":")[1].equalsIgnoreCase("vanish") ? String.valueOf(class_124.field_1061) + "O" : (player.split(":")[1].equalsIgnoreCase("gm3") ? String.valueOf(class_124.field_1054) + "O" : String.valueOf(class_124.field_1060) + "O"), (double)(px + (this.getPosX() + max_width - px) / 2.0f), (double)(this.getPosY() + 19.0f + (float)y_offset), HudEditor.textColor.getValue().getColor());
            Render2DEngine.drawRect(context.method_51448(), px, this.getPosY() + 17.0f + (float)y_offset, 0.5f, 8.0f, new Color(0x44FFFFFF, true));
            y_offset += 9;
        }
        Render2DEngine.popWindow();
        this.setBounds(this.getPosX(), this.getPosY(), this.hAnimation, this.vAnimation);
    }

    @Override
    public void onUpdate() {
        if (StaffBoard.mc.field_1724 != null && StaffBoard.mc.field_1724.field_6012 % 10 == 0) {
            this.players = this.getVanish();
            this.notSpec = StaffBoard.getOnlinePlayerD();
            this.players.sort(String::compareTo);
            this.notSpec.sort(String::compareTo);
        }
    }

    private class_2960 getTexture(String n) {
        class_2960 id = null;
        if (this.skinMap.containsKey(n)) {
            id = this.skinMap.get(n);
        }
        for (class_640 ple : mc.method_1562().method_2880()) {
            if (!n.contains(ple.method_2966().getName())) continue;
            id = ple.method_52810().comp_1626();
            if (this.skinMap.containsKey(n)) break;
            this.skinMap.put(n, id);
            break;
        }
        return id;
    }
}

