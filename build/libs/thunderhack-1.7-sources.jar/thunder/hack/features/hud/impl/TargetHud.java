/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.render.GameRenderer
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.effect.StatusEffect
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.scoreboard.ReadableScoreboardScore
 *  net.minecraft.scoreboard.ScoreHolder
 *  net.minecraft.scoreboard.ScoreboardDisplaySlot
 *  net.minecraft.scoreboard.ScoreboardObjective
 *  net.minecraft.scoreboard.number.NumberFormat
 *  net.minecraft.scoreboard.number.StyledNumberFormat
 *  net.minecraft.text.MutableText
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.collection.DefaultedList
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_266;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_742;
import net.minecraft.class_757;
import net.minecraft.class_8646;
import net.minecraft.class_9013;
import net.minecraft.class_9015;
import net.minecraft.class_9022;
import net.minecraft.class_9025;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.hud.impl.Particles;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.features.modules.misc.NameProtect;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.gui.hud.HudEditorGui;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.ThunderUtility;
import thunder.hack.utility.Timer;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;
import thunder.hack.utility.render.animation.EaseOutBack;
import thunder.hack.utility.render.animation.EaseOutCirc;

public class TargetHud
extends HudElement {
    private final Setting<Integer> blurRadius = new Setting<Integer>("BallonBlur", 10, 1, 10);
    private final Setting<Integer> animX = new Setting<Integer>("AnimationX", 0, -2000, 2000);
    private final Setting<Integer> animY = new Setting<Integer>("AnimationY", 0, -2000, 2000);
    private final Setting<HPmodeEn> hpMode = new Setting<HPmodeEn>("HP Mode", HPmodeEn.HP);
    private final Setting<ImageModeEn> imageMode = new Setting<ImageModeEn>("Image", ImageModeEn.Anime);
    private final Setting<ModeEn> Mode = new Setting<ModeEn>("Mode", ModeEn.ThunderHack);
    private final Setting<ColorSetting> color = new Setting<ColorSetting>("Color1", new ColorSetting(-16492289), v -> this.Mode.getValue() == ModeEn.CelkaPasta);
    private final Setting<ColorSetting> color2 = new Setting<ColorSetting>("Color2", new ColorSetting(-16492289), v -> this.Mode.getValue() == ModeEn.CelkaPasta);
    private final Setting<Boolean> scoreboardHp = new Setting<Boolean>("ScoreboardHp", false);
    private final Setting<Boolean> mini = new Setting<Boolean>("Mini", false, v -> this.Mode.getValue() == ModeEn.NurikZapen);
    private final Setting<Boolean> absorp = new Setting<Boolean>("Absorption", true);
    private final Setting<Boolean> showBps = new Setting<Boolean>("ShowBPS", true);
    private static class_2960 custom;
    public EaseOutBack animation = new EaseOutBack();
    public static EaseOutCirc healthAnimation;
    public static EaseOutCirc headAnimation;
    private final ArrayList<Particles> particles = new ArrayList();
    private boolean sentParticles;
    private boolean direction = false;
    private class_1309 target;
    float ticks;
    private final Timer timer = new Timer();

    public TargetHud() {
        super("TargetHud", 150, 50);
    }

    @Override
    public void onEnable() {
        try {
            custom = ThunderUtility.getCustomImg("thud");
        }
        catch (Exception e) {
            this.sendMessage(".minecraft -> ThunderHackRecode -> misc -> images -> thud.png");
        }
    }

    public String getDurationString(class_1293 pe) {
        if (pe.method_48559()) {
            return "*:*";
        }
        return pe.method_5584() / 1200 + ":" + pe.method_5584() % 1200 / 20;
    }

    @Override
    public void onUpdate() {
        this.animation.update(this.direction);
        healthAnimation.update();
        headAnimation.update();
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        this.getTarget();
        if (this.target == null) {
            return;
        }
        float health = Math.min(this.target.method_6063(), this.getHealth());
        context.method_51448().method_22903();
        if (!HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            if (this.Mode.is(ModeEn.NurikZapen) && this.mini.getValue().booleanValue()) {
                TargetHud.sizeAnimation(context.method_51448(), this.getPosX() + 45.0f + (float)this.animX.getValue().intValue(), this.getPosY() + 15.0f + (float)this.animY.getValue().intValue(), this.animation.getAnimationd());
            } else {
                TargetHud.sizeAnimation(context.method_51448(), this.getPosX() + 75.0f + (float)this.animX.getValue().intValue(), this.getPosY() + 25.0f + (float)this.animY.getValue().intValue(), this.animation.getAnimationd());
            }
        }
        if (this.animation.getAnimationd() > 0.0) {
            float animationFactor = (float)MathUtility.clamp(this.animation.getAnimationd(), 0.0, 1.0);
            double distance = Math.hypot(this.target.method_23317() - this.target.field_6014, this.target.method_23321() - this.target.field_5969);
            double speed = (double)Math.round(distance * 20.0 * 10.0) / 10.0;
            Object bps = this.showBps.getValue() != false ? speed + " BPS" : "";
            switch (this.Mode.getValue().ordinal()) {
                case 0: {
                    this.renderThunderHack(context, health, animationFactor, (String)bps);
                    break;
                }
                case 2: {
                    this.renderCelkaPasta(context, health, (String)bps);
                    break;
                }
                case 1: {
                    if (this.mini.getValue().booleanValue()) {
                        this.renderMiniNurik(context, health, animationFactor, (String)bps);
                        break;
                    }
                    this.renderNurik(context, health, animationFactor, (String)bps);
                }
            }
        }
        context.method_51448().method_22909();
    }

    private void getTarget() {
        if (Aura.target != null) {
            if (Aura.target instanceof class_1309) {
                this.target = (class_1309)Aura.target;
                this.direction = true;
            } else {
                this.target = null;
                this.direction = false;
            }
        } else if (TargetHud.mc.field_1755 instanceof class_408 || TargetHud.mc.field_1755 instanceof HudEditorGui) {
            this.target = TargetHud.mc.field_1724;
            this.direction = true;
        } else {
            this.direction = false;
            if (this.animation.getAnimationd() < 0.02) {
                this.target = null;
            }
        }
    }

    private void renderCelkaPasta(class_332 context, float health, String bps) {
        float hurtPercent = (float)this.target.field_6235 / 6.0f;
        Render2DEngine.drawBlurredShadow(context.method_51448(), this.getPosX() - 2.0f, this.getPosY() - 2.0f, 164.0f, 51.0f, 5, this.color.getValue().getColorObject());
        Render2DEngine.drawRect(context.method_51448(), this.getPosX(), this.getPosY(), 160.0f, 47.0f, new Color(0x66000000, true));
        this.setBounds(this.getPosX(), this.getPosY(), 160.0f, 47.0f);
        Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 117.0f, this.getPosY() + 4.0f, 18.0f, 18.0f, new Color(0x4D000000, true));
        Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 137.0f, this.getPosY() + 4.0f, 18.0f, 18.0f, new Color(0x4D000000, true));
        Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 117.0f, this.getPosY() + 25.0f, 18.0f, 18.0f, new Color(0x4D000000, true));
        Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 137.0f, this.getPosY() + 25.0f, 18.0f, 18.0f, new Color(0x4D000000, true));
        Render2DEngine.drawBlurredShadow(context.method_51448(), this.getPosX() + 49.0f, this.getPosY() + 29.0f, 62.0f, 12.0f, 5, this.color.getValue().getColorObject().brighter().brighter().brighter());
        Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 50.0f, this.getPosY() + 30.0f, 60.0f, 10.0f, new Color(-1644167168, true));
        Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 50.0f, this.getPosY() + 30.0f, MathUtility.clamp((int)(60.0f * (health / this.target.method_6063())), 0, 60), 10.0f, this.color.getValue().getColorObject().brighter().brighter().brighter());
        if (this.target instanceof class_1657) {
            RenderSystem.setShaderTexture((int)0, (class_2960)((class_742)(Object)this.target).method_52814().comp_1626());
        } else {
            RenderSystem.setShaderTexture((int)0, (class_2960)mc.method_1561().method_3953((class_1297)(Object)this.target).method_3931((class_1297)(Object)this.target));
        }
        RenderSystem.setShaderColor((float)1.0f, (float)(1.0f - hurtPercent), (float)(1.0f - hurtPercent), (float)1.0f);
        Render2DEngine.renderTexture(context.method_51448(), this.getPosX() + 3.5f + hurtPercent, this.getPosY() + 3.5f + hurtPercent, 40.0f - hurtPercent * 2.0f, 40.0f - hurtPercent * 2.0f, 8.0f, 8.0f, 8.0, 8.0, 64.0, 64.0);
        Render2DEngine.renderTexture(context.method_51448(), this.getPosX() + 3.5f + hurtPercent, this.getPosY() + 3.5f + hurtPercent, 40.0f - hurtPercent * 2.0f, 40.0f - hurtPercent * 2.0f, 40.0f, 8.0f, 8.0, 8.0, 64.0, 64.0);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        FontRenderers.modules.drawString(context.method_51448(), ModuleManager.nameProtect.isEnabled() && this.target == TargetHud.mc.field_1724 ? NameProtect.getCustomName() : this.target.method_5477().getString(), (double)(this.getPosX() + 50.0f), (double)(this.getPosY() + 7.0f), -1);
        FontRenderers.settings.drawString(context.method_51448(), bps, (double)(this.getPosX() + 50.0f), (double)(this.getPosY() + 16.0f), -1);
        FontRenderers.modules.drawCenteredString(context.method_51448(), (String)(this.hpMode.getValue() == HPmodeEn.HP ? String.valueOf((double)Math.round(10.0 * (double)this.getHealth()) / 10.0) : (double)Math.round(10.0 * (double)this.getHealth()) / 10.0 / 20.0 * 100.0 + "%"), (double)(this.getPosX() + 81.0f), (double)(this.getPosY() + 34.0f), -1);
        class_1309 class_13092 = this.target;
        if (class_13092 instanceof class_1657) {
            class_1657 pe = (class_1657)class_13092;
            this.celestialArmor(context, pe, this.getPosX(), this.getPosY());
            this.celestialHands(context, pe, this.getPosX(), this.getPosY());
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    private void renderNurik(class_332 context, float health, float animationFactor, String bps) {
        float hurtPercent = Render2DEngine.interpolateFloat(MathUtility.clamp(this.target.field_6235 == 0 ? 0 : this.target.field_6235 + 1, 0, 10), this.target.field_6235, Render3DEngine.getTickDelta()) / 8.0f;
        healthAnimation.setValue(health);
        health = (float)healthAnimation.getAnimationD();
        if (this.animation.getAnimationd() != 1.0 && !HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawGradientBlurredShadow1(context.method_51448(), this.getPosX() + 4.0f, this.getPosY() + 4.0f, 131.0f, 40.0f, 14, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
            Render2DEngine.renderRoundedGradientRect(context.method_51448(), HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90), this.getPosX(), this.getPosY(), 137.0f, 47.5f, 9.0f);
            Render2DEngine.drawRound(context.method_51448(), this.getPosX() + 0.5f, this.getPosY() + 0.5f, 136.0f, 46.0f, 9.0f, Render2DEngine.injectAlpha(Color.BLACK, 220));
        } else {
            Render2DEngine.drawHudBase2(context.method_51448(), this.getPosX(), this.getPosY(), 137.0f, 47.5f, 9.0f, HudEditor.blurStrength.getValue().floatValue(), HudEditor.blurOpacity.getValue().floatValue(), animationFactor);
        }
        this.setBounds(this.getPosX(), this.getPosY(), 137.0f, 47.5f);
        if (this.target instanceof class_1657) {
            RenderSystem.setShaderTexture((int)0, (class_2960)((class_742)(Object)this.target).method_52814().comp_1626());
        } else {
            RenderSystem.setShaderTexture((int)0, (class_2960)mc.method_1561().method_3953((class_1297)(Object)this.target).method_3931((class_1297)(Object)this.target));
        }
        context.method_51448().method_22903();
        context.method_51448().method_46416(this.getPosX() + 3.5f + 20.0f, this.getPosY() + 3.5f + 20.0f, 0.0f);
        context.method_51448().method_22905(1.0f - hurtPercent / 15.0f, 1.0f - hurtPercent / 15.0f, 1.0f);
        context.method_51448().method_46416(-(this.getPosX() + 3.5f + 20.0f), -(this.getPosY() + 3.5f + 20.0f), 0.0f);
        RenderSystem.enableBlend();
        RenderSystem.colorMask((boolean)false, (boolean)false, (boolean)false, (boolean)true);
        RenderSystem.clearColor((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        RenderSystem.clear((int)16384, (boolean)false);
        RenderSystem.colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
        RenderSystem.setShader(class_757::method_34540);
        Render2DEngine.renderRoundedQuadInternal(context.method_51448().method_23760().method_23761(), animationFactor, animationFactor, animationFactor, animationFactor, this.getPosX() + 3.5f, this.getPosY() + 3.5f, this.getPosX() + 3.5f + 40.0f, this.getPosY() + 3.5f + 40.0f, 7.0, 10.0);
        RenderSystem.blendFunc((int)772, (int)773);
        RenderSystem.setShaderColor((float)animationFactor, (float)(animationFactor - hurtPercent / 2.0f), (float)(animationFactor - hurtPercent / 2.0f), (float)((float)MathUtility.clamp(this.animation.getAnimationd(), 0.0, 1.0)));
        Render2DEngine.renderTexture(context.method_51448(), this.getPosX() + 3.5f, this.getPosY() + 3.5f, 40.0, 40.0, 8.0f, 8.0f, 8.0, 8.0, 64.0, 64.0);
        Render2DEngine.renderTexture(context.method_51448(), this.getPosX() + 3.5f, this.getPosY() + 3.5f, 40.0, 40.0, 40.0f, 8.0f, 8.0, 8.0, 64.0, 64.0);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.defaultBlendFunc();
        context.method_51448().method_22909();
        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 48.0f, this.getPosY() + 32.0f, 85.0f, 11.0f, 4.0f, (float)((double)0.15f * this.animation.getAnimationd()));
            Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 48.0f, this.getPosY() + 32.0f, MathUtility.clamp(85.0f * (health / this.target.method_6063()), 8.0f, 85.0f), 11.0f, 4.0f, (float)this.animation.getAnimationd());
        } else {
            Render2DEngine.drawGradientRound(context.method_51448(), this.getPosX() + 48.0f, this.getPosY() + 32.0f, 85.0f, 11.0f, 4.0f, HudEditor.getColor(0).darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker());
            Render2DEngine.renderRoundedGradientRect(context.method_51448(), HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(0), HudEditor.getColor(270), this.getPosX() + 48.0f, this.getPosY() + 32.0f, (int)MathUtility.clamp(85.0f * (health / this.target.method_6063()), 8.0f, 85.0f), 11.0f, 4.0f);
        }
        FontRenderers.sf_bold.drawCenteredString(context.method_51448(), (String)(this.hpMode.getValue() == HPmodeEn.HP ? String.valueOf((double)Math.round(10.0 * (double)this.getHealth()) / 10.0) : (double)Math.round(10.0 * (double)this.getHealth()) / 10.0 / 20.0 * 100.0 + "%"), (double)(this.getPosX() + 92.0f), (double)(this.getPosY() + 35.0f), Render2DEngine.applyOpacity(-1, animationFactor));
        FontRenderers.sf_bold.drawString(context.method_51448(), ModuleManager.nameProtect.isEnabled() && this.target == TargetHud.mc.field_1724 ? NameProtect.getCustomName() : this.target.method_5477().getString(), (double)(this.getPosX() + 48.0f), (double)(this.getPosY() + 7.0f), Render2DEngine.applyOpacity(-1, animationFactor));
        FontRenderers.sf_medium_mini.drawString(context.method_51448(), bps, (double)(this.getPosX() + 48.0f), (double)(this.getPosY() + 17.0f), Render2DEngine.applyOpacity(new Color(0xBBBBBB), animationFactor));
        if (this.target instanceof class_1657) {
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)((float)MathUtility.clamp(this.animation.getAnimationd(), 0.0, 1.0)));
            class_2371 armor = ((class_1657)(Object)this.target).method_31548().field_7548;
            class_1799[] items = new class_1799[]{this.target.method_6047(), (class_1799)armor.get(3), (class_1799)armor.get(2), (class_1799)armor.get(1), (class_1799)armor.get(0), this.target.method_6079()};
            float xItemOffset = this.getPosX() + 48.0f;
            for (class_1799 itemStack : items) {
                context.method_51448().method_22903();
                context.method_51448().method_46416(xItemOffset, this.getPosY() + 15.0f, 0.0f);
                context.method_51448().method_22905(0.75f, 0.75f, 0.75f);
                context.method_51427(itemStack, 0, 0);
                context.method_51431(TargetHud.mc.field_1772, itemStack, 0, 0);
                context.method_51448().method_22909();
                xItemOffset += 12.0f;
            }
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }

    private void renderMiniNurik(class_332 context, float health, float animationFactor, String bps) {
        float hurtPercent = Render2DEngine.interpolateFloat(MathUtility.clamp(this.target.field_6235 == 0 ? 0 : this.target.field_6235 + 1, 0, 10), this.target.field_6235, Render3DEngine.getTickDelta()) / 8.0f;
        healthAnimation.setValue(health);
        health = (float)healthAnimation.getAnimationD();
        if (this.animation.getAnimationd() != 1.0 && !HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawGradientBlurredShadow1(context.method_51448(), this.getPosX() + 2.0f, this.getPosY() + 2.0f, 91.0f, 31.0f, 12, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
            Render2DEngine.renderRoundedGradientRect(context.method_51448(), HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90), this.getPosX(), this.getPosY(), 95.0f, 35.0f, 7.0f);
            Render2DEngine.drawRound(context.method_51448(), this.getPosX() + 0.5f, this.getPosY() + 0.5f, 94.0f, 34.0f, 7.0f, Render2DEngine.injectAlpha(Color.BLACK, 220));
        } else {
            Render2DEngine.drawHudBase2(context.method_51448(), this.getPosX(), this.getPosY(), 95.0f, 35.5f, 8.0f, HudEditor.blurStrength.getValue().floatValue(), HudEditor.blurOpacity.getValue().floatValue(), animationFactor);
        }
        this.setBounds(this.getPosX(), this.getPosY(), 95.0f, 35.5f);
        if (this.target instanceof class_1657) {
            RenderSystem.setShaderTexture((int)0, (class_2960)((class_742)(Object)this.target).method_52814().comp_1626());
        } else {
            RenderSystem.setShaderTexture((int)0, (class_2960)mc.method_1561().method_3953((class_1297)(Object)this.target).method_3931((class_1297)(Object)this.target));
        }
        context.method_51448().method_22903();
        context.method_51448().method_22904((double)this.getPosX() + 2.5 + 15.0, (double)this.getPosY() + 2.5 + 15.0, 0.0);
        context.method_51448().method_22905(1.0f - hurtPercent / 20.0f, 1.0f - hurtPercent / 20.0f, 1.0f);
        context.method_51448().method_22904(-((double)this.getPosX() + 2.5 + 15.0), -((double)this.getPosY() + 2.5 + 15.0), 0.0);
        RenderSystem.enableBlend();
        RenderSystem.colorMask((boolean)false, (boolean)false, (boolean)false, (boolean)true);
        RenderSystem.clearColor((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        RenderSystem.clear((int)16384, (boolean)false);
        RenderSystem.colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
        RenderSystem.setShader(class_757::method_34540);
        Render2DEngine.renderRoundedQuadInternal(context.method_51448().method_23760().method_23761(), animationFactor, animationFactor, animationFactor, animationFactor, (double)this.getPosX() + 2.5, (double)this.getPosY() + 2.5, (double)this.getPosX() + 2.5 + 30.0, (double)this.getPosY() + 2.5 + 30.0, 5.0, 10.0);
        RenderSystem.blendFunc((int)772, (int)773);
        RenderSystem.setShaderColor((float)animationFactor, (float)(animationFactor - hurtPercent / 2.0f), (float)(animationFactor - hurtPercent / 2.0f), (float)animationFactor);
        Render2DEngine.renderTexture(context.method_51448(), (double)this.getPosX() + 2.5, (double)this.getPosY() + 2.5, 30.0, 30.0, 8.0f, 8.0f, 8.0, 8.0, 64.0, 64.0);
        Render2DEngine.renderTexture(context.method_51448(), (double)this.getPosX() + 2.5, (double)this.getPosY() + 2.5, 30.0, 30.0, 40.0f, 8.0f, 8.0, 8.0, 64.0, 64.0);
        RenderSystem.defaultBlendFunc();
        context.method_51448().method_22909();
        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 38.0f, this.getPosY() + 25.0f, 52.0f, 7.0f, 2.0f, (float)((double)0.15f * this.animation.getAnimationd()));
            Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 38.0f, this.getPosY() + 25.0f, MathUtility.clamp(52.0f * (health / this.target.method_6063()), 8.0f, 52.0f), 7.0f, 2.0f, (float)this.animation.getAnimationd());
        } else {
            Render2DEngine.drawGradientRound(context.method_51448(), this.getPosX() + 38.0f, this.getPosY() + 25.0f, 52.0f, 7.0f, 2.0f, HudEditor.getColor(0).darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker());
            Render2DEngine.renderRoundedGradientRect(context.method_51448(), HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(0), HudEditor.getColor(270), this.getPosX() + 38.0f, this.getPosY() + 25.0f, (int)MathUtility.clamp(52.0f * (health / this.target.method_6063()), 8.0f, 52.0f), 7.0f, 2.0f);
        }
        FontRenderers.sf_bold_mini.drawCenteredString(context.method_51448(), (String)(this.hpMode.getValue() == HPmodeEn.HP ? String.valueOf((double)Math.round(10.0 * (double)this.getHealth()) / 10.0) : (double)Math.round(10.0 * (double)this.getHealth()) / 10.0 / 20.0 * 100.0 + "%"), (double)(this.getPosX() + 65.0f), (double)(this.getPosY() + 27.0f), Render2DEngine.applyOpacity(-1, animationFactor));
        FontRenderers.sf_bold_mini.drawString(context.method_51448(), ModuleManager.nameProtect.isEnabled() && this.target == TargetHud.mc.field_1724 ? NameProtect.getCustomName() : this.target.method_5477().getString(), (double)(this.getPosX() + 38.0f), (double)(this.getPosY() + 5.0f), Render2DEngine.applyOpacity(-1, animationFactor));
        FontRenderers.sf_medium_mini.drawString(context.method_51448(), bps, (double)(this.getPosX() + 38.0f), (double)(this.getPosY() + 14.0f), Render2DEngine.applyOpacity(new Color(0xBBBBBB), animationFactor));
        if (this.target instanceof class_1657) {
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)((float)MathUtility.clamp(this.animation.getAnimationd(), 0.0, 1.0)));
            class_2371 armor = ((class_1657)(Object)this.target).method_31548().field_7548;
            class_1799[] items = new class_1799[]{this.target.method_6047(), (class_1799)armor.get(3), (class_1799)armor.get(2), (class_1799)armor.get(1), (class_1799)armor.get(0), this.target.method_6079()};
            float xItemOffset = this.getPosX() + 38.0f;
            for (class_1799 itemStack : items) {
                context.method_51448().method_22903();
                context.method_51448().method_46416(xItemOffset, this.getPosY() + 13.0f, 0.0f);
                context.method_51448().method_22905(0.5f, 0.5f, 0.5f);
                context.method_51427(itemStack, 0, 0);
                context.method_51431(TargetHud.mc.field_1772, itemStack, 0, 0);
                context.method_51448().method_22909();
                xItemOffset += 9.0f;
            }
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }

    /*
     * WARNING - void declaration
     */
    private void renderThunderHack(class_332 context, float health, float animationFactor, String bps) {
        float hurtPercent;
        block15: {
            block17: {
                block16: {
                    hurtPercent = (float)this.target.field_6235 / 6.0f;
                    Render2DEngine.drawRound(context.method_51448(), this.getPosX(), this.getPosY(), 70.0f, 50.0f, 6.0f, new Color(0, 0, 0, 139));
                    Render2DEngine.drawRound(context.method_51448(), this.getPosX() + 50.0f, this.getPosY(), 100.0f, 50.0f, 6.0f, new Color(0, 0, 0, 255));
                    this.setBounds(this.getPosX(), this.getPosY(), 150.0f, 50.0f);
                    if (this.imageMode.is(ImageModeEn.None)) break block15;
                    if (!this.imageMode.is(ImageModeEn.Anime)) break block16;
                    RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.thudPic);
                    break block17;
                }
                if (custom == null) break block15;
                RenderSystem.setShaderTexture((int)0, (class_2960)custom);
            }
            context.method_51448().method_22903();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            Render2DEngine.drawRound(context.method_51448(), this.getPosX() + 50.0f, this.getPosY(), 100.0f, 50.0f, 12.0f, new Color(0, 0, 0, 255));
            RenderSystem.disableBlend();
            RenderSystem.setShaderColor((float)0.3f, (float)0.3f, (float)0.3f, (float)1.0f);
            Render2DEngine.renderTexture(context.method_51448(), this.getPosX() + 50.0f, this.getPosY(), 95.0, 50.0, 0.0f, 0.0f, 100.0, 50.0, 100.0, 50.0);
            context.method_51448().method_22909();
        }
        for (Particles particles : this.particles) {
            if (!(particles.opacity > 4.0)) continue;
            particles.render2D(context.method_51448());
        }
        if (this.timer.passedMs(16L)) {
            this.ticks += 0.1f;
            for (Particles particles : this.particles) {
                particles.updatePosition();
                if (!(particles.opacity < 1.0)) continue;
                this.particles.remove(particles);
            }
            this.timer.reset();
        }
        ArrayList<Particles> removeList = new ArrayList<Particles>();
        for (Particles p : this.particles) {
            if (!(p.opacity <= 1.0)) continue;
            removeList.add(p);
        }
        for (Particles p : removeList) {
            this.particles.remove(p);
        }
        if (this.target.field_6235 == 9 && !this.sentParticles) {
            int var7_13 = 0;
            boolean bl = false;
            boolean bl2 = false;
            while (var7_13 <= 6) {
                Particles p = new Particles();
                Color c = Particles.mixColors(this.color.getValue().getColorObject(), this.color2.getValue().getColorObject(), (Math.sin(this.ticks + this.getPosX() * 0.4f + (float)var7_13) + 1.0) * 0.5);
                p.init(this.getPosX(), this.getPosY(), MathUtility.random(-3.0f, 3.0f), MathUtility.random(-3.0f, 3.0f), 20.0, c);
                this.particles.add(p);
                ++var7_13;
            }
            this.sentParticles = true;
        }
        if (this.target.field_6235 == 8) {
            this.sentParticles = false;
        }
        float f = hurtPercent;
        headAnimation.setValue(f);
        if (this.target instanceof class_1657) {
            RenderSystem.setShaderTexture((int)0, (class_2960)((class_742)(Object)this.target).method_52814().comp_1626());
        } else {
            RenderSystem.setShaderTexture((int)0, (class_2960)mc.method_1561().method_3953((class_1297)(Object)this.target).method_3931((class_1297)(Object)this.target));
        }
        context.method_51448().method_22903();
        context.method_51448().method_22904((double)this.getPosX() + 2.5 + 15.0, (double)this.getPosY() + 2.5 + 15.0, 0.0);
        context.method_51448().method_22905(1.0f - hurtPercent / 20.0f, 1.0f - hurtPercent / 20.0f, 1.0f);
        context.method_51448().method_22904(-((double)this.getPosX() + 2.5 + 15.0), -((double)this.getPosY() + 2.5 + 15.0), 0.0);
        RenderSystem.enableBlend();
        RenderSystem.colorMask((boolean)false, (boolean)false, (boolean)false, (boolean)true);
        RenderSystem.clearColor((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        RenderSystem.clear((int)16384, (boolean)false);
        RenderSystem.colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
        RenderSystem.setShader(class_757::method_34540);
        Render2DEngine.renderRoundedQuadInternal(context.method_51448().method_23760().method_23761(), animationFactor, animationFactor, animationFactor, animationFactor, (double)this.getPosX() + 2.5, (double)this.getPosY() + 2.5, (double)this.getPosX() + 2.5 + 45.0, (double)this.getPosY() + 2.5 + 45.0, 5.0, 10.0);
        RenderSystem.blendFunc((int)772, (int)773);
        RenderSystem.setShaderColor((float)animationFactor, (float)(animationFactor - hurtPercent / 2.0f), (float)(animationFactor - hurtPercent / 2.0f), (float)animationFactor);
        Render2DEngine.renderTexture(context.method_51448(), (double)this.getPosX() + 2.5, (double)this.getPosY() + 2.5, 45.0, 45.0, 8.0f, 8.0f, 8.0, 8.0, 64.0, 64.0);
        Render2DEngine.renderTexture(context.method_51448(), (double)this.getPosX() + 2.5, (double)this.getPosY() + 2.5, 45.0, 45.0, 40.0f, 8.0f, 8.0, 8.0, 64.0, 64.0);
        RenderSystem.defaultBlendFunc();
        context.method_51448().method_22909();
        healthAnimation.setValue(health);
        health = (float)healthAnimation.getAnimationD();
        Render2DEngine.drawBlurredShadow(context.method_51448(), this.getPosX() + 55.0f, this.getPosY() + 22.0f, 90.0f, 8.0f, this.blurRadius.getValue(), HudEditor.getColor(0));
        Render2DEngine.drawGradientRound(context.method_51448(), this.getPosX() + 55.0f, this.getPosY() + 35.0f - 14.0f, 90.0f, 10.0f, 2.0f, HudEditor.getColor(0).darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker(), HudEditor.getColor(0).darker().darker().darker().darker());
        Render2DEngine.renderRoundedGradientRect(context.method_51448(), HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(0), HudEditor.getColor(270), this.getPosX() + 55.0f, this.getPosY() + 35.0f - 14.0f, (int)MathUtility.clamp(90.0f * (health / this.target.method_6063()), 3.0f, 90.0f), 10.0f, 2.0f);
        FontRenderers.sf_bold.drawCenteredString(context.method_51448(), (String)(this.hpMode.getValue() == HPmodeEn.HP ? String.valueOf((double)Math.round(10.0 * (double)this.getHealth()) / 10.0) : (int)((double)Math.round(10.0 * (double)health) / 10.0 / 20.0 * 100.0) + "%"), (double)(this.getPosX() + 102.0f), (double)(this.getPosY() + 24.0f), Render2DEngine.applyOpacity(-1, animationFactor));
        FontRenderers.sf_bold.drawString(context.method_51448(), ModuleManager.nameProtect.isEnabled() && this.target == TargetHud.mc.field_1724 ? NameProtect.getCustomName() : this.target.method_5477().getString(), (double)(this.getPosX() + 55.0f), (double)(this.getPosY() + 5.0f), Render2DEngine.applyOpacity(-1, animationFactor));
        FontRenderers.sf_medium_mini.drawString(context.method_51448(), bps, (double)(this.getPosX() + 55.0f), (double)(this.getPosY() + 15.0f), Render2DEngine.applyOpacity(new Color(0xBBBBBB), animationFactor));
        if (this.target instanceof class_1657) {
            class_2371 armor = ((class_1657)(Object)this.target).method_31548().field_7548;
            class_1799[] items = new class_1799[]{this.target.method_6047(), (class_1799)armor.get(3), (class_1799)armor.get(2), (class_1799)armor.get(1), (class_1799)armor.get(0), this.target.method_6079()};
            float xItemOffset = this.getPosX() + 60.0f;
            for (class_1799 itemStack : items) {
                if (itemStack.method_7960()) continue;
                context.method_51448().method_22903();
                context.method_51448().method_46416(xItemOffset, this.getPosY() + 35.0f, 0.0f);
                context.method_51448().method_22905(0.75f, 0.75f, 0.75f);
                context.method_51427(itemStack, 0, 0);
                context.method_51431(TargetHud.mc.field_1772, itemStack, 0, 0);
                context.method_51448().method_22909();
                xItemOffset += 14.0f;
            }
            this.drawPotionEffect(context.method_51448(), (class_1657)(Object)this.target);
        }
    }

    private void celestialArmor(class_332 context, class_1657 target, float posX, float posY) {
        for (int i = 0; i < 4; ++i) {
            if (((class_1799)target.method_31548().field_7548.get(3 - i)).method_7960()) continue;
            context.method_51448().method_22903();
            context.method_51448().method_46416(posX + (float)(i > 1 ? 138 : 118), posY + (float)(i % 2 == 0 ? 5 : 26), 0.0f);
            context.method_51427((class_1799)target.method_31548().field_7548.get(3 - i), 0, 0);
            context.method_51431(TargetHud.mc.field_1772, (class_1799)target.method_31548().field_7548.get(3 - i), 0, 0);
            context.method_51448().method_22909();
        }
    }

    private void celestialHands(class_332 context, class_1657 target, float posX, float posY) {
        for (int i = 0; i < 2; ++i) {
            if ((i == 0 ? target.method_6047() : target.method_6079()).method_7960()) continue;
            context.method_51448().method_22903();
            context.method_51448().method_46416(posX + (float)(i == 0 ? 50 : 77), posY + 14.0f, 0.0f);
            context.method_51448().method_22905(0.75f, 0.75f, 1.0f);
            context.method_51427(i == 0 ? target.method_6047() : target.method_6079(), 0, 0);
            context.method_51448().method_22909();
            FontRenderers.settings.drawString(context.method_51448(), "x" + (i == 0 ? target.method_6047() : target.method_6079()).method_7947(), (double)(posX + (float)(i == 0 ? 50 : 77) + 12.0f), (double)(posY + 21.0f), -1);
        }
    }

    private void drawPotionEffect(class_4587 ms, class_1657 entity) {
        StringBuilder finalString = new StringBuilder();
        for (class_1293 potionEffect : entity.method_6026()) {
            class_1291 potion = (class_1291)potionEffect.method_5579().comp_349();
            if (potion != class_1294.field_5924.comp_349() && potion != class_1294.field_5904.comp_349() && potion != class_1294.field_5910.comp_349() && potion != class_1294.field_5911.comp_349()) continue;
            boolean potRanOut = (double)potionEffect.method_5584() != 0.0;
            boolean bl = potRanOut;
            if (!entity.method_6059(potionEffect.method_5579()) || !potRanOut) continue;
            finalString.append(TargetHud.getPotionName(potion)).append(potionEffect.method_5578() < 1 ? "" : Integer.valueOf(potionEffect.method_5578() + 1)).append(" ").append(this.getDurationString(potionEffect)).append(" ");
        }
        FontRenderers.settings.drawString(ms, finalString.toString(), (double)(this.getPosX() + 55.0f), (double)(this.getPosY() + 15.0f), new Color(0x8D8D8D).getRGB());
    }

    public float getHealth() {
        class_1309 class_13092 = this.target;
        if (class_13092 instanceof class_1657) {
            class_1657 ent = (class_1657)class_13092;
            if (mc.method_1562() != null && mc.method_1562().method_45734() != null && TargetHud.mc.method_1562().method_45734().field_3761.contains("funtime") || this.scoreboardHp.getValue().booleanValue()) {
                class_266 scoreBoard = null;
                String resolvedHp = "";
                if (ent.method_7327().method_1189(class_8646.field_45158) != null && (scoreBoard = ent.method_7327().method_1189(class_8646.field_45158)) != null) {
                    class_9013 readableScoreboardScore = ent.method_7327().method_55430((class_9015)ent, scoreBoard);
                    class_5250 text2 = class_9013.method_55398((class_9013)readableScoreboardScore, (class_9022)scoreBoard.method_55380((class_9022)class_9025.field_47566));
                    resolvedHp = text2.getString();
                }
                float numValue = 0.0f;
                try {
                    numValue = Float.parseFloat(resolvedHp);
                }
                catch (NumberFormatException numberFormatException) {
                    // empty catch block
                }
                return this.absorp.getValue() != false ? numValue + this.target.method_6067() : numValue;
            }
        }
        return this.absorp.getValue() != false ? this.target.method_6032() + this.target.method_6067() : this.target.method_6032();
    }

    public static void sizeAnimation(class_4587 matrixStack, double width, double height, double animation) {
        matrixStack.method_22904(width, height, 0.0);
        matrixStack.method_22905((float)animation, (float)animation, 1.0f);
        matrixStack.method_22904(-width, -height, 0.0);
    }

    public static String getPotionName(class_1291 p) {
        if (p == class_1294.field_5924.comp_349()) {
            return "Reg";
        }
        if (p == class_1294.field_5910.comp_349()) {
            return "Str";
        }
        if (p == class_1294.field_5904.comp_349()) {
            return "Spd";
        }
        if (p == class_1294.field_5917.comp_349()) {
            return "H";
        }
        if (p == class_1294.field_5911.comp_349()) {
            return "W";
        }
        if (p == class_1294.field_5907.comp_349()) {
            return "Res";
        }
        return "pon";
    }

    static {
        healthAnimation = new EaseOutCirc();
        headAnimation = new EaseOutCirc();
    }

    public static enum HPmodeEn {
        HP,
        Percentage;

    }

    public static enum ImageModeEn {
        None,
        Anime,
        Custom;

    }

    public static enum ModeEn {
        ThunderHack,
        NurikZapen,
        CelkaPasta;

    }
}

