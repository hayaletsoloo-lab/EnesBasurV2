/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.RotationAxis
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.class_124;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_7833;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.misc.NameProtect;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextUtil;
import thunder.hack.utility.render.TextureStorage;

public class WaterMark
extends HudElement {
    public static final Setting<Mode> mode = new Setting<Mode>("Mode", Mode.Big);
    private final Setting<Boolean> ru = new Setting<Boolean>("RU", false);
    private final TextUtil textUtil = new TextUtil("\u0422\u0430\u043d\u0434\u0435\u0440\u0425\u0430\u043a", "\u0413\u0440\u043e\u043c\u0425\u0430\u043a", "\u0413\u0440\u043e\u0437\u0430\u041a\u043b\u0438\u0435\u043d\u0442", "\u0422\u0430\u043d\u0434\u0435\u0440\u0425\u0443\u0439", "\u0422\u0430\u043d\u0434\u0435\u0440\u0425\u0440\u044f\u043a", "\u0422\u0430\u043d\u0434\u0435\u0440\u0425\u0440\u044e\u043a", "\u0422\u0438\u043d\u0434\u0435\u0440\u0425\u0430\u043a", "\u0422\u0443\u043d\u0434\u0440\u0430\u0425\u0430\u043a", "\u0413\u0440\u043e\u043c\u0412\u0437\u043b\u043e\u043c");

    public WaterMark() {
        super("WaterMark", 100, 35);
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        String username = ModuleManager.nameProtect.isEnabled() ? NameProtect.getCustomName() : mc.method_1548().method_1676();
        String string = username;
        if (mode.getValue() == Mode.Big) {
            Render2DEngine.drawHudBase(context.method_51448(), this.getPosX(), this.getPosY(), 106.0f, 30.0f, HudEditor.hudRound.getValue().floatValue());
            FontRenderers.thglitch.drawString(context.method_51448(), "THUNDERHACK", (double)this.getPosX() + 5.5, (double)(this.getPosY() + 5.0f), -1);
            FontRenderers.monsterrat.drawGradientString(context.method_51448(), "recode", this.getPosX() + 35.5f, this.getPosY() + 21.0f, 1);
            this.setBounds(this.getPosX(), this.getPosY(), 106.0f, 30.0f);
        } else if (mode.getValue() == Mode.Small) {
            if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
                float offset1 = FontRenderers.sf_bold.getStringWidth(username) + 72.0f;
                float offset2 = FontRenderers.sf_bold.getStringWidth(mc.method_1542() ? "SinglePlayer" : WaterMark.mc.method_1562().method_45734().field_3761);
                float offset3 = Managers.PROXY.isActive() ? FontRenderers.sf_bold.getStringWidth(Managers.PROXY.getActiveProxy().getName()) + 11.0f : 0.0f;
                Render2DEngine.drawRoundedBlur(context.method_51448(), this.getPosX(), this.getPosY(), 50.0f, 15.0f, 3.0f, HudEditor.blurColor.getValue().getColorObject());
                Render2DEngine.drawRoundedBlur(context.method_51448(), this.getPosX() + 55.0f, this.getPosY(), offset1 + offset2 - 36.0f + offset3, 15.0f, 3.0f, HudEditor.blurColor.getValue().getColorObject());
                Render2DEngine.setupRender();
                Render2DEngine.drawRect(context.method_51448(), this.getPosX() + 13.0f, this.getPosY() + 1.5f, 0.5f, 11.0f, new Color(0x44FFFFFF, true));
                FontRenderers.sf_bold.drawGradientString(context.method_51448(), "Recode", this.getPosX() + 18.0f, this.getPosY() + 5.0f, 20);
                RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.miniLogo);
                Render2DEngine.renderGradientTexture(context.method_51448(), this.getPosX() + 1.0f, this.getPosY() + 2.0f, 11.0, 11.0, 0.0f, 0.0f, 128.0, 128.0, 128.0, 128.0, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.playerIcon);
                Render2DEngine.renderGradientTexture(context.method_51448(), this.getPosX() + 58.0f, this.getPosY() + 3.0f, 8.0, 8.0, 0.0f, 0.0f, 128.0, 128.0, 128.0, 128.0, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
                RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.serverIcon);
                Render2DEngine.renderGradientTexture(context.method_51448(), this.getPosX() + offset1, this.getPosY() + 2.0f, 10.0, 10.0, 0.0f, 0.0f, 128.0, 128.0, 128.0, 128.0, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
                if (Managers.PROXY.isActive()) {
                    RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.proxyIcon);
                    Render2DEngine.renderGradientTexture(context.method_51448(), this.getPosX() + offset1 + offset2 + 16.0f, this.getPosY() + 2.0f, 10.0, 10.0, 0.0f, 0.0f, 128.0, 128.0, 128.0, 128.0, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
                    FontRenderers.sf_bold.drawString(context.method_51448(), Managers.PROXY.getActiveProxy().getName(), (double)(this.getPosX() + offset1 + offset2 + 28.0f), (double)(this.getPosY() + 5.0f), -1);
                }
                Render2DEngine.endRender();
                Render2DEngine.setupRender();
                RenderSystem.defaultBlendFunc();
                FontRenderers.sf_bold.drawString(context.method_51448(), username, (double)(this.getPosX() + 68.0f), (double)(this.getPosY() + 4.5f), HudEditor.textColor.getValue().getColor());
                FontRenderers.sf_bold.drawString(context.method_51448(), mc.method_1542() ? "SinglePlayer" : WaterMark.mc.method_1562().method_45734().field_3761, (double)(this.getPosX() + offset1 + 13.0f), (double)(this.getPosY() + 4.5f), HudEditor.textColor.getValue().getColor());
                Render2DEngine.endRender();
                this.setBounds(this.getPosX(), this.getPosY(), 100.0f, 15.0f);
            } else {
                String info = String.valueOf(class_124.field_1063) + "| " + String.valueOf(class_124.field_1070) + username + String.valueOf(class_124.field_1063) + " | " + String.valueOf(class_124.field_1070) + Managers.SERVER.getPing() + " ms" + String.valueOf(class_124.field_1063) + " | " + String.valueOf(class_124.field_1070) + (mc.method_1542() ? "SinglePlayer" : WaterMark.mc.method_1562().method_45734().field_3761);
                float width = FontRenderers.sf_bold.getStringWidth("ThunderHack " + info) + 5.0f;
                Render2DEngine.drawHudBase(context.method_51448(), this.getPosX(), this.getPosY(), width, 10.0f, 3.0f);
                FontRenderers.sf_bold.drawGradientString(context.method_51448(), (String)(this.ru.getValue() != false ? String.valueOf(this.textUtil) + " " : "ThunderHack "), this.getPosX() + 2.0f, this.getPosY() + 2.5f, 10);
                FontRenderers.sf_bold.drawString(context.method_51448(), info, (double)(this.getPosX() + 2.0f + FontRenderers.sf_bold.getStringWidth("ThunderHack ")), (double)(this.getPosY() + 2.5f), HudEditor.textColor.getValue().getColor());
                this.setBounds(this.getPosX(), this.getPosY(), width, 10.0f);
            }
        } else if (mode.getValue() == Mode.BaltikaClient) {
            Render2DEngine.drawHudBase(context.method_51448(), this.getPosX(), this.getPosY(), 100.0f, 64.0f, HudEditor.hudRound.getValue().floatValue());
            Render2DEngine.addWindow(context.method_51448(), this.getPosX(), this.getPosY(), this.getPosX() + 100.0f, this.getPosY() + 64.0f, 1.0);
            context.method_51448().method_22903();
            context.method_51448().method_46416(this.getPosX() + 10.0f, this.getPosY() + 32.0f, 0.0f);
            context.method_51448().method_22907(class_7833.field_40718.rotation((float)Math.toRadians((float)(WaterMark.mc.field_1724.field_6012 * 3) + Render3DEngine.getTickDelta())));
            context.method_51448().method_46416(-(this.getPosX() + 10.0f), -(this.getPosY() + 32.0f), 0.0f);
            context.method_25290(TextureStorage.baltika, (int)this.getPosX() - 10, (int)this.getPosY() + 2, 0.0f, 0.0f, 40, 64, 40, 64);
            context.method_51448().method_22909();
            Render2DEngine.popWindow();
            FontRenderers.thglitch.drawString(context.method_51448(), "BALTIKA", (double)(this.getPosX() + 43.0f), (double)this.getPosY() + 41.5, -1);
            this.setBounds(this.getPosX(), this.getPosY(), 100.0f, 64.0f);
        } else if (mode.is(Mode.Rifk)) {
            Date date = new Date(System.currentTimeMillis());
            SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
            String info = String.valueOf(class_124.field_1060) + String.format("th7 | build: 16/06/2024 | rate: %d | %s", Math.round(Managers.SERVER.getTPS()), format.format(date));
            float width = FontRenderers.profont.getStringWidth(info) + 5.0f;
            Render2DEngine.drawRectWithOutline(context.method_51448(), this.getPosX(), this.getPosY(), width, 8.0f, Color.decode("#192A1A"), Color.decode("#833B7B"));
            Render2DEngine.drawGradientBlurredShadow1(context.method_51448(), this.getPosX(), this.getPosY(), width, 8.0f, 10, Color.decode("#161A1E"), Color.decode("#161A1E"), Color.decode("#382E37"), Color.decode("#382E37"));
            FontRenderers.profont.drawString(context.method_51448(), info, (double)this.getPosX() + 2.7, (double)this.getPosY() + 2.953, HudEditor.textColor.getValue().getColor());
            this.setBounds(this.getPosX(), this.getPosY(), width, 8.0f);
        } else {
            FontRenderers.monsterrat.drawGradientString(context.method_51448(), "ThunderHack v1.7b2407", this.getPosX() + 5.5f, this.getPosY() + 5.0f, 10);
            this.setBounds(this.getPosX(), this.getPosY(), 100.0f, 3.0f);
        }
    }

    @Override
    public void onUpdate() {
        this.textUtil.tick();
    }

    private static enum Mode {
        Big,
        Small,
        Classic,
        BaltikaClient,
        Rifk;

    }
}

