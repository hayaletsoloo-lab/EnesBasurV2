/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.entity.effect.StatusEffect
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.util.Formatting
 */
package thunder.hack.features.hud.impl;

import java.awt.Color;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_332;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.animation.AnimationUtility;

public class PotionHud
extends HudElement {
    private float vAnimation;
    private float hAnimation;
    private final Setting<Boolean> colored = new Setting<Boolean>("Colored", false);

    public PotionHud() {
        super("Potions", 100, 100);
    }

    public static String getDuration(class_1293 pe) {
        if (pe.method_48559()) {
            return "*:*";
        }
        int var1 = pe.method_5584();
        int mins = var1 / 1200;
        String sec = String.format("%02d", var1 % 1200 / 20);
        return mins + ":" + sec;
    }

    @Override
    public void onRender2D(class_332 context) {
        class_1291 potion;
        super.onRender2D(context);
        int y_offset1 = 0;
        float max_width = 50.0f;
        float pointerX = 0.0f;
        for (class_1293 potionEffect : PotionHud.mc.field_1724.method_6026()) {
            float timeWidth;
            potion = (class_1291)potionEffect.method_5579().comp_349();
            if (y_offset1 == 0) {
                y_offset1 += 4;
            }
            y_offset1 += 9;
            float nameWidth = FontRenderers.sf_bold_mini.getStringWidth(potion.method_5560().getString() + " " + (potionEffect.method_5578() + 1));
            float width = (nameWidth + (timeWidth = FontRenderers.sf_bold_mini.getStringWidth(PotionHud.getDuration(potionEffect)))) * 1.4f;
            if (width > max_width) {
                max_width = width;
            }
            if (!(timeWidth > pointerX)) continue;
            pointerX = timeWidth;
        }
        this.vAnimation = AnimationUtility.fast(this.vAnimation, 14 + y_offset1, 15.0f);
        this.hAnimation = AnimationUtility.fast(this.hAnimation, max_width, 15.0f);
        Render2DEngine.drawHudBase(context.method_51448(), this.getPosX(), this.getPosY(), this.hAnimation, this.vAnimation, HudEditor.hudRound.getValue().floatValue());
        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Glowing)) {
            FontRenderers.sf_bold.drawCenteredString(context.method_51448(), "Potions", (double)(this.getPosX() + this.hAnimation / 2.0f), (double)(this.getPosY() + 4.0f), HudEditor.textColor.getValue().getColorObject());
        } else {
            FontRenderers.sf_bold.drawGradientCenteredString(context.method_51448(), "Potions", this.getPosX() + this.hAnimation / 2.0f, this.getPosY() + 4.0f, 10);
        }
        if (y_offset1 > 0) {
            if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
                Render2DEngine.drawRectDumbWay(context.method_51448(), this.getPosX() + 4.0f, this.getPosY() + 13.0f, this.getPosX() + this.getWidth() - 4.0f, this.getPosY() + 13.5f, new Color(0x54FFFFFF, true));
            } else {
                Render2DEngine.horizontalGradient(context.method_51448(), this.getPosX() + 2.0f, this.getPosY() + 13.7f, this.getPosX() + 2.0f + this.hAnimation / 2.0f - 2.0f, this.getPosY() + 14.0f, Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0), HudEditor.textColor.getValue().getColorObject());
                Render2DEngine.horizontalGradient(context.method_51448(), this.getPosX() + 2.0f + this.hAnimation / 2.0f - 2.0f, this.getPosY() + 13.7f, this.getPosX() + 2.0f + this.hAnimation - 4.0f, this.getPosY() + 14.0f, HudEditor.textColor.getValue().getColorObject(), Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0));
            }
        }
        Render2DEngine.addWindow(context.method_51448(), this.getPosX(), this.getPosY(), this.getPosX() + this.hAnimation, this.getPosY() + this.vAnimation, 1.0);
        int y_offset = 0;
        for (class_1293 potionEffect : PotionHud.mc.field_1724.method_6026()) {
            potion = (class_1291)potionEffect.method_5579().comp_349();
            float px = this.getPosX() + (max_width - pointerX - 10.0f);
            context.method_51448().method_22903();
            context.method_51448().method_46416(this.getPosX() + 2.0f, this.getPosY() + 16.0f + (float)y_offset, 0.0f);
            context.method_25298(0, 0, 0, 8, 8, mc.method_18505().method_18663(potionEffect.method_5579()));
            context.method_51448().method_22909();
            FontRenderers.sf_bold_mini.drawString(context.method_51448(), potion.method_5560().getString() + " " + String.valueOf(class_124.field_1061) + (potionEffect.method_5578() + 1), (double)(this.getPosX() + 12.0f), (double)(this.getPosY() + 19.0f + (float)y_offset), HudEditor.textColor.getValue().getColor());
            FontRenderers.sf_bold_mini.drawCenteredString(context.method_51448(), PotionHud.getDuration(potionEffect), (double)(px + (this.getPosX() + max_width - px) / 2.0f), (double)(this.getPosY() + 19.0f + (float)y_offset), HudEditor.textColor.getValue().getColor());
            Render2DEngine.drawRect(context.method_51448(), px, this.getPosY() + 17.0f + (float)y_offset, 0.5f, 8.0f, new Color(0x44FFFFFF, true));
            y_offset += 9;
        }
        Render2DEngine.popWindow();
        this.setBounds(this.getPosX(), this.getPosY(), this.hAnimation, this.vAnimation);
    }
}

