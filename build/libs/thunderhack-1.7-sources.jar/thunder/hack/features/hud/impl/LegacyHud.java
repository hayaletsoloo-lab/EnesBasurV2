/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.entity.effect.StatusEffect
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.item.ItemConvertible
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.registry.RegistryKeys
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.Pair
 *  net.minecraft.world.biome.Biome
 *  org.apache.commons.lang3.StringUtils
 */
package thunder.hack.features.hud.impl;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Objects;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3545;
import net.minecraft.class_408;
import net.minecraft.class_7924;
import org.apache.commons.lang3.StringUtils;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.hud.impl.PotionHud;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.font.FontRenderer;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.math.FrameRateCounter;
import thunder.hack.utility.math.MathUtility;

public class LegacyHud
extends Module {
    private static final class_1799 totem = new class_1799((class_1935)class_1802.field_8288);
    private final Setting<Font> customFont = new Setting<Font>("Font", Font.Minecraft);
    private final Setting<ColorSetting> colorSetting = new Setting<ColorSetting>("Color", new ColorSetting(new Color(30719)));
    private final Setting<Boolean> renderingUp = new Setting<Boolean>("RenderingUp", false);
    private final Setting<Boolean> waterMark = new Setting<Boolean>("Watermark", false);
    private final Setting<Boolean> arrayList = new Setting<Boolean>("ActiveModules", false);
    private final Setting<Boolean> coords = new Setting<Boolean>("Coords", false);
    private final Setting<Boolean> direction = new Setting<Boolean>("Direction", false);
    private final Setting<Boolean> armor = new Setting<Boolean>("Armor", false);
    private final Setting<Boolean> totems = new Setting<Boolean>("Totems", false);
    private final Setting<Boolean> greeter = new Setting<Boolean>("Welcomer", false);
    private final Setting<Boolean> speed = new Setting<Boolean>("Speed", false);
    private final Setting<Boolean> bps = new Setting<Boolean>("BPS", false, v -> this.speed.getValue());
    public final Setting<Boolean> potions = new Setting<Boolean>("Potions", false);
    private final Setting<Boolean> ping = new Setting<Boolean>("Ping", false);
    private final Setting<Boolean> tps = new Setting<Boolean>("TPS", false);
    private final Setting<Boolean> extraTps = new Setting<Boolean>("ExtraTPS", true, v -> this.tps.getValue());
    private final Setting<Boolean> offhandDurability = new Setting<Boolean>("OffhandDurability", false);
    private final Setting<Boolean> mainhandDurability = new Setting<Boolean>("MainhandDurability", false);
    private final Setting<Boolean> fps = new Setting<Boolean>("FPS", false);
    private final Setting<Boolean> chests = new Setting<Boolean>("Chests", false);
    private final Setting<Boolean> worldTime = new Setting<Boolean>("WorldTime", false);
    private final Setting<Boolean> biome = new Setting<Boolean>("Biome", false);
    public Setting<Boolean> time = new Setting<Boolean>("Time", false);
    public Setting<Integer> waterMarkY = new Setting<Integer>("WatermarkPosY", 2, 0, 20, v -> this.waterMark.getValue());
    private int color;

    public LegacyHud() {
        super("LegacyHud", Module.Category.HUD);
    }

    @Override
    public void onRender2D(class_332 context) {
        String str;
        int n2;
        String str2;
        int i = 0;
        int j = 0;
        if (LegacyHud.fullNullCheck()) {
            return;
        }
        int width = mc.method_22683().method_4486();
        int height = mc.method_22683().method_4502();
        int offset = switch (this.customFont.getValue().ordinal()) {
            case 0 -> 10;
            case 2 -> 9;
            default -> 8;
        };
        this.color = this.colorSetting.getValue().getColor();
        if (this.waterMark.getValue().booleanValue()) {
            this.drawText(context, "thunderhack v1.7b2407", 2, this.waterMarkY.getValue());
        }
        j = LegacyHud.mc.field_1755 instanceof class_408 && this.renderingUp.getValue() == false ? 14 : 0;
        int n = j;
        if (this.arrayList.getValue().booleanValue()) {
            for (Module module2 : Managers.MODULE.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> this.getStringWidth(module.getFullArrayString()) * -1)).toList()) {
                if (!module2.isDrawn()) continue;
                str2 = module2.getDisplayName() + String.valueOf(class_124.field_1080) + (String)(module2.getDisplayInfo() != null ? " [" + String.valueOf(class_124.field_1068) + module2.getDisplayInfo() + String.valueOf(class_124.field_1080) + "]" : "");
                if (this.renderingUp.getValue().booleanValue()) {
                    this.drawText(context, str2, width - 2 - this.getStringWidth(str2), 2 + j * offset);
                    ++j;
                    continue;
                }
                this.drawText(context, str2, width - 2 - this.getStringWidth(str2), height - (j += offset));
            }
        }
        int n3 = LegacyHud.mc.field_1755 instanceof class_408 && this.renderingUp.getValue() != false ? 13 : (n2 = (i = this.renderingUp.getValue() != false ? -2 : 0));
        if (this.potions.getValue().booleanValue()) {
            ArrayList<class_1293> effects = new ArrayList<>(LegacyHud.mc.field_1724.method_6026());
            for (class_1293 potionEffect : effects) {
                class_1291 potion = (class_1291)potionEffect.method_5579().comp_349();
                String power = "";
                switch (potionEffect.method_5578()) {
                    case 0: {
                        power = "I";
                        break;
                    }
                    case 1: {
                        power = "II";
                        break;
                    }
                    case 2: {
                        power = "III";
                        break;
                    }
                    case 3: {
                        power = "IV";
                        break;
                    }
                    case 4: {
                        power = "V";
                    }
                }
                String s = potion.method_5560().getString() + " " + power;
                String s2 = PotionHud.getDuration(potionEffect);
                Color c = new Color(((class_1291)potionEffect.method_5579().comp_349()).method_5556());
                if (this.renderingUp.getValue().booleanValue()) {
                    this.drawText(context, s + " " + s2, width - this.getStringWidth(s + " " + s2) - 2, height - 2 - (i += offset), c.getRGB());
                    continue;
                }
                this.drawText(context, s + " " + s2, width - this.getStringWidth(s + " " + s2) - 2, 2 + i++ * offset, c.getRGB());
            }
        }
        if (this.worldTime.getValue().booleanValue()) {
            String str22 = "WorldTime: " + String.valueOf(class_124.field_1068) + LegacyHud.mc.field_1687.method_8532() % 24000L;
            this.drawText(context, str22, width - this.getStringWidth(str22) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.mainhandDurability.getValue().booleanValue()) {
            str = "MainHand" + String.valueOf(class_124.field_1068) + " [" + (LegacyHud.mc.field_1724.method_6047().method_7936() - LegacyHud.mc.field_1724.method_6047().method_7919()) + "]";
            this.drawText(context, str, width - this.getStringWidth(str) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.tps.getValue().booleanValue()) {
            str = "TPS " + String.valueOf(class_124.field_1068) + Managers.SERVER.getTPS() + (String)(this.extraTps.getValue() != false ? " [" + Managers.SERVER.getTPS2() + "]" : "");
            this.drawText(context, str, width - this.getStringWidth(str) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.speed.getValue().booleanValue()) {
            str = "Speed " + String.valueOf(class_124.field_1068) + MathUtility.round(Managers.PLAYER.currentPlayerSpeed * (this.bps.getValue() != false ? 20.0f : 72.0f) * ThunderHack.TICK_TIMER) + (this.bps.getValue() != false ? " b/s" : " km/h");
            this.drawText(context, str, width - this.getStringWidth(str) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.chests.getValue().booleanValue()) {
            class_3545<Integer, Integer> chests = ModuleManager.chestCounter.getChestCount();
            str2 = "Chests: " + String.valueOf(class_124.field_1068) + "S:" + String.valueOf(chests.method_15442()) + " D:" + String.valueOf(chests.method_15441());
            this.drawText(context, str2, width - this.getStringWidth(str2) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.biome.getValue().booleanValue()) {
            String str3 = "Biome: " + String.valueOf(class_124.field_1068) + LegacyHud.biome();
            this.drawText(context, str3, width - this.getStringWidth(str3) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.time.getValue().booleanValue()) {
            str = "Time " + String.valueOf(class_124.field_1068) + new SimpleDateFormat("h:mm a").format(new Date());
            this.drawText(context, str, width - this.getStringWidth(str) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.offhandDurability.getValue().booleanValue()) {
            str = "OffHand" + String.valueOf(class_124.field_1068) + " [" + (LegacyHud.mc.field_1724.method_6079().method_7936() - LegacyHud.mc.field_1724.method_6079().method_7919()) + "]";
            this.drawText(context, str, width - this.getStringWidth(str) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.ping.getValue().booleanValue()) {
            String str1 = "Ping " + String.valueOf(class_124.field_1068) + Managers.SERVER.getPing();
            this.drawText(context, str1, width - this.getStringWidth(str1) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        if (this.fps.getValue().booleanValue()) {
            String fpsText = "FPS " + String.valueOf(class_124.field_1068) + FrameRateCounter.INSTANCE.getFps();
            this.drawText(context, fpsText, width - this.getStringWidth(fpsText) - 2, this.renderingUp.getValue() != false ? height - 2 - (i += offset) : 2 + i++ * offset);
        }
        boolean inHell = Objects.equals(LegacyHud.mc.field_1687.method_27983().method_29177().method_12832(), "the_nether");
        int posX = (int)LegacyHud.mc.field_1724.method_23317();
        int posY = (int)LegacyHud.mc.field_1724.method_23318();
        int posZ = (int)LegacyHud.mc.field_1724.method_23321();
        float nether = !inHell ? 0.125f : 8.0f;
        int hposX = (int)(LegacyHud.mc.field_1724.method_23317() * (double)nether);
        int hposZ = (int)(LegacyHud.mc.field_1724.method_23321() * (double)nether);
        i = LegacyHud.mc.field_1755 instanceof class_408 ? 14 : 0;
        String coordinates = String.valueOf(class_124.field_1068) + "XYZ " + String.valueOf(class_124.field_1070) + (inHell ? posX + ", " + posY + ", " + posZ + String.valueOf(class_124.field_1068) + " [" + String.valueOf(class_124.field_1070) + hposX + ", " + hposZ + String.valueOf(class_124.field_1068) + "]" + String.valueOf(class_124.field_1070) : posX + ", " + posY + ", " + posZ + String.valueOf(class_124.field_1068) + " [" + String.valueOf(class_124.field_1070) + hposX + ", " + hposZ + String.valueOf(class_124.field_1068) + "]");
        Object direction1 = "";
        i += offset;
        if (this.direction.getValue().booleanValue()) {
            switch (LegacyHud.mc.field_1724.method_5735()) {
                case field_11034: {
                    direction1 = "East" + String.valueOf(class_124.field_1068) + " [+X]";
                    break;
                }
                case field_11039: {
                    direction1 = "West" + String.valueOf(class_124.field_1068) + " [-X]";
                    break;
                }
                case field_11043: {
                    direction1 = "North" + String.valueOf(class_124.field_1068) + " [-Z]";
                    break;
                }
                case field_11035: {
                    direction1 = "South" + String.valueOf(class_124.field_1068) + " [+Z]";
                }
            }
            this.drawText(context, (String)direction1, 2, height - i - 11);
        }
        if (this.coords.getValue().booleanValue()) {
            this.drawText(context, coordinates, 2, height - i);
        }
        if (this.armor.getValue().booleanValue()) {
            this.renderArmorHUD(true, context);
        }
        if (this.totems.getValue().booleanValue()) {
            this.renderTotemHUD(context);
        }
        if (this.greeter.getValue().booleanValue()) {
            this.renderGreeter(context);
        }
    }

    private void drawText(class_332 context, String str, int x, int y, int color) {
        if (!this.customFont.getValue().equals(Font.Minecraft)) {
            FontRenderer adapter = switch (this.customFont.getValue().ordinal()) {
                case 2 -> FontRenderers.monsterrat;
                case 3 -> FontRenderers.sf_medium;
                default -> FontRenderers.modules;
            };
            adapter.drawString(context.method_51448(), str.replace(String.valueOf(class_124.field_1068), ""), (double)x + 0.5, (double)y + 0.5, Color.BLACK.getRGB());
            adapter.drawString(context.method_51448(), str, (double)x, (double)y, color);
            return;
        }
        context.method_51433(LegacyHud.mc.field_1772, str, x, y, color, true);
    }

    private void drawText(class_332 context, String str, int x, int y) {
        if (!this.customFont.getValue().equals(Font.Minecraft)) {
            FontRenderer adapter = switch (this.customFont.getValue().ordinal()) {
                case 2 -> FontRenderers.monsterrat;
                case 3 -> FontRenderers.sf_medium;
                default -> FontRenderers.modules;
            };
            adapter.drawString(context.method_51448(), str.replace(String.valueOf(class_124.field_1068), ""), (double)x + 0.5, (double)y + 0.5, Color.BLACK.getRGB());
            adapter.drawString(context.method_51448(), str, (double)x, (double)y, this.color);
            return;
        }
        context.method_51433(LegacyHud.mc.field_1772, str, x, y, this.color, true);
    }

    private int getStringWidth(String str) {
        switch (this.customFont.getValue().ordinal()) {
            case 2: {
                return (int)FontRenderers.monsterrat.getStringWidth(str);
            }
            case 3: {
                return (int)FontRenderers.sf_medium.getStringWidth(str);
            }
            case 0: {
                return LegacyHud.mc.field_1772.method_1727(str);
            }
        }
        return (int)FontRenderers.modules.getStringWidth(str);
    }

    public void renderGreeter(class_332 context) {
        String text = "Good " + LegacyHud.getTimeOfDay() + LegacyHud.mc.field_1724.method_5477().getString();
        this.drawText(context, text, (int)((float)mc.method_22683().method_4486() / 2.0f - (float)this.getStringWidth(text) / 2.0f + 2.0f), 2);
    }

    public static String getTimeOfDay() {
        int timeOfDay = Calendar.getInstance().get(11);
        if (timeOfDay < 12) {
            return "Morning ";
        }
        if (timeOfDay < 16) {
            return "Afternoon ";
        }
        if (timeOfDay < 21) {
            return "Evening ";
        }
        return "Night ";
    }

    public void renderTotemHUD(class_332 context) {
        int width = mc.method_22683().method_4486();
        int height = mc.method_22683().method_4502();
        int totems = LegacyHud.mc.field_1724.method_31548().field_7547.stream().filter(itemStack -> itemStack.method_7909() == class_1802.field_8288).mapToInt(class_1799::method_7947).sum();
        int u = LegacyHud.mc.field_1724.method_5748();
        int v = Math.min(LegacyHud.mc.field_1724.method_5669(), u);
        if (LegacyHud.mc.field_1724.method_6079().method_7909() == class_1802.field_8288) {
            totems += LegacyHud.mc.field_1724.method_6079().method_7947();
        }
        if (totems > 0) {
            int i = width / 2;
            int y = height - 55 - (LegacyHud.mc.field_1724.method_5869() || v < u ? 10 : 0);
            int x = i - 189 + 180 + 2;
            context.method_51427(totem, x, y);
            context.method_51431(LegacyHud.mc.field_1772, totem, x, y);
            this.drawText(context, "" + totems, 8 + (int)((float)x - (float)this.getStringWidth("" + totems) / 2.0f), y - 7, 0xFFFFFF);
        }
    }

    private static String biome() {
        if (LegacyHud.mc.field_1724 == null || LegacyHud.mc.field_1687 == null) {
            return null;
        }
        class_2960 id = LegacyHud.mc.field_1687.method_30349().method_30530(class_7924.field_41236).method_10221(((class_1959)LegacyHud.mc.field_1687.method_23753(LegacyHud.mc.field_1724.method_24515()).comp_349()));
        if (id == null) {
            return "Unknown";
        }
        return Arrays.stream(id.method_12832().split("_")).map(StringUtils::capitalize).collect(Collectors.joining(" "));
    }

    public void renderArmorHUD(boolean percent, class_332 context) {
        int i = 0;
        int u = LegacyHud.mc.field_1724.method_5748();
        int v = Math.min(LegacyHud.mc.field_1724.method_5669(), u);
        int y = mc.method_22683().method_4502() - 55 - (LegacyHud.mc.field_1724.method_5869() || v < u ? 10 : 0);
        for (class_1799 is : LegacyHud.mc.field_1724.method_31548().field_7548) {
            ++i;
            if (is.method_7960()) continue;
            int x = mc.method_22683().method_4486() / 2 - 90 + (9 - i) * 20 + 2;
            context.method_51427(is, x, y);
            context.method_51431(LegacyHud.mc.field_1772, is, x, y);
            String s = is.method_7947() > 1 ? "" + is.method_7947() : "";
            this.drawText(context, s, x + 19 - 2 - this.getStringWidth(s), y + 9, 0xFFFFFF);
            if (!percent) continue;
            float green = (float)(is.method_7936() - is.method_7919()) / (float)is.method_7936();
            float red = 1.0f - green;
            int dmg = 100 - (int)(red * 100.0f);
            this.drawText(context, "" + dmg, x + 8 - this.getStringWidth("" + dmg) / 2, y - 11, new Color((int)MathUtility.clamp(red * 255.0f, 0.0f, 255.0f), (int)MathUtility.clamp(green * 255.0f, 0.0f, 255.0f), 0).getRGB());
        }
    }

    private static enum Font {
        Minecraft,
        Comfortaa,
        Monsterrat,
        SF;

    }
}

