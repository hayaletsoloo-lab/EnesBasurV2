/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DstFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SrcFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.Pair
 */
package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_124;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3545;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.TextureStorage;

public class ChestCounter
extends HudElement {
    public ChestCounter() {
        super("ChestCounter", 50, 10);
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        class_3545<Integer, Integer> chests = this.getChestCount();
        String str = "Chests: " + String.valueOf(class_124.field_1068) + "S:" + String.valueOf(chests.method_15442()) + " D:" + String.valueOf(chests.method_15441());
        float pX = this.getPosX() > (float)mc.method_22683().method_4486() / 2.0f ? this.getPosX() - FontRenderers.getModulesRenderer().getStringWidth(str) : this.getPosX();
        float f = pX;
        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawRoundedBlur(context.method_51448(), pX, this.getPosY(), FontRenderers.getModulesRenderer().getStringWidth(str) + 21.0f, 13.0f, 3.0f, HudEditor.blurColor.getValue().getColorObject());
            Render2DEngine.drawRect(context.method_51448(), pX + 14.0f, this.getPosY() + 2.0f, 0.5f, 8.0f, new Color(0x44FFFFFF, true));
            Render2DEngine.setupRender();
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
            RenderSystem.setShaderTexture((int)0, (class_2960)TextureStorage.chestIcon);
            Render2DEngine.renderGradientTexture(context.method_51448(), pX + 2.0f, this.getPosY() + 1.0f, 10.0, 10.0, 0.0f, 0.0f, 512.0, 512.0, 512.0, 512.0, HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
            Render2DEngine.endRender();
        }
        FontRenderers.getModulesRenderer().drawString(context.method_51448(), str, (double)(pX + 18.0f), (double)(this.getPosY() + 5.0f), HudEditor.getColor(1).getRGB());
        this.setBounds(pX, this.getPosY(), FontRenderers.getModulesRenderer().getStringWidth(str) + 21.0f, 13.0f);
    }

    public class_3545<Integer, Integer> getChestCount() {
        int singleCount = 0;
        int doubleCount = 0;
        return new class_3545(singleCount, (doubleCount / 2));
    }
}

