/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.RotationAxis
 */
package thunder.hack.features.hud.impl;

import com.google.common.collect.Lists;
import java.awt.Color;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_332;
import net.minecraft.class_7833;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.hud.impl.RadarRewrite;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.math.MathUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.animation.AnimationUtility;

public class CrosshairArrows
extends HudElement {
    public static Setting<Boolean> glow = new Setting<Boolean>("Glow", false);
    private final Setting<Float> width = new Setting<Float>("Height", Float.valueOf(2.28f), Float.valueOf(0.1f), Float.valueOf(5.0f));
    private final Setting<BooleanSettingGroup> down = new Setting<BooleanSettingGroup>("Down", new BooleanSettingGroup(false));
    private final Setting<Float> downHeight = new Setting<Float>("DownHeight", Float.valueOf(3.63f), Float.valueOf(0.1f), Float.valueOf(20.0f)).addToGroup(this.down);
    private final Setting<Float> tracerWidth = new Setting<Float>("Width", Float.valueOf(0.44f), Float.valueOf(0.0f), Float.valueOf(8.0f));
    private final Setting<Integer> xOffset = new Setting<Integer>("TracerRadius", 68, 20, 100);
    private final Setting<Integer> pitchLock = new Setting<Integer>("PitchLock", 42, 0, 90);
    private final Setting<triangleModeEn> triangleMode = new Setting<triangleModeEn>("TracerCMode", triangleModeEn.Astolfo);
    private final Setting<ColorSetting> colorf = new Setting<ColorSetting>("Friend", new ColorSetting(new Color(59392)));
    private final Setting<ColorSetting> colors = new Setting<ColorSetting>("Tracer", new ColorSetting(new Color(0xFFFF00)));
    private float smoothYaw = 0.0f;

    public CrosshairArrows() {
        super("CrosshairArrows", 0, 0);
    }

    @Override
    public void onRender2D(class_332 context) {
        super.onRender2D(context);
        if (CrosshairArrows.fullNullCheck()) {
            return;
        }
        float middleW = ModuleManager.crosshair.getAnimatedPosX();
        float middleH = ModuleManager.crosshair.getAnimatedPosY();
        int color = 0;
        context.method_51448().method_22903();
        context.method_51448().method_46416(middleW, middleH, 0.0f);
        context.method_51448().method_22907(class_7833.field_40714.rotationDegrees(90.0f / Math.abs(90.0f / MathUtility.clamp(CrosshairArrows.mc.field_1724.method_36455(), (float)this.pitchLock.getValue().intValue(), 90.0f)) - 102.0f));
        context.method_51448().method_46416(-middleW, -middleH, 0.0f);
        this.smoothYaw = AnimationUtility.fast(this.smoothYaw, CrosshairArrows.mc.field_1724.method_36454(), 13.0f);
        for (class_1657 e : CrosshairArrows.mc.field_1687.method_18456()) {
            if (e == CrosshairArrows.mc.field_1724) continue;
            context.method_51448().method_22903();
            float yaw = RadarRewrite.getRotations((class_1297)e) - this.smoothYaw;
            context.method_51448().method_46416(middleW, middleH, 0.0f);
            context.method_51448().method_22907(class_7833.field_40718.rotationDegrees(yaw));
            context.method_51448().method_46416(-middleW, -middleH, 0.0f);
            if (Managers.FRIEND.isFriend(e)) {
                color = this.colorf.getValue().getColor();
            } else {
                color = switch (this.triangleMode.getValue().ordinal()) {
                    default -> throw new MatchException(null, null);
                    case 0 -> this.colors.getValue().getColor();
                    case 1 -> Render2DEngine.astolfo(false, 1).getRGB();
                };
            }
            Render2DEngine.drawTracerPointer(context.method_51448(), middleW, middleH - (float)this.xOffset.getValue().intValue(), this.width.getValue().floatValue() * 5.0f, this.tracerWidth.getValue().floatValue(), this.downHeight.getValue().floatValue(), this.down.getValue().isEnabled(), glow.getValue(), color);
            context.method_51448().method_46416(middleW, middleH, 0.0f);
            context.method_51448().method_22907(class_7833.field_40718.rotationDegrees(-yaw));
            context.method_51448().method_46416(-middleW, -middleH, 0.0f);
            context.method_51448().method_22909();
        }
        context.method_51448().method_22909();
    }

    public static enum triangleModeEn {
        Custom,
        Astolfo;

    }
}

