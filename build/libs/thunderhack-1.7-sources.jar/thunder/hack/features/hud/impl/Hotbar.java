/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.item.ItemStack
 */
package thunder.hack.features.hud.impl;

import java.awt.Color;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.gui.windows.WindowsScreen;
import thunder.hack.setting.Setting;
import thunder.hack.utility.render.Render2DEngine;

public class Hotbar
extends HudElement {
    public static final Setting<Mode> lmode = new Setting<Mode>("LeftHandMode", Mode.Merged);

    public Hotbar() {
        super("Hotbar", 0, 0);
    }

    @Override
    public void onRender2D(class_332 context) {
        if (Hotbar.mc.field_1755 instanceof WindowsScreen) {
            return;
        }
        class_746 playerEntity = Hotbar.mc.field_1724;
        if (playerEntity != null) {
            class_4587 matrices = context.method_51448();
            int i = mc.method_22683().method_4486() / 2;
            if (Hotbar.mc.field_1724.method_6079().method_7960()) {
                Render2DEngine.drawHudBase(matrices, i - 90, mc.method_22683().method_4502() - 25, 180.0f, 20.0f, HudEditor.hudRound.getValue().floatValue());
            } else if (lmode.getValue() == Mode.Merged) {
                Render2DEngine.drawHudBase(matrices, i - 111, mc.method_22683().method_4502() - 25, 201.0f, 20.0f, HudEditor.hudRound.getValue().floatValue());
                if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
                    Render2DEngine.drawRect(context.method_51448(), i - 109 + 18, mc.method_22683().method_4502() - 23, 0.5f, 15.0f, new Color(0x44FFFFFF, true));
                } else {
                    Render2DEngine.verticalGradient(matrices, i - 109 + 18, mc.method_22683().method_4502() - 22 + 1 - 4, (float)(i - 108 + 18) - 0.5f, mc.method_22683().method_4502() - 11 + 1 - 4, Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0), HudEditor.textColor.getValue().getColorObject());
                    Render2DEngine.verticalGradient(matrices, i - 109 + 18, mc.method_22683().method_4502() - 11 - 4, (float)(i - 108 + 18) - 0.5f, mc.method_22683().method_4502() - 5, HudEditor.textColor.getValue().getColorObject(), Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0));
                }
            } else {
                Render2DEngine.drawHudBase(matrices, i - 90, mc.method_22683().method_4502() - 25, 180.0f, 20.0f, HudEditor.hudRound.getValue().floatValue());
                Render2DEngine.drawHudBase(matrices, (float)i - 112.5f, mc.method_22683().method_4502() - 25, 20.0f, 20.0f, HudEditor.hudRound.getValue().floatValue());
            }
            Color c = HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry) ? new Color(2081756437, true) : new Color(2083467055, true);
            Render2DEngine.drawRect(matrices, (float)(i - 88) + (float)playerEntity.method_31548().field_7545 * 19.8f, mc.method_22683().method_4502() - 24, 17.0f, 17.0f, HudEditor.hudRound.getValue().floatValue(), 0.7f, c, c, c, c);
        }
    }

    public static void renderHotBarItems(float tickDelta, class_332 context) {
        if (Hotbar.mc.field_1755 instanceof WindowsScreen) {
            return;
        }
        class_746 playerEntity = Hotbar.mc.field_1724;
        if (playerEntity != null) {
            class_4587 matrices = context.method_51448();
            int i = mc.method_22683().method_4486() / 2;
            int o = mc.method_22683().method_4502() - 16 - 3;
            if (!Hotbar.mc.field_1724.method_6079().method_7960()) {
                if (lmode.getValue() == Mode.Merged) {
                    Hotbar.renderHotbarItem(context, i - 109, o - 5, playerEntity.method_6079());
                } else {
                    Hotbar.renderHotbarItem(context, i - 111, o - 5, playerEntity.method_6079());
                }
            }
            for (int m = 0; m < 9; ++m) {
                int n = i - 90 + m * 20 + 2;
                if (m == Hotbar.mc.field_1724.method_31548().field_7545) {
                    Hotbar.renderHotbarItem(context, n, o - 7, (class_1799)playerEntity.method_31548().field_7547.get(m));
                    continue;
                }
                Hotbar.renderHotbarItem(context, n, o - 5, (class_1799)playerEntity.method_31548().field_7547.get(m));
            }
        }
    }

    private static void renderHotbarItem(class_332 context, int i, int j, class_1799 itemStack) {
        if (!itemStack.method_7960()) {
            context.method_51448().method_22903();
            context.method_51448().method_46416((float)(i + 8), (float)(j + 12), 0.0f);
            context.method_51448().method_22905(0.9f, 0.9f, 1.0f);
            context.method_51448().method_46416((float)(-(i + 8)), (float)(-(j + 12)), 0.0f);
            context.method_51427(itemStack, i, j);
            context.method_51431(Hotbar.mc.field_1772, itemStack, i, j);
            context.method_51448().method_22909();
        }
    }

    public static void renderXpBar(int x, class_4587 matrices) {
        mc.method_16011().method_15396("expBar");
        mc.method_16011().method_15407();
        if (Hotbar.mc.field_1724.field_7520 > 0) {
            mc.method_16011().method_15396("expLevel");
            String string = "" + Hotbar.mc.field_1724.field_7520;
            int k = (int)(((float)mc.method_22683().method_4486() - FontRenderers.sf_bold_mini.getStringWidth(string)) / 2.0f);
            int l = mc.method_22683().method_4502() - 31 - 4;
            FontRenderers.sf_bold_mini.drawString(matrices, string, (double)k, (double)l, 8453920);
            mc.method_16011().method_15407();
        }
    }

    public static enum Mode {
        Merged,
        Separately;

    }
}

