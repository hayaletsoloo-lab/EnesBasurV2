/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.command.CommandSource
 *  net.minecraft.util.Formatting
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_3675;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.cmd.args.ModuleArgumentType;
import thunder.hack.features.hud.impl.KeyBinds;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.setting.impl.Bind;

public class BindCommand
extends Command {
    public BindCommand() {
        super("bind");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.then(BindCommand.arg("module", ModuleArgumentType.create()).then(BindCommand.arg("key", StringArgumentType.word()).executes(context -> {
            int key;
            Module module = (Module)context.getArgument("module", Module.class);
            String stringKey = (String)context.getArgument("key", String.class);
            if (stringKey == null) {
                BindCommand.sendMessage(module.getName() + " is bound to " + String.valueOf(class_124.field_1080) + module.getBind().getBind());
                return 1;
            }
            if (stringKey.equalsIgnoreCase("none") || stringKey.equalsIgnoreCase("null")) {
                key = -1;
            } else {
                try {
                    key = class_3675.method_15981((String)("key.keyboard." + stringKey.toLowerCase())).method_1444();
                }
                catch (NumberFormatException e) {
                    BindCommand.sendMessage(ClientSettings.isRu() ? "\u0422\u0430\u043a\u043e\u0439 \u043a\u043d\u043e\u043f\u043a\u0438 \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442!" : "There is no such button");
                    return 1;
                }
            }
            if (key == 0) {
                BindCommand.sendMessage("Unknown key '" + stringKey + "'!");
                return 1;
            }
            module.setBind(key, !stringKey.equals("M") && stringKey.contains("M"), false);
            BindCommand.sendMessage("Bind for " + String.valueOf(class_124.field_1060) + module.getName() + String.valueOf(class_124.field_1068) + " set to " + String.valueOf(class_124.field_1080) + stringKey.toUpperCase());
            return 1;
        })));
        builder.then(BindCommand.literal("list").executes(context -> {
            StringBuilder binds = new StringBuilder("Binds: ");
            for (Module feature : Managers.MODULE.modules) {
                if (Objects.equals(feature.getBind().getBind(), "None")) continue;
                binds.append("\n- ").append(feature.getName()).append(" -> ").append(KeyBinds.getShortKeyName(feature)).append(feature.getBind().isHold() ? "[hold]" : "");
            }
            BindCommand.sendMessage(binds.toString());
            return 1;
        }));
        builder.then(BindCommand.literal("clear").executes(context -> {
            for (Module mod : Managers.MODULE.modules) {
                mod.setBind(new Bind(-1, false, false));
            }
            return 1;
        }));
        builder.then(BindCommand.literal("reset").executes(context -> {
            for (Module mod : Managers.MODULE.modules) {
                mod.setBind(new Bind(-1, false, false));
            }
            BindCommand.sendMessage("Done!");
            return 1;
        }));
    }
}

