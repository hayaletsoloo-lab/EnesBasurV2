/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.DoubleArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.block.Blocks
 *  net.minecraft.command.CommandSource
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$PositionAndOnGround
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Position
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import org.jetbrains.annotations.NotNull;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.client.ClientSettings;

public class VClipCommand
extends Command {
    public VClipCommand() {
        super("vclip");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.then(VClipCommand.literal("down").executes(context -> {
            float y = 0.0f;
            for (int i = 1; i < 255; ++i) {
                if (VClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)VClipCommand.mc.field_1724.method_19538()).method_10069(0, -i, 0)) == class_2246.field_10124.method_9564()) {
                    y = -i - 1;
                    break;
                }
                if (VClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)VClipCommand.mc.field_1724.method_19538()).method_10069(0, -i, 0)) != class_2246.field_9987.method_9564()) continue;
                VClipCommand.sendMessage(String.valueOf(class_124.field_1061) + (ClientSettings.isRu() ? "\u041d\u0435\u043a\u0443\u0434\u0430 \u043a\u043b\u0438\u043f\u0430\u0442\u044c!" : "There's nowhere to clip!"));
                return 1;
            }
            this.clip(y);
            return 1;
        }));
        builder.then(VClipCommand.literal("up").executes(context -> {
            float y = 0.0f;
            for (int i = 4; i < 255; ++i) {
                if (VClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)VClipCommand.mc.field_1724.method_19538()).method_10069(0, i, 0)) != class_2246.field_10124.method_9564()) continue;
                y = i + 1;
                break;
            }
            this.clip(y);
            return 1;
        }));
        builder.then(VClipCommand.arg("count", DoubleArgumentType.doubleArg()).executes(context -> {
            double count = (Double)context.getArgument("count", Double.class);
            try {
                VClipCommand.sendMessage(String.valueOf(class_124.field_1060) + "\u041a\u043b\u0438\u043f\u0430\u0435\u043c\u0441\u044f \u043d\u0430 " + count + " \u0431\u043b\u043e\u043a\u043e\u0432");
                this.clip(count);
            }
            catch (Exception exception) {
                // empty catch block
            }
            return 1;
        }));
        builder.executes(context -> {
            VClipCommand.sendMessage("\u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439 .vclip <\u0447\u0438\u0441\u043b\u043e>");
            return 1;
        });
    }

    private void clip(double b) {
        if (ClientSettings.clipCommandMode.getValue() == ClientSettings.ClipCommandMode.Matrix) {
            int i;
            for (i = 0; i < 10; ++i) {
                VClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(VClipCommand.mc.field_1724.method_23317(), VClipCommand.mc.field_1724.method_23318(), VClipCommand.mc.field_1724.method_23321(), false));
            }
            for (i = 0; i < 10; ++i) {
                VClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(VClipCommand.mc.field_1724.method_23317(), VClipCommand.mc.field_1724.method_23318() + b, VClipCommand.mc.field_1724.method_23321(), false));
            }
        } else {
            VClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(VClipCommand.mc.field_1724.method_23317(), VClipCommand.mc.field_1724.method_23318() + b, VClipCommand.mc.field_1724.method_23321(), false));
        }
        VClipCommand.mc.field_1724.method_5814(VClipCommand.mc.field_1724.method_23317(), VClipCommand.mc.field_1724.method_23318() + b, VClipCommand.mc.field_1724.method_23321());
    }
}

