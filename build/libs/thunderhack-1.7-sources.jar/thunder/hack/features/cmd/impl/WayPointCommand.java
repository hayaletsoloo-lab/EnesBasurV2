/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.IntegerArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  net.minecraft.command.CommandSource
 *  net.minecraft.util.math.BlockPos
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.world.WayPointManager;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.cmd.args.WayPointArgumentType;
import thunder.hack.features.modules.client.ClientSettings;

public class WayPointCommand
extends Command {
    public WayPointCommand() {
        super("waypoint", "waypoints");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.then(WayPointCommand.literal("list").executes(context -> {
            WayPointCommand.sendMessage(ClientSettings.isRu() ? "\u041c\u0435\u0442\u043a\u0438:" : "Waypoints:");
            WayPointCommand.sendMessage(" ");
            Managers.WAYPOINT.getWayPoints().forEach(wp -> WayPointCommand.sendMessage(wp.getName() + " X: " + wp.getX() + " Y: " + wp.getY() + " Z: " + wp.getZ() + " Server: " + wp.getServer() + " Dimension: " + wp.getDimension()));
            return 1;
        }));
        builder.then(WayPointCommand.literal("remove").then(WayPointCommand.arg("name", WayPointArgumentType.create()).executes(context -> {
            WayPointManager.WayPoint wp = (WayPointManager.WayPoint)context.getArgument("name", WayPointManager.WayPoint.class);
            Managers.WAYPOINT.removeWayPoint(wp);
            WayPointCommand.sendMessage((String)(ClientSettings.isRu() ? "\u0423\u0434\u0430\u043b\u0435\u043d\u0430 \u043c\u0435\u0442\u043a\u0430 " : "Deleted waypoint " + wp.getName()));
            return 1;
        })));
        builder.then(WayPointCommand.literal("add").then(((RequiredArgumentBuilder)WayPointCommand.arg("name", StringArgumentType.word()).executes(context -> {
            String name = (String)context.getArgument("name", String.class);
            WayPointManager.WayPoint wp = new WayPointManager.WayPoint((int)WayPointCommand.mc.field_1724.method_23317(), (int)WayPointCommand.mc.field_1724.method_23318(), (int)WayPointCommand.mc.field_1724.method_23321(), name, mc.method_1542() ? "SinglePlayer" : WayPointCommand.mc.method_1562().method_45734().field_3761, WayPointCommand.mc.field_1687.method_27983().method_29177().method_12832());
            Managers.WAYPOINT.addWayPoint(wp);
            WayPointCommand.sendMessage((ClientSettings.isRu() ? "\u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u0430 \u043c\u0435\u0442\u043a\u0430 " + name + " \u0441 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u0430\u043c\u0438" : "Added waypoint " + name + " with coords") + " X: " + (int)WayPointCommand.mc.field_1724.method_23317() + " Y: " + (int)WayPointCommand.mc.field_1724.method_23318() + " Z: " + (int)WayPointCommand.mc.field_1724.method_23321());
            return 1;
        })).then(WayPointCommand.arg("x", IntegerArgumentType.integer()).then(WayPointCommand.arg("y", IntegerArgumentType.integer()).then(WayPointCommand.arg("z", IntegerArgumentType.integer()).executes(context -> {
            String name = (String)context.getArgument("name", String.class);
            class_2338 pos = new class_2338(((Integer)context.getArgument("x", Integer.class)).intValue(), ((Integer)context.getArgument("y", Integer.class)).intValue(), ((Integer)context.getArgument("z", Integer.class)).intValue());
            WayPointManager.WayPoint wp = new WayPointManager.WayPoint(pos.method_10263(), pos.method_10264(), pos.method_10260(), name, mc.method_1542() ? "SinglePlayer" : WayPointCommand.mc.method_1562().method_45734().field_3761, WayPointCommand.mc.field_1687.method_27983().method_29177().method_12832());
            Managers.WAYPOINT.addWayPoint(wp);
            WayPointCommand.sendMessage((ClientSettings.isRu() ? "\u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u0430 \u043c\u0435\u0442\u043a\u0430 " + name + " \u0441 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u0430\u043c\u0438 X: " : "Added waypoint " + name + " with coords") + pos.method_10263() + " Y: " + pos.method_10264() + " Z: " + pos.method_10260());
            return 1;
        }))))));
        builder.executes(context -> {
            WayPointCommand.sendMessage(this.usage());
            return 1;
        });
    }

    String usage() {
        return "waypoint add/remove/list (waypoint add x y z name), (waypoint remove name)";
    }
}

