/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.minecraft.UserApiService
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.client.network.SocialInteractionsManager
 *  net.minecraft.client.session.ProfileKeys
 *  net.minecraft.client.session.Session
 *  net.minecraft.client.session.Session$AccountType
 *  net.minecraft.client.session.report.AbuseReportContext
 *  net.minecraft.client.session.report.ReporterEnvironment
 *  net.minecraft.command.CommandSource
 *  net.minecraft.util.Uuids
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.nio.file.Path;
import java.util.Optional;
import net.minecraft.class_2172;
import net.minecraft.class_320;
import net.minecraft.class_4844;
import net.minecraft.class_5520;
import net.minecraft.class_7569;
import net.minecraft.class_7574;
import net.minecraft.class_7853;
import org.jetbrains.annotations.NotNull;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.injection.accesors.IMinecraftClient;

public class LoginCommand
extends Command {
    public LoginCommand() {
        super("login");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.then(LoginCommand.arg("name", StringArgumentType.word()).executes(context -> {
            this.login((String)context.getArgument("name", String.class));
            LoginCommand.sendMessage((ClientSettings.isRu() ? "\u0410\u043a\u043a\u0430\u0443\u043d\u0442 \u0438\u0437\u043c\u0435\u043d\u0435\u043d \u043d\u0430: " : "Switched account to: ") + mc.method_1548().method_1676());
            return 1;
        }));
        builder.executes(context -> {
            LoginCommand.sendMessage(ClientSettings.isRu() ? "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435: .login <nickname>" : "Usage: .login <nickname>");
            return 1;
        });
    }

    public void login(String name) {
        try {
            this.setSession(new class_320(name, class_4844.method_43344((String)name), "", Optional.empty(), Optional.empty(), class_320.class_321.field_1988));
        }
        catch (Exception exception) {
            LoginCommand.sendMessage((ClientSettings.isRu() ? "\u041d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0438\u043c\u044f! " : "Incorrect username! ") + String.valueOf(exception));
        }
    }

    public void setSession(class_320 session) {
        IMinecraftClient mca = (IMinecraftClient)mc;
        mca.setSessionT(session);
        mc.method_53462().getProperties().clear();
        UserApiService apiService = UserApiService.OFFLINE;
        mca.setUserApiService(apiService);
        mca.setSocialInteractionsManagerT(new class_5520(mc, apiService));
        mca.setProfileKeys(class_7853.method_46532((UserApiService)apiService, (class_320)session, (Path)LoginCommand.mc.field_1697.toPath()));
        mca.setAbuseReportContextT(class_7574.method_44599((class_7569)class_7569.method_44586(), (UserApiService)apiService));
    }
}

