/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.FloatArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.block.Blocks
 *  net.minecraft.command.CommandSource
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket
 *  net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket$Mode
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$PositionAndOnGround
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Position
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2172;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import org.jetbrains.annotations.NotNull;
import thunder.hack.features.cmd.Command;
import thunder.hack.utility.player.InventoryUtility;

public class EClipCommand
extends Command {
    public EClipCommand() {
        super("eclip");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.then(((LiteralArgumentBuilder)EClipCommand.literal("bedrock").executes(context -> {
            this.execute(-((float)EClipCommand.mc.field_1724.method_23318()) - 3.0f);
            return 1;
        })).then(EClipCommand.arg("number", FloatArgumentType.floatArg()).executes(context -> {
            float y = -((float)EClipCommand.mc.field_1724.method_23318()) - 3.0f;
            if (y == 0.0f) {
                y = ((Float)context.getArgument("number", Float.class)).floatValue();
            }
            this.execute(y);
            return 1;
        })));
        builder.then(((LiteralArgumentBuilder)EClipCommand.literal("down").executes(context -> {
            float y = 0.0f;
            for (int i = 1; i < 255; ++i) {
                if (EClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)EClipCommand.mc.field_1724.method_19538()).method_10069(0, -i, 0)) == class_2246.field_10124.method_9564()) {
                    y = -i - 1;
                    break;
                }
                if (EClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)EClipCommand.mc.field_1724.method_19538()).method_10069(0, -i, 0)) != class_2246.field_9987.method_9564()) continue;
                EClipCommand.sendMessage(String.valueOf(class_124.field_1061) + " \u043c\u043e\u0436\u043d\u043e \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u043e\u0434 \u0431\u0435\u0434\u0440\u043e\u043a");
                EClipCommand.sendMessage(String.valueOf(class_124.field_1061) + " eclip bedrock");
                return 1;
            }
            this.execute(y);
            return 1;
        })).then(EClipCommand.arg("number", FloatArgumentType.floatArg()).executes(context -> {
            float y = 0.0f;
            for (int i = 1; i < 255; ++i) {
                if (EClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)EClipCommand.mc.field_1724.method_19538()).method_10069(0, -i, 0)) == class_2246.field_10124.method_9564()) {
                    y = -i - 1;
                    break;
                }
                if (EClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)EClipCommand.mc.field_1724.method_19538()).method_10069(0, -i, 0)) != class_2246.field_9987.method_9564()) continue;
                EClipCommand.sendMessage(String.valueOf(class_124.field_1061) + " \u043c\u043e\u0436\u043d\u043e \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u043e\u0434 \u0431\u0435\u0434\u0440\u043e\u043a");
                EClipCommand.sendMessage(String.valueOf(class_124.field_1061) + " eclip bedrock");
                return 1;
            }
            if (y == 0.0f) {
                y = ((Float)context.getArgument("number", Float.class)).floatValue();
            }
            this.execute(y);
            return 1;
        })));
        builder.then(((LiteralArgumentBuilder)EClipCommand.literal("up").executes(context -> {
            float y = 0.0f;
            for (int i = 4; i < 255; ++i) {
                if (EClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)EClipCommand.mc.field_1724.method_19538()).method_10069(0, i, 0)) != class_2246.field_10124.method_9564()) continue;
                y = i + 1;
                break;
            }
            this.execute(y);
            return 1;
        })).then(EClipCommand.arg("number", FloatArgumentType.floatArg()).executes(context -> {
            float y = 0.0f;
            for (int i = 4; i < 255; ++i) {
                if (EClipCommand.mc.field_1687.method_8320(class_2338.method_49638((class_2374)EClipCommand.mc.field_1724.method_19538()).method_10069(0, i, 0)) != class_2246.field_10124.method_9564()) continue;
                y = i + 1;
                break;
            }
            if (y == 0.0f) {
                y = ((Float)context.getArgument("number", Float.class)).floatValue();
            }
            this.execute(y);
            return 1;
        })));
    }

    private void execute(float y) {
        int elytra = InventoryUtility.findItemInInventory(class_1802.field_8833).slot();
        if (elytra == -1) {
            EClipCommand.sendMessage(String.valueOf(class_124.field_1061) + "\u0432\u0430\u043c \u043d\u0443\u0436\u043d\u044b \u044d\u043b\u0438\u0442\u0440\u044b \u0432 \u0438\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u0435");
            return;
        }
        if (elytra != -2) {
            EClipCommand.mc.field_1761.method_2906(0, elytra, 1, class_1713.field_7790, (class_1657)EClipCommand.mc.field_1724);
            EClipCommand.mc.field_1761.method_2906(0, 6, 1, class_1713.field_7790, (class_1657)EClipCommand.mc.field_1724);
        }
        EClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(EClipCommand.mc.field_1724.method_23317(), EClipCommand.mc.field_1724.method_23318(), EClipCommand.mc.field_1724.method_23321(), false));
        EClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(EClipCommand.mc.field_1724.method_23317(), EClipCommand.mc.field_1724.method_23318(), EClipCommand.mc.field_1724.method_23321(), false));
        EClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)EClipCommand.mc.field_1724, class_2848.class_2849.field_12982));
        EClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(EClipCommand.mc.field_1724.method_23317(), EClipCommand.mc.field_1724.method_23318() + (double)y, EClipCommand.mc.field_1724.method_23321(), false));
        EClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)EClipCommand.mc.field_1724, class_2848.class_2849.field_12982));
        if (elytra != -2) {
            EClipCommand.mc.field_1761.method_2906(0, 6, 1, class_1713.field_7790, (class_1657)EClipCommand.mc.field_1724);
            EClipCommand.mc.field_1761.method_2906(0, elytra, 1, class_1713.field_7790, (class_1657)EClipCommand.mc.field_1724);
        }
        EClipCommand.mc.field_1724.method_5814(EClipCommand.mc.field_1724.method_23317(), EClipCommand.mc.field_1724.method_23318() + (double)y, EClipCommand.mc.field_1724.method_23321());
    }
}

