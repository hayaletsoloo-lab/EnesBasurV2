/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.command.CommandSource
 *  net.minecraft.world.GameMode
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_1934;
import net.minecraft.class_2172;
import thunder.hack.features.cmd.Command;

public class GamemodeCommand
extends Command {
    public GamemodeCommand() {
        super("gamemode", "gm");
    }

    @Override
    public void executeBuild(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(GamemodeCommand.arg("mode", StringArgumentType.greedyString()).executes(context -> {
            String mode;
            switch (mode = (String)context.getArgument("mode", String.class)) {
                case "survival": 
                case "0": {
                    GamemodeCommand.mc.field_1761.method_2907(class_1934.field_9215);
                }
                case "creative": 
                case "1": {
                    GamemodeCommand.mc.field_1761.method_2907(class_1934.field_9220);
                }
                case "spectator": 
                case "2": {
                    GamemodeCommand.mc.field_1761.method_2907(class_1934.field_9219);
                }
                case "adventure": 
                case "3": {
                    GamemodeCommand.mc.field_1761.method_2907(class_1934.field_9216);
                }
            }
            return 1;
        }));
    }
}

