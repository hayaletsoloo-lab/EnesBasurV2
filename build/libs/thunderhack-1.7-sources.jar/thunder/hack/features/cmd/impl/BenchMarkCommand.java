/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.command.CommandSource
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.Vec3d
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.utility.world.ExplosionUtility;

public class BenchMarkCommand
extends Command {
    public BenchMarkCommand() {
        super("benchmark");
    }

    @Override
    public void executeBuild(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            new Thread(() -> {
                long time = System.currentTimeMillis();
                class_2338 playerPos = class_2338.method_49638((class_2374)BenchMarkCommand.mc.field_1724.method_19538());
                int r = 6;
                for (int x = playerPos.method_10263() - r; x <= playerPos.method_10263() + r; ++x) {
                    for (int y = playerPos.method_10264() - r; y <= playerPos.method_10264() + r; ++y) {
                        for (int z = playerPos.method_10260() - r; z <= playerPos.method_10260() + r; ++z) {
                            float f = ExplosionUtility.getExplosionDamage(new class_243((double)x, (double)y, (double)z), (class_1657)BenchMarkCommand.mc.field_1724, false);
                        }
                    }
                }
                time = System.currentTimeMillis() - time;
                int score = (int)(216.0f / (float)time * 10000.0f);
                BenchMarkCommand.sendMessage((ClientSettings.isRu() ? "\u0422\u0432\u043e\u0439 CPU \u043d\u0430\u0431\u0440\u0430\u043b: " : "Your CPU score: ") + String.valueOf(class_124.field_1080) + score);
            }).start();
            return 1;
        });
    }
}

