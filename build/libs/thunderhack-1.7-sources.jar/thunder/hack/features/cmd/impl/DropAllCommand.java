/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.command.CommandSource
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket
 *  net.minecraft.screen.slot.SlotActionType
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_2172;
import net.minecraft.class_2596;
import net.minecraft.class_2815;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.features.cmd.Command;

public class DropAllCommand
extends Command {
    public DropAllCommand() {
        super("dropall", "drop");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.then(DropAllCommand.literal("legit").executes(context -> {
            Managers.ASYNC.run(() -> {
                for (int i = 5; i <= 45; ++i) {
                    DropAllCommand.mc.field_1761.method_2906(DropAllCommand.mc.field_1724.field_7512.field_7763, i, 1, class_1713.field_7795, (class_1657)DropAllCommand.mc.field_1724);
                    try {
                        Thread.sleep(70L);
                        continue;
                    }
                    catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
                DropAllCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2815(DropAllCommand.mc.field_1724.field_7512.field_7763));
            }, 1L);
            DropAllCommand.sendMessage("ok");
            return 1;
        }));
        builder.executes(context -> {
            for (int i = 5; i <= 45; ++i) {
                DropAllCommand.mc.field_1761.method_2906(DropAllCommand.mc.field_1724.field_7512.field_7763, i, 1, class_1713.field_7795, (class_1657)DropAllCommand.mc.field_1724);
            }
            DropAllCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2815(DropAllCommand.mc.field_1724.field_7512.field_7763));
            DropAllCommand.sendMessage("ok");
            return 1;
        });
    }
}

