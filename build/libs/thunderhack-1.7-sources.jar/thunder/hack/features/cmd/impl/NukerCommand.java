/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.block.Block
 *  net.minecraft.command.CommandSource
 *  net.minecraft.registry.Registries
 *  net.minecraft.util.Formatting
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2248;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.cmd.args.SearchArgumentType;
import thunder.hack.features.modules.client.ClientSettings;

public class NukerCommand
extends Command {
    public NukerCommand() {
        super("nuker");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.then(NukerCommand.literal("reset").executes(context -> {
            ModuleManager.nuker.selectedBlocks.getValue().clear();
            NukerCommand.sendMessage(ClientSettings.isRu() ? "\u0412\u0441\u0435 \u0431\u043b\u043e\u043a\u0438 \u0431\u044b\u043b\u0438 \u0443\u0434\u0430\u043b\u0435\u043d\u044b!" : "Nuker got reset!");
            return 1;
        }));
        builder.then(NukerCommand.literal("add").then(NukerCommand.arg("block", SearchArgumentType.create()).executes(context -> {
            String blockName = (String)context.getArgument("block", String.class);
            class_2248 result = NukerCommand.getRegisteredBlock(blockName);
            if (result != null) {
                ModuleManager.nuker.selectedBlocks.getValue().add(result);
                NukerCommand.sendMessage(String.valueOf(class_124.field_1060) + blockName + (ClientSettings.isRu() ? " \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0432 Nuker" : " added to Nuker"));
            } else {
                NukerCommand.sendMessage(String.valueOf(class_124.field_1061) + (ClientSettings.isRu() ? "\u0422\u0430\u043a\u043e\u0433\u043e \u0431\u043b\u043e\u043a\u0430 \u043d\u0435\u0442!" : "There is no such block!"));
            }
            return 1;
        })));
        builder.then(NukerCommand.literal("del").then(NukerCommand.arg("block", SearchArgumentType.create()).executes(context -> {
            String blockName = (String)context.getArgument("block", String.class);
            class_2248 result = NukerCommand.getRegisteredBlock(blockName);
            if (result != null) {
                ModuleManager.nuker.selectedBlocks.getValue().remove(blockName);
                NukerCommand.sendMessage(String.valueOf(class_124.field_1060) + blockName + (ClientSettings.isRu() ? " \u0443\u0434\u0430\u043b\u0435\u043d \u0438\u0437 Nuker" : " removed from Nuker"));
            } else {
                NukerCommand.sendMessage(String.valueOf(class_124.field_1061) + (ClientSettings.isRu() ? "\u0422\u0430\u043a\u043e\u0433\u043e \u0431\u043b\u043e\u043a\u0430 \u043d\u0435\u0442!" : "There is no such block!"));
            }
            return 1;
        })));
        builder.executes(context -> {
            if (ModuleManager.nuker.selectedBlocks.getValue().getItemsById().isEmpty()) {
                NukerCommand.sendMessage("Nuker list empty");
            } else {
                StringBuilder f = new StringBuilder("Nuker list: ");
                for (String name : ModuleManager.nuker.selectedBlocks.getValue().getItemsById()) {
                    try {
                        f.append(name).append(", ");
                    }
                    catch (Exception exception) {}
                }
                NukerCommand.sendMessage(f.toString());
            }
            return 1;
        });
    }

    public static class_2248 getRegisteredBlock(String blockName) {
        for (class_2248 block : class_7923.field_41175) {
            if (!block.method_9539().replace("block.minecraft.", "").equalsIgnoreCase(blockName.replace("block.minecraft.", ""))) continue;
            return block;
        }
        return null;
    }
}

