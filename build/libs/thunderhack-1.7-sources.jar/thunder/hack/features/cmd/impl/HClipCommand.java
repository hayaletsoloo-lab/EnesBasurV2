/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.DoubleArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.command.CommandSource
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$PositionAndOnGround
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.math.MathHelper
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;
import thunder.hack.features.cmd.Command;

public class HClipCommand
extends Command {
    public HClipCommand() {
        super("hclip");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.then(HClipCommand.literal("s").executes(context -> {
            double x = -((double)class_3532.method_15374((float)(HClipCommand.mc.field_1724.method_36454() * ((float)Math.PI / 180))) * 0.8);
            double z = (double)class_3532.method_15362((float)(HClipCommand.mc.field_1724.method_36454() * ((float)Math.PI / 180))) * 0.8;
            for (int i = 0; i < 10; ++i) {
                HClipCommand.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(HClipCommand.mc.field_1724.method_23317() + x, HClipCommand.mc.field_1724.method_23318(), HClipCommand.mc.field_1724.method_23321() + z, false));
            }
            HClipCommand.mc.field_1724.method_5814(HClipCommand.mc.field_1724.method_23317() + x, HClipCommand.mc.field_1724.method_23318(), HClipCommand.mc.field_1724.method_23321() + z);
            return 1;
        }));
        builder.then(HClipCommand.arg("count", DoubleArgumentType.doubleArg()).executes(context -> {
            double speed = (Double)context.getArgument("count", Double.class);
            try {
                HClipCommand.sendMessage(String.valueOf(class_124.field_1060) + "\u043a\u043b\u0438\u043f\u0430\u0435\u043c\u0441\u044f \u043d\u0430  " + speed + " \u0431\u043b\u043e\u043a\u043e\u0432.");
                HClipCommand.mc.field_1724.method_5814(HClipCommand.mc.field_1724.method_23317() - (double)class_3532.method_15374((float)(HClipCommand.mc.field_1724.method_36454() * ((float)Math.PI / 180))) * speed, HClipCommand.mc.field_1724.method_23318(), HClipCommand.mc.field_1724.method_23321() + (double)class_3532.method_15362((float)(HClipCommand.mc.field_1724.method_36454() * ((float)Math.PI / 180))) * speed);
            }
            catch (Exception exception) {
                // empty catch block
            }
            return 1;
        }));
        builder.executes(context -> {
            HClipCommand.sendMessage("\u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439 .hclip <\u0447\u0438\u0441\u043b\u043e>, .hclip s");
            return 1;
        });
    }
}

