/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  net.minecraft.command.CommandSource
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import org.jetbrains.annotations.NotNull;
import thunder.hack.features.cmd.Command;
import thunder.hack.features.modules.client.ClientSettings;

public class GetNbtCommand
extends Command {
    public GetNbtCommand() {
        super("nbt", "getnbt");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            GetNbtCommand.sendMessage(GetNbtCommand.mc.field_1724.method_6047().method_57353() != null ? GetNbtCommand.mc.field_1724.method_6047().method_57353().toString() : (ClientSettings.isRu() ? "\u0423 \u044d\u0442\u043e\u0433\u043e \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430 \u043d\u0435\u0442 nbt \u0442\u0435\u0433\u043e\u0432!" : "This item don't contains nbt tags!"));
            return 1;
        });
    }
}

