/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.CommandDispatcher
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.resource.language.I18n
 *  net.minecraft.command.CommandRegistryAccess
 *  net.minecraft.command.CommandSource
 *  net.minecraft.registry.BuiltinRegistries
 *  net.minecraft.registry.RegistryWrapper$WrapperLookup
 *  net.minecraft.server.command.CommandManager
 *  net.minecraft.text.Text
 *  org.jetbrains.annotations.NotNull
 */
package thunder.hack.features.cmd;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1074;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7157;
import net.minecraft.class_7225;
import net.minecraft.class_7887;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.manager.client.CommandManager;

public abstract class Command {
    protected static final class_7157 REGISTRY_ACCESS = net.minecraft.class_2170.method_46732((class_7225.class_7874)class_7887.method_46817());
    protected static final class_310 mc = class_310.method_1551();
    protected final List<String> names;
    private final String description;

    public Command(String ... names) {
        this.names = Arrays.asList(names);
        this.description = "descriptions.commands." + this.names.get(0);
    }

    public abstract void executeBuild(LiteralArgumentBuilder<class_2172> var1);

    public static void sendMessage(String message) {
        if (Command.mc.field_1724 == null) {
            return;
        }
        Command.mc.field_1724.method_43496(class_2561.method_30163((String)(CommandManager.getClientMessage() + " " + message)));
    }

    @NotNull
    protected static <T> RequiredArgumentBuilder<class_2172, T> arg(String name, ArgumentType<T> type) {
        return RequiredArgumentBuilder.argument((String)name, type);
    }

    @NotNull
    protected static LiteralArgumentBuilder<class_2172> literal(String name) {
        return LiteralArgumentBuilder.literal((String)name);
    }

    public void register(CommandDispatcher<class_2172> dispatcher) {
        for (String name : this.names) {
            LiteralArgumentBuilder builder = LiteralArgumentBuilder.literal((String)name);
            this.executeBuild((LiteralArgumentBuilder<class_2172>)builder);
            dispatcher.register(builder);
        }
    }

    public String getName() {
        return this.names.get(0);
    }

    public String getAliases() {
        return String.join((CharSequence)", ", this.names.stream().filter(n -> !n.equals(this.names.get(0))).toList());
    }

    public String getDescription() {
        return class_1074.method_4662((String)(Object)this.description, (Object[])new Object[0]);
    }
}

